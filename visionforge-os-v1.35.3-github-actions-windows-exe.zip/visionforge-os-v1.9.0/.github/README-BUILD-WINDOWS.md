# Gerar o instalador `.exe` do VisionForge OS

Este projeto possui um workflow do GitHub Actions que compila o Desktop Electron em um runner Windows e gera um instalador NSIS `.exe`.

## Estrutura obrigatória do repositório

O conteúdo desta pasta `visionforge-os-v1.9.0` deve ser a **raiz do repositório GitHub**. Não coloque `visionforge-os-v1.9.0` dentro de outra pasta.

```text
visionforge-os.php
includes/
desktop-app/
.github/
└── workflows/
    └── build-windows.yml
```

## Build manual

1. Crie um repositório no GitHub.
2. Envie o conteúdo de `visionforge-os-v1.9.0` para a raiz do repositório.
3. Abra **Actions**.
4. Selecione **Build VisionForge OS Desktop (Windows)**.
5. Clique em **Run workflow**.
6. Aguarde o job `Build Windows installer` terminar.
7. No final do workflow, abra **Artifacts**.
8. Baixe `VisionForge-OS-Windows-Installer`.

Dentro dele estará o instalador:

```text
VisionForge-OS-Setup-0.16.0.exe
```

## Criar uma Release automaticamente

Quando quiser publicar uma versão no GitHub Releases, crie uma tag no formato:

```text
desktop-v0.16.0
```

O workflow fará o build e anexará o `.exe` à Release.

## Por que funciona sem Node.js no computador do usuário?

Node.js e npm são usados somente pelo runner do GitHub durante a compilação. O Electron Builder empacota o aplicativo e o runtime Electron no instalador final.

O alvo configurado é **NSIS x64**, portanto o resultado é um instalador Windows `.exe`.
