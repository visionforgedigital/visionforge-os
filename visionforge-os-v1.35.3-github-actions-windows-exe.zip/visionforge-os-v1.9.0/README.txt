VisionForge OS v1.34.7

DESKTOP 0.13.0 — sessão, conta, permissões e sincronização

- O VisionForge Web continua sendo o sistema oficial e usa o banco MySQL.
- O Desktop é um aplicativo Electron independente, conectado pela API /wp-json/vfos/v1/.
- SQLite local mantém registros e fila de alterações para trabalho offline.
- Arquivos podem ser mantidos localmente e enviados quando a conexão retornar.
- Conflitos não são sobrescritos silenciosamente.
- A tela Minha conta mostra servidor, pendências, conflitos e permissões reais do usuário.
- O Desktop respeita as permissões do WordPress/VFOS_Team.
- A aba Aplicativo do WordPress continua oferecendo o download do pacote Desktop.
