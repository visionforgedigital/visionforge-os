jQuery(function($){
  let proposal=null;

  function esc(s){return $('<div>').text(s==null?'':String(s)).html();}
  function md(s){
    s=esc(s||'');
    s=s.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>');
    s=s.replace(/^### (.+)$/gm,'<h4>$1</h4>').replace(/^## (.+)$/gm,'<h3>$1</h3>').replace(/^# (.+)$/gm,'<h2>$1</h2>');
    s=s.replace(/^\s*[-•]\s+(.+)$/gm,'<li>$1</li>').replace(/(<li>.*<\/li>)/gs,'<ul>$1</ul>');
    return s.replace(/\n/g,'<br>');
  }
  function scrollChat(panel){
    const el=panel.find('.vfos-ai-conversation')[0];if(el)el.scrollTop=el.scrollHeight;
  }
  function messageHtml(role,text,meta){
    const who=role==='user'?'Você':'VisionForge AI';
    const avatar=role==='user'?'EU':'✦';
    return '<div class="vfos-chat-message is-'+role+'"><div class="vfos-chat-avatar">'+avatar+'</div><div class="vfos-chat-bubble"><div class="vfos-chat-who"><strong>'+who+'</strong>'+(meta?'<small>'+esc(meta)+'</small>':'')+'</div><div class="vfos-chat-text">'+(role==='assistant'?md(text):esc(text).replace(/\n/g,'<br>'))+'</div></div></div>';
  }
  function proposalHtml(p){
    if(!p||!p.action)return '';
    const labels={propor_criar_lead:'Novo lead',propor_criar_cliente:'Novo cliente',propor_criar_projeto:'Novo projeto',propor_criar_tarefa:'Nova tarefa',propor_criar_compromisso:'Novo compromisso',propor_criar_orcamento:'Novo orçamento',propor_criar_contrato:'Novo contrato',propor_criar_lancamento_financeiro:'Novo lançamento financeiro',propor_registrar_recebimento:'Novo recebimento',propor_atualizar_status_projeto:'Atualizar projeto',propor_atualizar_status_tarefa:'Atualizar tarefa'};
    let rows='';Object.keys(p.args||{}).forEach(k=>{if(p.args[k]!==''&&p.args[k]!=null){let v=String(p.args[k]);if(v.length>700)v=v.slice(0,700)+'…';rows+='<div><span>'+esc(k.replaceAll('_',' '))+'</span><strong>'+esc(v)+'</strong></div>';}});
    const packed=encodeURIComponent(JSON.stringify(p));return '<div class="vfos-proposal" data-proposal="'+esc(packed)+'"><div class="vfos-proposal-head"><div><span class="vfos-kicker">AÇÃO PREPARADA</span><h3>'+esc(labels[p.action]||'Ação da IA')+'</h3></div><span class="vfos-status">Confirmação necessária</span></div><div class="vfos-proposal-data">'+rows+'</div><div class="vfos-proposal-actions"><button type="button" class="button button-primary vfos-btn vfos-ai-confirm">Confirmar ação</button><button type="button" class="button vfos-ai-cancel">Cancelar</button></div></div>';
  }
  function appendAssistant(panel,text,meta,p){
    panel.find('.vfos-ai-welcome').remove();
    const wrap=$(messageHtml('assistant',text,meta));
    if(p)wrap.find('.vfos-chat-bubble').append(proposalHtml(p));
    panel.find('.vfos-ai-conversation').append(wrap);scrollChat(panel);
  }
  function appendUser(panel,text){
    panel.find('.vfos-ai-welcome').remove();
    panel.find('.vfos-ai-conversation').append(messageHtml('user',text,''));scrollChat(panel);
  }
  function typing(panel){
    const el=$('<div class="vfos-chat-message is-assistant vfos-typing"><div class="vfos-chat-avatar">✦</div><div class="vfos-chat-bubble"><div class="vfos-chat-who"><strong>VisionForge AI</strong><small>Analisando…</small></div><div class="vfos-typing-dots"><i></i><i></i><i></i></div></div></div>');
    panel.find('.vfos-ai-conversation').append(el);scrollChat(panel);return el;
  }
  function loadHistory(panel){
    const conv=panel.attr('data-conversation-id'),client=panel.data('client-id')||0;if(!conv)return;
    $.post(VFOS.ajax,{action:'vfos_ai_history',nonce:VFOS.nonce,conversation_id:conv,client_id:client}).done(r=>{
      if(!r.success||!r.data.messages||!r.data.messages.length)return;
      const box=panel.find('.vfos-ai-conversation').empty();
      r.data.messages.forEach(m=>{
        box.append(messageHtml('user',m.prompt,''));
        let p=null;try{p=m.proposal?JSON.parse(m.proposal):null;}catch(e){}
        const msg=$(messageHtml('assistant',m.response,(m.provider||'IA')+(m.model?' · '+m.model:'')));
        if(p)msg.find('.vfos-chat-bubble').append(proposalHtml(p));
        box.append(msg);
      });scrollChat(panel);
    });
  }
  $('.vfos-ai-panel').each(function(){loadHistory($(this));});

  function aiRequest(panel){
    const input=panel.find('#vfos-ai-prompt'),button=panel.find('#vfos-ai-send'),text=input.val();
    if(!text||!text.trim()||button.prop('disabled'))return;
    input.val('').trigger('input');appendUser(panel,text.trim());proposal=null;
    button.prop('disabled',true).addClass('is-loading').find('span').text('Enviando');
    const t=typing(panel);
    $.post(VFOS.ajax,{
      action:'vfos_ai_ask',nonce:VFOS.nonce,prompt:text.trim(),provider:panel.find('#vfos-ai-provider').val(),
      client_id:panel.data('client-id')||0,conversation_id:panel.attr('data-conversation-id')||''
    }).done(r=>{
      t.remove();
      if(r.success){
        if(r.data.conversation_id)panel.attr('data-conversation-id',r.data.conversation_id);
        proposal=r.data.proposal||null;
        appendAssistant(panel,r.data.text||'',(r.data.provider_label||'IA')+' · '+(r.data.model||''),proposal);
      }else appendAssistant(panel,'Não consegui concluir: '+r.data,'Erro',null);
    }).fail(()=>{t.remove();appendAssistant(panel,'Não foi possível concluir a solicitação. Verifique a conexão com a IA e tente novamente.','Erro',null);})
    .always(()=>button.prop('disabled',false).removeClass('is-loading').find('span').text('Enviar'));
  }

  $(document).on('click','#vfos-ai-send',function(){aiRequest($(this).closest('.vfos-ai-panel'));});
  $(document).on('keydown','#vfos-ai-prompt',function(e){
    if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();aiRequest($(this).closest('.vfos-ai-panel'));}
  });
  $(document).on('click','.vfos-ai-suggestions button',function(){
    const panel=$(this).closest('.vfos-ai-panel');panel.find('#vfos-ai-prompt').val($(this).text());aiRequest(panel);
  });
  $(document).on('click','#vfos-ai-new-chat',function(){
    const panel=$(this).closest('.vfos-ai-panel'),id=(window.crypto&&window.crypto.randomUUID)?window.crypto.randomUUID():'chat-'+Date.now()+'-'+Math.random().toString(36).slice(2);
    panel.attr('data-conversation-id',id);proposal=null;
    panel.find('.vfos-ai-conversation').html('<div class="vfos-ai-welcome"><div class="vfos-ai-brand-orb large">✦</div><h3>Novo chat</h3><p>Comece um novo assunto. O histórico anterior continua salvo.</p></div>');
    panel.find('#vfos-ai-prompt').val('').focus();
  });
  $(document).on('click','.vfos-ai-cancel',function(){proposal=null;$(this).closest('.vfos-proposal').replaceWith('<div class="vfos-action-cancelled">Ação cancelada.</div>');});
  $(document).on('click','.vfos-ai-confirm',function(){
    const b=$(this),card=b.closest('.vfos-proposal');let p=null;
    try{p=JSON.parse(decodeURIComponent(card.attr('data-proposal')||''));}catch(e){p=proposal;}
    if(!p)return;
    b.prop('disabled',true).text('Executando...');
    $.post(VFOS.ajax,{action:'vfos_ai_execute',nonce:VFOS.nonce,proposal:JSON.stringify(p)}).done(r=>{
      if(r.success){card.replaceWith('<div class="vfos-action-success">✓ '+esc(r.data.message)+'</div>');proposal=null;}
      else{b.prop('disabled',false).text('Confirmar ação');alert(r.data);}
    }).fail(()=>{b.prop('disabled',false).text('Confirmar ação');alert('Não foi possível executar a ação.');});
  });
  $(document).on('click','.vfos-ai-test',function(){const b=$(this),r=$('#vfos-test-result'),provider=b.data('provider');b.prop('disabled',true);r.text(' Testando '+provider+'...');$.post(VFOS.ajax,{action:'vfos_ai_test',nonce:VFOS.nonce,provider:provider}).done(x=>r.text(x.success?' ✓ '+x.data:' ✕ '+x.data)).fail(()=>r.text(' ✕ Falha na conexão.')).always(()=>b.prop('disabled',false));});
});

document.addEventListener('click',function(e){
  if(e.target && e.target.classList.contains('vfos-add-template-item')){
    var wrap=document.getElementById('vfos-template-items'); if(!wrap)return;
    var i=wrap.querySelectorAll('.vfos-template-item').length;
    var row=document.createElement('div'); row.className='vfos-template-item';
    row.innerHTML='<span class="vfos-drag">⋮⋮</span><label>Item<input name="items['+i+'][title]" placeholder="Ex.: Criar primeira versão"></label><label>Tipo<select name="items['+i+'][item_type]"><option value="task">Tarefa</option><option value="milestone">Etapa</option><option value="approval">Aprovação</option></select></label><label>Dia +<input type="number" min="0" name="items['+i+'][day_offset]" value="0"></label><label>Prioridade<select name="items['+i+'][priority]"><option value="low">Baixa</option><option value="normal" selected>Normal</option><option value="high">Alta</option><option value="urgent">Urgente</option></select></label><label class="vfos-grow">Descrição<input name="items['+i+'][description]"></label><button type="button" class="button vfos-remove-template-item">×</button>';
    wrap.appendChild(row);
  }
  if(e.target && e.target.classList.contains('vfos-remove-template-item')){
    var row=e.target.closest('.vfos-template-item'); if(row)row.remove();
  }
});

(function(){
  function money(v){return Number(v||0).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function quoteCalc(){
    var wrap=document.getElementById('vfos-quote-items'); if(!wrap)return;
    var subtotal=0;
    wrap.querySelectorAll('.vfos-quote-item').forEach(function(row){
      var qty=parseFloat((row.querySelector('.vfos-item-qty')||{}).value)||0;
      var price=parseFloat((row.querySelector('.vfos-item-price')||{}).value)||0;
      var total=qty*price; subtotal+=total;
      var b=row.querySelector('.vfos-item-total b');if(b)b.textContent=money(total);
    });
    var type=(document.getElementById('vfos-discount-type')||{}).value||'fixed';
    var val=parseFloat((document.getElementById('vfos-discount-value')||{}).value)||0;
    var discount=type==='percent'?subtotal*Math.min(100,val)/100:Math.min(subtotal,val);
    var total=Math.max(0,subtotal-discount);
    var s=document.getElementById('vfos-quote-subtotal'),t=document.getElementById('vfos-quote-total'),d=document.getElementById('vfos-quote-discount');
    if(s)s.textContent='R$ '+money(subtotal);if(d)d.textContent='R$ '+money(discount);if(t)t.textContent='R$ '+money(total);
  }
  document.addEventListener('input',function(e){
    if(e.target.matches('.vfos-item-qty,.vfos-item-price,#vfos-discount-value'))quoteCalc();
  });
  document.addEventListener('change',function(e){
    if(e.target.matches('#vfos-discount-type'))quoteCalc();
    if(e.target.matches('.vfos-quote-service')){
      var opt=e.target.options[e.target.selectedIndex],row=e.target.closest('.vfos-quote-item');
      if(opt && row && opt.value!=='0'){
        var title=row.querySelector('.vfos-item-title'),price=row.querySelector('.vfos-item-price'),desc=row.querySelector('.vfos-item-description');
        if(title && !title.value)title.value=opt.dataset.name||'';
        if(price)price.value=opt.dataset.price||0;
        if(desc && !desc.value)desc.value=opt.dataset.description||'';
        quoteCalc();
      }
    }
  });
  document.addEventListener('click',function(e){
    if(e.target.matches('.vfos-add-quote-item')){
      var wrap=document.getElementById('vfos-quote-items');if(!wrap)return;
      var first=wrap.querySelector('.vfos-quote-item');if(!first)return;
      var indexes=[].slice.call(wrap.querySelectorAll('.vfos-quote-item input[name],.vfos-quote-item select[name]')).map(function(el){var m=(el.name||'').match(/items\[(\d+)\]/);return m?parseInt(m[1],10):-1;});
      var i=(indexes.length?Math.max.apply(null,indexes):-1)+1,row=first.cloneNode(true);
      row.querySelectorAll('input,select').forEach(function(el){
        if(el.name)el.name=el.name.replace(/items\[\d+\]/,'items['+i+']');
        if(el.classList.contains('vfos-item-title')||el.classList.contains('vfos-item-description'))el.value='';
        if(el.classList.contains('vfos-item-qty'))el.value='1';
        if(el.classList.contains('vfos-item-price'))el.value='0';
        if(el.classList.contains('vfos-quote-service'))el.value='0';
      });
      var b=row.querySelector('.vfos-item-total b');if(b)b.textContent='0,00';wrap.appendChild(row);wrap.querySelectorAll('.vfos-quote-item-number').forEach(function(n,k){n.textContent=k+1;});quoteCalc();
    }
    if(e.target.matches('.vfos-remove-quote-item')){
      var wrap=document.getElementById('vfos-quote-items'),rows=wrap?wrap.querySelectorAll('.vfos-quote-item'):[];
      if(rows.length>1){e.target.closest('.vfos-quote-item').remove();wrap.querySelectorAll('.vfos-quote-item-number').forEach(function(n,k){n.textContent=k+1;});quoteCalc();}
    }
  });
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',quoteCalc);else quoteCalc();
})();

/* v1.1 — Kanban interativo */
(function(){
  var dragging=null;
  document.addEventListener('dragstart',function(e){
    var card=e.target.closest('.vfos-kanban-card');
    if(!card)return;
    dragging=card;card.classList.add('is-dragging');
    if(e.dataTransfer){e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',card.dataset.task||'');}
  });
  document.addEventListener('dragend',function(e){
    var card=e.target.closest('.vfos-kanban-card');if(card)card.classList.remove('is-dragging');
    document.querySelectorAll('.vfos-kanban-col').forEach(function(c){c.classList.remove('is-over');});
    dragging=null;
  });
  document.addEventListener('dragover',function(e){
    var col=e.target.closest('.vfos-kanban-col');if(!col||!dragging)return;
    e.preventDefault();document.querySelectorAll('.vfos-kanban-col').forEach(function(c){c.classList.remove('is-over');});col.classList.add('is-over');
  });
  document.addEventListener('drop',function(e){
    var col=e.target.closest('.vfos-kanban-col'),board=e.target.closest('.vfos-kanban');
    if(!col||!board||!dragging)return;e.preventDefault();
    col.classList.remove('is-over');
    var drop=col.querySelector('.vfos-kanban-drop');if(drop)drop.appendChild(dragging);
    var fd=new FormData();fd.append('action','vfos_task_status');fd.append('task_id',dragging.dataset.task);fd.append('status',col.dataset.status);fd.append('nonce',board.dataset.nonce);
    fetch(window.ajaxurl,{method:'POST',credentials:'same-origin',body:fd})
      .then(function(r){return r.json();})
      .then(function(r){
        if(!r.success){alert((r.data&&r.data.message)||'Não foi possível mover a tarefa.');location.reload();return;}
        board.querySelectorAll('.vfos-kanban-col').forEach(function(c){
          var count=c.querySelectorAll('.vfos-kanban-card').length,el=c.querySelector('header span');if(el)el.textContent=count;
        });
      }).catch(function(){location.reload();});
  });
})();

/* v1.9 — permissões granulares e apresentação */
(function(){
  document.addEventListener('click',function(e){
    if(e.target.matches('.vfos-perm-toggle')){
      e.preventDefault();var m=e.target.dataset.module,boxes=[].slice.call(document.querySelectorAll('.vfos-perm-checkbox[data-module="'+m+'"]'));
      var all=boxes.length&&boxes.every(function(b){return b.checked;});boxes.forEach(function(b){b.checked=!all;});
      e.target.textContent=all?'Marcar tudo':'Desmarcar tudo';
    }
    if(e.target.id==='vfos-fill-project-tasks'){
      e.preventDefault();var src=document.getElementById('vfos-current-project-tasks'),dst=document.querySelector('textarea[name="included_items"]');
      if(src&&dst){dst.value=src.value;}
    }
  });
})();

/* v1.10 — Cliente PF/PJ */
(function(){
  function togglePersonFields(){
    var checked=document.querySelector('input[name="person_type"]:checked');
    if(!checked)return;
    var pj=checked.value==='pj';
    document.querySelectorAll('.vfos-pf-fields').forEach(function(el){el.style.display=pj?'none':'';});
    document.querySelectorAll('.vfos-pj-fields').forEach(function(el){el.style.display=pj?'':'none';});
  }
  document.addEventListener('change',function(e){if(e.target&&e.target.name==='person_type')togglePersonFields();});
  document.addEventListener('DOMContentLoaded',togglePersonFields);
  if(document.readyState!=='loading')togglePersonFields();
})();

/* v1.11 — Máscaras brasileiras em cadastros */
(function(){
  function digits(v,n){return String(v||'').replace(/\D/g,'').slice(0,n);}
  function cpf(v){v=digits(v,11);return v.replace(/^(\d{3})(\d)/,'$1.$2').replace(/^(\d{3})\.(\d{3})(\d)/,'$1.$2.$3').replace(/\.(\d{3})(\d)/,'.$1-$2');}
  function cnpj(v){v=digits(v,14);return v.replace(/^(\d{2})(\d)/,'$1.$2').replace(/^(\d{2})\.(\d{3})(\d)/,'$1.$2.$3').replace(/\.(\d{3})(\d)/,'.$1/$2').replace(/(\d{4})(\d)/,'$1-$2');}
  function cep(v){v=digits(v,8);return v.replace(/^(\d{5})(\d)/,'$1-$2');}
  function phone(v){
    v=digits(v,11);
    if(v.length<=10)return v.replace(/^(\d{0,2})(\d{0,4})(\d{0,4}).*/,function(_,a,b,c){return (a?'('+a+(a.length===2?') ':''):'')+b+(c?'-'+c:'');});
    return v.replace(/^(\d{0,2})(\d{0,5})(\d{0,4}).*/,function(_,a,b,c){return (a?'('+a+(a.length===2?') ':''):'')+b+(c?'-'+c:'');});
  }
  function apply(el){
    if(!el||!el.name)return;var n=el.name.toLowerCase(),v=el.value;
    if(n==='document'||n==='responsible_cpf'||n.endsWith('_cpf')){el.value=cpf(v);el.maxLength=14;el.placeholder=el.placeholder||'000.000.000-00';el.inputMode='numeric';el.pattern='\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}';el.title='Informe no formato 000.000.000-00';}
    else if(n==='pj_document'||n.endsWith('_cnpj')){el.value=cnpj(v);el.maxLength=18;el.placeholder=el.placeholder||'00.000.000/0000-00';el.inputMode='numeric';el.pattern='\\d{2}\\.\\d{3}\\.\\d{3}/\\d{4}-\\d{2}';el.title='Informe no formato 00.000.000/0000-00';}
    else if(n==='address_zip'||n==='zip'||n==='cep'||n.endsWith('_cep')){el.value=cep(v);el.maxLength=9;el.placeholder=el.placeholder||'00000-000';el.inputMode='numeric';el.pattern='\\d{5}-\\d{3}';el.title='Informe no formato 00000-000';}
    else if(n.includes('phone')||n.includes('whatsapp')||n==='telefone'||n==='celular'){el.value=phone(v);el.maxLength=15;el.placeholder=el.placeholder||'(00) 00000-0000';el.inputMode='tel';}
    else if(n==='address_state'||n==='state'||n==='uf'){el.value=String(v||'').toUpperCase().replace(/[^A-Z]/g,'').slice(0,2);el.maxLength=2;el.placeholder=el.placeholder||'UF';}
  }
  function init(){
    document.querySelectorAll('input[name]').forEach(function(el){apply(el);});
  }
  document.addEventListener('input',function(e){if(e.target&&e.target.matches('input[name]'))apply(e.target);});
  document.addEventListener('blur',function(e){if(e.target&&e.target.matches('input[name]'))apply(e.target);},true);
  document.addEventListener('DOMContentLoaded',init);if(document.readyState!=='loading')init();
})();

/* v1.13 — Envio de notificações */
(function(){
  function notificationScope(){
    var selected=document.querySelector('input[name="scope"]:checked');
    var personalField=document.querySelector('.vfos-recipient-field');
    var groupField=document.querySelector('.vfos-group-recipient-field');
    if(!selected)return;
    var personal=selected.value==='personal';
    if(personalField){
      personalField.style.display=personal?'':'none';
      var pselect=personalField.querySelector('select');if(pselect)pselect.required=personal;
    }
    if(groupField){
      groupField.style.display=personal?'none':'';
      var gselect=groupField.querySelector('select');if(gselect)gselect.required=!personal;
    }
  }
  document.addEventListener('change',function(e){if(e.target&&e.target.name==='scope')notificationScope();});
  document.addEventListener('DOMContentLoaded',notificationScope);
  if(document.readyState!=='loading')notificationScope();
})();

/* v1.17 — Orçamentos comerciais avançados */
(function(){
  function nextIndex(wrap,group){
    var max=-1;
    wrap.querySelectorAll('[name]').forEach(function(el){
      var m=(el.name||'').match(new RegExp(group+'\\[(\\d+)\\]'));
      if(m)max=Math.max(max,parseInt(m[1],10));
    });
    return max+1;
  }
  function cloneRow(wrapSelector,rowSelector,group,defaults){
    var wrap=document.querySelector(wrapSelector);if(!wrap)return;
    var first=wrap.querySelector(rowSelector);if(!first)return;
    var i=nextIndex(wrap,group),row=first.cloneNode(true);
    row.setAttribute('data-index',i);
    row.querySelectorAll('input,select,textarea').forEach(function(el){
      if(el.name)el.name=el.name.replace(new RegExp(group+'\\[\\d+\\]'),group+'['+i+']');
      if(el.type==='checkbox'||el.type==='radio')el.checked=false;
      else if(el.tagName==='SELECT')el.selectedIndex=0;
      else el.value='';
    });
    (defaults||[]).forEach(function(d){var el=row.querySelector(d.selector);if(!el)return;if(el.type==='checkbox')el.checked=!!d.value;else el.value=d.value;});
    wrap.appendChild(row);
    return row;
  }
  document.addEventListener('click',function(e){
    if(e.target.matches('.vfos-add-quote-section')){
      cloneRow('#vfos-quote-sections','.vfos-quote-section-row','sections',[
        {selector:'select',value:'custom'},{selector:'input',value:''},{selector:'textarea',value:''}
      ]);
    }
    if(e.target.matches('.vfos-remove-quote-section')){
      var row=e.target.closest('.vfos-quote-section-row'),wrap=document.getElementById('vfos-quote-sections');if(row&&wrap&&wrap.children.length>1)row.remove();
    }
    if(e.target.matches('.vfos-add-quote-cost')){
      var wrap=document.getElementById('vfos-quote-costs'),first=wrap&&wrap.querySelector('.vfos-quote-cost-card');if(!wrap||!first)return;
      var parent=nextIndex(wrap,'costs'),card=first.cloneNode(true);card.setAttribute('data-index',parent);
      var options=card.querySelectorAll('.vfos-cost-option-row');for(var oi=1;oi<options.length;oi++)options[oi].remove();
      card.querySelectorAll('input,select,textarea').forEach(function(el){
        if(el.name)el.name=el.name.replace(/costs\[\d+\]/,'costs['+parent+']').replace(/\[options\]\[\d+\]/,'[options][0]');
        if(el.type==='checkbox')el.checked=el.name.indexOf('[is_required]')>-1;
        else if(el.tagName==='SELECT')el.selectedIndex=0;
        else el.value='';
      });
      var h=card.querySelector('.vfos-cost-card-head h4');if(h)h.textContent='Novo custo externo';
      var cycle=card.querySelector('[name*="[billing_cycle]"]');if(cycle)cycle.value='monthly';
      var duration=card.querySelector('[name*="[duration_months]"]');if(duration)duration.value='1';
      wrap.appendChild(card);
    }
    if(e.target.matches('.vfos-remove-quote-cost')){
      var card=e.target.closest('.vfos-quote-cost-card'),wrap=document.getElementById('vfos-quote-costs');if(card&&wrap&&wrap.children.length>1)card.remove();
    }
    if(e.target.matches('.vfos-add-cost-option')){
      var card=e.target.closest('.vfos-quote-cost-card'),wrap=card&&card.querySelector('.vfos-cost-options'),first=wrap&&wrap.querySelector('.vfos-cost-option-row');if(!card||!wrap||!first)return;
      var parent=parseInt(card.getAttribute('data-index')||'0',10),max=-1;
      wrap.querySelectorAll('[name]').forEach(function(el){var m=(el.name||'').match(/\[options\]\[(\d+)\]/);if(m)max=Math.max(max,parseInt(m[1],10));});
      var idx=max+1,row=first.cloneNode(true);row.setAttribute('data-option-index',idx);
      row.querySelectorAll('input,select,textarea').forEach(function(el){
        if(el.name)el.name=el.name.replace(/costs\[\d+\]/,'costs['+parent+']').replace(/\[options\]\[\d+\]/,'[options]['+idx+']');
        if(el.type==='checkbox')el.checked=false;
        else if(el.tagName==='SELECT')el.selectedIndex=0;
        else el.value='';
      });
      var cycle=row.querySelector('[name*="[billing_cycle]"]');if(cycle)cycle.value='monthly';
      var duration=row.querySelector('[name*="[duration_months]"]');if(duration)duration.value='1';
      wrap.appendChild(row);
    }
    if(e.target.matches('.vfos-remove-cost-option')){
      var row=e.target.closest('.vfos-cost-option-row'),wrap=row&&row.parentElement;if(row&&wrap&&wrap.querySelectorAll('.vfos-cost-option-row').length>1)row.remove();
    }
    if(e.target.matches('.vfos-add-payment-option')){
      cloneRow('#vfos-payment-options','.vfos-payment-option-row','payments',[
        {selector:'select',value:'one_time'},{selector:'input[type="number"][name*="[installments]"]',value:'1'}
      ]);
    }
    if(e.target.matches('.vfos-remove-payment-option')){
      var row=e.target.closest('.vfos-payment-option-row'),wrap=document.getElementById('vfos-payment-options');if(row&&wrap&&wrap.children.length>1)row.remove();
    }
  });
})();

/* v1.17 — compartilhar proposta padrão ou personalizada */
document.addEventListener('click',function(e){
  if(e.target.matches('.vfos-copy-proposal-link')){
    e.preventDefault();
    var url=e.target.getAttribute('data-url')||'';
    if(!url)return;
    if(navigator.clipboard&&navigator.clipboard.writeText){
      navigator.clipboard.writeText(url).then(function(){
        var old=e.target.textContent;e.target.textContent='Link copiado!';setTimeout(function(){e.target.textContent=old;},1600);
      });
    }else{
      window.prompt('Copie o link da proposta:',url);
    }
  }
});

/* v1.17.4 — Dados institucionais VisionForge */
(function(){
  function responsibleNext(){
    var wrap=document.getElementById('vfos-company-responsibles'),max=-1;
    if(!wrap)return 0;
    wrap.querySelectorAll('[name]').forEach(function(el){var m=(el.name||'').match(/responsibles\]\[(\d+)\]/);if(m)max=Math.max(max,parseInt(m[1],10));});
    return max+1;
  }
  function renumberResponsibles(){
    var wrap=document.getElementById('vfos-company-responsibles');if(!wrap)return;
    wrap.querySelectorAll('.vfos-company-responsible-number').forEach(function(el,i){el.textContent=i+1;});
  }
  document.addEventListener('click',function(e){
    if(e.target.matches('.vfos-add-company-responsible')){
      var wrap=document.getElementById('vfos-company-responsibles'),first=wrap&&wrap.querySelector('.vfos-company-responsible');if(!wrap||!first)return;
      var i=responsibleNext(),row=first.cloneNode(true);row.setAttribute('data-index',i);
      row.querySelectorAll('[name]').forEach(function(el){el.name=el.name.replace(/responsibles\]\[\d+\]/,'responsibles]['+i+']');if(el.type!=='button')el.value='';});
      wrap.appendChild(row);renumberResponsibles();
    }
    if(e.target.matches('.vfos-remove-company-responsible')){
      var row=e.target.closest('.vfos-company-responsible'),wrap=document.getElementById('vfos-company-responsibles');if(row&&wrap&&wrap.querySelectorAll('.vfos-company-responsible').length>1){row.remove();renumberResponsibles();}
    }
  });
  function docMask(input){
    if(!input)return;var v=(input.value||'').replace(/\D/g,'').slice(0,14);
    if(v.length<=11){
      v=v.replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1,2})$/,'$1-$2');
    }else{
      v=v.replace(/^(\d{2})(\d)/,'$1.$2').replace(/^(\d{2})\.(\d{3})(\d)/,'$1.$2.$3').replace(/\.(\d{3})(\d)/,'.$1/$2').replace(/(\d{4})(\d{1,2})$/,'$1-$2');
    }
    input.value=v;
  }
  document.addEventListener('input',function(e){if(e.target.matches('.vfos-company-document'))docMask(e.target);});
})();

/* v1.17.8 — ordenar páginas da proposta */
(function(){
  var drag=null;
  function syncOrder(){
    var wrap=document.getElementById('vfos-proposal-order');if(!wrap)return;
    wrap.querySelectorAll('.vfos-order-item').forEach(function(item){
      var input=item.querySelector('input[name="proposal_order[]"]');
      if(input)input.value=item.getAttribute('data-key')||'';
    });
  }
  document.addEventListener('click',function(e){
    if(e.target.matches('.vfos-order-up,.vfos-order-down')){
      var item=e.target.closest('.vfos-order-item'),wrap=item&&item.parentElement;if(!item||!wrap)return;
      if(e.target.matches('.vfos-order-up')&&item.previousElementSibling)wrap.insertBefore(item,item.previousElementSibling);
      if(e.target.matches('.vfos-order-down')&&item.nextElementSibling)wrap.insertBefore(item.nextElementSibling,item);
      syncOrder();
    }
  });
  document.addEventListener('dragstart',function(e){
    var item=e.target.closest&&e.target.closest('.vfos-order-item');if(!item)return;
    drag=item;item.classList.add('is-dragging');
    if(e.dataTransfer){e.dataTransfer.effectAllowed='move';try{e.dataTransfer.setData('text/plain',item.getAttribute('data-key')||'');}catch(err){}}
  });
  document.addEventListener('dragend',function(e){
    if(drag)drag.classList.remove('is-dragging');drag=null;syncOrder();
  });
  document.addEventListener('dragover',function(e){
    var wrap=e.target.closest&&e.target.closest('#vfos-proposal-order');if(!wrap||!drag)return;
    e.preventDefault();
    var after=null,closest=Infinity;
    wrap.querySelectorAll('.vfos-order-item:not(.is-dragging)').forEach(function(item){
      var r=item.getBoundingClientRect(),offset=e.clientY-(r.top+r.height/2);
      if(offset<0&&Math.abs(offset)<closest){closest=Math.abs(offset);after=item;}
    });
    if(after)wrap.insertBefore(drag,after);else wrap.appendChild(drag);
  });
})();


/* v1.18.0 — mover e duplicar itens internos dos orçamentos */
(function(){
  var dragItem=null, dragContainer=null;

  var configs=[
    {container:'#vfos-quote-sections', item:'.vfos-quote-section-row', type:'sections'},
    {container:'#vfos-quote-items', item:'.vfos-quote-item', type:'items'},
    {container:'#vfos-quote-costs', item:'.vfos-quote-cost-card', type:'costs'},
    {container:'#vfos-payment-options', item:'.vfos-payment-option-row', type:'payments'}
  ];

  function copyLiveValues(source,clone){
    var a=source.querySelectorAll('input,select,textarea');
    var b=clone.querySelectorAll('input,select,textarea');
    a.forEach(function(el,i){
      var dst=b[i];if(!dst)return;
      if(el.type==='checkbox'||el.type==='radio')dst.checked=el.checked;
      else dst.value=el.value;
    });
  }

  function stripEnhancement(clone){
    clone.querySelectorAll('.vfos-inner-tools').forEach(function(el){el.remove();});
    clone.classList.remove('is-inner-dragging');
  }

  function renumberOptions(card){
    var parentIndex=parseInt(card.getAttribute('data-index')||'0',10);
    card.querySelectorAll('.vfos-cost-option-row').forEach(function(row,optIndex){
      row.setAttribute('data-option-index',optIndex);
      row.querySelectorAll('[name]').forEach(function(el){
        el.name=el.name
          .replace(/costs\[\d+\]/,'costs['+parentIndex+']')
          .replace(/\[options\]\[\d+\]/,'[options]['+optIndex+']');
      });
    });
  }

  function renumberContainer(container){
    if(!container)return;
    if(container.id==='vfos-quote-sections'){
      container.querySelectorAll(':scope > .vfos-quote-section-row').forEach(function(row,i){
        row.setAttribute('data-index',i);
        row.querySelectorAll('[name]').forEach(function(el){el.name=el.name.replace(/sections\[\d+\]/,'sections['+i+']');});
      });
    }else if(container.id==='vfos-quote-items'){
      container.querySelectorAll(':scope > .vfos-quote-item').forEach(function(row,i){
        row.setAttribute('data-index',i);
        row.querySelectorAll('[name]').forEach(function(el){el.name=el.name.replace(/items\[\d+\]/,'items['+i+']');});
        var num=row.querySelector('.vfos-quote-item-number');if(num)num.textContent=i+1;
      });
    }else if(container.id==='vfos-quote-costs'){
      container.querySelectorAll(':scope > .vfos-quote-cost-card').forEach(function(card,i){
        card.setAttribute('data-index',i);
        card.querySelectorAll('[name]').forEach(function(el){el.name=el.name.replace(/costs\[\d+\]/,'costs['+i+']');});
        renumberOptions(card);
      });
    }else if(container.id==='vfos-payment-options'){
      container.querySelectorAll(':scope > .vfos-payment-option-row').forEach(function(row,i){
        row.setAttribute('data-index',i);
        row.querySelectorAll('[name]').forEach(function(el){el.name=el.name.replace(/payments\[\d+\]/,'payments['+i+']');});
      });
    }else if(container.classList.contains('vfos-cost-options')){
      var card=container.closest('.vfos-quote-cost-card');if(card)renumberOptions(card);
    }
  }

  function recalcQuote(){
    var price=document.querySelector('.vfos-item-price');
    if(price)price.dispatchEvent(new Event('input',{bubbles:true}));
  }

  function toolbar(){
    var tools=document.createElement('div');
    tools.className='vfos-inner-tools';
    tools.innerHTML='<button type="button" class="vfos-inner-drag" draggable="true" title="Arrastar para mover">⋮⋮</button>'+
      '<button type="button" class="button vfos-inner-up" title="Mover para cima">↑</button>'+
      '<button type="button" class="button vfos-inner-down" title="Mover para baixo">↓</button>'+
      '<button type="button" class="button vfos-inner-duplicate" title="Duplicar">Duplicar</button>';
    return tools;
  }

  function enhanceItem(item){
    if(!item||item.querySelector(':scope > .vfos-inner-tools'))return;
    item.insertBefore(toolbar(),item.firstChild);
  }

  function enhanceAll(){
    configs.forEach(function(cfg){
      var wrap=document.querySelector(cfg.container);if(!wrap)return;
      wrap.querySelectorAll(':scope > '+cfg.item).forEach(enhanceItem);
    });
    document.querySelectorAll('.vfos-cost-options').forEach(function(wrap){
      wrap.querySelectorAll(':scope > .vfos-cost-option-row').forEach(enhanceItem);
    });
  }

  function itemAndContainer(target){
    var item=target.closest('.vfos-quote-section-row,.vfos-quote-item,.vfos-quote-cost-card,.vfos-cost-option-row,.vfos-payment-option-row');
    if(!item)return null;
    var container=item.parentElement;
    return {item:item,container:container};
  }

  function duplicateItem(item,container){
    var clone=item.cloneNode(true);
    copyLiveValues(item,clone);
    stripEnhancement(clone);
    item.insertAdjacentElement('afterend',clone);
    renumberContainer(container);
    enhanceItem(clone);
    if(clone.classList.contains('vfos-quote-cost-card')){
      clone.querySelectorAll('.vfos-cost-option-row').forEach(enhanceItem);
    }
    recalcQuote();
  }

  document.addEventListener('click',function(e){
    if(e.target.matches('.vfos-inner-duplicate')){
      e.preventDefault();
      var pair=itemAndContainer(e.target);if(!pair)return;
      duplicateItem(pair.item,pair.container);
      return;
    }
    if(e.target.matches('.vfos-inner-up,.vfos-inner-down')){
      e.preventDefault();
      var pair=itemAndContainer(e.target);if(!pair)return;
      var item=pair.item,container=pair.container;
      if(e.target.matches('.vfos-inner-up')&&item.previousElementSibling){
        var prev=item.previousElementSibling;
        if(prev.classList.contains('vfos-inner-tools'))prev=prev.previousElementSibling;
        if(prev)container.insertBefore(item,prev);
      }
      if(e.target.matches('.vfos-inner-down')&&item.nextElementSibling){
        container.insertBefore(item,item.nextElementSibling.nextElementSibling);
      }
      renumberContainer(container);recalcQuote();return;
    }
  });

  document.addEventListener('dragstart',function(e){
    if(!e.target.matches('.vfos-inner-drag'))return;
    var pair=itemAndContainer(e.target);if(!pair)return;
    dragItem=pair.item;dragContainer=pair.container;
    dragItem.classList.add('is-inner-dragging');
    if(e.dataTransfer){
      e.dataTransfer.effectAllowed='move';
      try{e.dataTransfer.setData('text/plain','vfos-inner');}catch(err){}
    }
  });

  document.addEventListener('dragover',function(e){
    if(!dragItem||!dragContainer)return;
    var candidate=e.target.closest('.vfos-quote-section-row,.vfos-quote-item,.vfos-quote-cost-card,.vfos-cost-option-row,.vfos-payment-option-row');
    if(!candidate||candidate===dragItem||candidate.parentElement!==dragContainer)return;
    e.preventDefault();
    var r=candidate.getBoundingClientRect();
    var after=e.clientY>r.top+r.height/2;
    dragContainer.insertBefore(dragItem,after?candidate.nextElementSibling:candidate);
  });

  document.addEventListener('drop',function(e){
    if(!dragItem||!dragContainer)return;
    e.preventDefault();
    renumberContainer(dragContainer);recalcQuote();
  });

  document.addEventListener('dragend',function(){
    if(dragItem)dragItem.classList.remove('is-inner-dragging');
    if(dragContainer)renumberContainer(dragContainer);
    dragItem=null;dragContainer=null;
  });

  // Novos itens criados pelos botões já existentes recebem as ferramentas automaticamente.
  var observer=new MutationObserver(function(mutations){
    var changed=false;
    mutations.forEach(function(m){if(m.addedNodes&&m.addedNodes.length)changed=true;});
    if(changed){enhanceAll();document.querySelectorAll('#vfos-quote-sections,#vfos-quote-items,#vfos-quote-costs,#vfos-payment-options,.vfos-cost-options').forEach(renumberContainer);}
  });

  function init(){
    enhanceAll();
    document.querySelectorAll('#vfos-quote-sections,#vfos-quote-items,#vfos-quote-costs,#vfos-payment-options,.vfos-cost-options').forEach(renumberContainer);
    var form=document.querySelector('form input[name="action"][value="vfos_save_quote"]');
    if(form&&form.form)observer.observe(form.form,{childList:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* v1.18.2 — divisão de receitas entre sócios e caixa */
(function(){
  function money(v){return 'R$ '+(Number(v||0)).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function form(){return document.getElementById('vfos-split-form');}
  function mode(){var el=document.querySelector('input[name="split_mode"]:checked');return el?el.value:'amount';}
  function total(){
    var el=document.getElementById('vfos-split-total');
    return el?parseFloat(el.getAttribute('data-total')||'0')||0:0;
  }
  function recalc(){
    var f=form();if(!f)return;var t=total(),m=mode(),sum=0;
    f.querySelectorAll('.vfos-split-partner-row').forEach(function(row){
      var a=row.querySelector('.vfos-split-amount'),p=row.querySelector('.vfos-split-percent');
      if(m==='percent'){var pct=parseFloat(p.value||0)||0,amt=Math.round(t*pct)/100;a.value=amt.toFixed(2);sum+=amt;}
      else{var amt=parseFloat(a.value||0)||0,pct=t?amt/t*100:0;p.value=pct.toFixed(2);sum+=amt;}
    });
    var ca=document.getElementById('vfos-company-cash-amount'),cp=document.getElementById('vfos-company-cash-percent');
    if(ca&&cp){
      if(m==='percent'){var pct=parseFloat(cp.value||0)||0,amt=Math.round(t*pct)/100;ca.value=amt.toFixed(2);sum+=amt;}
      else{var amt=parseFloat(ca.value||0)||0,pct=t?amt/t*100:0;cp.value=pct.toFixed(2);sum+=amt;}
    }
    sum=Math.round(sum*100)/100;var rem=Math.round((t-sum)*100)/100;
    var ao=document.getElementById('vfos-split-allocated'),ro=document.getElementById('vfos-split-remaining'),msg=document.getElementById('vfos-split-validation-text');
    if(ao)ao.textContent=money(sum);if(ro)ro.textContent=money(rem);
    if(msg){var box=msg.closest('.vfos-split-validation');if(Math.abs(rem)<=0.01){msg.textContent='Perfeito: 100% da receita está distribuída.';box.classList.add('is-valid');}else{msg.textContent=rem>0?'Ainda faltam '+money(rem)+' para distribuir.':'A divisão ultrapassou a receita em '+money(Math.abs(rem))+'.';box.classList.remove('is-valid');}}
  }
  function renumber(){var w=document.getElementById('vfos-split-partners');if(!w)return;w.querySelectorAll('.vfos-split-partner-row').forEach(function(r,i){r.querySelectorAll('[name]').forEach(function(el){el.name=el.name.replace(/partners\[\d+\]/,'partners['+i+']');});});}
  document.addEventListener('click',function(e){
    if(e.target.matches('.vfos-add-split-partner')){var w=document.getElementById('vfos-split-partners'),f=w&&w.querySelector('.vfos-split-partner-row');if(!w||!f)return;var r=f.cloneNode(true);r.querySelectorAll('input').forEach(function(x){x.value='';});r.querySelectorAll('select').forEach(function(x){x.selectedIndex=0;});w.appendChild(r);renumber();recalc();}
    if(e.target.matches('.vfos-remove-split-partner')){var r=e.target.closest('.vfos-split-partner-row'),w=document.getElementById('vfos-split-partners');if(r&&w&&w.querySelectorAll('.vfos-split-partner-row').length>1){r.remove();renumber();recalc();}}
  });
  document.addEventListener('input',function(e){if(e.target.matches('.vfos-split-amount,.vfos-split-percent'))recalc();});
  document.addEventListener('change',function(e){
    if(e.target.matches('input[name="split_mode"]')){var p=mode()==='percent';document.querySelectorAll('.vfos-split-amount').forEach(function(x){x.readOnly=p;});document.querySelectorAll('.vfos-split-percent').forEach(function(x){x.readOnly=!p;});recalc();}
    if(e.target.matches('#vfos-financial-type')){
      var income=e.target.value==='income',b=document.getElementById('vfos-inline-split'),first=document.getElementById('vfos-income-first-payment'),expense=document.getElementById('vfos-expense-status');
      if(b)b.style.display=income?'':'none';
      if(first)first.style.display=income?'':'none';
      if(expense)expense.style.display=income?'none':'';
    }
  });
  function init(){
    if(form()){var p=mode()==='percent';document.querySelectorAll('.vfos-split-amount').forEach(function(x){x.readOnly=p;});document.querySelectorAll('.vfos-split-percent').forEach(function(x){x.readOnly=!p;});recalc();}
    var type=document.getElementById('vfos-financial-type');if(type)type.dispatchEvent(new Event('change',{bubbles:true}));
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


/* v1.18.5 — IA contextual nos campos */
(function(){
  function fieldType(el){
    var n=el.name||'';
    if(n==='description' && document.querySelector('input[name="action"][value="vfos_save_quote"],input[name="action"][value="vfos_update_quote_template"]'))return 'quote_intro';
    if(/\[content\]$/.test(n))return 'quote_section';
    if(n==='payment_terms')return 'quote_payment_terms';
    if(n==='notes' && document.querySelector('input[name="action"][value="vfos_save_quote"],input[name="action"][value="vfos_update_quote_template"]'))return 'quote_notes';
    if(/\[description\]$/.test(n) && n.indexOf('items[')===0)return 'quote_item_description';
    if(/\[condition_text\]$/.test(n))return 'external_condition';
    if(/\[benefits\]$/.test(n))return 'external_benefits';
    if(n==='content' && document.querySelector('input[name="action"][value="vfos_save_contract"]'))return 'contract_content';
    return '';
  }
  function contextFor(el){
    var form=el.form,parts=[];
    if(!form)return '';
    var title=form.querySelector('input[name="title"]');if(title&&title.value)parts.push('Título: '+title.value);
    var client=form.querySelector('select[name="client_id"]');if(client&&client.value){var opt=client.options[client.selectedIndex];if(opt)parts.push('Cliente: '+opt.text);}
    var section=el.closest('.vfos-quote-section-row');if(section){var t=section.querySelector('input[name*="[title]"]');if(t&&t.value)parts.push('Seção: '+t.value);}
    var item=el.closest('.vfos-quote-item');if(item){var t=item.querySelector('.vfos-item-title');if(t&&t.value)parts.push('Entregável: '+t.value);}
    var cost=el.closest('.vfos-cost-option-row');if(cost){var t=cost.querySelector('input[name*="[title]"]');if(t&&t.value)parts.push('Plano: '+t.value);}
    return parts.join('\n');
  }
  function addTools(el){
    if(!fieldType(el)||el.dataset.vfosAiReady)return;
    el.dataset.vfosAiReady='1';
    var wrap=document.createElement('div');wrap.className='vfos-field-ai';
    wrap.innerHTML='<span>✦ VisionForge AI</span><select class="vfos-field-ai-provider"><option value="openrouter">OpenRouter</option><option value="gemini">Gemini</option></select><button type="button" class="button vfos-field-ai-generate">Gerar com IA</button>';
    el.insertAdjacentElement('afterend',wrap);
  }
  function scan(){
    document.querySelectorAll('textarea,input[type="text"]').forEach(addTools);
  }
  document.addEventListener('click',function(e){
    if(!e.target.matches('.vfos-field-ai-generate'))return;
    var wrap=e.target.closest('.vfos-field-ai'),el=wrap&&wrap.previousElementSibling;if(!el)return;
    var type=fieldType(el);if(!type)return;
    var extra=window.prompt('O que a IA deve considerar? (opcional)','')||'';
    var context=contextFor(el)+(extra?'\nInstrução adicional: '+extra:'');
    var provider=wrap.querySelector('.vfos-field-ai-provider').value;
    var btn=e.target,old=btn.textContent;btn.disabled=true;btn.textContent='Gerando...';
    var body=new URLSearchParams({action:'vfos_ai_field',nonce:(window.VFOS&&VFOS.nonce)||'',provider:provider,field_type:type,context:context,current:el.value||''});
    fetch((window.VFOS&&VFOS.ajax)||ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()})
      .then(r=>r.json()).then(function(res){
        if(!res.success)throw new Error(typeof res.data==='string'?res.data:'Não foi possível gerar o conteúdo.');
        el.value=(res.data&&res.data.text)||'';el.dispatchEvent(new Event('input',{bubbles:true}));el.focus();
      }).catch(function(err){window.alert(err.message||'Erro ao gerar com IA.');})
      .finally(function(){btn.disabled=false;btn.textContent=old;});
  });
  var obs=new MutationObserver(scan);
  function init(){scan();obs.observe(document.body,{childList:true,subtree:true});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* v1.19.0 — busca global */
(function(){
  let timer=null,box=null,input=null;
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
  function close(){if(box){box.innerHTML='';box.classList.remove('is-open');}}
  function run(){
    if(!input||!box)return;let q=input.value.trim();if(q.length<2){close();return;}
    box.innerHTML='<div class="vfos-search-loading">Pesquisando...</div>';box.classList.add('is-open');
    let url=((window.VFOS&&VFOS.ajax)||ajaxurl)+'?action=vfos_global_search&nonce='+encodeURIComponent((window.VFOS&&VFOS.nonce)||'')+'&q='+encodeURIComponent(q);
    fetch(url).then(r=>r.json()).then(res=>{
      if(!res.success)throw new Error('Falha na busca');
      let rows=res.data||[];
      if(!rows.length){box.innerHTML='<div class="vfos-search-empty">Nenhum resultado encontrado.</div>';return;}
      let grouped={};rows.forEach(r=>{(grouped[r.type]||(grouped[r.type]=[])).push(r);});
      box.innerHTML=Object.keys(grouped).map(type=>'<section><span>'+esc(type)+'</span>'+grouped[type].map(r=>'<a href="'+esc(r.url)+'"><strong>'+esc(r.title)+'</strong><small>'+esc(r.meta||'')+'</small></a>').join('')+'</section>').join('');
    }).catch(()=>{box.innerHTML='<div class="vfos-search-empty">Não foi possível pesquisar agora.</div>';});
  }
  function init(){
    input=document.getElementById('vfos-global-search');box=document.getElementById('vfos-global-results');if(!input)return;
    input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(run,220);});
    input.addEventListener('focus',()=>{if(input.value.trim().length>=2)run();});
    document.addEventListener('click',e=>{if(!e.target.closest('.vfos-global-search'))close();});
    document.addEventListener('keydown',e=>{
      if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();input.focus();input.select();}
      if(e.key==='Escape'){close();input.blur();}
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* v1.20.0 — VisionForge OS instalável como aplicativo (PWA) */
(function(){
  let deferredInstallPrompt=null;

  function isStandalone(){
    return window.matchMedia('(display-mode: standalone)').matches ||
      window.matchMedia('(display-mode: window-controls-overlay)').matches ||
      window.navigator.standalone===true;
  }

  function deviceHint(){
    const ua=navigator.userAgent||'';
    const ios=/iPad|iPhone|iPod/.test(ua) || (navigator.platform==='MacIntel' && navigator.maxTouchPoints>1);
    const android=/Android/i.test(ua);
    const mac=/Macintosh|Mac OS X/i.test(ua);
    if(ios)return 'No iPhone/iPad: abra no Safari → Compartilhar → Adicionar à Tela de Início.';
    if(android)return 'Se o botão não abrir a instalação, use o menu do navegador → Instalar aplicativo / Adicionar à tela inicial.';
    if(mac)return 'No Chrome/Edge use Instalar. No Safari compatível use Arquivo → Adicionar ao Dock.';
    return 'Se o botão não abrir a instalação, procure o ícone “Instalar” na barra de endereço do Chrome ou Edge.';
  }

  function updateInstallUI(){
    const btn=document.getElementById('vfos-install-app');
    const open=document.getElementById('vfos-open-app');
    const status=document.getElementById('vfos-app-status');
    if(!btn&&!status)return;

    if(isStandalone()){
      if(btn){btn.style.display='none';}
      if(open){open.style.display='inline-flex';}
      if(status){status.innerHTML='<strong>✓ VisionForge OS está aberto como aplicativo.</strong>';}
      return;
    }

    if(deferredInstallPrompt){
      if(btn){btn.disabled=false;btn.style.display='inline-flex';}
      if(status){status.innerHTML='<strong>Pronto para instalar neste dispositivo.</strong> Clique em “Instalar VisionForge OS”.';}
    }else{
      if(btn){btn.disabled=false;}
      if(status){status.textContent=deviceHint();}
    }
  }

  window.addEventListener('beforeinstallprompt',function(e){
    e.preventDefault();
    deferredInstallPrompt=e;
    updateInstallUI();
  });

  window.addEventListener('appinstalled',function(){
    deferredInstallPrompt=null;
    updateInstallUI();
  });

  async function installApp(){
    const btn=document.getElementById('vfos-install-app');
    const status=document.getElementById('vfos-app-status');
    if(isStandalone()){updateInstallUI();return;}
    if(deferredInstallPrompt){
      if(btn)btn.disabled=true;
      try{
        deferredInstallPrompt.prompt();
        const choice=await deferredInstallPrompt.userChoice;
        deferredInstallPrompt=null;
        if(status){
          status.textContent=choice&&choice.outcome==='accepted'
            ? 'Instalação confirmada. O VisionForge OS aparecerá entre seus aplicativos.'
            : deviceHint();
        }
      }catch(err){
        if(status)status.textContent=deviceHint();
      }
      if(btn)btn.disabled=false;
    }else{
      if(status)status.innerHTML='<strong>Instalação manual necessária neste navegador.</strong> '+deviceHint();
    }
  }

  function initPWA(){
    if(window.VFOS_PWA && 'serviceWorker' in navigator){
      navigator.serviceWorker.register(window.VFOS_PWA.sw,{scope:'/'})
        .catch(function(err){console.warn('VisionForge OS PWA:',err);});
    }

    const btn=document.getElementById('vfos-install-app');
    if(btn)btn.addEventListener('click',installApp);

    const open=document.getElementById('vfos-open-app');
    if(open)open.addEventListener('click',function(){
      window.location.href=(window.VFOS_PWA&&VFOS_PWA.start)||window.location.href;
    });

    updateInstallUI();
    setTimeout(updateInstallUI,1200);
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initPWA);
  else initPWA();
})();


/* v1.22.0 — pagamentos em tempo real, links de cobrança e menções */
(function(){
  function money(v){return 'R$ '+Number(v||0).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m];});}

  /* Copiar link de cobrança */
  document.addEventListener('click',function(e){
    if(e.target.matches('.vfos-copy-payment-link')){
      var link=e.target.getAttribute('data-link')||'';
      if(!link)return;
      navigator.clipboard.writeText(link).then(function(){
        var old=e.target.textContent;e.target.textContent='Copiado ✓';setTimeout(function(){e.target.textContent=old;},1600);
      });
    }
  });

  /* Acompanhamento AJAX de pagamentos Mercado Pago */
  var liveTimer=null,liveBusy=false;
  function paymentLiveCheck(){
    var root=document.getElementById('vfos-payment-live');if(!root||liveBusy)return;
    var id=root.getAttribute('data-financial-id');if(!id)return;
    liveBusy=true;
    var dot=document.getElementById('vfos-payment-live-dot'),text=document.getElementById('vfos-payment-live-text');
    if(dot)dot.classList.add('is-checking');if(text)text.textContent='• verificando pagamentos...';
    var url=((window.VFOS&&VFOS.ajax)||ajaxurl)+'?action=vfos_payment_live&nonce='+encodeURIComponent((window.VFOS&&VFOS.nonce)||'')+'&financial_id='+encodeURIComponent(id);
    fetch(url,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(res){
      if(!res.success)return;
      var d=res.data||{},oldPaid=parseFloat(root.getAttribute('data-paid')||0),oldStatus=root.getAttribute('data-status')||'';
      var paid=document.getElementById('vfos-payment-paid'),remaining=document.getElementById('vfos-payment-remaining'),status=document.getElementById('vfos-payment-status');
      if(paid)paid.textContent=money(d.paid);if(remaining)remaining.textContent=money(d.remaining);if(status)status.textContent=d.status_label||d.status;
      (d.charges||[]).forEach(function(ch){
        var row=document.querySelector('[data-charge-id="'+ch.id+'"] .vfos-charge-status');if(row)row.textContent=ch.status;
      });
      root.setAttribute('data-paid',d.paid);root.setAttribute('data-status',d.status);
      if(text)text.textContent='• atualizado às '+(d.checked_at||'agora');
      if(Number(d.paid)>oldPaid+0.001 || (oldStatus!==d.status && d.status==='paid')){
        var notice=document.createElement('div');notice.className='vfos-live-payment-confirmed';notice.innerHTML='<strong>✓ Pagamento identificado!</strong><span>O financeiro e o caixa foram atualizados automaticamente.</span>';
        root.insertAdjacentElement('afterend',notice);
        setTimeout(function(){window.location.reload();},1400);
      }
    }).catch(function(){if(text)text.textContent='• não foi possível verificar agora';})
    .finally(function(){liveBusy=false;if(dot)dot.classList.remove('is-checking');});
  }
  function initPaymentLive(){
    if(!document.getElementById('vfos-payment-live'))return;
    paymentLiveCheck();
    liveTimer=setInterval(paymentLiveCheck,5000);
    document.addEventListener('visibilitychange',function(){if(!document.hidden)paymentLiveCheck();});
  }

  /* Vincular projeto/cliente/orçamento/etc. em notificação */
  var resourceTimer=null;
  function initResourcePicker(){
    var input=document.getElementById('vfos-notification-resource-search'),results=document.getElementById('vfos-notification-resource-results');
    if(!input||!results)return;
    input.addEventListener('input',function(){
      clearTimeout(resourceTimer);var q=input.value.trim();
      if(q.length<2){results.innerHTML='';results.classList.remove('is-open');return;}
      resourceTimer=setTimeout(function(){
        results.innerHTML='<div class="vfos-resource-loading">Pesquisando...</div>';results.classList.add('is-open');
        var url=((window.VFOS&&VFOS.ajax)||ajaxurl)+'?action=vfos_global_search&nonce='+encodeURIComponent((window.VFOS&&VFOS.nonce)||'')+'&q='+encodeURIComponent(q);
        fetch(url).then(r=>r.json()).then(function(res){
          var rows=res.success?(res.data||[]):[];
          if(!rows.length){results.innerHTML='<div class="vfos-resource-loading">Nenhum item encontrado.</div>';return;}
          results.innerHTML=rows.slice(0,12).map(function(r){
            return '<button type="button" class="vfos-resource-result" data-type="'+esc(r.type||'')+'" data-module="'+esc(r.module||'')+'" data-id="'+Number(r.id||0)+'" data-url="'+esc(r.url||'')+'" data-title="'+esc(r.title||'')+'"><strong>'+esc(r.title)+'</strong><small>'+esc(r.type)+(r.meta?' • '+esc(r.meta):'')+'</small></button>';
          }).join('');
        });
      },220);
    });
    results.addEventListener('click',function(e){
      var btn=e.target.closest('.vfos-resource-result');if(!btn)return;
      document.getElementById('vfos-notification-entity-type').value=(btn.dataset.module||btn.dataset.type||'item').toLowerCase().replace(/\s+/g,'_');
      document.getElementById('vfos-notification-entity-id').value=btn.dataset.id||0;
      document.getElementById('vfos-notification-url').value=btn.dataset.url||'';
      document.getElementById('vfos-notification-context-label').value=(btn.dataset.type||'Item')+' • '+(btn.dataset.title||'');
      var selected=document.getElementById('vfos-notification-resource-selected');
      selected.style.display='flex';selected.innerHTML='<div><strong>'+btn.dataset.title+'</strong><small>'+btn.dataset.type+' vinculado à notificação</small></div><button type="button" class="button vfos-clear-notification-resource">Remover</button>';
      input.value='';results.innerHTML='';results.classList.remove('is-open');
    });
    document.addEventListener('click',function(e){
      if(e.target.matches('.vfos-clear-notification-resource')){
        ['vfos-notification-entity-type','vfos-notification-entity-id','vfos-notification-url','vfos-notification-context-label'].forEach(function(id){var x=document.getElementById(id);if(x)x.value='';});
        var selected=document.getElementById('vfos-notification-resource-selected');if(selected){selected.style.display='none';selected.innerHTML='';}
      }
      if(!e.target.closest('.vfos-resource-picker'))results.classList.remove('is-open');
    });
  }

  function init(){initPaymentLive();initResourcePicker();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


/* v1.22.1 — menções @ dentro das notificações */
(function(){
  var timer=null, activeQuery=null;

  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m];});}

  function setLinkedResource(r){
    var type=document.getElementById('vfos-notification-entity-type'),
        id=document.getElementById('vfos-notification-entity-id'),
        url=document.getElementById('vfos-notification-url'),
        label=document.getElementById('vfos-notification-context-label'),
        selected=document.getElementById('vfos-notification-resource-selected');
    if(type)type.value=(r.module||r.type||'item').toLowerCase().replace(/\s+/g,'_');
    if(id)id.value=r.id||0;
    if(url)url.value=r.url||'';
    if(label)label.value=(r.type||'Item')+' • '+(r.title||'');
    if(selected){
      selected.style.display='flex';
      selected.innerHTML='<div><strong>'+esc(r.title||'Item')+'</strong><small>'+esc(r.type||'Item')+' vinculado à notificação</small></div><button type="button" class="button vfos-clear-notification-resource">Remover</button>';
    }
  }

  function findMention(text,caret){
    var before=text.slice(0,caret);
    var m=before.match(/(^|\s)@([^@\n]{0,60})$/);
    if(!m)return null;
    return {query:(m[2]||'').trim(),start:before.lastIndexOf('@'),end:caret};
  }

  function searchMention(q){
    var box=document.getElementById('vfos-mention-results');
    if(!box)return;
    if(q.length<1){
      box.innerHTML='<div class="vfos-mention-help"><strong>Digite após @ para pesquisar</strong><small>Projetos, clientes, tarefas, orçamentos, contratos, financeiro e leads.</small></div>';
      box.classList.add('is-open');return;
    }
    box.innerHTML='<div class="vfos-mention-help">Pesquisando...</div>';box.classList.add('is-open');
    var url=((window.VFOS&&VFOS.ajax)||ajaxurl)+'?action=vfos_global_search&nonce='+encodeURIComponent((window.VFOS&&VFOS.nonce)||'')+'&q='+encodeURIComponent(q);
    fetch(url,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(res){
      var rows=res.success?(res.data||[]):[];
      if(!rows.length){box.innerHTML='<div class="vfos-mention-help">Nenhum item encontrado para “'+esc(q)+'”.</div>';return;}
      box.innerHTML=rows.slice(0,10).map(function(r){
        return '<button type="button" class="vfos-mention-result" data-json="'+encodeURIComponent(JSON.stringify(r))+'"><span class="vfos-mention-type">'+esc(r.type||'Item')+'</span><strong>'+esc(r.title||'')+'</strong><small>'+esc(r.meta||'')+'</small></button>';
      }).join('');
    }).catch(function(){box.innerHTML='<div class="vfos-mention-help">Não foi possível pesquisar agora.</div>';});
  }

  function init(){
    var textarea=document.getElementById('vfos-notification-message'),
        box=document.getElementById('vfos-mention-results');
    if(!textarea||!box)return;

    textarea.addEventListener('input',function(){
      var mention=findMention(textarea.value,textarea.selectionStart||0);
      activeQuery=mention;
      clearTimeout(timer);
      if(!mention){box.classList.remove('is-open');box.innerHTML='';return;}
      timer=setTimeout(function(){searchMention(mention.query);},180);
    });

    textarea.addEventListener('keydown',function(e){
      if(e.key==='Escape'){box.classList.remove('is-open');box.innerHTML='';activeQuery=null;}
    });

    box.addEventListener('click',function(e){
      var btn=e.target.closest('.vfos-mention-result');if(!btn||!activeQuery)return;
      var r={};try{r=JSON.parse(decodeURIComponent(btn.getAttribute('data-json')||''));}catch(err){return;}
      var text=textarea.value;
      var mentionText='@'+(r.title||r.type||'Item');
      textarea.value=text.slice(0,activeQuery.start)+mentionText+text.slice(activeQuery.end);
      var pos=activeQuery.start+mentionText.length;
      textarea.focus();textarea.setSelectionRange(pos,pos);
      setLinkedResource(r);
      box.classList.remove('is-open');box.innerHTML='';activeQuery=null;
      textarea.dispatchEvent(new Event('input',{bubbles:true}));
    });

    document.addEventListener('click',function(e){
      if(!e.target.closest('.vfos-mention-editor'))box.classList.remove('is-open');
    });
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* v1.24.0 — Área do Cliente: copiar link */
(function(){
  document.addEventListener('click',function(e){
    var btn=e.target.closest('.vfos-copy-client-portal');if(!btn)return;
    var link=btn.getAttribute('data-link')||'';if(!link)return;
    if(navigator.clipboard&&navigator.clipboard.writeText){
      navigator.clipboard.writeText(link).then(function(){
        var old=btn.textContent;btn.textContent='Link copiado ✓';setTimeout(function(){btn.textContent=old;},1700);
      });
    }else{
      window.prompt('Copie o link da Área do Cliente:',link);
    }
  });
})();


/* v1.30.0 — IA contextual em campos */
(function(){
  function escapeHtml(s){return String(s==null?'':s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
  function contextFor(el){
    var form=el.closest('form')||document;
    var parts=[];
    ['title','name','description','service_interest'].forEach(function(n){
      var x=form.querySelector('[name="'+n+'"]');if(x&&x!==el&&x.value)parts.push(n+': '+x.value);
    });
    var client=form.querySelector('[name="client_id"]');if(client&&client.selectedIndex>0)parts.push('Cliente: '+client.options[client.selectedIndex].text);
    var section=el.closest('.vfos-quote-section-row');if(section){var st=section.querySelector('[name*="[title]"]');if(st&&st.value)parts.push('Título da seção: '+st.value);}
    return parts.join('\n');
  }
  async function runAI(el,box){
    var cmd=box.querySelector('.vfos-ai-command').value.trim();
    if(!cmd){box.querySelector('.vfos-ai-command').focus();return;}
    var provider=box.querySelector('.vfos-ai-provider').value;
    var btn=box.querySelector('.vfos-ai-run'),status=box.querySelector('.vfos-ai-status');
    btn.disabled=true;status.textContent='Gerando...';
    var current='';
    if(el.__vfosTinyMCE){current=el.__vfosTinyMCE.getContent({format:'text'});}
    else current=el.value||'';
    var context=contextFor(el)+'\n\nComando do usuário:\n'+cmd;
    try{
      var fd=new URLSearchParams({action:'vfos_ai_field',nonce:(window.VFOS&&VFOS.nonce)||'',provider:provider,field_type:el.dataset.vfosAi||'generic',context:context,current:current});
      var r=await fetch((window.VFOS&&VFOS.ajax)||ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString(),credentials:'same-origin'});
      var j=await r.json();if(!j.success)throw new Error(typeof j.data==='string'?j.data:'A IA não conseguiu gerar o texto.');
      if(el.__vfosTinyMCE){el.__vfosTinyMCE.setContent(String(j.data.text||'').replace(/\n/g,'<br>'));}
      else{el.value=j.data.text||'';el.dispatchEvent(new Event('input',{bubbles:true}));}
      status.textContent='Texto preenchido com '+(j.data.provider==='gemini'?'Gemini':'OpenRouter')+'.';
      box.classList.remove('is-open');
    }catch(e){status.textContent=e.message||'Erro ao gerar texto.';}finally{btn.disabled=false;}
  }
  function attach(el){
    if(!el||el.dataset.vfosAiAttached)return;el.dataset.vfosAiAttached='1';
    var wrap=document.createElement('div');wrap.className='vfos-ai-field-tools';
    wrap.innerHTML='<button type="button" class="button vfos-ai-open">✦ Preencher com IA</button><div class="vfos-ai-field-popover"><div><strong>VisionForge AI</strong><small>'+escapeHtml(el.dataset.vfosAiLabel||'Gerar texto para este campo')+'</small></div><textarea class="vfos-ai-command" rows="2" placeholder="Diga o que você quer. Ex.: Explique por que uma loja virtual ajuda uma loja de pesca a vender mais, com texto profissional e curto."></textarea><div class="vfos-ai-field-actions"><select class="vfos-ai-provider"><option value="gemini">Gemini</option><option value="openrouter">OpenRouter</option></select><button type="button" class="button button-primary vfos-ai-run">Gerar e preencher</button><button type="button" class="button vfos-ai-cancel">Cancelar</button></div><span class="vfos-ai-status"></span></div>';
    el.insertAdjacentElement('afterend',wrap);
    var pop=wrap.querySelector('.vfos-ai-field-popover');
    wrap.querySelector('.vfos-ai-open').addEventListener('click',()=>pop.classList.toggle('is-open'));
    wrap.querySelector('.vfos-ai-cancel').addEventListener('click',()=>pop.classList.remove('is-open'));
    wrap.querySelector('.vfos-ai-run').addEventListener('click',()=>runAI(el,pop));
  }
  function scan(){
    document.querySelectorAll('textarea').forEach(function(el){
      var n=el.getAttribute('name')||'';
      if(!el.dataset.vfosAi){
        if(/^sections\[.+\]\[content\]$/.test(n)){el.dataset.vfosAi='quote_section';el.dataset.vfosAiLabel='Conteúdo da seção do orçamento';}
        else if(/^items\[.+\]\[description\]$/.test(n)){el.dataset.vfosAi='quote_item_description';el.dataset.vfosAiLabel='Descrição do entregável';}
        else if(n==='payment_terms'){el.dataset.vfosAi='quote_payment_terms';el.dataset.vfosAiLabel='Condições de pagamento';}
        else if(n==='notes'&&el.closest('.vfos-quote-editor')){el.dataset.vfosAi='quote_notes';el.dataset.vfosAiLabel='Observações finais da proposta';}
        else if(n==='description'&&el.closest('.vfos-quote-editor')){el.dataset.vfosAi='quote_intro';el.dataset.vfosAiLabel='Apresentação inicial da proposta';}
      }
      if(el.dataset.vfosAi)attach(el);
    });
  }
  function attachContractEditor(){
    var area=document.querySelector('.vfos-contract-editor-panel textarea[name="content"]');if(!area||area.dataset.vfosAiAttached)return;
    area.dataset.vfosAi='contract_content';area.dataset.vfosAiLabel='Texto do contrato';
    if(window.tinymce){
      var ed=tinymce.get(area.id);if(ed)area.__vfosTinyMCE=ed;
    }
    attach(area);
  }
  function init(){scan();attachContractEditor();new MutationObserver(function(){scan();attachContractEditor();}).observe(document.body,{childList:true,subtree:true});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


/* v1.31.0 — feedback global de carregamento para o PWA/admin */
(function(){
  let pendingAjax=0, ajaxTimer=null, navLocked=false;
  function ensure(){
    if(document.getElementById('vfos-global-loading')) return;
    const el=document.createElement('div');
    el.id='vfos-global-loading';
    el.innerHTML='<div class="vfos-global-loading-bar"></div><div class="vfos-global-loading-card"><div class="vfos-global-spinner"></div><strong>Carregando...</strong><small>O VisionForge OS está processando sua solicitação.</small></div>';
    document.body.appendChild(el);
  }
  function show(mode){
    ensure();const el=document.getElementById('vfos-global-loading');
    el.classList.add('is-visible');el.classList.toggle('is-ajax',mode==='ajax');el.classList.toggle('is-navigation',mode!=='ajax');
  }
  function hide(){
    const el=document.getElementById('vfos-global-loading');if(el)el.classList.remove('is-visible','is-ajax','is-navigation');
    navLocked=false;
  }
  function ajaxStart(){
    pendingAjax++;
    if(pendingAjax===1){clearTimeout(ajaxTimer);ajaxTimer=setTimeout(()=>show('ajax'),180);}
  }
  function ajaxEnd(){
    pendingAjax=Math.max(0,pendingAjax-1);
    if(pendingAjax===0){clearTimeout(ajaxTimer);hide();}
  }

  document.addEventListener('DOMContentLoaded',function(){
    ensure();

    document.addEventListener('submit',function(e){
      const form=e.target;
      if(!(form instanceof HTMLFormElement)||form.dataset.vfosNoLoading==='1')return;
      if(typeof form.checkValidity==='function'&&!form.checkValidity())return;
      const btn=e.submitter||form.querySelector('button[type="submit"],input[type="submit"]');
      if(btn&&!btn.dataset.vfosOriginalText){
        btn.dataset.vfosOriginalText=btn.tagName==='INPUT'?btn.value:btn.textContent;
        if(btn.tagName==='INPUT')btn.value='Processando...';else btn.innerHTML='<span class="vfos-btn-spinner"></span> Processando...';
      }
      show('navigation');
    },true);

    // Não mostramos o overlay apenas no clique. Alguns botões/links internos
    // são tratados por JavaScript e podem cancelar a navegação; antes isso
    // deixava "Carregando..." preso na tela mesmo sem troca de página.
    window.addEventListener('pageshow',hide);
    window.addEventListener('pagehide',()=>show('navigation'));
    window.addEventListener('beforeunload',()=>show('navigation'));

    // Proteção adicional: nenhum overlay de navegação pode ficar preso.
    setInterval(()=>{
      const el=document.getElementById('vfos-global-loading');
      if(el&&el.classList.contains('is-navigation')&&document.visibilityState==='visible')hide();
    },5000);
  });

  if(window.fetch){
    const nativeFetch=window.fetch;
    window.fetch=function(){ajaxStart();return nativeFetch.apply(this,arguments).finally(ajaxEnd);}
  }
  if(window.XMLHttpRequest){
    const NativeXHR=window.XMLHttpRequest;
    const open=NativeXHR.prototype.open,send=NativeXHR.prototype.send;
    NativeXHR.prototype.open=function(){this.__vfosTrack=true;return open.apply(this,arguments);}
    NativeXHR.prototype.send=function(){if(this.__vfosTrack){ajaxStart();this.addEventListener('loadend',ajaxEnd,{once:true});}return send.apply(this,arguments);}
  }
  window.VFOSLoading={show:show,hide:hide};
})();

/* v1.32.0 — modo offline-first, sincronização local e app rápido */
(function(){
  // v1.32.7: módulo offline interativo temporariamente isolado para não interferir
  // na navegação normal do VisionForge. O Service Worker continua registrável,
  // mas nenhum listener de clique/formulário/modo é instalado por este módulo.
  try{ document.documentElement.dataset.vfosMode='online'; }catch(e){}
})();
