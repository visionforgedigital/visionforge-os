<?php
if (!defined('ABSPATH')) exit;
class VFOS_Admin {
    private static $instance;
    public static function instance(){ return self::$instance ?: (self::$instance=new self()); }
    private function __construct(){
        add_action('admin_menu',[$this,'menu']); add_action('admin_enqueue_scripts',[$this,'assets']);
        add_action('wp_ajax_vfos_global_search',[$this,'ajax_global_search']); add_action('wp_ajax_vfos_ai_ask',[$this,'ajax_ai']); add_action('wp_ajax_vfos_ai_field',[$this,'ajax_ai_field']); add_action('wp_ajax_vfos_ai_history',[$this,'ajax_ai_history']); add_action('wp_ajax_vfos_ai_test',[$this,'ajax_ai_test']); add_action('wp_ajax_vfos_ai_execute',[$this,'ajax_ai_execute']); add_action('wp_ajax_vfos_sign_callback',[$this,'sign_callback']); add_action('wp_ajax_nopriv_vfos_sign_callback',[$this,'sign_callback']);
        foreach(['settings','company_info','client','service','project','financial','task','quote','contract','lead'] as $x) add_action('admin_post_vfos_save_'.$x,[$this,'save_'.$x]);
        foreach(['client','project','task','quote','contract','lead','financial'] as $x) add_action('admin_post_vfos_delete_'.$x,[$this,'delete_'.$x]);
        add_action('admin_post_vfos_save_quote_template',[$this,'save_quote_template']); add_action('admin_post_vfos_update_quote_template',[$this,'update_quote_template']); add_action('admin_post_vfos_delete_quote_template',[$this,'delete_quote_template']); add_action('admin_post_vfos_quote_to_contract',[$this,'quote_to_contract']); add_action('admin_post_vfos_send_quote',[$this,'send_quote']); add_action('admin_post_vfos_send_sign',[$this,'send_sign']); add_action('admin_post_vfos_sign_sync',[$this,'sign_sync']); add_action('admin_post_vfos_sign_invite',[$this,'sign_invite']); add_action('admin_post_vfos_lead_stage',[$this,'lead_stage']); add_action('admin_post_vfos_convert_lead',[$this,'convert_lead']); add_action('admin_post_vfos_save_client_note',[$this,'save_client_note']); add_action('admin_post_vfos_upload_client_file',[$this,'upload_client_file']); add_action('admin_post_vfos_delete_client_file',[$this,'delete_client_file']);
        add_action('admin_post_vfos_save_project_comment',[$this,'save_project_comment']);
        add_action('admin_post_vfos_save_project_stage',[$this,'save_project_stage']);
        add_action('admin_post_vfos_delete_project_stage',[$this,'delete_project_stage']);
        add_action('admin_post_vfos_save_project_approval',[$this,'save_project_approval']);
        add_action('admin_post_vfos_save_project_presentation',[$this,'save_project_presentation']);
        add_action('admin_post_vfos_project_presentation_pdf',[$this,'project_presentation_pdf']);
        add_action('admin_post_vfos_send_project_presentation',[$this,'send_project_presentation']);
        add_action('admin_post_vfos_delete_project_approval',[$this,'delete_project_approval']); add_action('admin_post_vfos_toggle_project_approval_release',[$this,'toggle_project_approval_release']);
        add_action('admin_post_vfos_upload_project_file',[$this,'upload_project_file']);
        add_action('admin_post_vfos_delete_project_file',[$this,'delete_project_file']);
        add_action('admin_post_vfos_add_checklist_item',[$this,'add_checklist_item']);
        add_action('admin_post_vfos_toggle_checklist_item',[$this,'toggle_checklist_item']);
        add_action('admin_post_vfos_delete_checklist_item',[$this,'delete_checklist_item']);
        add_action('wp_ajax_vfos_task_status',[$this,'ajax_task_status']);
        add_action('admin_post_vfos_save_calendar_event',[$this,'save_calendar_event']);
        add_action('admin_post_vfos_save_financial_split',[$this,'save_financial_split']); add_action('admin_post_vfos_add_financial_payment',[$this,'add_financial_payment']); add_action('admin_post_vfos_delete_financial_payment',[$this,'delete_financial_payment']);
        add_action('admin_post_vfos_mark_notification',[$this,'mark_notification']);
        add_action('admin_post_vfos_send_notification',[$this,'send_notification']);
        add_action('admin_post_vfos_save_notification_preferences',[$this,'save_notification_preferences']);
        add_action('wp_ajax_vfos_payment_live',[$this,'ajax_payment_live']);
        add_action('admin_post_vfos_reply_notification',[$this,'reply_notification']);
        add_action('admin_post_vfos_delete_sent_notification',[$this,'delete_sent_notification']);
        add_action('admin_post_vfos_mark_all_notifications',[$this,'mark_all_notifications']);
        add_action('admin_post_vfos_delete_calendar_event',[$this,'delete_calendar_event']);
        add_action('admin_post_vfos_save_team_member',[$this,'save_team_member']);
        add_action('admin_post_vfos_save_team_group',[$this,'save_team_group']);
        add_action('admin_post_vfos_delete_team_group',[$this,'delete_team_group']);
        add_action('admin_post_vfos_save_group_members',[$this,'save_group_members']);
        add_action('admin_post_vfos_delete_team_member',[$this,'delete_team_member']);
        add_action('admin_post_vfos_save_project_template',[$this,'save_project_template']);
        add_action('admin_post_vfos_delete_project_template',[$this,'delete_project_template']);
        add_action('admin_post_vfos_apply_project_template',[$this,'apply_project_template']);
        add_action('admin_post_vfos_save_contract_template',[$this,'save_contract_template']);
        add_action('admin_post_vfos_delete_contract_template',[$this,'delete_contract_template']);
        add_action('admin_post_vfos_contract_pdf',[$this,'contract_pdf']);
        add_action('admin_post_vfos_desktop_download',[$this,'desktop_download']);
    }
    public function menu(){
        $c='vfos_access';
        add_menu_page('VisionForge OS','VisionForge OS',$c,'vfos',[$this,'dashboard'],'dashicons-chart-area',2);
        $items=[
            ['Dashboard','vfos','dashboard','dashboard'],
            ['Leads / CRM','vfos-leads','leads','crm'],
            ['Clientes','vfos-clients','clients','clients'],
            ['Serviços','vfos-services','services','services'],
            ['Orçamentos','vfos-quotes','quotes','quotes'],
            ['Projetos','vfos-projects','projects','projects'],
            ['Modelos de Projeto','vfos-project-templates','project_templates','projects'],
            ['Tarefas','vfos-tasks','tasks','tasks'],
            ['Agenda','vfos-calendar','calendar','calendar'],
            ['Financeiro','vfos-financial','financial','financial'],
            ['Contratos','vfos-contracts','contracts','contracts'],
            ['VisionForge Sign','vfos-sign','sign_page','sign'],
            ['Notificações'.(class_exists('VFOS_Notifications')&&VFOS_Notifications::unread_count()?'<span class="awaiting-mod count-'.VFOS_Notifications::unread_count().'"><span class="pending-count">'.VFOS_Notifications::unread_count().'</span></span>':''),'vfos-notifications','notifications','notifications'],
            ['Auditoria','vfos-audit','audit','audit'],
            ['Relatórios','vfos-reports','reports','reports'],
            ['Automações','vfos-automations','automations','automations'],
            ['Equipe','vfos-team','team','team'],
            ['VisionForge AI','vfos-ai','ai_page','ai'],
            ['Dados da VisionForge','vfos-company','company_info','company'],
            ['Configurações','vfos-settings','settings','settings'],
            ['Aplicativo','vfos-app','app_page','dashboard'],
            ['Tutorial','vfos-tutorial','tutorial','dashboard']
        ];
        foreach($items as $i) if(VFOS_Team::can($i[3]) && !($i[1]==='vfos-project-templates' && VFOS_Team::limited_to_assigned())) add_submenu_page('vfos',$i[0],$i[0],$c,$i[1],[$this,$i[2]]);
        if(VFOS_Team::can('clients')) add_submenu_page(null,'Cliente 360°','Cliente 360°',$c,'vfos-client-view',[$this,'client_view']);
        if(VFOS_Team::can('projects')) add_submenu_page(null,'Projeto','Projeto',$c,'vfos-project-view',[$this,'project_view']);
    }

    public function assets($hook){ if(strpos($hook,'vfos')===false&&strpos($hook,'visionforge-os')===false)return; wp_enqueue_style('vfos-admin',VFOS_URL.'admin/assets/css/admin.css',[],VFOS_VERSION);wp_enqueue_script('vfos-admin',VFOS_URL.'admin/assets/js/admin.js',['jquery'],VFOS_VERSION,true);wp_localize_script('vfos-admin','VFOS',['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('vfos_ajax'),'version'=>VFOS_VERSION]); }
    private function header($title,$subtitle=''){ echo '<div class="wrap vfos-wrap"><div class="vfos-top"><div><div class="vfos-brand"><span class="vfos-mark">VF</span><span>VISIONFORGE <b>OS</b></span></div><h1>'.esc_html($title).'</h1>'.($subtitle?'<p>'.esc_html($subtitle).'</p>':'').'</div><div class="vfos-top-actions"><button type="button" id="vfos-connectivity-trigger" class="vfos-connectivity-trigger" aria-expanded="false"><i></i><span id="vfos-connectivity-label">Conectando…</span><b id="vfos-offline-queue-count" hidden>0</b></button><div id="vfos-connectivity-popover" class="vfos-connectivity-popover" hidden><strong>Modo de conexão</strong><p>Escolha como o aplicativo deve trabalhar neste dispositivo.</p><div class="vfos-mode-buttons"><button type="button" data-vfos-mode="auto">Automático</button><button type="button" data-vfos-mode="online">Online</button><button type="button" data-vfos-mode="offline">Offline</button></div><small id="vfos-connectivity-detail">Verificando conexão…</small><button type="button" id="vfos-sync-now" class="button">Sincronizar agora</button></div><div class="vfos-global-search"><input id="vfos-global-search" autocomplete="off" placeholder="Pesquisar no VisionForge OS..."><span class="vfos-search-key">Ctrl K</span><div id="vfos-global-results" class="vfos-global-results"></div></div><span class="vfos-version">v'.esc_html(VFOS_VERSION).'</span></div></div>'; if(!empty($_GET['vfos_msg'])) echo '<div class="vfos-notice">'.esc_html(wp_unslash($_GET['vfos_msg'])).'</div>'; }
    private function end(){echo '</div>';}
    private function card($label,$value,$meta){echo '<div class="vfos-card"><span>'.esc_html($label).'</span><strong>'.esc_html($value).'</strong><small>'.esc_html($meta).'</small></div>';}
    private function form_start($action){echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="'.esc_attr($action).'">';wp_nonce_field($action);}
    private function clients_options($selected=0){global $wpdb;$rows=$wpdb->get_results('SELECT id,name FROM '.VFOS_DB::table('clients')." WHERE status='active' ORDER BY name");echo '<option value="0">Selecione</option>';foreach($rows as $r)echo '<option value="'.$r->id.'" '.selected($selected,$r->id,false).'>'.esc_html($r->name).'</option>';}
    private function status_label($s){$m=['active'=>'Ativo','inactive'=>'Inativo','planning'=>'Planejamento','in_progress'=>'Em andamento','review'=>'Em aprovação','completed'=>'Concluído','pending'=>'Pendente','pending_authorization'=>'Aguardando autorização','paused'=>'Pausada','partial'=>'Parcialmente pago','done'=>'Concluída','draft'=>'Rascunho','sent'=>'Enviado','accepted'=>'Aceito','rejected'=>'Recusado','paid'=>'Pago','cancelled'=>'Cancelado','pending_signature'=>'Aguardando assinatura','signed'=>'Assinado','new'=>'Novo lead','contacted'=>'Contato realizado','qualified'=>'Qualificado','proposal'=>'Orçamento enviado','negotiation'=>'Negociação','won'=>'Ganho','lost'=>'Perdido'];return $m[$s]??$s;}

    private function module_tab($page,$tab,$label,$active,$extra=[]){$url=add_query_arg(array_merge(['page'=>$page,'tab'=>$tab],$extra),admin_url('admin.php'));echo '<a class="vfos-tab '.($active===$tab?'active':'').'" href="'.esc_url($url).'">'.esc_html($label).'</a>';}
    private function module_tabs($page,$active,$new_label='Novo cadastro',$extra_tabs=[]){echo '<nav class="vfos-tabs">';$this->module_tab($page,'list','Visualização',$active);$this->module_tab($page,'new',$new_label,$active);foreach($extra_tabs as $k=>$v)$this->module_tab($page,$k,$v,$active);echo '</nav>';}
    private function filter_start($page){echo '<form class="vfos-filters" method="get"><input type="hidden" name="page" value="'.esc_attr($page).'"><input type="hidden" name="tab" value="list">';}
    private function filter_end(){echo '<div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Filtrar</button><a class="button" href="'.esc_url(admin_url('admin.php?page='.sanitize_key($_GET['page']??'vfos'))).'">Limpar</a></div></form>';}
    private function q($key){return sanitize_text_field(wp_unslash($_GET[$key]??''));}
    private function client_filter_select($selected=0,$all_label='Todos os clientes'){global $wpdb;$rows=$wpdb->get_results('SELECT id,name FROM '.VFOS_DB::table('clients').' ORDER BY name');echo '<option value="0">'.esc_html($all_label).'</option>';foreach($rows as $r)echo '<option value="'.$r->id.'" '.selected($selected,$r->id,false).'>'.esc_html($r->name).'</option>';}

    public function ajax_global_search(){
        check_ajax_referer('vfos_ajax','nonce');global $wpdb;
        $q=sanitize_text_field(wp_unslash($_GET['q']??$_POST['q']??''));
        if(mb_strlen($q)<2)wp_send_json_success([]);
        $like='%'.$wpdb->esc_like($q).'%';$out=[];
        $add=function($module,$type,$title,$meta,$url,$id)use(&$out){$out[]=['module'=>$module,'type'=>$type,'title'=>$title,'meta'=>$meta,'url'=>$url,'id'=>(int)$id];};
        if(VFOS_Team::can('clients'))foreach($wpdb->get_results($wpdb->prepare("SELECT id,name,email,document FROM ".VFOS_DB::table('clients')." WHERE name LIKE %s OR email LIKE %s OR document LIKE %s ORDER BY id DESC LIMIT 6",$like,$like,$like)) as $r)$add('clients','Cliente',$r->name,trim(($r->email?:'').' '.($r->document?:'')),admin_url('admin.php?page=vfos-client-view&id='.$r->id),$r->id);
        if(VFOS_Team::can('projects'))foreach($wpdb->get_results($wpdb->prepare("SELECT id,name,status FROM ".VFOS_DB::table('projects')." WHERE name LIKE %s OR notes LIKE %s ORDER BY id DESC LIMIT 6",$like,$like)) as $r)$add('projects','Projeto',$r->name,$this->status_label($r->status),admin_url('admin.php?page=vfos-project-view&id='.$r->id),$r->id);
        if(VFOS_Team::can('tasks'))foreach($wpdb->get_results($wpdb->prepare("SELECT id,title,status,due_date FROM ".VFOS_DB::table('tasks')." WHERE title LIKE %s OR description LIKE %s ORDER BY id DESC LIMIT 6",$like,$like)) as $r)$add('tasks','Tarefa',$r->title,$this->status_label($r->status).($r->due_date?' • '.date_i18n('d/m/Y',strtotime($r->due_date)):''),admin_url('admin.php?page=vfos-tasks&tab=new&edit='.$r->id),$r->id);
        if(VFOS_Team::can('quotes'))foreach($wpdb->get_results($wpdb->prepare("SELECT id,number,title,status,total FROM ".VFOS_DB::table('quotes')." WHERE number LIKE %s OR title LIKE %s OR description LIKE %s ORDER BY id DESC LIMIT 6",$like,$like,$like)) as $r)$add('quotes','Orçamento',$r->number.' — '.$r->title,$this->status_label($r->status).' • R$ '.number_format((float)$r->total,2,',','.'),admin_url('admin.php?page=vfos-quotes&tab=new&edit='.$r->id),$r->id);
        if(VFOS_Team::can('contracts'))foreach($wpdb->get_results($wpdb->prepare("SELECT id,number,title,status,value FROM ".VFOS_DB::table('contracts')." WHERE number LIKE %s OR title LIKE %s OR content LIKE %s ORDER BY id DESC LIMIT 6",$like,$like,$like)) as $r)$add('contracts','Contrato',$r->number.' — '.$r->title,$this->status_label($r->status).' • R$ '.number_format((float)$r->value,2,',','.'),admin_url('admin.php?page=vfos-contracts&tab=new&edit='.$r->id),$r->id);
        if(VFOS_Team::can('financial'))foreach($wpdb->get_results($wpdb->prepare("SELECT id,description,type,status,amount,paid_amount FROM ".VFOS_DB::table('financial')." WHERE description LIKE %s ORDER BY id DESC LIMIT 6",$like)) as $r)$add('financial','Financeiro',$r->description,($r->type==='income'?'Receita':'Saída').' • R$ '.number_format((float)$r->amount,2,',','.'),admin_url('admin.php?page=vfos-financial'),$r->id);
        if(VFOS_Team::can('crm'))foreach($wpdb->get_results($wpdb->prepare("SELECT id,name,email,company,stage FROM ".VFOS_DB::table('leads')." WHERE name LIKE %s OR email LIKE %s OR company LIKE %s ORDER BY id DESC LIMIT 6",$like,$like,$like)) as $r)$add('crm','Lead',$r->name,trim(($r->company?:'').' • '.$this->status_label($r->stage)),admin_url('admin.php?page=vfos-leads'),$r->id);
        wp_send_json_success(array_slice($out,0,24));
    }

    public function app_page(){
        VFOS_Team::require_permission('dashboard.view');
        $this->header('Aplicativo VisionForge OS','Tenha o VisionForge instalado no computador, conectado ao seu sistema WordPress.');
        $download=wp_nonce_url(admin_url('admin-post.php?action=vfos_desktop_download'),'vfos_desktop_download');
        $desktop_version='0.16.0';
        $exe_path=VFOS_DIR.'desktop-app/VisionForge-OS-Setup-'.$desktop_version.'.exe';
        $exe_exists=file_exists($exe_path);
        $download_label=$exe_exists?'↓ Baixar instalador do VisionForge OS':'↓ Instalador Windows em preparação';
        $release_status=$exe_exists?'Instalador Windows disponível':'O instalador Windows ainda não foi publicado. O pacote de desenvolvimento não será entregue como instalador.';
        echo '<div class="vfos-app-hero"><div class="vfos-app-icon-wrap"><img src="'.esc_url(VFOS_URL.'admin/assets/images/vfos-app-192-v2.png').'" alt="VisionForge OS"></div><div><span class="vfos-kicker">VISIONFORGE OS DESKTOP</span><h2>Seu sistema instalado no computador</h2><p>O aplicativo desktop é uma interface independente do navegador, conectada ao mesmo VisionForge OS instalado no WordPress. A base oficial continua sendo o banco MySQL do sistema.</p><div class="vfos-app-actions">'.($exe_exists?'<a class="button button-primary vfos-btn" href="'.esc_url($download).'">'.esc_html($download_label).'</a>':'<button type="button" class="button button-primary vfos-btn" disabled>'.esc_html($download_label).'</button>').'<button id="vfos-install-app" type="button" class="button">Instalar versão web</button></div><div class="vfos-app-status">Windows 10/11 • Desktop VisionForge OS • '.esc_html($release_status).'</div></div></div>';

        echo '<div class="vfos-grid vfos-grid-3 vfos-app-benefits"><div class="vfos-panel"><span class="vfos-kicker">CONECTADO AO WORDPRESS</span><h3>Mesmo sistema, outra interface</h3><p>O desktop será conectado ao VisionForge OS por uma API própria. Clientes, projetos, orçamentos, contratos, financeiro e permissões continuam centralizados no WordPress.</p></div><div class="vfos-panel"><span class="vfos-kicker">OFFLINE DE VERDADE</span><h3>Banco local no computador</h3><p>A versão desktop terá armazenamento local para permitir trabalho sem internet. Quando a conexão voltar, as alterações serão sincronizadas com o servidor.</p></div><div class="vfos-panel"><span class="vfos-kicker">SINCRONIZAÇÃO</span><h3>Envio automático das alterações</h3><p>As operações feitas enquanto estiver offline ficam em uma fila local e são enviadas ao VisionForge quando a internet estiver disponível novamente.</p></div></div>';

        echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">APLICATIVO DESKTOP</span><h2>Como vai funcionar</h2><p>O aplicativo e o sistema WordPress fazem parte do mesmo VisionForge OS.</p></div></div><div class="vfos-grid vfos-grid-3"><article><strong>01 · Online</strong><p>O aplicativo consulta e grava os dados no VisionForge OS normalmente.</p></article><article><strong>02 · Sem internet</strong><p>O desktop usa o banco local e continua permitindo as operações compatíveis com o modo offline.</p></article><article><strong>03 · Internet voltou</strong><p>A fila de alterações é enviada para a API e o servidor atualiza o banco oficial.</p></article></div></div>';

        echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VERSÃO WEB</span><h2>Também pode instalar como aplicativo</h2><p>Se estiver no Chrome ou Edge, você ainda pode instalar a versão web no dispositivo. Isso é separado do aplicativo desktop instalado no computador.</p></div></div><div class="vfos-app-actions"><button type="button" class="button button-primary vfos-btn" onclick="document.getElementById(\'vfos-install-app\')?.click()">Instalar VisionForge OS Web</button><button id="vfos-open-app" type="button" class="button" style="display:none">Abrir aplicativo</button></div><div id="vfos-app-status" class="vfos-app-status">Verificando compatibilidade deste dispositivo...</div></div>';

        echo '<div class="vfos-panel vfos-app-security"><span class="vfos-kicker">ARQUITETURA</span><h3>O banco oficial continua sendo o WordPress</h3><p>O aplicativo desktop não cria um segundo sistema. Ele usa uma base local apenas como apoio para o modo offline e sincroniza com a base oficial do VisionForge OS.</p><p><strong>Serviços que dependem da internet:</strong> Mercado Pago, envio de e-mails, VisionForge AI, webhooks, assinatura online e outras integrações externas.</p></div>';
        $this->end();
    }

    public function desktop_download(){
        if(!current_user_can('vfos_access')) wp_die('Sem permissão para baixar o aplicativo.');
        check_admin_referer('vfos_desktop_download');
        $exe=VFOS_DIR.'desktop-app/VisionForge-OS-Setup-0.16.0.exe';
        if(!file_exists($exe)) wp_die('O instalador Windows do VisionForge OS ainda não foi publicado. Volte a esta página após a publicação da nova versão.');
        $file=$exe;
        $is_exe=(substr($file,-4)==='.exe');
        nocache_headers();
        header('Content-Type: '.($is_exe?'application/vnd.microsoft.portable-executable':'application/zip'));
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Content-Length: '.filesize($file));
        readfile($file);
        exit;
    }

    public function tutorial(){
        VFOS_Team::require_permission('dashboard.view');
        $this->header('Tutorial do VisionForge OS','Manual personalizado conforme as permissões do seu usuário.');
        $modules=[
            'dashboard'=>['Dashboard','Sua página inicial. Resume somente as áreas que seu usuário pode acompanhar.','Use os indicadores e atalhos para chegar rapidamente às rotinas liberadas para você.'],
            'crm'=>['Leads / CRM','Organiza pessoas e empresas que ainda estão em negociação com a VisionForge.','Cadastre leads, registre contatos, acompanhe o estágio do funil e converta o lead em cliente quando a negociação for concluída.'],
            'clients'=>['Clientes','Centraliza os dados completos dos clientes PF e PJ, responsáveis, contatos, documentos, observações e arquivos.','Use a visualização para localizar clientes e os filtros para refinar a lista. Abra o Cliente 360° para consultar o relacionamento completo.'],
            'services'=>['Serviços','Mantém o catálogo de serviços da VisionForge para reaproveitar informações em propostas e projetos.','Cadastre serviços padrões com informações e valores de referência para agilizar novos trabalhos.'],
            'quotes'=>['Orçamentos','Cria e acompanha propostas comerciais enviadas aos clientes.','Monte os itens, valores, descontos e condições. Depois acompanhe o status e, quando aplicável, converta o orçamento em projeto ou contrato.'],
            'projects'=>['Projetos','É a área operacional dos trabalhos vendidos pela VisionForge.','Cadastre o projeto, vincule cliente e serviço, acompanhe etapas, tarefas, arquivos, comentários e aprovações. Use apresentações quando precisar mostrar ao cliente o que está incluso.'],
            'tasks'=>['Tarefas','Organiza atividades, responsáveis, prioridades, prazos e checklists.','Use os filtros para encontrar suas tarefas e atualize o andamento conforme o trabalho evoluir.'],
            'calendar'=>['Agenda','Reúne compromissos, reuniões, prazos e eventos ligados à operação.','Crie eventos com data, horário e vínculos disponíveis. Consulte a agenda antes de organizar novas atividades.'],
            'financial'=>['Financeiro','Controla receitas, despesas, pagamentos pendentes e recebimentos.','Registre os lançamentos corretamente e atualize o status quando houver pagamento ou recebimento.'],
            'contracts'=>['Contratos','Cria contratos editáveis, modelos reutilizáveis e PDFs vinculados aos clientes e projetos.','Escreva ou carregue o conteúdo necessário, formate o contrato, salve modelos quando fizer sentido e encaminhe para assinatura pelo VF Sign quando autorizado.'],
            'sign'=>['VisionForge Sign','Integra o VisionForge OS ao assinador eletrônico da VisionForge.','Crie documentos, gerencie signatários e campos de assinatura, envie convites e acompanhe os documentos conforme as permissões liberadas ao seu usuário.'],
            'notifications'=>['Notificações','É a comunicação interna do VisionForge OS. Pode receber avisos, enviar mensagens e manter conversas quando a resposta estiver habilitada.','Abra Minha central para ler seus avisos. Se puder enviar, escolha pessoa ou grupo, escreva a mensagem e defina se aceita respostas. A aba Enviadas mostra os seus envios e conversas.'],
            'audit'=>['Auditoria','Registra ações relevantes realizadas dentro do sistema.','Use para conferir quem realizou determinada ação, quando ocorreu e quais informações foram registradas pelo sistema.'],
            'reports'=>['Relatórios','Consolida informações operacionais e gerenciais do VisionForge OS.','Escolha os dados disponíveis ao seu perfil, aplique os filtros e exporte somente quando sua permissão permitir.'],
            'automations'=>['Automações','Permite configurar rotinas automáticas do sistema.','Consulte as automações existentes e, se tiver permissão de gerenciamento, crie ou ajuste rotinas para reduzir tarefas repetitivas.'],
            'team'=>['Equipe','Gerencia usuários internos, cargos, grupos e permissões do VisionForge OS.','Use os grupos para separar áreas como Financeiro, Comercial e Criação. Permissões podem ser globais ou limitadas a grupos específicos.'],
            'company'=>['Dados da VisionForge','Centraliza os dados institucionais que aparecem automaticamente nas propostas comerciais.','Cadastre nome, documento, contatos, endereço, redes sociais e responsáveis. Altere uma vez e os orçamentos passam a usar os dados atualizados.'],
            'ai'=>['VisionForge AI','Assistente de inteligência artificial integrado ao sistema, com os provedores configurados pela VisionForge.','Converse com a IA no formato de chat. Use-a para auxiliar nas atividades disponíveis e revise qualquer conteúdo antes de utilizá-lo oficialmente.'],
            'settings'=>['Configurações','Reúne configurações administrativas e integrações do VisionForge OS.','Altere somente o que estiver sob sua responsabilidade, especialmente integrações e credenciais.']
        ];
        $perms=VFOS_Team::permissions();
        echo '<div class="vfos-tutorial-hero"><div><span class="vfos-kicker">MANUAL INTELIGENTE</span><h2>Olá, '.esc_html(wp_get_current_user()->display_name).'. Este tutorial foi montado para o seu acesso.</h2><p>Você verá abaixo apenas módulos e ações que realmente estão liberados para sua conta. Se uma permissão for removida depois, a explicação correspondente também desaparece automaticamente.</p></div><div class="vfos-tutorial-shield"><strong>'.count(array_filter(array_keys($modules),fn($m)=>VFOS_Team::can($m))).'</strong><span>áreas disponíveis</span></div></div>';
        echo '<div class="vfos-tutorial-nav">';
        foreach($modules as $m=>$info)if(VFOS_Team::can($m))echo '<a href="#tutorial-'.$m.'">'.esc_html($info[0]).'</a>';
        echo '</div><div class="vfos-tutorial-list">';
        $n=0;
        foreach($modules as $module=>$info){
            if(!VFOS_Team::can($module))continue;$n++;
            echo '<section id="tutorial-'.$module.'" class="vfos-tutorial-section"><div class="vfos-tutorial-number">'.str_pad((string)$n,2,'0',STR_PAD_LEFT).'</div><div class="vfos-tutorial-body"><span class="vfos-kicker">COMO FUNCIONA</span><h2>'.esc_html($info[0]).'</h2><p class="vfos-tutorial-purpose">'.esc_html($info[1]).'</p><div class="vfos-tutorial-how"><strong>Como usar</strong><p>'.esc_html($info[2]).'</p></div>';
            $available=[];
            foreach(($perms[$module]??[]) as $action=>$label)if(VFOS_Team::can_permission($module.'.'.$action))$available[$module.'.'.$action]=$label;
            if($available){
                echo '<div class="vfos-tutorial-permissions"><strong>O que você pode fazer nesta área</strong><div>';
                foreach($available as $key=>$label){
                    $scopes=VFOS_Team::permission_scope_groups($key);$scope_text='';
                    if($scopes){$names=[];foreach(VFOS_Team::groups(true) as $g)if(in_array((int)$g->id,$scopes,true))$names[]=$g->name;if($names)$scope_text=' • somente '.implode(', ',$names);}
                    echo '<span><b>✓</b>'.esc_html($label.$scope_text).'</span>';
                }
                echo '</div></div>';
            }
            echo '</div></section>';
        }
        echo '</div><div class="vfos-panel vfos-tutorial-footer"><strong>Seu acesso mudou?</strong><p>Não é necessário atualizar este manual manualmente. Ele lê as permissões atuais da sua conta sempre que a página é aberta.</p></div>';
        $this->end();
    }

    public function dashboard(){
        VFOS_Team::require_permission('dashboard.view');global $wpdb;
        $uid=get_current_user_id();$user=wp_get_current_user();$profile=VFOS_Team::profile($uid);$limited=VFOS_Team::limited_to_assigned();$s=VFOS_DB::dashboard_stats();
        $first=$user->first_name?:explode(' ',$user->display_name)[0];
        $role_label='Equipe VisionForge';if($profile){$presets=VFOS_Team::presets();$role_label=$profile->job_title?:($presets[$profile->role_key]['label']??'Equipe VisionForge');}
        $this->header('Olá, '.$first,'Seu painel foi montado de acordo com as suas funções e permissões.');

        echo '<div class="vfos-user-dashboard-hero"><div><span class="vfos-user-avatar">'.esc_html(strtoupper(mb_substr($user->display_name,0,2))).'</span><div><span class="vfos-kicker">SEU AMBIENTE VISIONFORGE</span><h2>'.esc_html($user->display_name).'</h2><p>'.esc_html($role_label).($profile&&$profile->department?' • '.esc_html($profile->department):'').'</p></div></div><div class="vfos-user-dashboard-date"><small>Hoje</small><strong>'.esc_html(date_i18n('d/m/Y')).'</strong><span>'.esc_html(date_i18n('l')).'</span></div></div>';

        echo '<div class="vfos-grid vfos-grid-4 vfos-personal-stats">';
        if(VFOS_Team::can('tasks')){
            $mine=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('tasks')." WHERE assigned_user_id=%d AND status NOT IN ('done','cancelled')",$uid));
            $late=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('tasks')." WHERE assigned_user_id=%d AND due_date<CURDATE() AND status NOT IN ('done','cancelled')",$uid));
            $this->card('Minhas tarefas',$mine,$late?$late.' vencida(s)':'Tudo em dia');
        }
        if(VFOS_Team::can('projects')){
            $projects=$limited?(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT project_id) FROM ".VFOS_DB::table('tasks')." WHERE assigned_user_id=%d AND project_id>0",$uid)):$s['projects'];
            $this->card($limited?'Meus projetos':'Projetos ativos',$projects,$limited?'Atribuídos a você':'Em andamento');
        }
        if(VFOS_Team::can('calendar')){
            $today_events=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('calendar_events')." WHERE DATE(start_at)=CURDATE() AND status NOT IN ('done','cancelled') AND (assigned_user_id=0 OR assigned_user_id=%d)",$uid));
            $this->card('Agenda de hoje',$today_events,'Compromisso(s)');
        }
        if(VFOS_Team::can('notifications')){
            $this->card('Notificações',class_exists('VFOS_Notifications')?VFOS_Notifications::unread_count($uid):0,'Não lidas');
        }
        if(VFOS_Team::can('crm')){$this->card('Leads abertos',$s['leads'],'Pipeline comercial');$this->card('Pipeline','R$ '.number_format($s['pipeline_value'],2,',','.'),'Valor estimado');}
        if(VFOS_Team::can('clients')&&!$limited)$this->card('Clientes',$s['clients'],'Ativos');
        if(VFOS_Team::can('quotes'))$this->card('Orçamentos',$s['quotes'],'Em aberto');
        if(VFOS_Team::can('financial')){$cash=VFOS_DB::financial_cash_stats();$this->card('Faturamento no mês','R$ '.number_format($s['received'],2,',','.'),'Recebido');$this->card('Saldo em caixa','R$ '.number_format($cash['cash'],2,',','.'),'Após despesas e retiradas');$this->card('A receber','R$ '.number_format($s['receivable'],2,',','.'),'Pendente');}
        if(VFOS_Team::can('contracts'))$this->card('Contratos',$s['contracts'],'Em andamento');
        echo '</div>';

        $quick=[];
        if(VFOS_Team::can_permission('crm.create'))$quick[]=['Novo lead','Cadastrar oportunidade','vfos-leads&tab=new','dashicons-megaphone'];
        if(VFOS_Team::can_permission('clients.create'))$quick[]=['Novo cliente','Cadastrar PF ou PJ','vfos-clients&tab=new','dashicons-groups'];
        if(VFOS_Team::can_permission('quotes.create'))$quick[]=['Novo orçamento','Criar proposta comercial','vfos-quotes&tab=new','dashicons-media-text'];
        if(VFOS_Team::can_permission('projects.create'))$quick[]=['Novo projeto','Iniciar projeto VisionForge','vfos-projects&tab=new','dashicons-portfolio'];
        if(VFOS_Team::can_permission('tasks.create'))$quick[]=['Nova tarefa','Organizar uma entrega','vfos-tasks&tab=new','dashicons-yes-alt'];
        if(VFOS_Team::can_permission('calendar.create'))$quick[]=['Novo compromisso','Adicionar à agenda','vfos-calendar&tab=new','dashicons-calendar-alt'];
        if(VFOS_Team::can_permission('contracts.create'))$quick[]=['Novo contrato','Criar documento','vfos-contracts&tab=new','dashicons-media-document'];
        if(VFOS_Team::can_permission('financial.create'))$quick[]=['Novo lançamento','Registrar financeiro','vfos-financial&tab=new','dashicons-money-alt'];
        if($quick){
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">ATALHOS</span><h2>O que você pode fazer</h2><p>Somente ações liberadas para o seu usuário aparecem aqui.</p></div></div><div class="vfos-dashboard-quick">';
            foreach($quick as $q)echo '<a href="'.esc_url(admin_url('admin.php?page='.$q[2])).'"><span class="dashicons '.esc_attr($q[3]).'"></span><div><strong>'.esc_html($q[0]).'</strong><small>'.esc_html($q[1]).'</small></div><b>→</b></a>';
            echo '</div></div>';
        }

        echo '<div class="vfos-grid vfos-grid-2">';
        if(VFOS_Team::can('tasks')){
            $today=$wpdb->get_results($wpdb->prepare("SELECT t.*,p.name project_name FROM ".VFOS_DB::table('tasks')." t LEFT JOIN ".VFOS_DB::table('projects')." p ON p.id=t.project_id WHERE t.assigned_user_id=%d AND t.status NOT IN ('done','cancelled') ORDER BY t.due_date IS NULL,t.due_date ASC LIMIT 7",$uid));
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">MINHA ROTINA</span><h2>Próximas tarefas</h2></div><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab=mine')).'">Ver todas</a></div><div class="vfos-dashboard-tasks">';
            if(!$today)echo '<div class="vfos-empty">Nenhuma tarefa aberta atribuída a você.</div>';
            foreach($today as $t){$late=$t->due_date&&strtotime($t->due_date)<strtotime(date('Y-m-d'));echo '<article><div><strong>'.esc_html($t->title).'</strong><small>'.esc_html($t->project_name?:'Sem projeto').'</small></div><span class="vfos-pill">'.esc_html($this->status_label($t->status)).'</span><time class="'.($late?'is-late':'').'">'.($t->due_date?esc_html(date_i18n('d/m/Y',strtotime($t->due_date))):'Sem prazo').'</time></article>';}echo '</div></div>';
        }
        if(VFOS_Team::can('calendar')){
            $events=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('calendar_events')." WHERE start_at>=NOW() AND status NOT IN ('done','cancelled') AND (assigned_user_id=0 OR assigned_user_id=%d) ORDER BY start_at ASC LIMIT 7",$uid));
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">AGENDA</span><h2>Próximos compromissos</h2></div><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-calendar')).'">Abrir agenda</a></div><div class="vfos-dashboard-agenda">';
            if(!$events)echo '<div class="vfos-empty">Nenhum compromisso próximo.</div>';
            foreach($events as $ev)echo '<article><time><strong>'.esc_html(date_i18n('d',strtotime($ev->start_at))).'</strong><small>'.esc_html(date_i18n('M',strtotime($ev->start_at))).'</small></time><div><strong>'.esc_html($ev->title).'</strong><small>'.esc_html(date_i18n('H:i',strtotime($ev->start_at))).($ev->location?' • '.esc_html($ev->location):'').'</small></div></article>';
            echo '</div></div>';
        }
        echo '</div>';

        if(VFOS_Team::can('notifications')){
            $nt=VFOS_DB::table('notifications');$notes=$wpdb->get_results($wpdb->prepare("SELECT * FROM $nt WHERE user_id=%d ORDER BY is_read ASC,id DESC LIMIT 5",$uid));
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">ATENÇÃO</span><h2>Suas notificações recentes</h2></div><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-notifications')).'">Central de notificações</a></div><div class="vfos-dashboard-notifications">';
            if(!$notes)echo '<div class="vfos-empty">Nenhuma notificação recente.</div>';foreach($notes as $n)echo '<a class="'.(!$n->is_read?'is-unread':'').'" href="'.esc_url($n->url?:admin_url('admin.php?page=vfos-notifications')).'"><i></i><div><strong>'.esc_html($n->title).'</strong><small>'.esc_html($n->message).'</small></div><time>'.esc_html(date_i18n('d/m H:i',strtotime($n->created_at))).'</time></a>';echo '</div></div>';
        }

        if(VFOS_Team::can_permission('audit.view')){
            $logs=$wpdb->get_results("SELECT l.*,u.display_name FROM ".VFOS_DB::table('activity_logs')." l LEFT JOIN {$wpdb->users} u ON u.ID=l.user_id ORDER BY l.id DESC LIMIT 5");
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">AUDITORIA</span><h2>Atividade recente da equipe</h2></div><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-audit')).'">Ver auditoria</a></div><div class="vfos-mini-audit">';foreach($logs as $l)echo '<div><span>'.esc_html($l->display_name?:'Sistema').'</span><strong>'.esc_html($l->action_label?:$l->action).'</strong><small>'.esc_html($l->object_label).' • '.esc_html(date_i18n('d/m H:i',strtotime($l->created_at))).'</small></div>';echo '</div></div>';
        }

        if(VFOS_Team::can('ai'))$this->ai_box(false);
        echo '<div class="vfos-dashboard-footer-card"><div><span class="vfos-kicker">VISIONFORGE OS</span><h3>Seu sistema. Suas permissões.</h3><p>Este ambiente mostra apenas os módulos e ações liberados para o seu usuário.</p></div><span>v'.esc_html(VFOS_VERSION).'</span></div>';
        $this->end();
    }

    private function ai_box($large=true,$client_id=0){
        $provider=VFOS_AI::default_provider();$conversation=VFOS_AI::latest_conversation($client_id);
        echo '<div class="vfos-panel vfos-ai-panel vfos-ai-chat '.($large?'is-large':'is-compact').'" data-client-id="'.absint($client_id).'" data-conversation-id="'.esc_attr($conversation).'">';
        echo '<div class="vfos-ai-chat-head"><div><div class="vfos-ai-brand-orb">✦</div><div><span class="vfos-kicker">VISIONFORGE AI</span><h2>'.($large?'Assistente da VisionForge':'Assistente inteligente').'</h2><p>Converse normalmente. A IA lembra o contexto deste chat e pode preparar ações para você confirmar.</p></div></div><div class="vfos-ai-head-actions"><label>Modelo<select id="vfos-ai-provider"><option value="openrouter" '.selected($provider,'openrouter',false).'>OpenRouter</option><option value="gemini" '.selected($provider,'gemini',false).'>Gemini</option></select></label><span class="vfos-status '.(VFOS_AI::is_configured()?'ok':'off').'">'.(VFOS_AI::is_configured()?'Online':'Não configurada').'</span><button type="button" class="button" id="vfos-ai-new-chat">+ Novo chat</button></div></div>';
        echo '<div class="vfos-ai-conversation" id="vfos-ai-conversation"><div class="vfos-ai-welcome"><div class="vfos-ai-brand-orb large">✦</div><h3>Como posso ajudar?</h3><p>Posso analisar clientes e projetos, ajudar a priorizar tarefas, criar textos e preparar novos registros.</p><div class="vfos-ai-suggestions"><button type="button">O que preciso resolver hoje?</button><button type="button">Quais projetos estão atrasados?</button><button type="button">Resuma meus clientes e pendências</button><button type="button">Crie uma tarefa para mim</button></div></div></div>';
        echo '<div class="vfos-ai-composer"><textarea id="vfos-ai-prompt" rows="2" placeholder="Envie uma mensagem para a VisionForge AI..."></textarea><div class="vfos-ai-composer-foot"><small><b>Enter</b> envia • <b>Shift + Enter</b> quebra linha</small><button type="button" class="button button-primary vfos-ai-send-btn" id="vfos-ai-send"><span>Enviar</span><b>➜</b></button></div></div></div>';
    }
    public function clients(){
        VFOS_Team::require_permission('clients.view');global $wpdb;$t=VFOS_DB::table('clients');$edit=absint($_GET['edit']??0);$tab=$edit?'new':sanitize_key($_GET['tab']??'list');$e=$edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$edit)):null;
        if($tab==='new')VFOS_Team::require_permission($edit?'clients.edit':'clients.create');
        $this->header('Clientes','Área interna da VisionForge para cadastrar, organizar e administrar clientes.');echo '<nav class="vfos-tabs">';$this->module_tab('vfos-clients','list','Visualização',$tab);if(VFOS_Team::can_permission('clients.create')||($edit&&VFOS_Team::can_permission('clients.edit')))$this->module_tab('vfos-clients','new',$edit?'Editar cliente':'Novo cliente',$tab);echo '</nav>';
        if($tab==='new'){
            $type=$e->person_type??'pf';
            echo '<div class="vfos-panel vfos-client-editor"><div class="vfos-panel-head"><div><span class="vfos-kicker">CADASTRO COMPLETO</span><h2>'.($e?'Editar cliente':'Novo cliente').'</h2><p>Cadastre dados pessoais, empresariais, endereço, cobrança e responsável legal.</p></div></div>';$this->form_start('vfos_save_client');if($e)echo '<input type="hidden" name="id" value="'.$e->id.'">';
            echo '<section class="vfos-client-section"><h3>Tipo de cliente</h3><div class="vfos-person-selector"><label><input type="radio" name="person_type" value="pf" '.checked($type,'pf',false).'> <span><strong>Pessoa Física</strong><small>CPF e dados pessoais</small></span></label><label><input type="radio" name="person_type" value="pj" '.checked($type,'pj',false).'> <span><strong>Pessoa Jurídica</strong><small>CNPJ, empresa e responsável</small></span></label></div></section>';
            echo '<section class="vfos-client-section vfos-pf-fields"><div class="vfos-section-title"><span>01</span><div><h3>Dados pessoais</h3><p>Informações do cliente pessoa física.</p></div></div><div class="vfos-form-grid"><label>Nome completo<input name="name" value="'.esc_attr($e->name??'').'"></label><label>CPF<input name="document" value="'.esc_attr($e->document??'').'"></label><label>RG<input name="rg" value="'.esc_attr($e->rg??'').'"></label><label>Data de nascimento<input type="date" name="birth_date" value="'.esc_attr($e->birth_date??'').'"></label><label>Nacionalidade<input name="nationality" value="'.esc_attr($e->nationality??'').'"></label><label>Estado civil<input name="marital_status" value="'.esc_attr($e->marital_status??'').'"></label><label>Profissão<input name="profession" value="'.esc_attr($e->profession??'').'"></label></div></section>';
            echo '<section class="vfos-client-section vfos-pj-fields"><div class="vfos-section-title"><span>01</span><div><h3>Dados da empresa</h3><p>Informações cadastrais da pessoa jurídica.</p></div></div><div class="vfos-form-grid"><label>Razão social<input name="legal_name" value="'.esc_attr($e->legal_name??'').'"></label><label>Nome fantasia<input name="trade_name" value="'.esc_attr($e->trade_name??($e->company??'')).'"></label><label>CNPJ<input name="pj_document" value="'.esc_attr($type==='pj'?($e->document??''):'').'"></label><label>Inscrição estadual<input name="state_registration" value="'.esc_attr($e->state_registration??'').'"></label><label>Inscrição municipal<input name="municipal_registration" value="'.esc_attr($e->municipal_registration??'').'"></label><label>Site<input type="url" name="website" value="'.esc_attr($e->website??'').'" placeholder="https://"></label></div></section>';
            echo '<section class="vfos-client-section vfos-pj-fields"><div class="vfos-section-title"><span>02</span><div><h3>Responsável pela empresa</h3><p>Pessoa que representa a empresa nos projetos e contratos.</p></div></div><div class="vfos-form-grid"><label>Nome completo<input name="responsible_name" value="'.esc_attr($e->responsible_name??'').'"></label><label>Cargo / função<input name="responsible_role" value="'.esc_attr($e->responsible_role??'').'"></label><label>CPF<input name="responsible_cpf" value="'.esc_attr($e->responsible_cpf??'').'"></label><label>RG<input name="responsible_rg" value="'.esc_attr($e->responsible_rg??'').'"></label><label>Data de nascimento<input type="date" name="responsible_birth_date" value="'.esc_attr($e->responsible_birth_date??'').'"></label><label>E-mail pessoal<input type="email" name="responsible_email" value="'.esc_attr($e->responsible_email??'').'"></label><label>Telefone<input name="responsible_phone" value="'.esc_attr($e->responsible_phone??'').'"></label><label>WhatsApp<input name="responsible_whatsapp" value="'.esc_attr($e->responsible_whatsapp??'').'"></label><label>Nacionalidade<input name="responsible_nationality" value="'.esc_attr($e->responsible_nationality??'').'"></label><label>Estado civil<input name="responsible_marital_status" value="'.esc_attr($e->responsible_marital_status??'').'"></label><label>Profissão<input name="responsible_profession" value="'.esc_attr($e->responsible_profession??'').'"></label></div></section>';
            echo '<section class="vfos-client-section"><div class="vfos-section-title"><span>03</span><div><h3>Contato e cobrança</h3><p>Canais principais usados pela VisionForge.</p></div></div><div class="vfos-form-grid"><label>E-mail principal<input type="email" name="email" value="'.esc_attr($e->email??'').'"></label><label>E-mail financeiro / cobrança<input type="email" name="billing_email" value="'.esc_attr($e->billing_email??'').'"></label><label>Telefone<input name="phone" value="'.esc_attr($e->phone??'').'"></label><label>WhatsApp<input name="whatsapp" value="'.esc_attr($e->whatsapp??'').'"></label><label>Status<select name="status"><option value="active" '.selected($e->status??'active','active',false).'>Ativo</option><option value="inactive" '.selected($e->status??'','inactive',false).'>Inativo</option></select></label></div></section>';
            echo '<section class="vfos-client-section"><div class="vfos-section-title"><span>04</span><div><h3>Endereço</h3><p>Endereço completo para documentos, contratos e cadastro.</p></div></div><div class="vfos-form-grid"><label>CEP<input name="address_zip" value="'.esc_attr($e->address_zip??'').'"></label><label>Logradouro<input name="address_street" value="'.esc_attr($e->address_street??'').'"></label><label>Número<input name="address_number" value="'.esc_attr($e->address_number??'').'"></label><label>Complemento<input name="address_complement" value="'.esc_attr($e->address_complement??'').'"></label><label>Bairro<input name="address_neighborhood" value="'.esc_attr($e->address_neighborhood??'').'"></label><label>Cidade<input name="address_city" value="'.esc_attr($e->address_city??'').'"></label><label>Estado / UF<input name="address_state" maxlength="30" value="'.esc_attr($e->address_state??'').'"></label></div></section>';
            echo '<section class="vfos-client-section"><div class="vfos-section-title"><span>05</span><div><h3>Informações internas</h3><p>Observações visíveis apenas para a equipe.</p></div></div><label>Observações<textarea rows="5" name="notes">'.esc_textarea($e->notes??'').'</textarea></label></section>';
            if(!$e){$tpls=$wpdb->get_results("SELECT id,name FROM ".VFOS_DB::table('project_templates')." WHERE status='active' ORDER BY name");echo '<section class="vfos-client-section"><label>Modelo padrão do projeto<select name="template_id"><option value="0">Começar do zero</option>';foreach($tpls as $tpl)echo '<option value="'.$tpl->id.'">'.esc_html($tpl->name).'</option>';echo '</select><small>Opcional: cria um projeto base após o cadastro.</small></label></section>';}
            echo '<div class="vfos-form-actions"><button class="button button-primary vfos-btn">'.($e?'Salvar alterações':'Cadastrar cliente').'</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-clients&tab=list')).'">Cancelar</a></div></form></div>';
        }elseif($tab==='split'){
            $split_table=VFOS_DB::table('financial_splits');
            $total_partner=(float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM $split_table WHERE split_type='partner'");
            $total_cash=(float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM $split_table WHERE split_type='company_cash'");
            $split_count=(int)$wpdb->get_var("SELECT COUNT(DISTINCT financial_id) FROM $split_table");
            echo '<div class="vfos-stats vfos-split-global-stats"><div class="vfos-stat"><span>Distribuído aos sócios</span><strong>R$ '.number_format($total_partner,2,',','.').'</strong></div><div class="vfos-stat"><span>Reservado no caixa</span><strong>R$ '.number_format($total_cash,2,',','.').'</strong></div><div class="vfos-stat"><span>Receitas divididas</span><strong>'.$split_count.'</strong></div></div>';
            $team_table=VFOS_DB::table('team');
            $selected_id=absint($_GET['financial_id']??0);
            $incomes=$wpdb->get_results("SELECT f.*,c.name client_name FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.type='income' ORDER BY f.id DESC LIMIT 300");
            $selected=$selected_id?$wpdb->get_row($wpdb->prepare("SELECT f.*,c.name client_name,c.email client_email,c.billing_email FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.id=%d AND f.type='income'",$selected_id)):null;
            $members=$wpdb->get_results("SELECT tm.user_id,u.display_name,tm.job_title FROM $team_table tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE tm.status='active' ORDER BY u.display_name");
            $existing=$selected?$wpdb->get_results($wpdb->prepare("SELECT * FROM $split_table WHERE financial_id=%d ORDER BY sort_order,id",$selected->id)):[];
            $partner_rows=array_values(array_filter($existing,fn($x)=>$x->split_type==='partner'));
            $cash_row=null;foreach($existing as $x)if($x->split_type==='company_cash'){$cash_row=$x;break;}

            echo '<div class="vfos-grid vfos-grid-2 vfos-financial-split-layout"><div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">RECEITAS</span><h2>Escolha uma entrada</h2><p>Selecione um recebimento para dividir entre os sócios e o caixa da empresa.</p></div></div><div class="vfos-split-income-list">';
            if(!$incomes)echo '<div class="vfos-empty">Nenhuma entrada financeira cadastrada.</div>';
            foreach($incomes as $inc){
                $url=admin_url('admin.php?page=vfos-financial&tab=split&financial_id='.$inc->id);
                $sum=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM $split_table WHERE financial_id=%d",$inc->id));
                echo '<a class="'.($selected_id===$inc->id?'is-active':'').'" href="'.esc_url($url).'"><div><strong>'.esc_html($inc->description).'</strong><small>'.esc_html($inc->client_name?:'Sem cliente').' • '.esc_html($this->status_label($inc->status)).'</small></div><div><strong>R$ '.number_format((float)$inc->amount,2,',','.').'</strong><small>'.($sum>0?'Dividido: R$ '.number_format($sum,2,',','.'):'Ainda não dividido').'</small></div></a>';
            }
            echo '</div></div><div class="vfos-panel">';
            if(!$selected){
                echo '<div class="vfos-empty"><strong>Selecione uma entrada</strong><p>Depois você poderá indicar quanto vai para cada sócio e quanto fica no caixa da VisionForge.</p></div>';
            }else{
                $allocated=0;foreach($existing as $x)$allocated+=(float)$x->amount;$remaining=(float)$selected->amount-$allocated;
                echo '<div class="vfos-panel-head"><div><span class="vfos-kicker">DIVISÃO DA RECEITA</span><h2>'.esc_html($selected->description).'</h2><p>Valor recebido: <strong>R$ '.number_format((float)$selected->amount,2,',','.').'</strong></p></div><span class="vfos-pill">'.esc_html($selected->status==='paid'?'Recebido':'Pendente').'</span></div>';
                echo '<div class="vfos-split-summary"><div><span>Receita</span><strong>R$ '.number_format((float)$selected->amount,2,',','.').'</strong></div><div><span>Já distribuído</span><strong id="vfos-split-allocated">R$ '.number_format($allocated,2,',','.').'</strong></div><div class="'.($remaining<0?'is-negative':'').'"><span>Saldo da divisão</span><strong id="vfos-split-remaining">R$ '.number_format($remaining,2,',','.').'</strong></div></div>';
                echo '<form id="vfos-split-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_financial_split"><input type="hidden" name="financial_id" value="'.$selected->id.'">';wp_nonce_field('vfos_save_financial_split_'.$selected->id);
                echo '<div class="vfos-split-mode"><strong>Como deseja informar?</strong><label><input type="radio" name="split_mode" value="amount" checked> Valores em R$</label><label><input type="radio" name="split_mode" value="percent"> Percentuais</label></div>';
                echo '<div class="vfos-split-section"><div class="vfos-panel-head"><div><span class="vfos-kicker">SÓCIOS</span><h3>Distribuição entre os sócios</h3></div><button type="button" class="button vfos-add-split-partner">+ Adicionar sócio</button></div><div id="vfos-split-partners">';
                $seed=$partner_rows?:[(object)['user_id'=>0,'label'=>'','percentage'=>0,'amount'=>0]];
                foreach($seed as $i=>$r){
                    echo '<div class="vfos-split-partner-row"><label>Sócio<select name="partners['.$i.'][user_id]"><option value="0">Selecione...</option>';foreach($members as $m)echo '<option value="'.$m->user_id.'" '.selected($r->user_id??0,$m->user_id,false).'>'.esc_html($m->display_name.($m->job_title?' — '.$m->job_title:'')).'</option>';echo '</select></label><label class="vfos-grow">Nome livre <small>Opcional</small><input name="partners['.$i.'][label]" value="'.esc_attr($r->label??'').'" placeholder="Use se o sócio não estiver na equipe"></label><label>Valor R$<input class="vfos-split-amount" type="number" step="0.01" min="0" name="partners['.$i.'][amount]" value="'.esc_attr($r->amount??0).'"></label><label>Percentual %<input class="vfos-split-percent" type="number" step="0.01" min="0" max="100" name="partners['.$i.'][percentage]" value="'.esc_attr($r->percentage??0).'"></label><button type="button" class="button vfos-remove-split-partner">×</button></div>';
                }
                echo '</div></div>';
                echo '<div class="vfos-split-section vfos-company-cash-box"><span class="vfos-kicker">CAIXA DA EMPRESA</span><h3>Valor reservado para investimento na VisionForge</h3><p>Esse valor continua pertencendo à empresa para hospedagens, ferramentas, marketing, equipamentos ou outros investimentos.</p><div class="vfos-form-grid"><label>Valor para o caixa (R$)<input id="vfos-company-cash-amount" class="vfos-split-amount" type="number" step="0.01" min="0" name="company_cash_amount" value="'.esc_attr($cash_row->amount??0).'"></label><label>Percentual para o caixa (%)<input id="vfos-company-cash-percent" class="vfos-split-percent" type="number" step="0.01" min="0" max="100" name="company_cash_percentage" value="'.esc_attr($cash_row->percentage??0).'"></label></div></div>';
                echo '<div class="vfos-split-validation"><strong>A soma precisa fechar exatamente o valor da receita.</strong><p id="vfos-split-validation-text">Ajuste os valores antes de salvar.</p></div><div class="vfos-form-actions"><button class="button button-primary vfos-btn">Salvar divisão</button></div></form>';
            }
            echo '</div></div>';
        }else{
            $search=$this->q('s');$status=sanitize_key($_GET['status']??'');$person=sanitize_key($_GET['person_type']??'');$where=['1=1'];$args=[];
            if($search!==''){$where[]='(name LIKE %s OR company LIKE %s OR legal_name LIKE %s OR trade_name LIKE %s OR email LIKE %s OR phone LIKE %s OR whatsapp LIKE %s OR document LIKE %s OR responsible_name LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like,$like,$like,$like,$like,$like,$like,$like);}
            if(in_array($status,['active','inactive'],true)){$where[]='status=%s';$args[]=$status;}if(in_array($person,['pf','pj'],true)){$where[]='person_type=%s';$args[]=$person;}
            $sql="SELECT * FROM $t WHERE ".implode(' AND ',$where).' ORDER BY id DESC LIMIT 300';$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISUALIZAÇÃO</span><h2>Clientes cadastrados</h2></div>'.(VFOS_Team::can_permission('clients.create')?'<a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-clients&tab=new')).'">+ Novo cliente</a>':'').'</div>';$this->filter_start('vfos-clients');echo '<label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Nome, empresa, responsável, e-mail ou documento"></label><label>Tipo<select name="person_type"><option value="">PF e PJ</option><option value="pf" '.selected($person,'pf',false).'>Pessoa Física</option><option value="pj" '.selected($person,'pj',false).'>Pessoa Jurídica</option></select></label><label>Status<select name="status"><option value="">Todos</option><option value="active" '.selected($status,'active',false).'>Ativos</option><option value="inactive" '.selected($status,'inactive',false).'>Inativos</option></select></label>';$this->filter_end();
            echo '<div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Cliente</th><th>Tipo / Documento</th><th>Contato</th><th>Responsável</th><th>Status</th><th>Ações</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="6">Nenhum cliente encontrado.</td></tr>';
            foreach($rows as $r){$ed=admin_url('admin.php?page=vfos-clients&tab=new&edit='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_client&id='.$r->id),'vfos_delete_client');$display=$r->person_type==='pj'?($r->trade_name?:$r->legal_name?:$r->company?:$r->name):$r->name;echo '<tr><td><strong>'.esc_html($display).'</strong><small>'.esc_html($r->person_type==='pj'?($r->legal_name?:$r->name):($r->profession?:'Pessoa física')).'</small></td><td><span class="vfos-pill">'.($r->person_type==='pj'?'Pessoa Jurídica':'Pessoa Física').'</span><small>'.esc_html($r->document?:'Sem documento').'</small></td><td>'.esc_html($r->email?:'—').'<small>'.esc_html($r->whatsapp?:$r->phone).'</small></td><td>'.esc_html($r->person_type==='pj'?($r->responsible_name?:'—'):'—').'<small>'.esc_html($r->person_type==='pj'?($r->responsible_role?:''):'').'</small></td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td><a class="vfos-open-link" href="'.esc_url(admin_url('admin.php?page=vfos-client-view&id='.$r->id)).'">Abrir 360°</a>'.((current_user_can('manage_options')||VFOS_Team::can_permission('clients.portal'))?' · <a href="'.esc_url(admin_url('admin.php?page=vfos-portal&client_id='.$r->id)).'">Área do Cliente</a>':'').(VFOS_Team::can_permission('clients.edit')?' · <a href="'.esc_url($ed).'">Editar</a>':'').(VFOS_Team::can_permission('clients.delete')?' · <a class="vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir este cliente? A auditoria manterá o registro da exclusão.\')">Excluir</a>':'').'</td></tr>';}
            echo '</tbody></table></div></div>';
        }$this->end();
    }
    public function client_view(){
        global $wpdb; $id=absint($_GET['id']??0); $ct=VFOS_DB::table('clients');
        $client=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM $ct WHERE id=%d",$id)):null;
        if(!$client){$this->header('Cliente não encontrado');echo '<div class="vfos-panel"><p>O cliente informado não existe.</p><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-clients')).'">Voltar para clientes</a></div>';$this->end();return;}
        $pt=VFOS_DB::table('projects');$tt=VFOS_DB::table('tasks');$qt=VFOS_DB::table('quotes');$cot=VFOS_DB::table('contracts');$ft=VFOS_DB::table('financial');$nt=VFOS_DB::table('client_notes');$flt=VFOS_DB::table('client_files');
        $projects=$wpdb->get_results($wpdb->prepare("SELECT * FROM $pt WHERE client_id=%d ORDER BY id DESC",$id));
        $tasks=$wpdb->get_results($wpdb->prepare("SELECT * FROM $tt WHERE client_id=%d ORDER BY (status='done'),due_date IS NULL,due_date,id DESC",$id));
        $quotes=$wpdb->get_results($wpdb->prepare("SELECT * FROM $qt WHERE client_id=%d ORDER BY id DESC",$id));
        $contracts=$wpdb->get_results($wpdb->prepare("SELECT * FROM $cot WHERE client_id=%d ORDER BY id DESC",$id));
        $financial=$wpdb->get_results($wpdb->prepare("SELECT * FROM $ft WHERE client_id=%d ORDER BY id DESC",$id));
        $notes=$wpdb->get_results($wpdb->prepare("SELECT n.*,u.display_name user_name FROM $nt n LEFT JOIN {$wpdb->users} u ON u.ID=n.user_id WHERE n.client_id=%d ORDER BY n.id DESC",$id));
        $files=$wpdb->get_results($wpdb->prepare("SELECT * FROM $flt WHERE client_id=%d ORDER BY id DESC",$id));$audit_rows=$wpdb->get_results($wpdb->prepare("SELECT l.*,u.display_name user_name FROM ".VFOS_DB::table('activity_logs')." l LEFT JOIN {$wpdb->users} u ON u.ID=l.user_id WHERE l.object_type='client' AND l.object_id=%d ORDER BY l.id DESC LIMIT 50",$id));
        $received=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(paid_amount),0) FROM $ft WHERE client_id=%d AND type='income'",$id));
        $receivable=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(amount-paid_amount,0)),0) FROM $ft WHERE client_id=%d AND type='income' AND status IN ('pending','partial')",$id));
        $open_tasks=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE client_id=%d AND status NOT IN ('done','cancelled')",$id));
        $active_projects=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $pt WHERE client_id=%d AND status NOT IN ('completed','cancelled')",$id));
        $display_name=$client->person_type==='pj'?($client->trade_name?:$client->legal_name?:$client->company?:$client->name):$client->name;
        $portal_users=get_users(['meta_key'=>'vfos_client_id','meta_value'=>$id]);
        $portal_page_id=absint(get_option('vfos_portal_page_id'));$portal_url=$portal_page_id?get_permalink($portal_page_id):'';
        $portal_enabled=in_array($client->portal_access_mode,['direct_link','identifier','both'],true)&&($client->portal_access_mode!=='direct_link'||!empty($client->portal_token_hash));if(!$portal_enabled)foreach($portal_users as $pu)if(get_user_meta($pu->ID,'vfos_portal_enabled',true)){$portal_enabled=true;break;}
        $pending_approvals=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('client_approvals')." WHERE client_id=%d AND status='pending'",$id));
        $pending_approvals+=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('project_approvals')." pa JOIN $pt p ON p.id=pa.project_id WHERE p.client_id=%d AND pa.status='pending'",$id));
        $this->header($display_name,'Visão 360° do relacionamento com este cliente.');
        echo '<div class="vfos-client-hero"><div><span class="vfos-avatar">'.esc_html(mb_strtoupper(mb_substr($display_name,0,1))).'</span><div><h2>'.esc_html($display_name).'</h2><p>'.esc_html($client->person_type==='pj'?($client->legal_name?:'Pessoa Jurídica'):'Pessoa Física').'</p></div></div><div class="vfos-client-actions">'.(VFOS_Team::can_permission('clients.edit')?'<a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-clients&edit='.$id)).'">Editar cadastro</a>':'').((current_user_can('manage_options')||VFOS_Team::can_permission('clients.portal'))?'<a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-portal&client_id='.$id)).'">Área do Cliente</a>':'').(VFOS_Team::can_permission('quotes.create')?'<a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-quotes&client_id='.$id)).'">Novo orçamento</a>':'').'</div></div>';
        echo '<div class="vfos-grid vfos-grid-4">';$this->card('Recebido','R$ '.number_format($received,2,',','.'),'Total do cliente');$this->card('A receber','R$ '.number_format($receivable,2,',','.'),'Pendente');$this->card('Projetos ativos',$active_projects,'Em andamento');$this->card('Tarefas abertas',$open_tasks,'Pendências');echo '</div>';
        if(current_user_can('manage_options')||VFOS_Team::can_permission('clients.portal')){
            echo '<div class="vfos-panel vfos-client-portal-card"><div class="vfos-panel-head"><div><span class="vfos-kicker">ÁREA DO CLIENTE</span><h2>Portal de acompanhamento de '.esc_html($display_name).'</h2><p>É este ambiente que você envia ao cliente para acompanhar projetos, pagamentos, aprovações, propostas, contratos, arquivos e mensagens.</p></div><span class="vfos-pill '.($portal_enabled?'is-active':'').'">'.($portal_enabled?'Acesso ativo':'Sem acesso').'</span></div>';
            $mode_labels=['direct_link'=>'Link direto','identifier'=>'E-mail/CPF/CNPJ','both'=>'Link + identificação','wordpress'=>'Login tradicional'];echo '<div class="vfos-client-portal-summary"><div><span>Modo de acesso</span><strong>'.esc_html($mode_labels[$client->portal_access_mode]??'Link direto').'</strong></div><div><span>Aprovações pendentes</span><strong>'.$pending_approvals.'</strong></div><div><span>Portal</span><strong>'.($portal_url?'Configurado':'Não criado').'</strong></div></div>';
            if($portal_url){
                $plain=get_transient('vfos_portal_plain_'.$id);$direct=$plain?add_query_arg('vfos_access',$plain,$portal_url):'';
                echo '<div class="vfos-client-portal-actions"><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-portal&client_id='.$id)).'">Gerenciar acesso</a>';
                if($direct)echo '<button type="button" class="button vfos-copy-client-portal" data-link="'.esc_attr($direct).'">Copiar link direto</button>';
                elseif(in_array($client->portal_access_mode,['direct_link','both'],true)){$gen=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_generate_link&client_id='.$id),'vfos_portal_generate_link');echo '<a class="button" href="'.esc_url($gen).'">Gerar link direto</a>';}
                if($client->email||$client->billing_email){$mail=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_send_access&client_id='.$id),'vfos_portal_send_access');echo '<a class="button" href="'.esc_url($mail).'">Enviar link por e-mail</a>';}
                echo '<a class="button" target="_blank" href="'.esc_url($portal_url).'">Abrir portal</a></div>';
                echo '<div class="vfos-notice">Não é obrigatório criar usuário ou senha. Configure <b>Link direto</b>, <b>E-mail/CPF/CNPJ</b> ou os dois.</div>';
            }else{
                echo '<div class="vfos-notice">A página pública da Área do Cliente ainda não foi criada. <a href="'.esc_url(admin_url('admin.php?page=vfos-portal&client_id='.$id)).'">Configurar agora</a>.</div>';
            }
            echo '</div>';
        }
        echo '<div class="vfos-grid vfos-grid-3">';
        echo '<div class="vfos-panel"><span class="vfos-kicker">CADASTRO</span><h2>Dados principais</h2><div class="vfos-detail-list"><div><span>Tipo</span><strong>'.($client->person_type==='pj'?'Pessoa Jurídica':'Pessoa Física').'</strong></div><div><span>'.($client->person_type==='pj'?'CNPJ':'CPF').'</span><strong>'.esc_html($client->document?:'—').'</strong></div>'.($client->person_type==='pj'?'<div><span>Razão social</span><strong>'.esc_html($client->legal_name?:'—').'</strong></div><div><span>Nome fantasia</span><strong>'.esc_html($client->trade_name?:'—').'</strong></div><div><span>Inscrição estadual</span><strong>'.esc_html($client->state_registration?:'—').'</strong></div>':'<div><span>RG</span><strong>'.esc_html($client->rg?:'—').'</strong></div><div><span>Profissão</span><strong>'.esc_html($client->profession?:'—').'</strong></div>').'<div><span>Status</span><strong>'.esc_html($this->status_label($client->status)).'</strong></div></div></div>';
        echo '<div class="vfos-panel"><span class="vfos-kicker">CONTATO</span><h2>Canais</h2><div class="vfos-detail-list"><div><span>E-mail</span><strong>'.esc_html($client->email?:'—').'</strong></div><div><span>E-mail financeiro</span><strong>'.esc_html($client->billing_email?:'—').'</strong></div><div><span>Telefone</span><strong>'.esc_html($client->phone?:'—').'</strong></div><div><span>WhatsApp</span><strong>'.esc_html($client->whatsapp?:'—').'</strong></div><div><span>Site</span><strong>'.esc_html($client->website?:'—').'</strong></div></div></div>';
        echo '<div class="vfos-panel"><span class="vfos-kicker">ENDEREÇO</span><h2>Localização</h2><div class="vfos-detail-list"><div><span>CEP</span><strong>'.esc_html($client->address_zip?:'—').'</strong></div><div><span>Endereço</span><strong>'.esc_html(trim(($client->address_street?:'').' '.($client->address_number?:''))?:'—').'</strong></div><div><span>Bairro</span><strong>'.esc_html($client->address_neighborhood?:'—').'</strong></div><div><span>Cidade / UF</span><strong>'.esc_html(trim(($client->address_city?:'').' / '.($client->address_state?:''),' /')?:'—').'</strong></div></div></div></div>';
        if($client->person_type==='pj')echo '<div class="vfos-panel vfos-responsible-card"><div class="vfos-panel-head"><div><span class="vfos-kicker">RESPONSÁVEL PELA EMPRESA</span><h2>'.esc_html($client->responsible_name?:'Não informado').'</h2></div><span class="vfos-pill">'.esc_html($client->responsible_role?:'Responsável').'</span></div><div class="vfos-detail-grid"><div><span>CPF</span><strong>'.esc_html($client->responsible_cpf?:'—').'</strong></div><div><span>RG</span><strong>'.esc_html($client->responsible_rg?:'—').'</strong></div><div><span>E-mail</span><strong>'.esc_html($client->responsible_email?:'—').'</strong></div><div><span>WhatsApp</span><strong>'.esc_html($client->responsible_whatsapp?:$client->responsible_phone?:'—').'</strong></div><div><span>Nacionalidade</span><strong>'.esc_html($client->responsible_nationality?:'—').'</strong></div><div><span>Estado civil</span><strong>'.esc_html($client->responsible_marital_status?:'—').'</strong></div><div><span>Profissão</span><strong>'.esc_html($client->responsible_profession?:'—').'</strong></div><div><span>Nascimento</span><strong>'.($client->responsible_birth_date?esc_html(date_i18n('d/m/Y',strtotime($client->responsible_birth_date))):'—').'</strong></div></div></div>';
        $creator=$client->created_by?get_userdata($client->created_by):null;$updater=$client->updated_by?get_userdata($client->updated_by):null;echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><h2>Observações do cadastro</h2><p class="vfos-client-notes">'.nl2br(esc_html($client->notes?:'Nenhuma observação cadastrada.')).'</p></div><div class="vfos-record-meta"><small>Cadastrado por</small><strong>'.esc_html($creator?$creator->display_name:'—').'</strong><small>Última alteração</small><strong>'.esc_html($updater?$updater->display_name:'—').' • '.esc_html(date_i18n('d/m/Y H:i',strtotime($client->updated_at))).'</strong></div></div></div>';
        $this->ai_box(true,$id);
        echo '<div class="vfos-client-tabs">';
        $this->client_section_projects($id,$projects);$this->client_section_quotes($id,$quotes);$this->client_section_contracts($id,$contracts);$this->client_section_financial($id,$financial);$this->client_section_tasks($id,$tasks);
        echo '</div>';
        echo '<div class="vfos-grid vfos-grid-2"><div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">HISTÓRICO</span><h2>Linha do tempo</h2></div></div>';
        echo '<div class="vfos-timeline">';$events=[];
        foreach($notes as $n)$events[]=['date'=>$n->created_at,'type'=>'Nota','title'=>$n->content,'meta'=>$n->user_name?:'Equipe VisionForge'];
        foreach($projects as $x)$events[]=['date'=>$x->created_at,'type'=>'Projeto','title'=>$x->name,'meta'=>$this->status_label($x->status)];
        foreach($quotes as $x)$events[]=['date'=>$x->created_at,'type'=>'Orçamento','title'=>$x->number.' · '.$x->title,'meta'=>'R$ '.number_format($x->total,2,',','.')];
        foreach($contracts as $x)$events[]=['date'=>$x->created_at,'type'=>'Contrato','title'=>$x->number.' · '.$x->title,'meta'=>$this->status_label($x->status)];
        foreach($financial as $x)$events[]=['date'=>$x->created_at,'type'=>'Financeiro','title'=>$x->description,'meta'=>'R$ '.number_format($x->amount,2,',','.')];foreach($audit_rows as $x)$events[]=['date'=>$x->created_at,'type'=>'Auditoria','title'=>($x->user_name?:'Sistema').' — '.($x->action_label?:$x->action),'meta'=>$x->details?:($x->object_label?:'Ação registrada')];
        usort($events,fn($a,$b)=>strcmp($b['date'],$a['date']));
        if(!$events)echo '<div class="vfos-empty">Ainda não há movimentações.</div>';foreach(array_slice($events,0,40) as $ev)echo '<div class="vfos-timeline-item"><span></span><div><small>'.esc_html($ev['type'].' · '.date_i18n('d/m/Y H:i',strtotime($ev['date']))).'</small><strong>'.esc_html($ev['title']).'</strong><em>'.esc_html($ev['meta']).'</em></div></div>';
        echo '</div><div class="vfos-note-form"><h3>Adicionar anotação</h3>';$this->form_start('vfos_save_client_note');echo '<input type="hidden" name="client_id" value="'.$id.'"><textarea name="content" rows="3" required placeholder="Ex.: Cliente solicitou alteração no prazo da entrega..."></textarea><button class="button button-primary vfos-btn">Adicionar ao histórico</button></form></div></div>';
        echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">ARQUIVOS</span><h2>Documentos e entregas</h2></div></div>';
        echo '<form class="vfos-upload" method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_upload_client_file"><input type="hidden" name="client_id" value="'.$id.'">';wp_nonce_field('vfos_upload_client_file');echo '<label>Título<input name="title" placeholder="Ex.: Logo final, briefing, documento..."></label><label>Arquivo<input type="file" name="client_file" required></label><button class="button button-primary vfos-btn">Enviar arquivo</button></form><div class="vfos-files">';
        if(!$files)echo '<div class="vfos-empty">Nenhum arquivo vinculado a este cliente.</div>';foreach($files as $f){$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_client_file&id='.$f->id.'&client_id='.$id),'vfos_delete_client_file');echo '<div class="vfos-file"><span class="dashicons dashicons-media-default"></span><div><strong>'.esc_html($f->title?:basename(parse_url($f->file_url,PHP_URL_PATH))).'</strong><small>'.esc_html($f->mime_type).' · '.date_i18n('d/m/Y',strtotime($f->created_at)).'</small></div><a target="_blank" rel="noopener" href="'.esc_url($f->file_url).'">Abrir</a><a class="vfos-danger" onclick="return confirm(\'Remover este arquivo do cliente?\')" href="'.esc_url($del).'">Remover</a></div>';}
        echo '</div></div></div>';
        $this->end();
    }
    private function client_section_projects($id,$rows){echo '<div class="vfos-panel"><div class="vfos-panel-head"><h2>Projetos</h2><a href="'.esc_url(admin_url('admin.php?page=vfos-projects&client_id='.$id)).'">Ver módulo</a></div><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Projeto</th><th>Status</th><th>Progresso</th><th>Valor</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="4">Nenhum projeto.</td></tr>';foreach($rows as $r)echo '<tr><td><strong>'.esc_html($r->name).'</strong><small>'.($r->due_date?'Prazo '.date_i18n('d/m/Y',strtotime($r->due_date)):'Sem prazo').'</small></td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td>'.$r->progress.'%</td><td>R$ '.number_format($r->value,2,',','.').'</td></tr>';echo '</tbody></table></div></div>';}
    private function client_section_quotes($id,$rows){echo '<div class="vfos-panel"><div class="vfos-panel-head"><h2>Orçamentos</h2><a href="'.esc_url(admin_url('admin.php?page=vfos-quotes&client_id='.$id)).'">Novo orçamento</a></div><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Número</th><th>Título</th><th>Status</th><th>Valor</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="4">Nenhum orçamento.</td></tr>';foreach($rows as $r)echo '<tr><td><strong>'.esc_html($r->number).'</strong></td><td>'.esc_html($r->title).'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td>R$ '.number_format($r->total,2,',','.').'</td></tr>';echo '</tbody></table></div></div>';}
    private function client_section_contracts($id,$rows){echo '<div class="vfos-panel"><div class="vfos-panel-head"><h2>Contratos / Sign</h2><a href="'.esc_url(admin_url('admin.php?page=vfos-contracts&client_id='.$id)).'">Novo contrato</a></div><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Número</th><th>Título</th><th>Status</th><th>VisionForge Sign</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="4">Nenhum contrato.</td></tr>';foreach($rows as $r)echo '<tr><td><strong>'.esc_html($r->number).'</strong></td><td>'.esc_html($r->title).'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td>'.esc_html($r->sign_status?:'Não enviado').($r->sign_url?'<small><a target="_blank" rel="noopener" href="'.esc_url($r->sign_url).'">Abrir</a></small>':'').'</td></tr>';echo '</tbody></table></div></div>';}
    private function client_section_financial($id,$rows){echo '<div class="vfos-panel"><div class="vfos-panel-head"><h2>Financeiro</h2><a href="'.esc_url(admin_url('admin.php?page=vfos-financial&client_id='.$id)).'">Novo lançamento</a></div><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Descrição</th><th>Tipo</th><th>Status</th><th>Valor</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="4">Nenhum lançamento.</td></tr>';foreach($rows as $r)echo '<tr><td><strong>'.esc_html($r->description).'</strong><small>'.($r->due_date?'Venc. '.date_i18n('d/m/Y',strtotime($r->due_date)):'').'</small></td><td>'.($r->type==='income'?'Entrada':'Despesa').'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td>R$ '.number_format($r->amount,2,',','.').'</td></tr>';echo '</tbody></table></div></div>';}
    private function client_section_tasks($id,$rows){echo '<div class="vfos-panel"><div class="vfos-panel-head"><h2>Tarefas</h2><a href="'.esc_url(admin_url('admin.php?page=vfos-tasks&client_id='.$id)).'">Nova tarefa</a></div><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Tarefa</th><th>Prioridade</th><th>Prazo</th><th>Status</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="4">Nenhuma tarefa.</td></tr>';foreach($rows as $r)echo '<tr><td><strong>'.esc_html($r->title).'</strong></td><td>'.esc_html(ucfirst($r->priority)).'</td><td>'.($r->due_date?date_i18n('d/m/Y',strtotime($r->due_date)):'—').'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td></tr>';echo '</tbody></table></div></div>';}

    public function services(){
        global $wpdb;$t=VFOS_DB::table('services');$tab=sanitize_key($_GET['tab']??'list');$this->header('Serviços','Catálogo de serviços e preços base.');$this->module_tabs('vfos-services',$tab,'Novo serviço');
        if($tab==='new'){echo '<div class="vfos-panel"><span class="vfos-kicker">CADASTRO</span><h2>Novo serviço</h2>';$this->form_start('vfos_save_service');echo '<div class="vfos-form-grid"><label>Nome<input name="name" required></label><label>Preço base (R$)<input type="number" step="0.01" name="price" value="0"></label></div><label>Descrição<textarea name="description"></textarea></label><button class="button button-primary vfos-btn">Salvar serviço</button> <a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-services&tab=list')).'">Cancelar</a></form></div>';}
        else{$search=$this->q('s');$min=$this->q('min_price');$max=$this->q('max_price');$where=['1=1'];$args=[];if($search!==''){$where[]='(name LIKE %s OR description LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like);}if($min!==''){$where[]='price >= %f';$args[]=(float)$min;}if($max!==''){$where[]='price <= %f';$args[]=(float)$max;}$sql="SELECT * FROM $t WHERE ".implode(' AND ',$where).' ORDER BY id DESC';$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISUALIZAÇÃO</span><h2>Catálogo</h2></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-services&tab=new')).'">+ Novo serviço</a></div>';$this->filter_start('vfos-services');echo '<label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Nome ou descrição"></label><label>Preço mínimo<input type="number" step="0.01" name="min_price" value="'.esc_attr($min).'"></label><label>Preço máximo<input type="number" step="0.01" name="max_price" value="'.esc_attr($max).'"></label>';$this->filter_end();echo '<div class="vfos-cards-list">';if(!$rows)echo '<div class="vfos-empty">Nenhum serviço encontrado.</div>';foreach($rows as $r)echo '<div><strong>'.esc_html($r->name).'</strong><span>R$ '.number_format($r->price,2,',','.').'</span><small>'.esc_html($r->description).'</small></div>';echo '</div></div>';}$this->end();
    }
    public function quotes(){
        VFOS_Team::require_permission('quotes.view');global $wpdb;
        $qt=VFOS_DB::table('quotes');$qit=VFOS_DB::table('quote_items');$qst=VFOS_DB::table('quote_sections');$qct=VFOS_DB::table('quote_costs');$qpt=VFOS_DB::table('quote_payment_options');$qtt=VFOS_DB::table('quote_templates');$ct=VFOS_DB::table('clients');$st=VFOS_DB::table('services');
        $edit=absint($_GET['edit']??0);$edit_template=absint($_GET['edit_template']??0);$tab=($edit||$edit_template)?'new':sanitize_key($_GET['tab']??'list');if(!in_array($tab,['list','new','templates'],true))$tab='list';
        $e=$edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $qt WHERE id=%d",$edit)):null;if($edit&&!$e)$this->go('vfos-quotes','Orçamento não encontrado.');
        if($tab==='new')VFOS_Team::require_permission($edit?'quotes.edit':'quotes.create');if($tab==='templates')VFOS_Team::require_permission('quotes.templates');
        $services=$wpdb->get_results("SELECT id,name,description,price FROM $st WHERE status='active' ORDER BY name");
        $templates=$wpdb->get_results("SELECT id,name,description FROM $qtt WHERE status='active' ORDER BY name");

        $template_id=!$edit?($edit_template?:absint($_GET['template_id']??0)):0;$template_data=null;$template_row=null;
        if($template_id){$template_row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $qtt WHERE id=%d",$template_id));if($template_row)$template_data=json_decode($template_row->data_json,true);}
        if($edit_template&&!$template_row)$this->go('vfos-quotes','Modelo de orçamento não encontrado.');
        $this->header('Orçamentos','Propostas comerciais completas, persuasivas e personalizadas.');
        echo '<nav class="vfos-tabs">';$this->module_tab('vfos-quotes','list','Visualização',$tab);if(VFOS_Team::can_permission('quotes.create')||($edit&&VFOS_Team::can_permission('quotes.edit')))$this->module_tab('vfos-quotes','new',$edit?'Editar orçamento':($edit_template?'Editar modelo':'Novo orçamento'),$tab);if(VFOS_Team::can_permission('quotes.templates'))$this->module_tab('vfos-quotes','templates','Modelos',$tab);echo '</nav>';

        if($tab==='templates'){
            $rows=$wpdb->get_results("SELECT t.*,u.display_name creator_name FROM $qtt t LEFT JOIN {$wpdb->users} u ON u.ID=t.created_by ORDER BY t.id DESC");
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">BIBLIOTECA DE MODELOS</span><h2>Modelos de orçamento</h2><p>Salve propostas prontas para reutilizar com ou sem cliente específico.</p></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-quotes&tab=new')).'">Criar orçamento base</a></div><div class="vfos-quote-template-grid">';
            if(!$rows)echo '<div class="vfos-empty">Nenhum modelo salvo. Crie um orçamento e use “Salvar como modelo”.</div>';
            foreach($rows as $r){$data=json_decode($r->data_json,true);$use=admin_url('admin.php?page=vfos-quotes&tab=new&template_id='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_quote_template&id='.$r->id),'vfos_delete_quote_template_'.$r->id);$sections=count($data['sections']??[]);$items=count($data['items']??[]);echo '<article><div class="vfos-template-icon">✦</div><div><span class="vfos-kicker">MODELO REUTILIZÁVEL</span><h3>'.esc_html($r->name).'</h3><p>'.esc_html($r->description?:'Modelo de proposta VisionForge').'</p><div class="vfos-template-meta"><span>'.$items.' item(ns)</span><span>'.$sections.' seção(ões)</span><span>'.esc_html($r->creator_name?:'VisionForge').'</span></div></div><div class="vfos-template-actions"><a class="button button-primary" href="'.esc_url($use).'">Usar modelo</a><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-quotes&edit_template='.$r->id)).'">Editar modelo</a><a class="button vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir este modelo?\')">Excluir</a></div></article>';}
            echo '</div></div>';
        }elseif($tab==='new'){
            $items=$e?$wpdb->get_results($wpdb->prepare("SELECT * FROM $qit WHERE quote_id=%d ORDER BY sort_order,id",$e->id)):[];
            $sections=$e?$wpdb->get_results($wpdb->prepare("SELECT * FROM $qst WHERE quote_id=%d ORDER BY sort_order,id",$e->id)):[];
            $costs=$e?$wpdb->get_results($wpdb->prepare("SELECT * FROM $qct WHERE quote_id=%d ORDER BY sort_order,id",$e->id)):[];
            if($costs){$qcot=VFOS_DB::table('quote_cost_options');foreach($costs as $cost){$cost->options=$wpdb->get_results($wpdb->prepare("SELECT * FROM $qcot WHERE cost_id=%d ORDER BY sort_order,id",$cost->id));}}
            $payments=$e?$wpdb->get_results($wpdb->prepare("SELECT * FROM $qpt WHERE quote_id=%d ORDER BY sort_order,id",$e->id)):[];
            if($template_data){
                $items=array_map(fn($x)=>(object)$x,$template_data['items']??[]);
                $sections=array_map(fn($x)=>(object)$x,$template_data['sections']??[]);
                $costs=array_map(fn($x)=>(object)$x,$template_data['costs']??[]);
                $payments=array_map(fn($x)=>(object)$x,$template_data['payments']??[]);
            }
            $title=$e->title??($template_data['quote']['title']??'');$description=$e->description??($template_data['quote']['description']??'');$payment_terms=$e->payment_terms??($template_data['quote']['payment_terms']??'50% no início e 50% na entrega final.');$notes=$e->notes??($template_data['quote']['notes']??'');$discount_type=$e->discount_type??($template_data['quote']['discount_type']??'fixed');$discount_value=$e->discount_value??($template_data['quote']['discount_value']??0);
            echo '<div class="vfos-panel vfos-quote-editor vfos-quote-pro"><div class="vfos-panel-head"><div><span class="vfos-kicker">PROPOSTA COMERCIAL VISIONFORGE</span><h2>'.($e?'Editar '.$e->number:($edit_template?'Editar modelo: '.esc_html($template_row->name):'Criar proposta')).'</h2><p>Construa uma apresentação comercial completa: argumento de venda, visão do projeto, investimento, pagamentos e custos externos.</p></div><img class="vfos-quote-brand-logo" src="'.esc_url(VFOS_URL.'admin/assets/images/visionforge-logo-horizontal.png').'" alt="VisionForge Digital"></div>';
            if($e&&!$edit_template){echo '<div class="vfos-related-flow"><span class="vfos-kicker">FLUXO RELACIONADO</span><div>';if($e->lead_id)echo '<a href="'.esc_url(admin_url('admin.php?page=vfos-leads&tab=new&edit='.$e->lead_id)).'">Lead #'.$e->lead_id.'</a>';echo '<b>→</b><strong>'.$e->number.'</strong>';if($e->converted_contract_id)echo '<b>→</b><a href="'.esc_url(admin_url('admin.php?page=vfos-contracts&tab=new&edit='.$e->converted_contract_id)).'">Contrato</a>';if($e->converted_project_id)echo '<b>→</b><a href="'.esc_url(admin_url('admin.php?page=vfos-project-view&id='.$e->converted_project_id)).'">Projeto</a>';if($e->converted_financial_id)echo '<b>→</b><a href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.$e->converted_financial_id)).'">Financeiro</a>';echo '</div></div>';}
            if($e&&($e->client_observations||$e->rejection_reason||$e->revision_suggestion)){echo '<div class="vfos-client-feedback-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">RETORNO DO CLIENTE</span><h3>Feedback recebido pelo link da proposta</h3><p>Essas informações foram enviadas diretamente pelo cliente.</p></div>'.($e->feedback_updated_at?'<span class="vfos-pill">'.esc_html(date_i18n('d/m/Y H:i',strtotime($e->feedback_updated_at))).'</span>':'').'</div><div class="vfos-client-feedback-grid">';if($e->client_observations)echo '<div><span>Observações</span><p>'.nl2br(esc_html($e->client_observations)).'</p></div>';if($e->rejection_reason)echo '<div class="is-rejection"><span>Motivo da recusa</span><p>'.nl2br(esc_html($e->rejection_reason)).'</p></div>';if($e->revision_suggestion)echo '<div class="is-suggestion"><span>Sugestão de alteração</span><p>'.nl2br(esc_html($e->revision_suggestion)).'</p></div>';echo '</div></div>';}

            if(!$e&&!$edit_template&&$templates){echo '<div class="vfos-template-picker"><div><strong>Começar por um modelo</strong><small>Carregue uma proposta já estruturada e personalize.</small></div><select onchange="if(this.value)location.href=this.value"><option value="">Selecionar modelo...</option>';foreach($templates as $tpl)echo '<option value="'.esc_url(admin_url('admin.php?page=vfos-quotes&tab=new&template_id='.$tpl->id)).'" '.selected($template_id,$tpl->id,false).'>'.esc_html($tpl->name).'</option>';echo '</select></div>';}

            $this->form_start($edit_template?'vfos_update_quote_template':'vfos_save_quote');if($e)echo '<input type="hidden" name="id" value="'.$e->id.'">';if($edit_template)echo '<input type="hidden" name="template_id" value="'.$edit_template.'">';if($edit_template)echo '<section class="vfos-template-edit-meta"><div><span class="vfos-kicker">EDITANDO MODELO</span><h3>Informações do modelo</h3><p>Altere o nome e a descrição usados na biblioteca de modelos.</p></div><label>Nome do modelo<input name="template_name" required value="'.esc_attr($template_row->name).'"></label><label>Descrição do modelo<input name="template_description" value="'.esc_attr($template_row->description).'"></label></section>';
            echo '<section class="vfos-quote-pro-section"><div class="vfos-section-title"><span>01</span><div><h3>Identificação da proposta</h3><p>'.($edit_template?'Modelos não ficam vinculados a clientes.':'O cliente é opcional: deixe sem cliente para gerar uma proposta padrão compartilhável.').'</p></div></div><div class="vfos-form-grid">';if(!$edit_template){echo '<label>Cliente <small>Opcional</small><select name="client_id"><option value="0">Proposta padrão / sem cliente específico</option>';$this->clients_options($e->client_id??0);echo '</select></label>';}else{echo '<input type="hidden" name="client_id" value="0">';}echo '<label>Título da proposta<input name="title" required value="'.esc_attr($title).'" placeholder="Ex.: Desenvolvimento de Loja Virtual"></label><label>Validade<input type="date" name="valid_until" value="'.esc_attr($e->valid_until??($template_data['quote']['valid_until']??date('Y-m-d',strtotime('+10 days')))).'"></label><label>Status<select name="status">';foreach(['draft'=>'Rascunho','sent'=>'Enviado','accepted'=>'Aceito','rejected'=>'Recusado'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->status??'draft',$k,false).'>'.$v.'</option>';echo '</select></label></div><label>Apresentação inicial<textarea name="description" rows="4" data-vfos-ai="quote_intro" data-vfos-ai-label="Apresentação inicial da proposta" placeholder="Uma introdução curta, profissional e persuasiva sobre a proposta.">'.esc_textarea($description).'</textarea></label></section>';

            echo '<section class="vfos-quote-pro-section"><div class="vfos-panel-head"><div class="vfos-section-title"><span>02</span><div><h3>Seções comerciais e persuasivas</h3><p>Crie páginas como “Por que contratar?”, “O que pensamos para sua loja virtual”, diferenciais, estratégia, resultados esperados e qualquer outra.</p></div></div><button type="button" class="button button-primary vfos-add-quote-section">+ Adicionar seção</button></div><div id="vfos-quote-sections">';
            $default_sections=[
                (object)['section_type'=>'why','title'=>'Por que contratar esta solução?','content'=>'Mostre ao cliente os benefícios comerciais, estratégicos e de posicionamento que esta solução pode gerar.'],
                (object)['section_type'=>'vision','title'=>'O que pensamos para o seu projeto','content'=>'Descreva a visão da VisionForge para o projeto, experiência desejada, estratégia, identidade e diferenciais.'],
                (object)['section_type'=>'benefits','title'=>'Resultados e diferenciais','content'=>'Apresente os principais ganhos, diferenciais, facilidades e resultados esperados.'],
            ];
            $section_seed=$sections?:$default_sections;
            foreach($section_seed as $i=>$sec)echo '<div class="vfos-quote-section-row" data-index="'.$i.'"><div class="vfos-drag-handle">☰</div><label>Tipo<select name="sections['.$i.'][section_type]"><option value="why" '.selected($sec->section_type??'custom','why',false).'>Por que contratar?</option><option value="vision" '.selected($sec->section_type??'custom','vision',false).'>Nossa visão</option><option value="benefits" '.selected($sec->section_type??'custom','benefits',false).'>Benefícios</option><option value="process" '.selected($sec->section_type??'custom','process',false).'>Como trabalhamos</option><option value="custom" '.selected($sec->section_type??'custom','custom',false).'>Personalizada</option></select></label><label class="vfos-grow">Título<input name="sections['.$i.'][title]" value="'.esc_attr($sec->title??'').'" placeholder="Título da seção"></label><label class="vfos-section-content">Conteúdo<textarea data-vfos-ai="quote_section" data-vfos-ai-label="Conteúdo da seção do orçamento" name="sections['.$i.'][content]" rows="5" placeholder="Escreva o conteúdo que aparecerá como uma página/bloco da proposta.">'.esc_textarea($sec->content??'').'</textarea></label><button type="button" class="button vfos-remove-quote-section">×</button></div>';
            echo '</div></section>';

            echo '<section class="vfos-quote-pro-section"><div class="vfos-panel-head"><div class="vfos-section-title"><span>03</span><div><h3>Serviços e entregáveis VisionForge</h3><p>Itens cobrados diretamente pela VisionForge.</p></div></div><button type="button" class="button button-primary vfos-add-quote-item">+ Adicionar item</button></div><div id="vfos-quote-items">';
            $seed=$items?:[(object)['service_id'=>0,'title'=>'','description'=>'','quantity'=>1,'unit_price'=>0]];
            foreach($seed as $i=>$x){echo '<div class="vfos-quote-item" data-index="'.$i.'"><div class="vfos-quote-item-number">'.($i+1).'</div><label>Serviço padrão<select class="vfos-quote-service" name="items['.$i.'][service_id]"><option value="0">Item personalizado</option>';foreach($services as $srv)echo '<option value="'.$srv->id.'" data-name="'.esc_attr($srv->name).'" data-price="'.esc_attr($srv->price).'" data-description="'.esc_attr($srv->description).'" '.selected($x->service_id??0,$srv->id,false).'>'.esc_html($srv->name).'</option>';echo '</select></label><label class="vfos-grow">Item / entrega<input class="vfos-item-title" name="items['.$i.'][title]" required value="'.esc_attr($x->title??'').'" placeholder="Ex.: Desenvolvimento completo da loja virtual"></label><label>Qtd.<input class="vfos-item-qty" type="number" min="0.01" step="0.01" inputmode="decimal" name="items['.$i.'][quantity]" value="'.esc_attr($x->quantity??1).'"></label><label>Valor unitário<input class="vfos-item-price" type="number" min="0" step="0.01" inputmode="decimal" name="items['.$i.'][unit_price]" value="'.esc_attr($x->unit_price??0).'"></label><label class="vfos-grow vfos-item-desc-label">Descrição<input class="vfos-item-description" name="items['.$i.'][description]" value="'.esc_attr($x->description??'').'" placeholder="O que está incluso neste item"></label><div class="vfos-item-total"><span>Total</span><strong>R$ <b>0,00</b></strong></div><button type="button" class="button vfos-remove-quote-item">×</button></div>';}
            echo '</div></section>';

            $visibility_defaults=['custom_sections'=>1,'external_costs'=>1,'payment_options'=>1,'company_info'=>1];
            $order_defaults=['custom_sections','deliverables','external_costs','payment_options','summary','company_info'];
            $visibility=$visibility_defaults;$proposal_order=$order_defaults;
            $stored_visibility=$e->proposal_visibility??($template_data['quote']['proposal_visibility']??'');
            if($stored_visibility){
                $decoded=json_decode($stored_visibility,true);
                if(is_array($decoded)){
                    $visibility=array_merge($visibility_defaults,array_intersect_key($decoded,$visibility_defaults));
                    if(!empty($decoded['order'])&&is_array($decoded['order'])){
                        $allowed_order=$order_defaults;$clean_order=[];
                        foreach($decoded['order'] as $key)if(in_array($key,$allowed_order,true)&&!in_array($key,$clean_order,true))$clean_order[]=$key;
                        foreach($allowed_order as $key)if(!in_array($key,$clean_order,true))$clean_order[]=$key;
                        $proposal_order=$clean_order;
                    }
                }
            }
            echo '<section class="vfos-quote-pro-section vfos-proposal-visibility"><div class="vfos-section-title"><span>⚙</span><div><h3>Páginas e tópicos da proposta</h3><p>Escolha o que aparece e arraste para definir a ordem em que o cliente verá cada parte.</p></div></div><div class="vfos-proposal-page-toggles">';
            foreach(['custom_sections'=>'Apresentação e tópicos personalizados','external_costs'=>'Custos externos','payment_options'=>'Opções detalhadas de pagamento','company_info'=>'Informações da VisionForge'] as $key=>$label){
                echo '<label><input type="checkbox" name="proposal_visibility['.$key.']" value="1" '.checked(!empty($visibility[$key]),true,false).'><span><strong>'.esc_html($label).'</strong><small>'.($key==='external_costs'?'Desative quando o projeto não possuir hospedagem, domínio, licenças ou outros custos pagos a terceiros.':'Você pode ocultar este tópico apenas nesta proposta.').'</small></span></label>';
            }
            echo '</div><div class="vfos-proposal-order-head"><div><strong>Ordem das páginas</strong><small>Arraste os blocos ou use ↑ e ↓. A capa continua sempre no início e o aceite/recusa sempre no final.</small></div></div><div id="vfos-proposal-order" class="vfos-proposal-order">';
            $order_labels=['custom_sections'=>'Apresentação / tópicos','deliverables'=>'Serviços e entregáveis','external_costs'=>'Custos externos','payment_options'=>'Formas de pagamento','summary'=>'Resumo da proposta','company_info'=>'Informações da VisionForge'];
            foreach($proposal_order as $key){
                echo '<div class="vfos-order-item" draggable="true" data-key="'.esc_attr($key).'"><span class="vfos-order-drag">⋮⋮</span><strong>'.esc_html($order_labels[$key]??$key).'</strong><div><button type="button" class="button vfos-order-up" title="Subir">↑</button><button type="button" class="button vfos-order-down" title="Descer">↓</button></div><input type="hidden" name="proposal_order[]" value="'.esc_attr($key).'"></div>';
            }
            echo '</div><div class="vfos-visibility-note">A capa e a página final de decisão são fixas. Os demais blocos podem ser reorganizados; tópicos desativados são simplesmente ignorados no link e no PDF.</div></section>';

            echo '<section class="vfos-quote-pro-section"><div class="vfos-panel-head"><div class="vfos-section-title"><span>04</span><div><h3>Custos externos e necessários</h3><p>Cadastre o fornecedor e, dentro dele, todas as opções de plano que o cliente poderá escolher.</p></div></div><button type="button" class="button button-primary vfos-add-quote-cost">+ Adicionar custo externo</button></div><div id="vfos-quote-costs">';
            $cost_seed=$costs?:[(object)['title'=>'Hospedagem','description'=>'Serviço necessário para manter o site online.','provider'=>'Hostinger','is_required'=>1,'options'=>[(object)['title'=>'Plano anual','amount'=>0,'billing_cycle'=>'annual','duration_months'=>12,'condition_text'=>'','benefits'=>'','highlight'=>1]]]];
            foreach($cost_seed as $i=>$c){
                $opts=$c->options??[];
                if(is_array($c)&&isset($c['options']))$opts=$c['options'];
                if(!$opts){
                    $fallback_amount=is_object($c)?($c->amount??0):($c['amount']??0);
                    $fallback_cycle=is_object($c)?($c->billing_cycle??'annual'):($c['billing_cycle']??'annual');
                    $opts=[(object)['title'=>'Opção principal','amount'=>$fallback_amount,'billing_cycle'=>$fallback_cycle,'duration_months'=>1,'condition_text'=>'','benefits'=>'','highlight'=>1]];
                }
                $ctitle=is_object($c)?($c->title??''):($c['title']??'');
                $cdesc=is_object($c)?($c->description??''):($c['description']??'');
                $cprovider=is_object($c)?($c->provider??''):($c['provider']??'');
                $creq=is_object($c)?($c->is_required??1):($c['is_required']??1);
                echo '<div class="vfos-quote-cost-card" data-index="'.$i.'"><div class="vfos-cost-card-head"><div><span class="vfos-kicker">CUSTO EXTERNO</span><h4>'.esc_html($ctitle?:'Novo custo externo').'</h4></div><button type="button" class="button vfos-remove-quote-cost">Remover custo</button></div><div class="vfos-form-grid"><label>Tipo de custo<input name="costs['.$i.'][title]" value="'.esc_attr($ctitle).'" placeholder="Ex.: Hospedagem"></label><label>Empresa / fornecedor<input name="costs['.$i.'][provider]" value="'.esc_attr($cprovider).'" placeholder="Ex.: Hostinger"></label><label class="vfos-grow">Descrição<input name="costs['.$i.'][description]" value="'.esc_attr($cdesc).'" placeholder="Explique por que este custo é necessário"></label><label class="vfos-check-inline"><input type="checkbox" name="costs['.$i.'][is_required]" value="1" '.checked($creq,1,false).'> Custo obrigatório</label></div><div class="vfos-cost-options-head"><div><strong>Planos e condições</strong><small>Cadastre mensal, trimestral, semestral, anual, bienal ou qualquer outra opção.</small></div><button type="button" class="button vfos-add-cost-option">+ Adicionar opção</button></div><div class="vfos-cost-options">';
                foreach($opts as $j=>$o){
                    $otitle=is_object($o)?($o->title??''):$o['title'];
                    $oamount=is_object($o)?($o->amount??0):($o['amount']??0);
                    $ocycle=is_object($o)?($o->billing_cycle??'monthly'):($o['billing_cycle']??'monthly');
                    $oduration=is_object($o)?($o->duration_months??1):($o['duration_months']??1);
                    $ocond=is_object($o)?($o->condition_text??''):($o['condition_text']??'');
                    $oben=is_object($o)?($o->benefits??''):($o['benefits']??'');
                    $ohigh=is_object($o)?($o->highlight??0):($o['highlight']??0);
                    echo '<div class="vfos-cost-option-row" data-option-index="'.$j.'"><label>Nome do plano<input name="costs['.$i.'][options]['.$j.'][title]" value="'.esc_attr($otitle).'" placeholder="Ex.: Premium 12 meses"></label><label>Valor total<input type="number" step="0.01" min="0" name="costs['.$i.'][options]['.$j.'][amount]" value="'.esc_attr($oamount).'"></label><label>Cobrança<select name="costs['.$i.'][options]['.$j.'][billing_cycle]"><option value="monthly" '.selected($ocycle,'monthly',false).'>Mensal</option><option value="quarterly" '.selected($ocycle,'quarterly',false).'>Trimestral</option><option value="semiannual" '.selected($ocycle,'semiannual',false).'>Semestral</option><option value="annual" '.selected($ocycle,'annual',false).'>Anual</option><option value="biennial" '.selected($ocycle,'biennial',false).'>A cada 2 anos</option><option value="one_time" '.selected($ocycle,'one_time',false).'>Pagamento único</option><option value="variable" '.selected($ocycle,'variable',false).'>Variável</option></select></label><label>Duração (meses)<input type="number" min="1" max="120" name="costs['.$i.'][options]['.$j.'][duration_months]" value="'.esc_attr($oduration).'"></label><label class="vfos-grow">Condições<input name="costs['.$i.'][options]['.$j.'][condition_text]" value="'.esc_attr($ocond).'" placeholder="Ex.: Domínio grátis em planos a partir de 12 meses"></label><label class="vfos-grow">Benefícios inclusos<input name="costs['.$i.'][options]['.$j.'][benefits]" value="'.esc_attr($oben).'" placeholder="Ex.: SSL, e-mails, backups, domínio grátis"></label><label class="vfos-check-inline"><input type="checkbox" name="costs['.$i.'][options]['.$j.'][highlight]" value="1" '.checked($ohigh,1,false).'> Destacar</label><button type="button" class="button vfos-remove-cost-option">×</button></div>';
                }
                echo '</div></div>';
            }
            echo '</div></section>';

                        echo '<section class="vfos-quote-pro-section"><div class="vfos-panel-head"><div class="vfos-section-title"><span>05</span><div><h3>Formas de pagamento</h3><p>Mostre alternativas detalhadas: à vista, parcelado, mensal, anual ou recorrente.</p></div></div><button type="button" class="button button-primary vfos-add-payment-option">+ Adicionar opção</button></div><div id="vfos-payment-options">';
            $payment_seed=$payments?:[(object)['title'=>'Pagamento do projeto','description'=>'50% no início e 50% na entrega final.','amount'=>0,'billing_cycle'=>'one_time','installments'=>2,'highlight'=>1]];
            foreach($payment_seed as $i=>$p)echo '<div class="vfos-payment-option-row" data-index="'.$i.'"><label class="vfos-grow">Nome da opção<input name="payments['.$i.'][title]" value="'.esc_attr($p->title??'').'" placeholder="Ex.: Plano anual"></label><label>Valor<input type="number" step="0.01" min="0" name="payments['.$i.'][amount]" value="'.esc_attr($p->amount??0).'"></label><label>Periodicidade<select name="payments['.$i.'][billing_cycle]"><option value="one_time" '.selected($p->billing_cycle??'one_time','one_time',false).'>Pagamento único</option><option value="monthly" '.selected($p->billing_cycle??'one_time','monthly',false).'>Mensal</option><option value="annual" '.selected($p->billing_cycle??'one_time','annual',false).'>Anual</option><option value="recurring" '.selected($p->billing_cycle??'one_time','recurring',false).'>Recorrente</option></select></label><label>Parcelas<input type="number" min="1" max="36" name="payments['.$i.'][installments]" value="'.esc_attr($p->installments??1).'"></label><label class="vfos-grow">Detalhes<input name="payments['.$i.'][description]" value="'.esc_attr($p->description??'').'"></label><label class="vfos-check-inline"><input type="checkbox" name="payments['.$i.'][highlight]" value="1" '.checked($p->highlight??0,1,false).'> Destacar</label><button type="button" class="button vfos-remove-payment-option">×</button></div>';
            echo '</div></section>';

            echo '<section class="vfos-quote-pro-section"><div class="vfos-section-title"><span>06</span><div><h3>Resumo e condições</h3><p>Finalize o investimento e as observações comerciais.</p></div></div><div class="vfos-quote-bottom"><div class="vfos-quote-conditions"><label>Condições gerais de pagamento<textarea name="payment_terms" rows="4" data-vfos-ai="quote_payment_terms" data-vfos-ai-label="Condições de pagamento">'.esc_textarea($payment_terms).'</textarea></label><label>Observações finais<textarea name="notes" rows="5" data-vfos-ai="quote_notes" data-vfos-ai-label="Observações finais">'.esc_textarea($notes).'</textarea></label></div><aside class="vfos-quote-summary"><span class="vfos-kicker">INVESTIMENTO VISIONFORGE</span><h3>Resumo financeiro</h3><div><span>Subtotal</span><strong id="vfos-quote-subtotal">R$ 0,00</strong></div><label>Tipo de desconto<select name="discount_type" id="vfos-discount-type"><option value="fixed" '.selected($discount_type,'fixed',false).'>Valor em R$</option><option value="percent" '.selected($discount_type,'percent',false).'>Percentual %</option></select></label><label>Desconto<input id="vfos-discount-value" type="number" min="0" step="0.01" inputmode="decimal" name="discount_value" value="'.esc_attr($discount_value).'"></label><div class="vfos-quote-discount-line"><span>Desconto aplicado</span><strong id="vfos-quote-discount">R$ 0,00</strong></div><div class="vfos-quote-final"><span>INVESTIMENTO FINAL</span><strong id="vfos-quote-total">R$ 0,00</strong></div><small>Custos externos são demonstrados separadamente e não entram neste total.</small></aside></div></section>';

            if(!$edit_template)echo '<section class="vfos-flow-builder"><div><span class="vfos-kicker">AUTOMAÇÃO DO FLUXO</span><h3>Quando este orçamento for aceito</h3><p>Escolha quais etapas o VisionForge deve preparar automaticamente. Você também poderá executar qualquer uma manualmente depois.</p></div><div class="vfos-flow-options"><label><input type="checkbox" name="flow_create_contract" value="1" '.checked($e->flow_create_contract??1,1,false).'> Criar contrato</label><label><input type="checkbox" name="flow_create_project" value="1" '.checked($e->flow_create_project??1,1,false).'> Criar projeto</label><label><input type="checkbox" name="flow_create_financial" value="1" '.checked($e->flow_create_financial??1,1,false).'> Criar cobrança no financeiro</label></div></section>';
            echo '<div class="vfos-form-actions"><button class="button button-primary vfos-btn">'.($edit_template?'Salvar alterações no modelo':($e?'Salvar alterações':'Criar orçamento')).'</button>'.($e?'<a class="button" target="_blank" href="'.esc_url(VFOS_Proposal::url($e)).'">Visualizar proposta</a>':'').'<a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-quotes&tab='.($edit_template?'templates':'list'))).'">Cancelar</a></div></form>';
            if($e&&!$edit_template&&VFOS_Team::can_permission('quotes.templates')){echo '<div class="vfos-save-template-box"><div><span class="vfos-kicker">REUTILIZAR</span><h3>Salvar esta proposta como modelo</h3><p>O modelo guarda textos, itens, seções, custos externos e formas de pagamento, mas não fica preso ao cliente.</p></div><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_quote_template"><input type="hidden" name="quote_id" value="'.$e->id.'">';wp_nonce_field('vfos_save_quote_template_'.$e->id);echo '<input name="template_name" required placeholder="Nome do modelo, ex.: Loja Virtual Completa"><input name="template_description" placeholder="Descrição opcional"><button class="button button-primary">Salvar como modelo</button></form></div>';}
            echo '</div>';
        }else{
            $search=$this->q('s');$status=sanitize_key($_GET['status']??'');$client=absint($_GET['client']??0);$valid=sanitize_key($_GET['valid']??'');$where=['1=1'];$args=[];
            if($search!==''){$where[]='(q.number LIKE %s OR q.title LIKE %s OR c.name LIKE %s OR c.trade_name LIKE %s OR c.legal_name LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like,$like,$like,$like);}
            if(in_array($status,['draft','sent','accepted','rejected'],true)){$where[]='q.status=%s';$args[]=$status;}if($client){$where[]='q.client_id=%d';$args[]=$client;}if($valid==='expired')$where[]="q.valid_until<CURDATE() AND q.status NOT IN ('accepted','rejected')";elseif($valid==='active')$where[]="(q.valid_until IS NULL OR q.valid_until>=CURDATE())";
            $sql="SELECT q.*,COALESCE(NULLIF(c.trade_name,''),NULLIF(c.legal_name,''),c.name) client_name,c.email client_email FROM $qt q LEFT JOIN $ct c ON c.id=q.client_id WHERE ".implode(' AND ',$where)." ORDER BY q.id DESC LIMIT 400";$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">PROPOSTAS COMERCIAIS</span><h2>Orçamentos</h2><p>Links podem ser compartilhados inclusive quando a proposta não possui cliente específico.</p></div>'.(VFOS_Team::can_permission('quotes.create')?'<a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-quotes&tab=new')).'">+ Novo orçamento</a>':'').'</div>';$this->filter_start('vfos-quotes');echo '<label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Número, título ou cliente"></label><label>Status<select name="status"><option value="">Todos</option>';foreach(['draft'=>'Rascunho','sent'=>'Enviado','accepted'=>'Aceito','rejected'=>'Recusado'] as $k=>$v)echo '<option value="'.$k.'" '.selected($status,$k,false).'>'.$v.'</option>';echo '</select></label>';$this->filter_end();
            echo '<div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Número</th><th>Proposta</th><th>Cliente</th><th>Status</th><th>Investimento</th><th>Ações</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="6">Nenhum orçamento encontrado.</td></tr>';
            foreach($rows as $r){$ed=admin_url('admin.php?page=vfos-quotes&tab=new&edit='.$r->id);$preview=VFOS_Proposal::url($r);$send=wp_nonce_url(admin_url('admin-post.php?action=vfos_send_quote&id='.$r->id),'vfos_send_quote');$flowContract=wp_nonce_url(admin_url('admin-post.php?action=vfos_flow_quote_contract&id='.$r->id),'vfos_flow_quote_contract');$flowProject=wp_nonce_url(admin_url('admin-post.php?action=vfos_flow_quote_project&id='.$r->id),'vfos_flow_quote_project');$flowFinancial=wp_nonce_url(admin_url('admin-post.php?action=vfos_flow_quote_financial&id='.$r->id),'vfos_flow_quote_financial');$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_quote&id='.$r->id),'vfos_delete_quote');echo '<tr><td><strong>'.esc_html($r->number).'</strong></td><td><strong>'.esc_html($r->title).'</strong><small>'.esc_html(date_i18n('d/m/Y',strtotime($r->created_at))).'</small></td><td>'.esc_html($r->client_name?:'Proposta padrão').'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td><strong>R$ '.number_format((float)$r->total,2,',','.').'</strong></td><td><a target="_blank" href="'.esc_url($preview).'">Visualizar</a> · <button type="button" class="button-link vfos-copy-proposal-link" data-url="'.esc_attr($preview).'">Copiar link</button>';if(VFOS_Team::can_permission('quotes.edit'))echo ' · <a href="'.esc_url($ed).'">Editar</a>';if($r->client_id&&VFOS_Team::can_permission('quotes.send'))echo ' · <a href="'.esc_url($send).'">Enviar</a>';if($r->client_id&&VFOS_Team::can_permission('quotes.convert')){echo ' · <details class="vfos-inline-flow"><summary>Continuar fluxo</summary><div>';echo '<a href="'.esc_url($flowContract).'">'.($r->converted_contract_id?'Abrir contrato':'Criar contrato').'</a><a href="'.esc_url($flowProject).'">'.($r->converted_project_id?'Abrir projeto':'Criar projeto').'</a><a href="'.esc_url($flowFinancial).'">'.($r->converted_financial_id?'Abrir cobrança':'Criar cobrança').'</a></div></details>';}if(VFOS_Team::can_permission('quotes.delete'))echo ' · <a class="vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir orçamento?\')">Excluir</a>';echo '</td></tr>';}
            echo '</tbody></table></div></div>';
        }$this->end();
    }

    public function projects(){
        VFOS_Team::require_permission('projects.view');global $wpdb;$pt=VFOS_DB::table('projects');$ct=VFOS_DB::table('clients');$st=VFOS_DB::table('services');$edit=absint($_GET['edit']??0);$tab=$edit?'new':sanitize_key($_GET['tab']??'list');$e=$edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $pt WHERE id=%d",$edit)):null;$services=$wpdb->get_results("SELECT id,name FROM $st WHERE status='active' ORDER BY name");if($tab==='new')VFOS_Team::require_permission($edit?'projects.edit':'projects.create');$this->header('Projetos','Acompanhe entregas, prazos e progresso.');echo '<nav class="vfos-tabs">';$this->module_tab('vfos-projects','list','Visualização',$tab);if(VFOS_Team::can_permission('projects.create')||($edit&&VFOS_Team::can_permission('projects.edit')))$this->module_tab('vfos-projects','new',$edit?'Editar projeto':'Novo projeto',$tab);echo '</nav>';
        if($tab==='new'){echo '<div class="vfos-panel"><span class="vfos-kicker">CADASTRO</span><h2>'.($e?'Editar projeto':'Novo projeto').'</h2>';if($e&&!empty($e->source_type))echo '<div class="vfos-origin-note">Criado a partir de <strong>'.esc_html(ucfirst($e->source_type)).' #'.absint($e->source_id).'</strong></div>';$this->form_start('vfos_save_project');if($e)echo '<input type="hidden" name="id" value="'.$e->id.'">';echo '<div class="vfos-form-grid"><label>Projeto<input name="name" required value="'.esc_attr($e->name??'').'"></label><label>Cliente<select name="client_id">';$this->clients_options($e->client_id??absint($_GET['client_id']??0));echo '</select></label><label>Serviço<select name="service_id"><option value="0">Opcional</option>';foreach($services as $sv)echo '<option value="'.$sv->id.'" '.selected($e->service_id??0,$sv->id,false).'>'.esc_html($sv->name).'</option>';echo '</select></label><label>Valor (R$)<input type="number" step="0.01" name="value" value="'.esc_attr($e->value??'').'"></label><label>Prazo<input type="date" name="due_date" value="'.esc_attr($e->due_date??'').'"></label><label>Status<select name="status">';foreach(['planning'=>'Planejamento','in_progress'=>'Em andamento','review'=>'Em aprovação','completed'=>'Concluído','cancelled'=>'Cancelado'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->status??'planning',$k,false).'>'.$v.'</option>';echo '</select></label><label>Prioridade<select name="priority">';foreach(['low'=>'Baixa','normal'=>'Normal','high'=>'Alta','urgent'=>'Urgente'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->priority??'normal',$k,false).'>'.$v.'</option>';echo '</select></label><label>Progresso (%)<input type="number" min="0" max="100" name="progress" value="'.esc_attr($e->progress??0).'"></label></div><label>Observações<textarea name="notes" data-vfos-ai="generic" data-vfos-ai-label="Observações e escopo do projeto">'.esc_textarea($e->notes??'').'</textarea></label><div class="vfos-flow-box"><div><span class="vfos-kicker">FINANCEIRO</span><strong>Gerar cobrança a partir do projeto</strong><small>Útil quando o processo começou diretamente pelo projeto, sem orçamento ou contrato.</small></div><label class="vfos-switch-row"><input type="checkbox" name="flow_create_financial" value="1" '.checked($e->flow_create_financial??0,1,false).'> Criar cobrança automaticamente ao salvar</label></div><button class="button button-primary vfos-btn">'.($e?'Salvar alterações':'Criar projeto').'</button> <a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-projects&tab=list')).'">Cancelar</a></form></div>';}
        else{$search=$this->q('s');$status=sanitize_key($_GET['status']??'');$priority=sanitize_key($_GET['priority']??'');$client=absint($_GET['client']??0);$where=['1=1'];$args=[];if($search!==''){$where[]='(p.name LIKE %s OR c.name LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like);}if($status!==''){$where[]='p.status=%s';$args[]=$status;}if($priority!==''){$where[]='p.priority=%s';$args[]=$priority;}if($client){$where[]='p.client_id=%d';$args[]=$client;}if(VFOS_Team::limited_to_assigned()){$where[]='EXISTS (SELECT 1 FROM '.VFOS_DB::table('tasks').' tx WHERE tx.project_id=p.id AND tx.assigned_user_id=%d)';$args[]=get_current_user_id();}$sql="SELECT p.*,c.name client_name FROM $pt p LEFT JOIN $ct c ON c.id=p.client_id WHERE ".implode(' AND ',$where).' ORDER BY p.id DESC';$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISUALIZAÇÃO</span><h2>Projetos</h2></div>'.(!VFOS_Team::limited_to_assigned()&&VFOS_Team::can_permission('projects.create')?'<a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-projects&tab=new')).'">+ Novo projeto</a>':'').'</div>';$this->filter_start('vfos-projects');echo '<label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Projeto ou cliente"></label><label>Cliente<select name="client">';$this->client_filter_select($client);echo '</select></label><label>Status<select name="status"><option value="">Todos</option>';foreach(['planning'=>'Planejamento','in_progress'=>'Em andamento','review'=>'Em aprovação','completed'=>'Concluído','cancelled'=>'Cancelado'] as $k=>$v)echo '<option value="'.$k.'" '.selected($status,$k,false).'>'.$v.'</option>';echo '</select></label><label>Prioridade<select name="priority"><option value="">Todas</option>';foreach(['low'=>'Baixa','normal'=>'Normal','high'=>'Alta','urgent'=>'Urgente'] as $k=>$v)echo '<option value="'.$k.'" '.selected($priority,$k,false).'>'.$v.'</option>';echo '</select></label>';$this->filter_end();echo '<div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Projeto</th><th>Cliente</th><th>Status</th><th>Prioridade</th><th>Progresso</th><th>Prazo</th><th>Valor</th><th>Ações</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="8">Nenhum projeto encontrado.</td></tr>';foreach($rows as $r){$ed=admin_url('admin.php?page=vfos-projects&tab=new&edit='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_project&id='.$r->id),'vfos_delete_project');$view=admin_url('admin.php?page=vfos-project-view&id='.$r->id);echo '<tr><td><strong><a href="'.esc_url($view).'">'.esc_html($r->name).'</a></strong></td><td>'.esc_html($r->client_name?:'Sem cliente').'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td>'.esc_html(ucfirst($r->priority)).'</td><td>'.(int)$r->progress.'%</td><td>'.($r->due_date?esc_html(date_i18n('d/m/Y',strtotime($r->due_date))):'—').'</td><td>R$ '.number_format($r->value,2,',','.').'</td><td><a href="'.esc_url($view).'">Visualizar</a> · <a href="'.esc_url($ed).'">Editar</a> · <a class="vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir projeto?\')">Excluir</a></td></tr>';}echo '</tbody></table></div></div>';}$this->end();
    }
    public function project_view(){
        VFOS_Team::require_module('projects');global $wpdb;
        $id=absint($_GET['id']??0);$tab=sanitize_key($_GET['tab']??'overview');
        if(!in_array($tab,['overview','stages','tasks','kanban','timeline','files','approvals','presentation','financial','history'],true))$tab='overview';
        $pt=VFOS_DB::table('projects');$ct=VFOS_DB::table('clients');$st=VFOS_DB::table('services');$tt=VFOS_DB::table('tasks');
        $p=$wpdb->get_row($wpdb->prepare("SELECT p.*,c.name client_name,s.name service_name FROM $pt p LEFT JOIN $ct c ON c.id=p.client_id LEFT JOIN $st s ON s.id=p.service_id WHERE p.id=%d",$id));
        if(!$p)wp_die('Projeto não encontrado.');
        if(VFOS_Team::limited_to_assigned()){ $assigned=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE project_id=%d AND assigned_user_id=%d",$id,get_current_user_id()));if(!$assigned)wp_die('Este projeto não está atribuído a você.');}
        $tasks=$wpdb->get_results($wpdb->prepare("SELECT t.*,u.display_name assigned_name,ps.title stage_name FROM $tt t LEFT JOIN {$wpdb->users} u ON u.ID=t.assigned_user_id LEFT JOIN ".VFOS_DB::table('project_stages')." ps ON ps.id=t.stage_id WHERE t.project_id=%d ORDER BY (t.status='done'),t.due_date IS NULL,t.due_date,t.id",$id));
        $done=count(array_filter($tasks,fn($x)=>$x->status==='done'));$progress=count($tasks)?(int)round($done/count($tasks)*100):(int)$p->progress;
        if(count($tasks)&&(int)$p->progress!==$progress){$wpdb->update($pt,['progress'=>$progress,'updated_at'=>current_time('mysql')],['id'=>$id]);$p->progress=$progress;}
        $hours_est=array_sum(array_map(fn($x)=>(float)$x->estimated_hours,$tasks));$hours_real=array_sum(array_map(fn($x)=>(float)$x->actual_hours,$tasks));
        $base=admin_url('admin.php?page=vfos-project-view&id='.$id);
        $this->header($p->name,'Projeto 360° • '.($p->client_name?:'Sem cliente'));
        echo '<div class="vfos-project-hero"><div class="vfos-project-hero-logo"><img src="'.esc_url(VFOS_URL.'admin/assets/images/visionforge-logo.png').'" alt="VisionForge"></div><div class="vfos-project-hero-copy"><span class="vfos-kicker">PROJETO 360°</span><h2>'.esc_html($p->name).'</h2><p>'.esc_html($p->service_name?:'Projeto personalizado').' • '.esc_html($p->client_name?:'Sem cliente').'</p></div><div class="vfos-project-progress"><strong>'.$progress.'%</strong><span>concluído</span></div></div>';
        echo '<nav class="vfos-project-tabs vfos-project-tabs-360">';foreach(['overview'=>'Resumo','stages'=>'Etapas','tasks'=>'Tarefas','kanban'=>'Kanban','timeline'=>'Cronograma','files'=>'Arquivos','approvals'=>'Aprovações','presentation'=>'Apresentação','financial'=>'Financeiro','history'=>'Histórico'] as $k=>$label){if($k==='financial'&&!VFOS_Team::can('financial'))continue;if($k==='presentation'&&!VFOS_Team::can_permission('projects.presentation'))continue;echo '<a class="'.($tab===$k?'is-active':'').'" href="'.esc_url(add_query_arg('tab',$k,$base)).'">'.$label.'</a>';}echo '</nav>';

        if($tab==='overview'){
            $stages=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_stages')." WHERE project_id=%d ORDER BY sort_order,id",$id));$approvals=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('project_approvals')." WHERE project_id=%d AND status='pending'",$id));
            echo '<div class="vfos-stats"><div class="vfos-stat"><span>Status</span><strong>'.esc_html($this->status_label($p->status)).'</strong></div><div class="vfos-stat"><span>Progresso</span><strong>'.$progress.'%</strong></div><div class="vfos-stat"><span>Prazo</span><strong>'.($p->due_date?date_i18n('d/m/Y',strtotime($p->due_date)):'—').'</strong></div><div class="vfos-stat"><span>Tarefas</span><strong>'.$done.'/'.count($tasks).'</strong></div><div class="vfos-stat"><span>Horas</span><strong>'.number_format($hours_real,1,',','.').' / '.number_format($hours_est,1,',','.').'</strong></div><div class="vfos-stat"><span>Aprovações pendentes</span><strong>'.$approvals.'</strong></div></div>';
            echo '<div class="vfos-grid vfos-grid-2"><div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">ETAPAS</span><h2>Andamento do projeto</h2></div><a class="button" href="'.esc_url(add_query_arg('tab','stages',$base)).'">Gerenciar</a></div><div class="vfos-stage-mini">';
            if(!$stages)echo '<div class="vfos-empty">Nenhuma etapa criada ainda.</div>';foreach($stages as $s){$cnt=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE stage_id=%d",$s->id));$sdone=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE stage_id=%d AND status='done'",$s->id));$pct=$cnt?(int)round($sdone/$cnt*100):($s->status==='done'?100:0);echo '<div><header><strong>'.esc_html($s->title).'</strong><span>'.$pct.'%</span></header><div class="vfos-stage-bar"><i style="width:'.$pct.'%"></i></div><small>'.$sdone.'/'.$cnt.' tarefas'.($s->due_date?' • '.date_i18n('d/m',strtotime($s->due_date)):'').'</small></div>';}echo '</div></div>';
            echo '<div class="vfos-panel"><span class="vfos-kicker">DETALHES</span><h2>Resumo</h2><p><strong>Cliente:</strong> '.esc_html($p->client_name?:'—').'</p><p><strong>Serviço:</strong> '.esc_html($p->service_name?:'—').'</p><p><strong>Valor:</strong> R$ '.number_format((float)$p->value,2,',','.').'</p><p><strong>Prioridade:</strong> '.esc_html(ucfirst($p->priority)).'</p><p>'.nl2br(esc_html($p->notes?:'Sem observações.')).'</p>'.(!VFOS_Team::limited_to_assigned()?'<a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-projects&tab=new&edit='.$id)).'">Editar projeto</a>':'').'</div></div>'; $project_contracts=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('contracts')." WHERE project_id=%d ORDER BY id DESC",$id)); if($project_contracts){echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISIONFORGE SIGN</span><h2>Contratos do projeto</h2></div><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-contracts&client_id='.$p->client_id.'&project_id='.$id)).'">Novo contrato</a></div><div class="vfos-document-list-admin">';foreach($project_contracts as $pc)echo '<article><div><strong>'.esc_html($pc->number.' · '.$pc->title).'</strong><small>'.esc_html($pc->sign_public_code?:'Ainda não conectado ao Sign').' • '.esc_html($pc->sign_status?:$pc->status).'</small></div>'.($pc->sign_admin_url?'<a class="button" target="_blank" href="'.esc_url($pc->sign_admin_url).'">Abrir Sign</a>':'').($pc->sign_signed_url?'<a class="button button-primary" target="_blank" href="'.esc_url($pc->sign_signed_url).'">PDF assinado</a>':'').'</article>';echo '</div></div>';}
        } elseif($tab==='stages'){
            $rows=$wpdb->get_results($wpdb->prepare("SELECT ps.*,u.display_name assigned_name FROM ".VFOS_DB::table('project_stages')." ps LEFT JOIN {$wpdb->users} u ON u.ID=ps.assigned_user_id WHERE ps.project_id=%d ORDER BY ps.sort_order,ps.id",$id));
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">ETAPAS</span><h2>Fluxo de produção</h2></div></div>';
            if(!VFOS_Team::limited_to_assigned()){echo '<form class="vfos-stage-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_project_stage"><input type="hidden" name="project_id" value="'.$id.'">';wp_nonce_field('vfos_save_project_stage');echo '<input name="title" required placeholder="Nome da etapa"><input type="date" name="due_date"><select name="assigned_user_id"><option value="0">Sem responsável</option>';$members=$wpdb->get_results("SELECT tm.user_id,u.display_name FROM ".VFOS_DB::table('team')." tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE tm.status='active' ORDER BY u.display_name");foreach($members as $m)echo '<option value="'.$m->user_id.'">'.esc_html($m->display_name).'</option>';echo '</select><button class="button button-primary vfos-btn">+ Adicionar etapa</button></form>';}
            echo '<div class="vfos-stage-list">';if(!$rows)echo '<div class="vfos-empty">Crie etapas como Briefing, Criação, Revisão e Entrega.</div>';foreach($rows as $s){$cnt=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE stage_id=%d",$s->id));$sdone=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE stage_id=%d AND status='done'",$s->id));$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_project_stage&id='.$s->id.'&project_id='.$id),'vfos_delete_project_stage');echo '<article><div class="vfos-stage-order">'.((int)$s->sort_order+1).'</div><div><strong>'.esc_html($s->title).'</strong><small>'.esc_html($s->assigned_name?:'Sem responsável').' • '.$sdone.'/'.$cnt.' tarefas'.($s->due_date?' • prazo '.date_i18n('d/m/Y',strtotime($s->due_date)):'').'</small></div><span class="vfos-pill">'.esc_html($this->status_label($s->status)).'</span>'.(!VFOS_Team::limited_to_assigned()?'<a class="vfos-mini-danger" href="'.esc_url($del).'">×</a>':'').'</article>';}echo '</div></div>';
        } elseif($tab==='tasks'){
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">PRODUÇÃO</span><h2>Tarefas do projeto</h2></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab=new&project_id='.$id.'&client_id='.$p->client_id)).'">+ Nova tarefa</a></div><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Tarefa</th><th>Etapa</th><th>Responsável</th><th>Horas</th><th>Prazo</th><th>Status</th></tr></thead><tbody>';if(!$tasks)echo '<tr><td colspan="6">Nenhuma tarefa.</td></tr>';foreach($tasks as $t)echo '<tr><td><a href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab=new&edit='.$t->id)).'"><strong>'.esc_html($t->title).'</strong></a></td><td>'.esc_html($t->stage_name?:'—').'</td><td>'.esc_html($t->assigned_name?:'—').'</td><td>'.number_format((float)$t->actual_hours,1,',','.').' / '.number_format((float)$t->estimated_hours,1,',','.').'</td><td>'.($t->due_date?date_i18n('d/m/Y',strtotime($t->due_date)):'—').'</td><td><span class="vfos-pill">'.esc_html($this->status_label($t->status)).'</span></td></tr>';echo '</tbody></table></div></div>';
        } elseif($tab==='approvals'){
            $rows=$wpdb->get_results($wpdb->prepare("SELECT a.*,u.display_name requested_name FROM ".VFOS_DB::table('project_approvals')." a LEFT JOIN {$wpdb->users} u ON u.ID=a.requested_by WHERE a.project_id=%d ORDER BY a.id DESC",$id));
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">APRESENTAR AO CLIENTE</span><h2>Entregas para aprovação</h2><p>Envie posts, artes, layouts, PDFs ou links para o cliente revisar na Área do Cliente.</p></div></div><form class="vfos-approval-form" method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_project_approval"><input type="hidden" name="project_id" value="'.$id.'">';wp_nonce_field('vfos_save_project_approval');echo '<div class="vfos-form-grid"><label>Título<input name="title" required placeholder="Ex.: Post 01 — Campanha de agosto"></label><label>Arquivo da apresentação<input type="file" name="approval_file" accept="image/*,.pdf,.doc,.docx,.zip"></label><label class="vfos-grow">Ou link externo <small>Opcional</small><input type="url" name="file_url" placeholder="https://..."></label></div><label>Orientações ao cliente<textarea name="description" placeholder="Ex.: Confira texto, cores e posicionamento antes de aprovar."></textarea></label><div class="vfos-approval-protection"><div><span class="vfos-kicker">PROTEÇÃO DE IMAGEM</span><h3>Prévia com marca d’água</h3><p>Se o arquivo for uma imagem, o cliente verá uma cópia marcada. O original não é mostrado até você liberá-lo.</p></div><label class="vfos-switch-row"><input type="checkbox" name="watermark_enabled" value="1" checked> Aplicar marca d’água</label><label>Texto da marca <small>Opcional</small><input name="watermark_text" placeholder="VISIONFORGE • APENAS PARA APROVAÇÃO"></label></div><button class="button button-primary vfos-btn">Enviar para aprovação do cliente</button></form><div class="vfos-approval-grid">';if(!$rows)echo '<div class="vfos-empty">Nenhuma aprovação cadastrada.</div>';foreach($rows as $a){$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_project_approval&id='.$a->id.'&project_id='.$id),'vfos_delete_project_approval');$orig=!empty($a->original_path)?wp_nonce_url(admin_url('admin-post.php?action=vfos_approval_original&table=project_approvals&id='.$a->id),'vfos_approval_original_project_approvals_'.$a->id):'';$toggle=wp_nonce_url(admin_url('admin-post.php?action=vfos_toggle_project_approval_release&id='.$a->id.'&project_id='.$id),'vfos_toggle_project_approval_release_'.$a->id);echo '<article><div><span class="vfos-kicker">'.esc_html(strtoupper($a->status)).'</span><h3>'.esc_html($a->title).'</h3><p>'.esc_html($a->description).'</p>'.(!empty($a->watermark_enabled)?'<small>🔒 Prévia protegida por marca d’água</small>':'').'<small>Criado por '.esc_html($a->requested_name?:'VisionForge').' • '.date_i18n('d/m/Y H:i',strtotime($a->requested_at)).'</small></div><div>'.($a->file_url?'<a class="button button-primary vfos-btn" target="_blank" href="'.esc_url($a->file_url).'">Ver prévia</a> ':'').($orig?'<a class="button" href="'.esc_url($orig).'">Baixar original</a> ':'').($a->status==='approved'&&!empty($a->original_path)?'<a class="button" href="'.esc_url($toggle).'">'.($a->release_original?'Bloquear download':'Liberar download').'</a> ':'').'<a class="button vfos-danger" href="'.esc_url($del).'">Excluir</a></div></article>';}echo '</div></div>';
        } elseif($tab==='presentation'){
            VFOS_Team::require_permission('projects.presentation');
            $ptab=VFOS_DB::table('project_presentations');$pr=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ptab WHERE project_id=%d",$id));
            $task_items=implode("\n",array_map(fn($t)=>$t->title,$tasks));
            $defaults=(object)[
                'title'=>$p->name,'subtitle'=>'Apresentação comercial e escopo do projeto','why_title'=>'Por que investir neste projeto?','why_content'=>'',
                'vision_title'=>'O que imaginamos para '.($p->client_name?:'o cliente'),'vision_content'=>$p->notes?:'',
                'included_title'=>'O que está incluso','included_items'=>$task_items,'investment_title'=>'Investimento','investment_content'=>'O investimento contempla o desenvolvimento e as entregas descritas nesta apresentação.','investment_value'=>$p->value,
                'differentials_title'=>'Diferenciais e benefícios','differentials'=>"Atendimento próximo e personalizado\nProjeto alinhado à identidade da marca\nOrganização e acompanhamento pelo VisionForge OS\nSuporte e orientações durante a execução",
                'payment_title'=>'Formas de pagamento e como trabalhamos','payment_content'=>"50% do valor no início do projeto.\n\n50% restantes na entrega final.\n\nO desenvolvimento é acompanhado por etapas, com comunicação transparente e aprovação das entregas.",
                'closing_title'=>'Rumo ao Sucesso Digital!','closing_content'=>'Agradecemos a oportunidade de apresentar este projeto. Será um prazer transformar esta ideia em uma experiência digital profissional, funcional e alinhada aos objetivos da sua marca.',
                'show_why'=>1,'show_vision'=>1,'show_included'=>1,'show_investment'=>1,'show_differentials'=>1,'show_payment'=>1,'show_closing'=>1,'pdf_path'=>''
            ];$pr=$pr?:$defaults;
            echo '<div class="vfos-panel vfos-presentation-editor"><div class="vfos-panel-head"><div><span class="vfos-kicker">APRESENTAÇÃO DO PROJETO</span><h2>PDF comercial para o cliente</h2><p>Monte uma apresentação visual no estilo das propostas da VisionForge: capa, visão do projeto, itens inclusos, investimento, diferenciais, pagamento e encerramento.</p></div>'.(!empty($pr->pdf_path)?'<a class="button button-primary vfos-btn" target="_blank" href="'.esc_url(admin_url('admin-post.php?action=vfos_project_presentation_pdf&project_id='.$id.'&view=1&_wpnonce='.wp_create_nonce('vfos_project_presentation_pdf'))).'">Visualizar PDF atual</a>':'').'</div>';
            echo '<div class="vfos-presentation-preview"><img src="'.esc_url(VFOS_URL.'admin/assets/images/visionforge-presentation-bg.jpg').'" alt=""><div><strong>Identidade VisionForge</strong><p>O PDF usa fundo exclusivo azul/laranja, marca d’água, títulos fortes, cartões e páginas separadas por assunto.</p></div></div>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_project_presentation"><input type="hidden" name="project_id" value="'.$id.'">';wp_nonce_field('vfos_save_project_presentation');
            echo '<div class="vfos-form-grid"><label>Título da capa<input name="title" required value="'.esc_attr($pr->title).'"></label><label>Subtítulo<input name="subtitle" value="'.esc_attr($pr->subtitle).'"></label><label>Valor apresentado<input type="number" step="0.01" min="0" name="investment_value" value="'.esc_attr($pr->investment_value).'"></label></div>';
            $sections=[
                ['why','Por que investir?',$pr->why_title,$pr->why_content],
                ['vision','O que imaginamos',$pr->vision_title,$pr->vision_content],
                ['investment','Investimento',$pr->investment_title,$pr->investment_content],
                ['payment','Pagamento e processo',$pr->payment_title,$pr->payment_content],
                ['closing','Encerramento',$pr->closing_title,$pr->closing_content],
            ];
            foreach($sections as $sec){[$key,$label,$title,$content]=$sec;echo '<section class="vfos-presentation-section"><header><label class="vfos-switch-row"><input type="checkbox" name="show_'.$key.'" value="1" '.checked($pr->{'show_'.$key}??1,1,false).'> Incluir esta página</label><strong>'.esc_html($label).'</strong></header><label>Título da página<input name="'.$key.'_title" value="'.esc_attr($title).'"></label><label>Conteúdo<textarea name="'.$key.'_content" rows="6">'.esc_textarea($content).'</textarea></label></section>';}
            echo '<div class="vfos-grid vfos-grid-2"><section class="vfos-presentation-section"><header><label class="vfos-switch-row"><input type="checkbox" name="show_included" value="1" '.checked($pr->show_included??1,1,false).'> Incluir esta página</label><strong>O que está incluso</strong></header><label>Título<input name="included_title" value="'.esc_attr($pr->included_title).'"></label><label>Itens <small>Um item por linha.</small><textarea name="included_items" rows="10">'.esc_textarea($pr->included_items).'</textarea></label><button type="button" class="button" id="vfos-fill-project-tasks">Preencher com tarefas atuais</button><textarea id="vfos-current-project-tasks" hidden>'.esc_textarea($task_items).'</textarea></section>';
            echo '<section class="vfos-presentation-section"><header><label class="vfos-switch-row"><input type="checkbox" name="show_differentials" value="1" '.checked($pr->show_differentials??1,1,false).'> Incluir esta página</label><strong>Diferenciais / brindes</strong></header><label>Título<input name="differentials_title" value="'.esc_attr($pr->differentials_title).'"></label><label>Itens <small>Um item por linha.</small><textarea name="differentials" rows="10">'.esc_textarea($pr->differentials).'</textarea></label></section></div>';
            echo '<div class="vfos-form-actions"><button class="button button-primary vfos-btn">Salvar apresentação</button><a class="button" target="_blank" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=vfos_project_presentation_pdf&project_id='.$id),'vfos_project_presentation_pdf')).'">Gerar / abrir PDF</a><a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=vfos_send_project_presentation&project_id='.$id),'vfos_send_project_presentation')).'">Enviar PDF por e-mail ao cliente</a></div></form></div>';
        } elseif($tab==='financial'&&VFOS_Team::can('financial')){
            $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('financial')." WHERE project_id=%d ORDER BY due_date,id DESC",$id));$received=0;$pending=0;foreach($rows as $r){if($r->type==='income'&&$r->status==='paid')$received+=(float)$r->amount;if($r->type==='income'&&$r->status==='pending')$pending+=(float)$r->amount;}echo '<div class="vfos-stats"><div class="vfos-stat"><span>Valor do projeto</span><strong>R$ '.number_format((float)$p->value,2,',','.').'</strong></div><div class="vfos-stat"><span>Recebido</span><strong>R$ '.number_format($received,2,',','.').'</strong></div><div class="vfos-stat"><span>A receber</span><strong>R$ '.number_format($pending,2,',','.').'</strong></div></div><div class="vfos-panel"><h2>Movimentações vinculadas</h2><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Descrição</th><th>Valor</th><th>Vencimento</th><th>Status</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="4">Nenhum lançamento vinculado diretamente ao projeto.</td></tr>';foreach($rows as $r)echo '<tr><td>'.esc_html($r->description).'</td><td>R$ '.number_format((float)$r->amount,2,',','.').'</td><td>'.($r->due_date?date_i18n('d/m/Y',strtotime($r->due_date)):'—').'</td><td>'.$this->status_label($r->status).'</td></tr>';echo '</tbody></table></div></div>';
        } elseif($tab==='history'){
            $rows=$wpdb->get_results($wpdb->prepare("SELECT a.*,u.display_name actor_name FROM ".VFOS_DB::table('activity_feed')." a LEFT JOIN {$wpdb->users} u ON u.ID=a.actor_user_id WHERE a.entity_type='project' AND a.entity_id=%d ORDER BY a.created_at DESC LIMIT 150",$id));echo '<div class="vfos-panel"><span class="vfos-kicker">HISTÓRICO</span><h2>Tudo que aconteceu neste projeto</h2><div class="vfos-activity-feed">';if(!$rows)echo '<div class="vfos-empty">O histórico será preenchido conforme o projeto for movimentado.</div>';foreach($rows as $r)echo '<article><div class="vfos-activity-dot"></div><div><strong>'.esc_html($r->title).'</strong><p>'.esc_html($r->description).'</p><small>'.esc_html($r->actor_name?:'VisionForge OS').' • '.date_i18n('d/m/Y H:i',strtotime($r->created_at)).'</small></div></article>';echo '</div></div>';
        } else {
            /* Mantém as visões operacionais existentes de Kanban, Cronograma e Arquivos dentro do Projeto 360 */
            if($tab==='kanban'){$cols=['pending'=>'Pendente','in_progress'=>'Em andamento','review'=>'Em aprovação','done'=>'Concluída'];echo '<div class="vfos-kanban">';foreach($cols as $status=>$label){echo '<section><header><strong>'.$label.'</strong><span>'.count(array_filter($tasks,fn($x)=>$x->status===$status)).'</span></header>';foreach($tasks as $t)if($t->status===$status)echo '<article><strong>'.esc_html($t->title).'</strong><small>'.esc_html($t->assigned_name?:'Não atribuído').'</small><small>'.($t->due_date?date_i18n('d/m/Y',strtotime($t->due_date)):'Sem prazo').'</small><a href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab=new&edit='.$t->id)).'">Abrir tarefa →</a></article>';echo '</section>';}echo '</div>';}
            elseif($tab==='timeline'){echo '<div class="vfos-panel"><span class="vfos-kicker">CRONOGRAMA</span><h2>Linha do tempo</h2><div class="vfos-timeline">';foreach($tasks as $t)echo '<article><div class="vfos-timeline-dot"></div><div><strong>'.esc_html($t->title).'</strong><small>'.esc_html($t->stage_name?:'Sem etapa').' • '.($t->due_date?date_i18n('d/m/Y',strtotime($t->due_date)):'Sem prazo').'</small></div><span class="vfos-pill">'.esc_html($this->status_label($t->status)).'</span></article>';echo '</div></div>';}
            else{$files=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_files')." WHERE project_id=%d ORDER BY id DESC",$id));$comments=$wpdb->get_results($wpdb->prepare("SELECT pc.*,u.display_name FROM ".VFOS_DB::table('project_comments')." pc LEFT JOIN {$wpdb->users} u ON u.ID=pc.user_id WHERE pc.project_id=%d ORDER BY pc.id DESC",$id));$finalA=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('client_approvals')." WHERE project_id=%d AND status='approved' AND release_original=1 AND original_path<>'' ORDER BY decided_at DESC,id DESC",$id));$finalP=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_approvals')." WHERE project_id=%d AND status='approved' AND release_original=1 AND original_path<>'' ORDER BY responded_at DESC,id DESC",$id));echo '<div class="vfos-panel vfos-project-final-files"><div class="vfos-panel-head"><div><span class="vfos-kicker">ENTREGAS FINAIS</span><h2>Arquivos aprovados e liberados</h2><p>Estes arquivos também aparecem para o cliente em Área do Cliente → Arquivos.</p></div><span class="vfos-pill">'.(count($finalA)+count($finalP)).' arquivo(s)</span></div><div class="vfos-admin-final-file-grid">';if(!$finalA&&!$finalP)echo '<div class="vfos-empty">Nenhuma entrega final liberada ainda.</div>';foreach($finalA as $fa){$u=wp_nonce_url(admin_url('admin-post.php?action=vfos_approval_original&table=client_approvals&id='.$fa->id),'vfos_approval_original_client_approvals_'.$fa->id);echo '<a href="'.esc_url($u).'"><span>↓</span><div><strong>'.esc_html($fa->option_label?:$fa->title).'</strong><small>'.esc_html($fa->original_name?:'Arquivo final').' • Área do Cliente</small></div></a>';}foreach($finalP as $fa){$u=wp_nonce_url(admin_url('admin-post.php?action=vfos_approval_original&table=project_approvals&id='.$fa->id),'vfos_approval_original_project_approvals_'.$fa->id);echo '<a href="'.esc_url($u).'"><span>↓</span><div><strong>'.esc_html($fa->title).'</strong><small>'.esc_html($fa->original_name?:'Arquivo final').' • Projeto</small></div></a>';}echo '</div></div><div class="vfos-grid vfos-grid-2"><div class="vfos-panel"><h2>Outros arquivos do projeto</h2>';if(!$files)echo '<div class="vfos-empty">Nenhum outro arquivo enviado.</div>';foreach($files as $f)echo '<p><a target="_blank" href="'.esc_url($f->file_url).'"><strong>'.esc_html($f->file_name).'</strong></a></p>';echo '</div><div class="vfos-panel"><h2>Conversas</h2>';foreach($comments as $c)echo '<article class="vfos-comment"><strong>'.esc_html($c->display_name?:'VisionForge').'</strong><p>'.esc_html($c->content).'</p><small>'.date_i18n('d/m/Y H:i',strtotime($c->created_at)).'</small></article>';echo '</div></div>';}
        }
        $this->end();
    }


    public function save_project_presentation(){
        check_admin_referer('vfos_save_project_presentation');VFOS_Team::require_permission('projects.presentation');global $wpdb;$project=absint($_POST['project_id']??0);$t=VFOS_DB::table('project_presentations');$now=current_time('mysql');
        $data=['project_id'=>$project,'title'=>sanitize_text_field($_POST['title']??''),'subtitle'=>sanitize_text_field($_POST['subtitle']??''),
            'why_title'=>sanitize_text_field($_POST['why_title']??''),'why_content'=>wp_kses_post($_POST['why_content']??''),
            'vision_title'=>sanitize_text_field($_POST['vision_title']??''),'vision_content'=>wp_kses_post($_POST['vision_content']??''),
            'included_title'=>sanitize_text_field($_POST['included_title']??''),'included_items'=>sanitize_textarea_field($_POST['included_items']??''),
            'investment_title'=>sanitize_text_field($_POST['investment_title']??''),'investment_content'=>wp_kses_post($_POST['investment_content']??''),'investment_value'=>max(0,(float)($_POST['investment_value']??0)),
            'differentials_title'=>sanitize_text_field($_POST['differentials_title']??''),'differentials'=>sanitize_textarea_field($_POST['differentials']??''),
            'payment_title'=>sanitize_text_field($_POST['payment_title']??''),'payment_content'=>wp_kses_post($_POST['payment_content']??''),
            'closing_title'=>sanitize_text_field($_POST['closing_title']??''),'closing_content'=>wp_kses_post($_POST['closing_content']??''),
            'show_why'=>empty($_POST['show_why'])?0:1,'show_vision'=>empty($_POST['show_vision'])?0:1,'show_included'=>empty($_POST['show_included'])?0:1,'show_investment'=>empty($_POST['show_investment'])?0:1,'show_differentials'=>empty($_POST['show_differentials'])?0:1,'show_payment'=>empty($_POST['show_payment'])?0:1,'show_closing'=>empty($_POST['show_closing'])?0:1,
            'updated_by'=>get_current_user_id(),'updated_at'=>$now];
        $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE project_id=%d",$project));if($exists)$wpdb->update($t,$data,['project_id'=>$project]);else{$data['created_at']=$now;$wpdb->insert($t,$data);}
        $pdf=VFOS_Project_Presentation::generate($project);VFOS_DB::log('save_project_presentation','project',$project);if(class_exists('VFOS_Notifications'))VFOS_Notifications::activity('project_presentation','Apresentação do projeto atualizada',$data['title'],'projects','project',$project,admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=presentation'));
        wp_safe_redirect(add_query_arg(['page'=>'vfos-project-view','id'=>$project,'tab'=>'presentation','vfos_msg'=>rawurlencode(is_wp_error($pdf)?'Apresentação salva, mas o PDF não pôde ser gerado: '.$pdf->get_error_message():'Apresentação salva e PDF atualizado.')],admin_url('admin.php')));exit;
    }
    public function project_presentation_pdf(){
        check_admin_referer('vfos_project_presentation_pdf');VFOS_Team::require_permission('projects.presentation');$project=absint($_GET['project_id']??0);$path=VFOS_Project_Presentation::generate($project);if(is_wp_error($path))wp_die(esc_html($path->get_error_message()));if(!is_file($path))wp_die('PDF não encontrado.');
        nocache_headers();header('Content-Type: application/pdf');header('Content-Disposition: inline; filename="'.sanitize_file_name(basename($path)).'"');header('Content-Length: '.filesize($path));readfile($path);exit;
    }

    public function send_project_presentation(){
        check_admin_referer('vfos_send_project_presentation');VFOS_Team::require_permission('projects.presentation');global $wpdb;$project=absint($_GET['project_id']??0);
        $p=$wpdb->get_row($wpdb->prepare("SELECT p.*,c.name client_name,c.email client_email FROM ".VFOS_DB::table('projects')." p LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=p.client_id WHERE p.id=%d",$project));
        if(!$p||!is_email($p->client_email))wp_die('O cliente deste projeto não possui e-mail válido.');
        $path=VFOS_Project_Presentation::generate($project);if(is_wp_error($path))wp_die(esc_html($path->get_error_message()));
        $u=wp_upload_dir();$url=str_replace($u['basedir'],$u['baseurl'],$path);
        $title='Apresentação do Projeto - '.$p->name;
        $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".VFOS_DB::table('client_files')." WHERE client_id=%d AND project_id=%d AND title=%s",$p->client_id,$project,$title));
        $file=['client_id'=>$p->client_id,'project_id'=>$project,'attachment_id'=>0,'title'=>$title,'file_url'=>$url,'mime_type'=>'application/pdf','source'=>'staff','uploaded_by'=>get_current_user_id(),'created_at'=>current_time('mysql')];
        if($exists)$wpdb->update(VFOS_DB::table('client_files'),['file_url'=>$url,'mime_type'=>'application/pdf'],['id'=>$exists]);else$wpdb->insert(VFOS_DB::table('client_files'),$file);
        $subject='Apresentação do projeto '.$p->name.' - VisionForge Digital';
        $message="Olá, ".$p->client_name."!\n\nPreparamos a apresentação do projeto ".$p->name." com o escopo, investimento e demais informações.\n\nAcesse o PDF:\n".$url."\n\nVisionForge Digital";
        $sent=wp_mail($p->client_email,$subject,$message);VFOS_DB::log('send_project_presentation','project',$project,$p->client_email);
        wp_safe_redirect(add_query_arg(['page'=>'vfos-project-view','id'=>$project,'tab'=>'presentation','vfos_msg'=>rawurlencode($sent?'Apresentação enviada para '.$p->client_email.' e publicada nos arquivos do cliente.':'PDF publicado nos arquivos do cliente, mas o WordPress não confirmou o envio do e-mail.')],admin_url('admin.php')));exit;
    }

    public function save_project_stage(){
        $this->guard('vfos_save_project_stage');global $wpdb;$project=absint($_POST['project_id']??0);$t=VFOS_DB::table('project_stages');$max=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(MAX(sort_order),-1) FROM $t WHERE project_id=%d",$project));
        $wpdb->insert($t,['project_id'=>$project,'title'=>sanitize_text_field($_POST['title']??''),'description'=>sanitize_textarea_field($_POST['description']??''),'status'=>'pending','assigned_user_id'=>absint($_POST['assigned_user_id']??0),'due_date'=>$this->date($_POST['due_date']??''),'sort_order'=>$max+1,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);$sid=$wpdb->insert_id;
        VFOS_DB::log('save_project_stage','project',$project);VFOS_Notifications::activity('project_stage_created','Nova etapa criada',sanitize_text_field($_POST['title']??''),'projects','project',$project,admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=stages'));
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=stages'));exit;
    }
    public function delete_project_stage(){
        $this->guard('vfos_delete_project_stage');global $wpdb;$id=absint($_GET['id']??0);$project=absint($_GET['project_id']??0);$wpdb->update(VFOS_DB::table('tasks'),['stage_id'=>0],['stage_id'=>$id]);$wpdb->delete(VFOS_DB::table('project_stages'),['id'=>$id]);wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=stages'));exit;
    }
    public function save_project_approval(){
        $this->guard('vfos_save_project_approval');global $wpdb;
        $project=absint($_POST['project_id']??0);$title=sanitize_text_field($_POST['title']??'');if(!$project||!$title)wp_die('Informe projeto e título.');
        $p=$wpdb->get_row($wpdb->prepare("SELECT p.*,c.name client_name FROM ".VFOS_DB::table('projects')." p LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=p.client_id WHERE p.id=%d",$project));if(!$p)wp_die('Projeto não encontrado.');
        $asset=['original_path'=>'','original_name'=>'','preview_url'=>'','file_url'=>'','mime_type'=>'','is_image'=>0,'watermark_text'=>''];
        if(!empty($_FILES['approval_file']['name'])){
            $asset=VFOS_Approval_Assets::handle_upload('approval_file',$p->client_name,!empty($_POST['watermark_enabled']),sanitize_text_field($_POST['watermark_text']??''));
            if(is_wp_error($asset))wp_die('Erro no arquivo: '.esc_html($asset->get_error_message()));
        }
        $external=esc_url_raw($_POST['file_url']??'');$file_url=$asset['file_url']?:$external;
        $wpdb->insert(VFOS_DB::table('project_approvals'),[
            'project_id'=>$project,'title'=>$title,'description'=>sanitize_textarea_field($_POST['description']??''),
            'file_url'=>$file_url,'original_path'=>$asset['original_path'],'original_name'=>$asset['original_name'],'preview_url'=>$asset['preview_url'],
            'mime_type'=>$asset['mime_type'],'watermark_enabled'=>!empty($_POST['watermark_enabled'])&&$asset['is_image']?1:0,
            'watermark_text'=>$asset['watermark_text'],'release_original'=>0,'status'=>'pending','requested_by'=>get_current_user_id(),'requested_at'=>current_time('mysql')
        ]);$aid=$wpdb->insert_id;
        VFOS_DB::log('project_approval_created','project_approval',$aid,'Entrega enviada para aprovação | watermark='.(int)(!empty($_POST['watermark_enabled'])&&$asset['is_image']),null,null,$title);
        VFOS_Notifications::activity('approval_created','Nova aprovação solicitada',$title,'projects','project',$project,admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=approvals'));
        $client_id=(int)$p->client_id;
        if($client_id){
            $portal_id=absint(get_option('vfos_portal_page_id'));$portal_url=$portal_id?add_query_arg(['vfos_tab'=>'approvals'],get_permalink($portal_id)):'';
            $users=get_users(['meta_key'=>'vfos_client_id','meta_value'=>$client_id]);
            foreach($users as $u)VFOS_Notifications::notify($u->ID,'approval','Nova entrega para aprovação',$title,'portal','project_approval',$aid,$portal_url,get_current_user_id(),'personal','',0,'Projeto • '.$p->name.' • '.$title);
        }
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=approvals&vfos_msg='.rawurlencode('Entrega enviada para a Área do Cliente.')));exit;
    }
    public function toggle_project_approval_release(){
        if(!VFOS_Team::can_permission('projects.approvals'))wp_die('Sem permissão para gerenciar aprovações do projeto.');
        $id=absint($_GET['id']??0);check_admin_referer('vfos_toggle_project_approval_release_'.$id);global $wpdb;$project=absint($_GET['project_id']??0);
        $t=VFOS_DB::table('project_approvals');$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));if(!$r)wp_die('Aprovação não encontrada.');
        if($r->status!=='approved')wp_die('O original só pode ser liberado depois da aprovação do cliente.');
        $new=empty($r->release_original)?1:0;$wpdb->update($t,['release_original'=>$new],['id'=>$id]);
        VFOS_DB::log('project_approval_release','project_approval',$id,$new?'Original liberado ao cliente':'Original bloqueado novamente',['release_original'=>(int)$r->release_original],['release_original'=>$new],$r->title);
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.($project?:$r->project_id).'&tab=approvals&vfos_msg='.rawurlencode($new?'Arquivo original liberado ao cliente.':'Arquivo original bloqueado.')));exit;
    }
    public function delete_project_approval(){
        $this->guard('vfos_delete_project_approval');global $wpdb;$id=absint($_GET['id']??0);$project=absint($_GET['project_id']??0);$t=VFOS_DB::table('project_approvals');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));
        if($row){if(!empty($row->original_path)&&is_file($row->original_path))@unlink($row->original_path);if(!empty($row->preview_url)){$up=wp_upload_dir();$preview=str_replace($up['baseurl'],$up['basedir'],$row->preview_url);if($preview&&is_file($preview))@unlink($preview);}$wpdb->delete($t,['id'=>$id]);VFOS_DB::log('project_approval_deleted','project_approval',$id,'Entrega de aprovação excluída',(array)$row,null,$row->title);}
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=approvals'));exit;
    }

    public function project_templates(){
        global $wpdb;$t=VFOS_DB::table('project_templates');$it=VFOS_DB::table('project_template_items');$st=VFOS_DB::table('services');$tab=sanitize_key($_GET['tab']??'list');$edit=absint($_GET['edit']??0);if($edit)$tab='new';$e=$edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$edit)):null;
        $this->header('Modelos de Projeto','Crie estruturas reutilizáveis para iniciar projetos com tarefas e etapas padrões.');$this->module_tabs('vfos-project-templates',$tab,$edit?'Editar modelo':'Novo modelo');
        if($tab==='new'){
            $items=$e?$wpdb->get_results($wpdb->prepare("SELECT * FROM $it WHERE template_id=%d ORDER BY sort_order,id",$e->id)):[];
            echo '<div class="vfos-panel"><span class="vfos-kicker">PADRÃO REUTILIZÁVEL</span><h2>'.($e?'Editar modelo':'Novo modelo').'</h2>';$this->form_start('vfos_save_project_template');if($e)echo '<input type="hidden" name="id" value="'.$e->id.'">';
            echo '<div class="vfos-form-grid"><label>Nome do modelo<input name="name" required value="'.esc_attr($e->name??'').'" placeholder="Ex.: Site Institucional"></label><label>Serviço<select name="service_id"><option value="0">Qualquer serviço</option>';foreach($wpdb->get_results("SELECT id,name FROM $st WHERE status='active' ORDER BY name") as $s)echo '<option value="'.$s->id.'" '.selected($e->service_id??0,$s->id,false).'>'.esc_html($s->name).'</option>';echo '</select></label><label>Duração padrão (dias)<input type="number" min="1" name="default_duration" value="'.esc_attr($e->default_duration??30).'"></label><label>Valor padrão (R$)<input type="number" step="0.01" name="default_value" value="'.esc_attr($e->default_value??0).'"></label><label>Prioridade<select name="default_priority">';foreach(['low'=>'Baixa','normal'=>'Normal','high'=>'Alta','urgent'=>'Urgente'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->default_priority??'normal',$k,false).'>'.$v.'</option>';echo '</select></label><label>Status<select name="status"><option value="active" '.selected($e->status??'active','active',false).'>Ativo</option><option value="inactive" '.selected($e->status??'active','inactive',false).'>Inativo</option></select></label></div><label>Descrição<textarea name="description">'.esc_textarea($e->description??'').'</textarea></label>';
            echo '<div class="vfos-template-builder"><div class="vfos-panel-head"><div><span class="vfos-kicker">ITENS PADRÕES</span><h3>Tarefas e etapas</h3></div><button type="button" class="button vfos-add-template-item">+ Adicionar item</button></div><div id="vfos-template-items">';
            $seed=$items?:[(object)['title'=>'','item_type'=>'task','description'=>'','day_offset'=>0,'priority'=>'normal']];
            foreach($seed as $i=>$x){echo $this->template_item_row($i,$x);}
            echo '</div></div><button class="button button-primary vfos-btn">'.($e?'Salvar modelo':'Criar modelo').'</button></form></div>';
        }else{
            $search=$this->q('s');$status=sanitize_key($_GET['status']??'');$where=['1=1'];$args=[];if($search!==''){$where[]='name LIKE %s';$args[]='%'.$wpdb->esc_like($search).'%';}if($status!==''){$where[]='status=%s';$args[]=$status;}$sql="SELECT * FROM $t WHERE ".implode(' AND ',$where)." ORDER BY id DESC";$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">BIBLIOTECA</span><h2>Modelos de Projeto</h2></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-project-templates&tab=new')).'">+ Novo modelo</a></div>';$this->filter_start('vfos-project-templates');echo '<label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Nome do modelo"></label><label>Status<select name="status"><option value="">Todos</option><option value="active" '.selected($status,'active',false).'>Ativos</option><option value="inactive" '.selected($status,'inactive',false).'>Inativos</option></select></label>';$this->filter_end();
            echo '<div class="vfos-template-cards">';if(!$rows)echo '<div class="vfos-empty">Nenhum modelo encontrado.</div>';foreach($rows as $r){$count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $it WHERE template_id=%d",$r->id));$ed=admin_url('admin.php?page=vfos-project-templates&tab=new&edit='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_project_template&id='.$r->id),'vfos_delete_project_template');echo '<article class="vfos-template-card"><div class="vfos-template-icon">VF</div><span class="vfos-pill">'.($r->status==='active'?'Ativo':'Inativo').'</span><h3>'.esc_html($r->name).'</h3><p>'.esc_html($r->description?:'Modelo reutilizável VisionForge.').'</p><div class="vfos-template-meta"><span>'.$count.' itens</span><span>'.$r->default_duration.' dias</span><span>R$ '.number_format((float)$r->default_value,2,',','.').'</span></div><div><a class="button" href="'.esc_url($ed).'">Editar</a> <a class="button vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir este modelo?\')">Excluir</a></div></article>';}echo '</div></div>';
        }$this->end();
    }

    private function template_item_row($i,$x){
        return '<div class="vfos-template-item"><span class="vfos-drag">⋮⋮</span><label>Item<input name="items['.$i.'][title]" value="'.esc_attr($x->title??'').'" placeholder="Ex.: Receber briefing"></label><label>Tipo<select name="items['.$i.'][item_type]"><option value="task" '.selected($x->item_type??'task','task',false).'>Tarefa</option><option value="milestone" '.selected($x->item_type??'task','milestone',false).'>Etapa</option><option value="approval" '.selected($x->item_type??'task','approval',false).'>Aprovação</option></select></label><label>Dia +<input type="number" min="0" name="items['.$i.'][day_offset]" value="'.(int)($x->day_offset??0).'"></label><label>Prioridade<select name="items['.$i.'][priority]">'.implode('',array_map(fn($k,$v)=>'<option value="'.$k.'" '.selected($x->priority??'normal',$k,false).'>'.$v.'</option>',array_keys(['low'=>'Baixa','normal'=>'Normal','high'=>'Alta','urgent'=>'Urgente']),array_values(['low'=>'Baixa','normal'=>'Normal','high'=>'Alta','urgent'=>'Urgente']))).'</select></label><label class="vfos-grow">Descrição<input name="items['.$i.'][description]" value="'.esc_attr($x->description??'').'"></label><button type="button" class="button vfos-remove-template-item">×</button></div>';
    }

    public function tasks(){
        VFOS_Team::require_module('tasks');global $wpdb;
        $tt=VFOS_DB::table('tasks');$pt=VFOS_DB::table('projects');$ct=VFOS_DB::table('clients');$teamt=VFOS_DB::table('team');
        $edit=absint($_GET['edit']??0);$tab=$edit?'new':sanitize_key($_GET['tab']??'list');if(!in_array($tab,['list','new','mine'],true))$tab='list';
        $e=$edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $tt WHERE id=%d",$edit)):null;
        if($e && VFOS_Team::limited_to_assigned() && (int)$e->assigned_user_id!==get_current_user_id())wp_die('Esta tarefa não está atribuída a você.');
        $projects=$wpdb->get_results("SELECT id,name FROM $pt ORDER BY name");
        $members=$wpdb->get_results("SELECT tm.user_id,u.display_name FROM $teamt tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE tm.status='active' ORDER BY u.display_name");
        $this->header('Tarefas','Organize responsabilidades, prazos e a rotina da equipe.');
        $this->module_tabs('vfos-tasks',$tab,$edit?'Editar tarefa':'Nova tarefa',['mine'=>'Minhas tarefas']);

        if($tab==='new'){
            echo '<div class="vfos-panel"><span class="vfos-kicker">CADASTRO</span><h2>'.($e?'Editar tarefa':'Nova tarefa').'</h2>';$this->form_start('vfos_save_task');if($e)echo '<input type="hidden" name="id" value="'.$e->id.'">';
            echo '<div class="vfos-form-grid"><label>Tarefa<input name="title" required value="'.esc_attr($e->title??'').'"></label><label>Projeto<select name="project_id"><option value="0">Sem projeto</option>';foreach($projects as $pr){if(VFOS_Team::limited_to_assigned() && !$e){$has=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE project_id=%d AND assigned_user_id=%d",$pr->id,get_current_user_id()));if(!$has)continue;}echo '<option value="'.$pr->id.'" '.selected($e->project_id??absint($_GET['project_id']??0),$pr->id,false).'>'.esc_html($pr->name).'</option>';}echo '</select></label><label>Cliente<select name="client_id">';$this->clients_options($e->client_id??absint($_GET['client_id']??0));echo '</select></label>';
            $can_transfer=VFOS_Team::can_permission('tasks.transfer');
            if($e&&!$can_transfer){
                $current_assignee='Não atribuído';foreach($members as $u)if((int)$u->user_id===(int)$e->assigned_user_id){$current_assignee=$u->display_name;break;}
                echo '<label>Responsável<input value="'.esc_attr($current_assignee).'" readonly><small>Você pode editar a tarefa, mas não transferi-la.</small><input type="hidden" name="assigned_user_id" value="'.absint($e->assigned_user_id).'"></label>';
            }else{
                echo '<label id="vfos-task-assignee">Responsável'.($e?'<small>Transferir tarefa</small>':'').'<select name="assigned_user_id">';
                if(VFOS_Team::limited_to_assigned()) echo '<option value="'.get_current_user_id().'">'.esc_html(wp_get_current_user()->display_name).'</option>';
                else {echo '<option value="0">Não atribuído</option>';foreach($members as $u)echo '<option value="'.$u->user_id.'" '.selected($e->assigned_user_id??get_current_user_id(),$u->user_id,false).'>'.esc_html($u->display_name).'</option>';}
                echo '</select></label>';
            }
            $selected_project=absint($e->project_id??($_GET['project_id']??0));$stages=$selected_project?$wpdb->get_results($wpdb->prepare("SELECT id,title FROM ".VFOS_DB::table('project_stages')." WHERE project_id=%d ORDER BY sort_order,id",$selected_project)):[];
            $siblings=$selected_project?$wpdb->get_results($wpdb->prepare("SELECT id,title FROM $tt WHERE project_id=%d AND id<>%d ORDER BY id",$selected_project,$edit)):[];
            echo '<label>Etapa<select name="stage_id"><option value="0">Sem etapa</option>';foreach($stages as $sg)echo '<option value="'.$sg->id.'" '.selected($e->stage_id??0,$sg->id,false).'>'.esc_html($sg->title).'</option>';echo '</select></label><label>Depende de<select name="depends_on_task_id"><option value="0">Sem dependência</option>';foreach($siblings as $sb)echo '<option value="'.$sb->id.'" '.selected($e->depends_on_task_id??0,$sb->id,false).'>'.esc_html($sb->title).'</option>';echo '</select></label><label>Horas estimadas<input type="number" min="0" step="0.5" name="estimated_hours" value="'.esc_attr($e->estimated_hours??0).'"></label><label>Horas realizadas<input type="number" min="0" step="0.5" name="actual_hours" value="'.esc_attr($e->actual_hours??0).'"></label><label>Início<input type="date" name="start_date" value="'.esc_attr($e->start_date??'').'"></label><label>Prazo<input type="date" name="due_date" value="'.esc_attr($e->due_date??'').'"></label><label>Prioridade<select name="priority">';foreach(['low'=>'Baixa','normal'=>'Normal','high'=>'Alta','urgent'=>'Urgente'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->priority??'normal',$k,false).'>'.$v.'</option>';echo '</select></label><label>Status<select name="status">';foreach(['pending'=>'Pendente','in_progress'=>'Em andamento','review'=>'Em aprovação','done'=>'Concluída','cancelled'=>'Cancelada'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->status??'pending',$k,false).'>'.$v.'</option>';echo '</select></label></div><label>Descrição<textarea name="description">'.esc_textarea($e->description??'').'</textarea></label><button class="button button-primary vfos-btn">'.($e?'Salvar tarefa':'Criar tarefa').'</button> <a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab=list')).'">Cancelar</a></form></div>';
        } else {
            $search=$this->q('s');$status=sanitize_key($_GET['status']??'');$priority=sanitize_key($_GET['priority']??'');$client=absint($_GET['client']??0);$period=sanitize_key($_GET['period']??'');$assigned=absint($_GET['assigned']??0);
            if($tab==='mine' || VFOS_Team::limited_to_assigned())$assigned=get_current_user_id();
            $where=['1=1'];$args=[];
            if($search!==''){$where[]='(t.title LIKE %s OR t.description LIKE %s OR p.name LIKE %s OR c.name LIKE %s OR u.display_name LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like,$like,$like,$like);}
            if($status!==''){$where[]='t.status=%s';$args[]=$status;}if($priority!==''){$where[]='t.priority=%s';$args[]=$priority;}if($client){$where[]='t.client_id=%d';$args[]=$client;}if($assigned){$where[]='t.assigned_user_id=%d';$args[]=$assigned;}
            if($period==='overdue')$where[]="t.due_date < CURDATE() AND t.status NOT IN ('done','cancelled')";elseif($period==='today')$where[]='t.due_date=CURDATE()';elseif($period==='week')$where[]='t.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY)';
            $sql="SELECT t.*,p.name project_name,c.name client_name,u.display_name assigned_name FROM $tt t LEFT JOIN $pt p ON p.id=t.project_id LEFT JOIN $ct c ON c.id=t.client_id LEFT JOIN {$wpdb->users} u ON u.ID=t.assigned_user_id WHERE ".implode(' AND ',$where)." ORDER BY (t.status='done'),t.due_date IS NULL,t.due_date,t.id DESC";
            $rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">'.($tab==='mine'?'MINHA ROTINA':'VISUALIZAÇÃO').'</span><h2>'.($tab==='mine'?'Minhas tarefas':'Lista de tarefas').'</h2></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab=new')).'">+ Nova tarefa</a></div>';
            echo '<form class="vfos-filters" method="get"><input type="hidden" name="page" value="vfos-tasks"><input type="hidden" name="tab" value="'.esc_attr($tab).'"><label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Tarefa, projeto, cliente ou responsável"></label><label>Cliente<select name="client">';$this->client_filter_select($client);echo '</select></label><label>Status<select name="status"><option value="">Todos</option>';foreach(['pending'=>'Pendente','in_progress'=>'Em andamento','review'=>'Em aprovação','done'=>'Concluída','cancelled'=>'Cancelada'] as $k=>$v)echo '<option value="'.$k.'" '.selected($status,$k,false).'>'.$v.'</option>';echo '</select></label><label>Prioridade<select name="priority"><option value="">Todas</option>';foreach(['low'=>'Baixa','normal'=>'Normal','high'=>'Alta','urgent'=>'Urgente'] as $k=>$v)echo '<option value="'.$k.'" '.selected($priority,$k,false).'>'.$v.'</option>';echo '</select></label><label>Prazo<select name="period"><option value="">Qualquer data</option><option value="overdue" '.selected($period,'overdue',false).'>Vencidas</option><option value="today" '.selected($period,'today',false).'>Hoje</option><option value="week" '.selected($period,'week',false).'>Próximos 7 dias</option></select></label>';
            if($tab!=='mine' && !VFOS_Team::limited_to_assigned()){echo '<label>Responsável<select name="assigned"><option value="0">Todos</option>';foreach($members as $u)echo '<option value="'.$u->user_id.'" '.selected($assigned,$u->user_id,false).'>'.esc_html($u->display_name).'</option>';echo '</select></label>';}
            echo '<div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Filtrar</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab='.$tab)).'">Limpar</a></div></form>';
            echo '<div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Tarefa</th><th>Projeto / cliente</th><th>Responsável</th><th>Prioridade</th><th>Prazo</th><th>Status</th><th>Ações</th></tr></thead><tbody>';
            if(!$rows)echo '<tr><td colspan="7">Nenhuma tarefa encontrada.</td></tr>';
            foreach($rows as $r){$ed=admin_url('admin.php?page=vfos-tasks&tab=new&edit='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_task&id='.$r->id),'vfos_delete_task');$late=$r->due_date&&strtotime($r->due_date)<strtotime(date('Y-m-d'))&&!in_array($r->status,['done','cancelled'],true);echo '<tr><td><strong>'.esc_html($r->title).'</strong>'.($late?'<small class="vfos-text-danger">Prazo vencido</small>':'').'</td><td>'.esc_html($r->project_name?:'Sem projeto').'<small>'.esc_html($r->client_name?:'').'</small></td><td>'.esc_html($r->assigned_name?:'Não atribuído').'</td><td>'.esc_html(ucfirst($r->priority)).'</td><td>'.($r->due_date?esc_html(date_i18n('d/m/Y',strtotime($r->due_date))):'—').'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td><a href="'.esc_url($ed).'">Editar</a>'.(VFOS_Team::can_permission('tasks.transfer')?' · <a href="'.esc_url($ed).'#vfos-task-assignee">Transferir</a>':'').' · <a class="vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir tarefa?\')">Excluir</a></td></tr>';}
            echo '</tbody></table></div></div>';
        }
        $this->end();
    }

    private function calendar_collect_events($from,$to,$filters=[]){
        global $wpdb;$events=[];$uid=get_current_user_id();$limited=VFOS_Team::limited_to_assigned();
        $types=(array)($filters['types']??[]);$assigned=absint($filters['assigned']??0);$client=absint($filters['client']??0);
        $want=function($type)use($types){return !$types||in_array($type,$types,true);};

        if($want('manual')){
            $t=VFOS_DB::table('calendar_events');$where=['e.start_at BETWEEN %s AND %s'];$args=[$from.' 00:00:00',$to.' 23:59:59'];
            if($assigned){$where[]='e.assigned_user_id=%d';$args[]=$assigned;}elseif($limited){$where[]='e.assigned_user_id=%d';$args[]=$uid;}
            if($client){$where[]='e.client_id=%d';$args[]=$client;}
            $sql="SELECT e.*,c.name client_name,p.name project_name,u.display_name assigned_name FROM $t e LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=e.client_id LEFT JOIN ".VFOS_DB::table('projects')." p ON p.id=e.project_id LEFT JOIN {$wpdb->users} u ON u.ID=e.assigned_user_id WHERE ".implode(' AND ',$where)." ORDER BY e.start_at";
            foreach($wpdb->get_results($wpdb->prepare($sql,$args)) as $r)$events[]=['source'=>'manual','id'=>$r->id,'type'=>$r->event_type,'title'=>$r->title,'description'=>$r->description,'start'=>$r->start_at,'end'=>$r->end_at,'all_day'=>(int)$r->all_day,'status'=>$r->status,'client'=>$r->client_name,'project'=>$r->project_name,'assigned'=>$r->assigned_name,'location'=>$r->location,'url'=>$r->meeting_url];
        }

        if(VFOS_Team::can('tasks')&&$want('task')){
            $t=VFOS_DB::table('tasks');$where=["t.due_date BETWEEN %s AND %s","t.status NOT IN ('done','cancelled')"];$args=[$from,$to];
            if($assigned){$where[]='t.assigned_user_id=%d';$args[]=$assigned;}elseif($limited){$where[]='t.assigned_user_id=%d';$args[]=$uid;}
            if($client){$where[]='t.client_id=%d';$args[]=$client;}
            $sql="SELECT t.*,p.name project_name,c.name client_name,u.display_name assigned_name FROM $t t LEFT JOIN ".VFOS_DB::table('projects')." p ON p.id=t.project_id LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=t.client_id LEFT JOIN {$wpdb->users} u ON u.ID=t.assigned_user_id WHERE ".implode(' AND ',$where);
            foreach($wpdb->get_results($wpdb->prepare($sql,$args)) as $r)$events[]=['source'=>'task','id'=>$r->id,'type'=>'task','title'=>$r->title,'description'=>$r->description,'start'=>$r->due_date.' 09:00:00','end'=>null,'all_day'=>1,'status'=>$r->status,'client'=>$r->client_name,'project'=>$r->project_name,'assigned'=>$r->assigned_name,'location'=>'','url'=>admin_url('admin.php?page=vfos-tasks&tab=new&edit='.$r->id)];
        }

        if(VFOS_Team::can('projects')&&$want('project')){
            $t=VFOS_DB::table('projects');$where=["p.due_date BETWEEN %s AND %s","p.status NOT IN ('completed','cancelled')"];$args=[$from,$to];
            if($client){$where[]='p.client_id=%d';$args[]=$client;}
            if($limited){$where[]='EXISTS (SELECT 1 FROM '.VFOS_DB::table('tasks').' tx WHERE tx.project_id=p.id AND tx.assigned_user_id=%d)';$args[]=$uid;}
            $sql="SELECT p.*,c.name client_name FROM $t p LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=p.client_id WHERE ".implode(' AND ',$where);
            foreach($wpdb->get_results($wpdb->prepare($sql,$args)) as $r)$events[]=['source'=>'project','id'=>$r->id,'type'=>'project','title'=>'Prazo: '.$r->name,'description'=>$r->notes,'start'=>$r->due_date.' 17:00:00','end'=>null,'all_day'=>1,'status'=>$r->status,'client'=>$r->client_name,'project'=>$r->name,'assigned'=>'','location'=>'','url'=>admin_url('admin.php?page=vfos-project-view&id='.$r->id)];
        }

        if(VFOS_Team::can('crm')&&$want('lead')){
            $t=VFOS_DB::table('leads');$where=["next_followup BETWEEN %s AND %s","stage NOT IN ('won','lost')"];$args=[$from,$to];
            $sql="SELECT * FROM $t WHERE ".implode(' AND ',$where);
            foreach($wpdb->get_results($wpdb->prepare($sql,$args)) as $r)$events[]=['source'=>'lead','id'=>$r->id,'type'=>'lead','title'=>'Follow-up: '.$r->name,'description'=>$r->service_interest,'start'=>$r->next_followup.' 10:00:00','end'=>null,'all_day'=>1,'status'=>$r->stage,'client'=>$r->company?:$r->name,'project'=>'','assigned'=>'','location'=>'','url'=>admin_url('admin.php?page=vfos-leads&tab=new&edit='.$r->id)];
        }

        if(VFOS_Team::can('financial')&&$want('financial')){
            $t=VFOS_DB::table('financial');$where=["f.due_date BETWEEN %s AND %s","f.status='pending'"];$args=[$from,$to];
            if($client){$where[]='f.client_id=%d';$args[]=$client;}
            $sql="SELECT f.*,c.name client_name FROM $t f LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=f.client_id WHERE ".implode(' AND ',$where);
            foreach($wpdb->get_results($wpdb->prepare($sql,$args)) as $r)$events[]=['source'=>'financial','id'=>$r->id,'type'=>'financial','title'=>($r->type==='income'?'Receber: ':'Pagar: ').$r->description,'description'=>'R$ '.number_format((float)$r->amount,2,',','.'),'start'=>$r->due_date.' 09:00:00','end'=>null,'all_day'=>1,'status'=>$r->status,'client'=>$r->client_name,'project'=>'','assigned'=>'','location'=>'','url'=>admin_url('admin.php?page=vfos-financial')];
        }

        usort($events,fn($a,$b)=>strcmp($a['start'],$b['start']));
        return $events;
    }

    private function calendar_type_label($type){
        $map=['meeting'=>'Reunião','delivery'=>'Entrega','internal'=>'Interno','reminder'=>'Lembrete','manual'=>'Compromisso','task'=>'Tarefa','project'=>'Projeto','lead'=>'Lead','financial'=>'Financeiro'];
        return $map[$type]??ucfirst($type);
    }

    public function calendar(){
        VFOS_Team::require_module('calendar');global $wpdb;
        $table=VFOS_DB::table('calendar_events');$edit=absint($_GET['edit']??0);$tab=$edit?'new':sanitize_key($_GET['tab']??'calendar');
        if(!in_array($tab,['calendar','week','list','new'],true))$tab='calendar';
        $e=$edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$edit)):null;
        if($e&&VFOS_Team::limited_to_assigned()&&(int)$e->assigned_user_id!==get_current_user_id())wp_die('Este compromisso não está atribuído a você.');

        $this->header('Agenda','Prazos, reuniões, tarefas e compromissos da VisionForge em uma única visão.');
        echo '<nav class="vfos-tabs">';$this->module_tab('vfos-calendar','calendar','Calendário',$tab);$this->module_tab('vfos-calendar','week','Semana',$tab);$this->module_tab('vfos-calendar','list','Visualização',$tab);$this->module_tab('vfos-calendar','new',$edit?'Editar compromisso':'Novo compromisso',$tab);echo '</nav>';

        if($tab==='new'){
            $members=$wpdb->get_results("SELECT tm.user_id,u.display_name FROM ".VFOS_DB::table('team')." tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE tm.status='active' ORDER BY u.display_name");
            $projects=$wpdb->get_results("SELECT id,name FROM ".VFOS_DB::table('projects')." WHERE status NOT IN ('completed','cancelled') ORDER BY name");
            $start=$e?$e->start_at:date('Y-m-d H:i:s',strtotime('+1 hour'));
            $end=$e?$e->end_at:date('Y-m-d H:i:s',strtotime('+2 hours'));
            echo '<div class="vfos-panel vfos-calendar-editor"><div class="vfos-panel-head"><div><span class="vfos-kicker">COMPROMISSO</span><h2>'.($e?'Editar compromisso':'Novo compromisso').'</h2></div><div class="vfos-brand-chip"><span></span> Agenda VisionForge</div></div>';
            $this->form_start('vfos_save_calendar_event');if($e)echo '<input type="hidden" name="id" value="'.$e->id.'">';
            echo '<div class="vfos-form-grid"><label>Título<input name="title" required value="'.esc_attr($e->title??'').'" placeholder="Ex.: Reunião de alinhamento"></label><label>Tipo<select name="event_type">';foreach(['meeting'=>'Reunião','delivery'=>'Entrega','internal'=>'Interno','reminder'=>'Lembrete'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->event_type??'meeting',$k,false).'>'.$v.'</option>';echo '</select></label><label>Início<input type="datetime-local" name="start_at" required value="'.esc_attr(date('Y-m-d\TH:i',strtotime($start))).'"></label><label>Término<input type="datetime-local" name="end_at" value="'.esc_attr($end?date('Y-m-d\TH:i',strtotime($end)):'').'"></label><label>Cliente<select name="client_id">';$this->clients_options($e->client_id??0);echo '</select></label><label>Projeto<select name="project_id"><option value="0">Sem projeto</option>';foreach($projects as $pr)echo '<option value="'.$pr->id.'" '.selected($e->project_id??0,$pr->id,false).'>'.esc_html($pr->name).'</option>';echo '</select></label><label>Responsável<select name="assigned_user_id">';
            if(VFOS_Team::limited_to_assigned())echo '<option value="'.get_current_user_id().'">'.esc_html(wp_get_current_user()->display_name).'</option>';
            else{echo '<option value="0">Equipe / sem responsável</option>';foreach($members as $u)echo '<option value="'.$u->user_id.'" '.selected($e->assigned_user_id??get_current_user_id(),$u->user_id,false).'>'.esc_html($u->display_name).'</option>';}
            echo '</select></label><label>Status<select name="status">';foreach(['scheduled'=>'Agendado','confirmed'=>'Confirmado','done'=>'Concluído','cancelled'=>'Cancelado'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->status??'scheduled',$k,false).'>'.$v.'</option>';echo '</select></label><label>Local<input name="location" value="'.esc_attr($e->location??'').'" placeholder="Ex.: Google Meet / Escritório"></label><label>Link da reunião<input type="url" name="meeting_url" value="'.esc_attr($e->meeting_url??'').'" placeholder="https://..."></label></div><label>Descrição<textarea name="description" rows="5">'.esc_textarea($e->description??'').'</textarea></label><label class="vfos-switch-row"><input type="checkbox" name="all_day" value="1" '.checked($e->all_day??0,1,false).'> Compromisso de dia inteiro</label><div class="vfos-form-actions"><button class="button button-primary vfos-btn">'.($e?'Salvar alterações':'Criar compromisso').'</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-calendar')).'">Cancelar</a></div></form></div>';
            $this->end();return;
        }

        $types=array_values(array_intersect(['manual','task','project','lead','financial'],array_map('sanitize_key',(array)($_GET['types']??[]))));
        $assigned=absint($_GET['assigned']??0);$client=absint($_GET['client']??0);
        if(VFOS_Team::limited_to_assigned())$assigned=get_current_user_id();

        $members=$wpdb->get_results("SELECT tm.user_id,u.display_name FROM ".VFOS_DB::table('team')." tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE tm.status='active' ORDER BY u.display_name");
        $filter_html=function()use($types,$assigned,$client,$members,$tab){
            echo '<form class="vfos-filters vfos-calendar-filters" method="get"><input type="hidden" name="page" value="vfos-calendar"><input type="hidden" name="tab" value="'.esc_attr($tab).'"><label>Cliente<select name="client">';$this->client_filter_select($client);echo '</select></label>';
            if(!VFOS_Team::limited_to_assigned()){echo '<label>Responsável<select name="assigned"><option value="0">Todos</option>';foreach($members as $u)echo '<option value="'.$u->user_id.'" '.selected($assigned,$u->user_id,false).'>'.esc_html($u->display_name).'</option>';echo '</select></label>';}
            echo '<fieldset class="vfos-calendar-types"><legend>Exibir</legend>';foreach(['manual'=>'Compromissos','task'=>'Tarefas','project'=>'Projetos','lead'=>'Leads','financial'=>'Financeiro'] as $k=>$v){if(($k==='lead'&&!VFOS_Team::can('crm'))||($k==='financial'&&!VFOS_Team::can('financial'))||($k==='project'&&!VFOS_Team::can('projects'))||($k==='task'&&!VFOS_Team::can('tasks')))continue;echo '<label><input type="checkbox" name="types[]" value="'.$k.'" '.checked(!$types||in_array($k,$types,true),true,false).'> '.$v.'</label>';}echo '</fieldset><div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Aplicar</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-calendar&tab='.$tab)).'">Limpar</a></div></form>';
        };

        if($tab==='calendar'){
            $month=sanitize_text_field($_GET['month']??date('Y-m'));if(!preg_match('/^\d{4}-\d{2}$/',$month))$month=date('Y-m');
            $first=$month.'-01';$last=date('Y-m-t',strtotime($first));$events=$this->calendar_collect_events($first,$last,['types'=>$types,'assigned'=>$assigned,'client'=>$client]);
            $prev=date('Y-m',strtotime($first.' -1 month'));$next=date('Y-m',strtotime($first.' +1 month'));
            echo '<div class="vfos-panel"><div class="vfos-calendar-toolbar"><div><span class="vfos-kicker">VISÃO MENSAL</span><h2>'.esc_html(date_i18n('F \d\e Y',strtotime($first))).'</h2></div><div><a class="button" href="'.esc_url(add_query_arg(['month'=>$prev])).'">‹</a><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-calendar&tab=calendar&month='.date('Y-m'))).'">Hoje</a><a class="button" href="'.esc_url(add_query_arg(['month'=>$next])).'">›</a><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-calendar&tab=new')).'">+ Compromisso</a></div></div>';
            $filter_html();
            $firstDow=(int)date('N',strtotime($first));$days=(int)date('t',strtotime($first));$cells=[];for($i=1;$i<$firstDow;$i++)$cells[]=null;for($d=1;$d<=$days;$d++)$cells[]=sprintf('%s-%02d',$month,$d);while(count($cells)%7)$cells[]=null;
            echo '<div class="vfos-month"><div class="vfos-month-head">';foreach(['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'] as $d)echo '<span>'.$d.'</span>';echo '</div><div class="vfos-month-grid">';
            foreach($cells as $date){if(!$date){echo '<div class="vfos-day is-empty"></div>';continue;}$dayEvents=array_values(array_filter($events,fn($x)=>substr($x['start'],0,10)===$date));$today=$date===date('Y-m-d');echo '<div class="vfos-day '.($today?'is-today':'').'"><header><strong>'.(int)substr($date,8,2).'</strong>'.($dayEvents?'<span>'.count($dayEvents).'</span>':'').'</header><div class="vfos-day-events">';foreach(array_slice($dayEvents,0,4) as $ev){$url=$ev['source']==='manual'?admin_url('admin.php?page=vfos-calendar&tab=new&edit='.$ev['id']):$ev['url'];echo '<a class="vfos-cal-event is-'.esc_attr($ev['type']).'" href="'.esc_url($url).'"><i></i><span>'.esc_html($ev['title']).'</span><small>'.(!$ev['all_day']?esc_html(date_i18n('H:i',strtotime($ev['start']))):'').'</small></a>';}if(count($dayEvents)>4)echo '<small class="vfos-more">+'.(count($dayEvents)-4).' evento(s)</small>';echo '</div></div>';}echo '</div></div></div>';
        } elseif($tab==='week'){
            $anchor=$this->date($_GET['date']??'')?:date('Y-m-d');$dow=(int)date('N',strtotime($anchor));$from=date('Y-m-d',strtotime($anchor.' -'.($dow-1).' days'));$to=date('Y-m-d',strtotime($from.' +6 days'));$events=$this->calendar_collect_events($from,$to,['types'=>$types,'assigned'=>$assigned,'client'=>$client]);
            echo '<div class="vfos-panel"><div class="vfos-calendar-toolbar"><div><span class="vfos-kicker">VISÃO SEMANAL</span><h2>'.esc_html(date_i18n('d/m',strtotime($from))).' — '.esc_html(date_i18n('d/m/Y',strtotime($to))).'</h2></div><div><a class="button" href="'.esc_url(add_query_arg('date',date('Y-m-d',strtotime($from.' -7 days')))).'">‹ Semana</a><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-calendar&tab=week&date='.date('Y-m-d'))).'">Hoje</a><a class="button" href="'.esc_url(add_query_arg('date',date('Y-m-d',strtotime($from.' +7 days')))).'">Próxima ›</a><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-calendar&tab=new')).'">+ Compromisso</a></div></div>';
            $filter_html();echo '<div class="vfos-week">';
            for($i=0;$i<7;$i++){$date=date('Y-m-d',strtotime($from." +$i days"));$dayEvents=array_values(array_filter($events,fn($x)=>substr($x['start'],0,10)===$date));echo '<section class="vfos-week-day '.($date===date('Y-m-d')?'is-today':'').'"><header><span>'.esc_html(date_i18n('D',strtotime($date))).'</span><strong>'.esc_html(date_i18n('d/m',strtotime($date))).'</strong></header><div>';if(!$dayEvents)echo '<small class="vfos-no-events">Sem compromissos</small>';foreach($dayEvents as $ev){$url=$ev['source']==='manual'?admin_url('admin.php?page=vfos-calendar&tab=new&edit='.$ev['id']):$ev['url'];echo '<a class="vfos-week-event is-'.esc_attr($ev['type']).'" href="'.esc_url($url).'"><time>'.(!$ev['all_day']?esc_html(date_i18n('H:i',strtotime($ev['start']))):'Dia todo').'</time><strong>'.esc_html($ev['title']).'</strong>'.($ev['assigned']?'<small>'.esc_html($ev['assigned']).'</small>':'').'</a>';}echo '</div></section>';}echo '</div></div>';
        } else {
            $from=$this->date($_GET['from']??'')?:date('Y-m-d');$to=$this->date($_GET['to']??'')?:date('Y-m-d',strtotime('+30 days'));$events=$this->calendar_collect_events($from,$to,['types'=>$types,'assigned'=>$assigned,'client'=>$client]);
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISUALIZAÇÃO</span><h2>Compromissos e prazos</h2></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-calendar&tab=new')).'">+ Novo compromisso</a></div>';
            echo '<form class="vfos-filters" method="get"><input type="hidden" name="page" value="vfos-calendar"><input type="hidden" name="tab" value="list"><label>De<input type="date" name="from" value="'.esc_attr($from).'"></label><label>Até<input type="date" name="to" value="'.esc_attr($to).'"></label><label>Cliente<select name="client">';$this->client_filter_select($client);echo '</select></label>';
            if(!VFOS_Team::limited_to_assigned()){echo '<label>Responsável<select name="assigned"><option value="0">Todos</option>';foreach($members as $u)echo '<option value="'.$u->user_id.'" '.selected($assigned,$u->user_id,false).'>'.esc_html($u->display_name).'</option>';echo '</select></label>';}
            echo '<div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Filtrar</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-calendar&tab=list')).'">Limpar</a></div></form><div class="vfos-agenda-list">';
            if(!$events)echo '<div class="vfos-empty">Nenhum compromisso encontrado no período.</div>';
            foreach($events as $ev){$url=$ev['source']==='manual'?admin_url('admin.php?page=vfos-calendar&tab=new&edit='.$ev['id']):$ev['url'];echo '<article><div class="vfos-agenda-date"><strong>'.esc_html(date_i18n('d',strtotime($ev['start']))).'</strong><span>'.esc_html(date_i18n('M',strtotime($ev['start']))).'</span></div><div class="vfos-agenda-icon is-'.esc_attr($ev['type']).'"></div><div><span class="vfos-kicker">'.esc_html($this->calendar_type_label($ev['type'])).'</span><h3><a href="'.esc_url($url).'">'.esc_html($ev['title']).'</a></h3><p>'.esc_html($ev['description']??'').'</p><div class="vfos-task-meta">'.(!$ev['all_day']?'<span>'.esc_html(date_i18n('H:i',strtotime($ev['start']))).'</span>':'<span>Dia inteiro</span>').($ev['client']?'<span>Cliente: '.esc_html($ev['client']).'</span>':'').($ev['assigned']?'<span>Responsável: '.esc_html($ev['assigned']).'</span>':'').'</div></div>';
                if($ev['source']==='manual'){$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_calendar_event&id='.$ev['id']),'vfos_delete_calendar_event');echo '<div class="vfos-agenda-actions"><a class="button" href="'.esc_url($url).'">Editar</a><a class="button vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir compromisso?\')">Excluir</a></div>';}echo '</article>';}
            echo '</div></div>';
        }
        $this->end();
    }

    public function save_calendar_event(){
        check_admin_referer('vfos_save_calendar_event');$id=absint($_POST['id']??0);VFOS_Team::require_permission($id?'calendar.edit':'calendar.create');global $wpdb;$t=VFOS_DB::table('calendar_events');$now=current_time('mysql');
        $start=sanitize_text_field($_POST['start_at']??'');$end=sanitize_text_field($_POST['end_at']??'');
        $start=$start?date('Y-m-d H:i:s',strtotime($start)):'';$end=$end?date('Y-m-d H:i:s',strtotime($end)):null;
        if(!$start)$this->go('vfos-calendar','Informe a data e hora de início.');
        $assigned=absint($_POST['assigned_user_id']??0);if(VFOS_Team::limited_to_assigned())$assigned=get_current_user_id();
        $d=['title'=>sanitize_text_field($_POST['title']??''),'description'=>sanitize_textarea_field($_POST['description']??''),'event_type'=>sanitize_key($_POST['event_type']??'meeting'),'start_at'=>$start,'end_at'=>$end,'all_day'=>empty($_POST['all_day'])?0:1,'client_id'=>absint($_POST['client_id']??0),'project_id'=>absint($_POST['project_id']??0),'assigned_user_id'=>$assigned,'status'=>sanitize_key($_POST['status']??'scheduled'),'location'=>sanitize_text_field($_POST['location']??''),'meeting_url'=>esc_url_raw($_POST['meeting_url']??''),'updated_at'=>$now];
        if($id)$wpdb->update($t,$d,['id'=>$id]);else{$d['created_by']=get_current_user_id();$d['created_at']=$now;$wpdb->insert($t,$d);$id=$wpdb->insert_id;}
        VFOS_DB::log('save_calendar_event','calendar_event',$id);$event_url=admin_url('admin.php?page=vfos-calendar&tab=new&edit='.$id);VFOS_Notifications::activity('calendar_event_saved','Compromisso salvo na agenda',$d['title'],'calendar','calendar_event',$id,$event_url);if($assigned&&$assigned!==get_current_user_id())VFOS_Notifications::notify($assigned,'calendar','Novo compromisso na sua agenda',$d['title'].' • '.date_i18n('d/m/Y H:i',strtotime($start)),'calendar','calendar_event',$id,$event_url);$this->go('vfos-calendar','Compromisso salvo na agenda.');
    }

    public function delete_calendar_event(){
        $this->guard('vfos_delete_calendar_event');global $wpdb;$id=absint($_GET['id']??0);$t=VFOS_DB::table('calendar_events');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));if($row&&VFOS_Team::limited_to_assigned()&&(int)$row->assigned_user_id!==get_current_user_id())wp_die('Sem permissão para excluir este compromisso.');
        $wpdb->delete($t,['id'=>$id]);VFOS_DB::log('delete_calendar_event','calendar_event',$id);$this->go('vfos-calendar','Compromisso excluído.');
    }

    public function financial(){
        VFOS_Team::require_permission('financial.view');global $wpdb;
        $ft=VFOS_DB::table('financial');$ct=VFOS_DB::table('clients');$payt=VFOS_DB::table('financial_payments');$splitt=VFOS_DB::table('financial_splits');
        $tab=sanitize_key($_GET['tab']??'list');
        if($tab==='payments')$tab='charges';if(!in_array($tab,['list','new','charges','receipts','recurring','statement','split','integrations'],true))$tab='list';
        if($tab==='new')VFOS_Team::require_permission('financial.create');
        if(in_array($tab,['charges','receipts'],true))VFOS_Team::require_permission('financial.payments');
        if($tab==='recurring')VFOS_Team::require_permission('financial.view');
        if($tab==='split')VFOS_Team::require_permission('financial.split');
        if($tab==='statement')VFOS_Team::require_permission('financial.view');
        if($tab==='integrations')VFOS_Team::require_permission('financial.integrations');

        $this->header('Financeiro','Caixa, cobranças, recebimentos, despesas e distribuição dos valores em uma única central.');
        echo '<nav class="vfos-tabs">';
        $this->module_tab('vfos-financial','list','Visão geral',$tab);
        if(VFOS_Team::can_permission('financial.create'))$this->module_tab('vfos-financial','new','Novo lançamento',$tab);
        if(VFOS_Team::can_permission('financial.payments')){$this->module_tab('vfos-financial','charges','Cobranças',$tab);$this->module_tab('vfos-financial','receipts','Recebimentos',$tab);}
        $this->module_tab('vfos-financial','recurring','Recorrentes',$tab);
        $this->module_tab('vfos-financial','statement','Extrato do caixa',$tab);
        if(VFOS_Team::can_permission('financial.split'))$this->module_tab('vfos-financial','split','Sócios e caixa',$tab);
        if(VFOS_Team::can_permission('financial.integrations'))$this->module_tab('vfos-financial','integrations','Integrações',$tab);
        echo '</nav>';

        if($tab==='new'){
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">CADASTRO FINANCEIRO</span><h2>Novo lançamento</h2><p>Em receitas, o valor contratado e o valor já recebido são informações diferentes.</p></div></div>';
            $this->form_start('vfos_save_financial');
            echo '<div class="vfos-form-grid">';
            echo '<label>Descrição<input name="description" required placeholder="Ex.: Desenvolvimento de loja virtual"></label>';
            echo '<label>Cliente<select name="client_id">';$this->clients_options(absint($_GET['client_id']??0));echo '</select></label>';
            echo '<label>Tipo<select id="vfos-financial-type" name="type"><option value="income">Receita / valor a receber</option><option value="expense">Despesa</option></select></label>';
            echo '<label>Valor total (R$)<input id="vfos-financial-amount" type="number" min="0.01" step="0.01" name="amount" required></label>';
            echo '<label>Vencimento<input type="date" name="due_date"></label>';
            echo '<label>Forma principal<input name="method" placeholder="Pix, cartão, boleto..."></label>';
            echo '</div>';
            echo '<div id="vfos-income-first-payment" class="vfos-first-payment"><div class="vfos-panel-head"><div><span class="vfos-kicker">ENTRADA / PRIMEIRO PAGAMENTO</span><h3>O cliente já pagou alguma parte?</h3><p>Pode ser R$ 0,00, uma entrada ou o valor integral. O restante continuará como saldo a receber.</p></div></div><div class="vfos-form-grid"><label>Valor já recebido (R$)<input type="number" min="0" step="0.01" name="initial_payment" value="0"></label><label>Data do recebimento<input type="date" name="initial_payment_date" value="'.esc_attr(date('Y-m-d')).'"></label><label>Forma deste pagamento<input name="initial_payment_method" placeholder="Ex.: Pix"></label><label class="vfos-grow">Observação<input name="initial_payment_notes" placeholder="Ex.: Entrada de 50% para início do projeto"></label></div></div>';
            echo '<div id="vfos-expense-status" style="display:none"><div class="vfos-form-grid"><label>Status da despesa<select name="expense_status"><option value="pending">Pendente</option><option value="paid">Pago</option></select></label></div></div>';
            if(VFOS_Team::can_permission('financial.split'))echo '<div id="vfos-inline-split" class="vfos-inline-split"><div><strong>Abrir divisão depois de salvar?</strong><small>Se houver valor recebido, você poderá dividi-lo entre sócios e caixa.</small></div><label><input type="checkbox" name="create_split" value="1"> Ir para divisão</label></div>';
            echo '<div class="vfos-form-actions"><button class="button button-primary vfos-btn">Salvar lançamento</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-financial')).'">Cancelar</a></div></form></div>';

        }elseif($tab==='statement'){
            $cash=VFOS_DB::financial_cash_stats();
            $payments=$wpdb->get_results("SELECT p.id,p.amount,p.payment_date,p.method,p.notes,f.description,c.name client_name FROM $payt p JOIN $ft f ON f.id=p.financial_id LEFT JOIN $ct c ON c.id=f.client_id ORDER BY p.payment_date DESC,p.id DESC LIMIT 500");
            $expenses=$wpdb->get_results("SELECT id,description,amount,paid_at,due_date,method,is_partner_withdrawal FROM $ft WHERE type='expense' AND status='paid' ORDER BY COALESCE(paid_at,created_at) DESC,id DESC LIMIT 500");
            $moves=[];
            foreach($payments as $p)$moves[]=['ts'=>$p->payment_date,'kind'=>'in','title'=>$p->description,'meta'=>($p->client_name?:'Cliente').($p->method?' • '.$p->method:''),'amount'=>(float)$p->amount];
            foreach($expenses as $x)$moves[]=['ts'=>$x->paid_at?:($x->due_date.' 00:00:00'),'kind'=>'out','title'=>$x->description,'meta'=>$x->is_partner_withdrawal?'Retirada de sócio':('Despesa'.($x->method?' • '.$x->method:'')),'amount'=>(float)$x->amount];
            usort($moves,fn($a,$b)=>strcmp($b['ts'],$a['ts']));
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">CAIXA REAL</span><h2>Extrato de movimentações</h2><p>Somente dinheiro que efetivamente entrou ou saiu. Valores apenas contratados não aparecem no saldo.</p></div></div>';
            echo '<div class="vfos-cash-overview"><div class="is-main"><span>Saldo atual em caixa</span><strong>R$ '.number_format($cash['cash'],2,',','.').'</strong><small>Recebimentos - despesas pagas - retiradas dos sócios</small></div><div><span>Entradas recebidas</span><strong>R$ '.number_format($cash['received'],2,',','.').'</strong></div><div><span>Despesas operacionais</span><strong>R$ '.number_format($cash['operational_expenses'],2,',','.').'</strong></div><div><span>Retiradas dos sócios</span><strong>R$ '.number_format($cash['partner_withdrawals'],2,',','.').'</strong></div></div>';
            echo '<div class="vfos-ledger">';
            if(!$moves)echo '<div class="vfos-empty">Ainda não há movimentações efetivas no caixa.</div>';
            foreach($moves as $m)echo '<article class="is-'.$m['kind'].'"><div><strong>'.esc_html($m['title']).'</strong><small>'.esc_html(date_i18n('d/m/Y H:i',strtotime($m['ts']))).' • '.esc_html($m['meta']).'</small></div><b>'.($m['kind']==='in'?'+':'−').' R$ '.number_format($m['amount'],2,',','.').'</b></article>';
            echo '</div></div>';

        }elseif($tab==='integrations'){
            $mp=VFOS_MercadoPago::settings();$webhook=VFOS_MercadoPago::webhook_url();$connection=null;
            if(!empty($mp['access_token'])&&!empty($_GET['test_mp']))$connection=VFOS_MercadoPago::test_connection();
            echo '<div class="vfos-grid vfos-grid-2"><div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">MERCADO PAGO</span><h2>Pagamentos automáticos e transparentes</h2><p>Pix e cartão podem ser pagos na própria página da VisionForge, com baixa automática e sem redirecionar o cliente.</p></div><span class="vfos-pill">'.(!empty($mp['enabled'])?'Ativo':'Desativado').'</span></div>';
            if(is_wp_error($connection))echo '<div class="vfos-notice" style="border-color:#e9c2c2">Falha na conexão: '.esc_html($connection->get_error_message()).'</div>';
            elseif(is_array($connection))echo '<div class="vfos-notice">✓ Conectado à conta Mercado Pago '.esc_html($connection['nickname']?:$connection['email']).' (#'.absint($connection['id']).')</div>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_mp_save_settings">';wp_nonce_field('vfos_mp_save_settings');
            echo '<div class="vfos-mp-switches"><label><input type="checkbox" name="mp[enabled]" value="1" '.checked(!empty($mp['enabled']),true,false).'> Ativar Mercado Pago</label><label><input type="checkbox" name="mp[pix_enabled]" value="1" '.checked(!empty($mp['pix_enabled']),true,false).'> Pix</label><label><input type="checkbox" name="mp[checkout_enabled]" value="1" '.checked(!empty($mp['checkout_enabled']),true,false).'> Cartão transparente</label><label class="vfos-mp-required"><input type="checkbox" checked disabled> Pagamento transparente obrigatório</label><label><input type="checkbox" name="mp[auto_capture]" value="1" '.checked(!empty($mp['auto_capture']),true,false).'> Baixa automática</label></div>';
            echo '<div class="vfos-form-grid"><label>Ambiente<select name="mp[environment]"><option value="test" '.selected($mp['environment'],'test',false).'>Teste / Sandbox</option><option value="production" '.selected($mp['environment'],'production',false).'>Produção / pagamentos reais</option></select></label><label>Public Key<input name="mp[public_key]" value="'.esc_attr($mp['public_key']).'" autocomplete="off" placeholder="APP_USR-..."></label><label class="vfos-grow">Access Token <small>Privado • fica somente no servidor</small><input type="password" name="mp[access_token]" value="'.esc_attr($mp['access_token']).'" autocomplete="new-password" placeholder="APP_USR-..."></label><label class="vfos-grow">Webhook Secret <small>Recomendado</small><input type="password" name="mp[webhook_secret]" value="'.esc_attr($mp['webhook_secret']).'" autocomplete="new-password"></label><label>Expiração Pix (minutos)<input type="number" min="30" max="43200" name="mp[pix_expiration_minutes]" value="'.esc_attr($mp['pix_expiration_minutes']).'"></label></div>';
            echo '<div class="vfos-form-actions"><button class="button button-primary vfos-btn">Salvar integração</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=integrations&test_mp=1')).'">Testar conexão</a></div></form></div>';
            echo '<div class="vfos-panel"><span class="vfos-kicker">WEBHOOK / BAIXA AUTOMÁTICA</span><h2>URL para o Mercado Pago</h2><p>Cadastre esta URL em <b>Suas integrações → sua aplicação → Webhooks</b>. Para cobranças normais e recorrentes, habilite os tópicos <b>Pagamentos (payment)</b>, <b>Vinculação de assinatura (subscription_preapproval)</b> e <b>Pagamento recorrente (subscription_authorized_payment)</b>.</p><div class="vfos-copy-box"><input readonly value="'.esc_attr($webhook).'" onclick="this.select()"><button type="button" class="button" onclick="navigator.clipboard.writeText(this.previousElementSibling.value);this.textContent=\'Copiado ✓\'">Copiar</button></div><div class="vfos-mp-flow"><strong>Fluxo automático</strong><span>1. VisionForge gera a cobrança</span><span>2. Cliente paga ou autoriza a recorrência</span><span>3. Webhook avisa o VisionForge OS</span><span>4. O sistema consulta o pagamento diretamente na API</span><span>5. Recebimento, saldo e caixa são atualizados automaticamente</span></div><p class="vfos-muted-action">O Access Token nunca é enviado ao navegador ou ao cliente.</p></div></div>';

        }elseif($tab==='charges'){
            $selected_id=absint($_GET['financial_id']??0);
            $incomes=$wpdb->get_results("SELECT f.*,c.name client_name,c.email client_email,c.billing_email FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.type='income' ORDER BY FIELD(f.status,'pending','partial','paid'),f.due_date IS NULL,f.due_date,f.id DESC LIMIT 500");
            $selected=$selected_id?$wpdb->get_row($wpdb->prepare("SELECT f.*,c.name client_name,c.email client_email,c.billing_email FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.id=%d AND f.type='income'",$selected_id)):null;
            $open_total=0;$overdue=0;foreach($incomes as $inc){$rem=max(0,(float)$inc->amount-(float)$inc->paid_amount);$open_total+=$rem;if($rem>0&&$inc->due_date&&$inc->due_date<date('Y-m-d'))$overdue+=$rem;}
            echo '<div class="vfos-finance-section-head"><div><span class="vfos-kicker">CONTAS A RECEBER</span><h2>Cobranças</h2><p>Aqui ficam valores contratados e cobranças a enviar. Dinheiro recebido aparece em uma aba separada.</p></div><div class="vfos-finance-mini-kpis"><span>Em aberto <b>R$ '.number_format($open_total,2,',','.').'</b></span><span>Vencido <b>R$ '.number_format($overdue,2,',','.').'</b></span></div></div>';
            echo '<div class="vfos-grid vfos-grid-2 vfos-financial-payment-layout"><div class="vfos-panel"><div class="vfos-panel-head"><div><h3>Carteira de cobranças</h3><p>Selecione para gerar Pix, cartão transparente ou link.</p></div></div><div class="vfos-payment-income-list">';
            if(!$incomes)echo '<div class="vfos-empty">Nenhuma cobrança cadastrada.</div>';
            foreach($incomes as $inc){$remaining=max(0,(float)$inc->amount-(float)$inc->paid_amount);$url=admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.$inc->id);echo '<a class="'.($selected_id===$inc->id?'is-active':'').'" href="'.esc_url($url).'"><div><strong>'.esc_html($inc->description).'</strong><small>'.esc_html($inc->client_name?:'Sem cliente').($inc->due_date?' • vence '.date_i18n('d/m/Y',strtotime($inc->due_date)):'').'</small></div><div><strong>R$ '.number_format($remaining,2,',','.').'</strong><small>'.($remaining>0?esc_html($this->status_label($inc->status)):'Quitado').'</small></div></a>';}echo '</div></div><div class="vfos-panel">';
            if(!$selected)echo '<div class="vfos-empty"><strong>Selecione uma cobrança</strong><p>Você poderá gerar um link de pagamento ou cobrar por Pix/cartão dentro da página VisionForge.</p></div>';
            else{
                $remaining=max(0,(float)$selected->amount-(float)$selected->paid_amount);
                echo '<div id="vfos-payment-live" data-financial-id="'.$selected->id.'" data-paid="'.esc_attr($selected->paid_amount).'" data-status="'.esc_attr($selected->status).'"><div class="vfos-panel-head"><div><span class="vfos-kicker">COBRANÇA <i id="vfos-payment-live-dot" class="vfos-live-dot"></i></span><h2>'.esc_html($selected->description).'</h2><p>'.esc_html($selected->client_name?:'Sem cliente').' <small id="vfos-payment-live-text">• acompanhamento em tempo real</small></p></div><span id="vfos-payment-status" class="vfos-pill">'.esc_html($this->status_label($selected->status)).'</span></div><div class="vfos-payment-summary"><div><span>Contratado</span><strong>R$ '.number_format((float)$selected->amount,2,',','.').'</strong></div><div><span>Recebido</span><strong id="vfos-payment-paid">R$ '.number_format((float)$selected->paid_amount,2,',','.').'</strong></div><div><span>Saldo</span><strong id="vfos-payment-remaining">R$ '.number_format($remaining,2,',','.').'</strong></div></div></div>';
                if($remaining>0){
                    $mp=VFOS_MercadoPago::settings();
                    if(!empty($mp['enabled'])){
                        $charges=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_MercadoPago::table()." WHERE financial_id=%d ORDER BY id DESC LIMIT 20",$selected->id));
                        echo '<div class="vfos-mp-charge-box"><div class="vfos-panel-head"><div><span class="vfos-kicker">PAGAMENTO ONLINE</span><h3>Gerar cobrança</h3><p>O cliente paga na página da VisionForge. Pix e cartão não precisam redirecionar para o site do Mercado Pago.</p></div><span class="vfos-pill">Baixa automática</span></div><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_mp_create_charge"><input type="hidden" name="financial_id" value="'.$selected->id.'">';wp_nonce_field('vfos_mp_create_charge');
                        echo '<div class="vfos-form-grid"><label>Valor (R$)<input type="number" name="charge_amount" min="0.01" max="'.esc_attr($remaining).'" step="0.01" value="'.esc_attr($remaining).'" required></label><label>E-mail do pagador<input type="email" name="payer_email" value="'.esc_attr($selected->billing_email?:$selected->client_email).'" required></label><label>Forma<select name="charge_method">';
                        if(!empty($mp['pix_enabled']))echo '<option value="pix">Pix transparente</option>';
                        if(!empty($mp['checkout_enabled']))echo '<option value="card">Cartão transparente</option>';
                        echo '</select></label></div><button class="button button-primary vfos-btn">Gerar cobrança</button></form>';
                        if($charges){echo '<div class="vfos-mp-charge-list"><strong>Links gerados</strong>';foreach($charges as $ch){$view=VFOS_MercadoPago::payment_url($ch->public_token);$sync=wp_nonce_url(admin_url('admin-post.php?action=vfos_mp_sync_charge&id='.$ch->id),'vfos_mp_sync_charge_'.$ch->id);$cancel=wp_nonce_url(admin_url('admin-post.php?action=vfos_mp_cancel_charge&id='.$ch->id),'vfos_mp_cancel_charge_'.$ch->id);$email_charge=wp_nonce_url(admin_url('admin-post.php?action=vfos_mp_email_charge&id='.$ch->id),'vfos_mp_email_charge_'.$ch->id);echo '<article data-charge-id="'.$ch->id.'"><div><b>'.($ch->method==='pix'?'Pix':($ch->method==='card'?'Cartão':'Checkout legado')).' • R$ '.number_format((float)$ch->amount,2,',','.').'</b><small>Status: <span class="vfos-charge-status">'.esc_html($ch->status).'</span></small></div><div><a class="button" target="_blank" href="'.esc_url($view).'">Abrir página</a><button type="button" class="button vfos-copy-payment-link" data-link="'.esc_attr($view).'">Copiar link</button><a class="button" href="'.esc_url($email_charge).'">Enviar e-mail</a><a class="button" href="'.esc_url($sync).'">Sincronizar</a>'.(!in_array($ch->status,['approved','cancelled'],true)?'<a class="button vfos-danger" href="'.esc_url($cancel).'">Cancelar</a>':'').'</div></article>';}echo '</div>';}
                        echo '</div>';
                    }else echo '<div class="vfos-notice">Mercado Pago não está ativo. Configure em Financeiro → Integrações para gerar cobranças automáticas.</div>';
                }else echo '<div class="vfos-paid-banner"><strong>✓ Cobrança quitada</strong><span>Não há saldo a cobrar.</span></div>';
            }
            echo '</div></div>';

        }elseif($tab==='receipts'){
            $selected_id=absint($_GET['financial_id']??0);
            $incomes=$wpdb->get_results("SELECT f.*,c.name client_name FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.type='income' ORDER BY f.id DESC LIMIT 500");
            $selected=$selected_id?$wpdb->get_row($wpdb->prepare("SELECT f.*,c.name client_name FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.id=%d AND f.type='income'",$selected_id)):null;
            $recent=$wpdb->get_results("SELECT p.*,f.description,c.name client_name,u.display_name created_by_name FROM $payt p JOIN $ft f ON f.id=p.financial_id LEFT JOIN $ct c ON c.id=f.client_id LEFT JOIN {$wpdb->users} u ON u.ID=p.created_by ORDER BY p.payment_date DESC,p.id DESC LIMIT 120");
            echo '<div class="vfos-finance-section-head"><div><span class="vfos-kicker">DINHEIRO QUE ENTROU</span><h2>Recebimentos</h2><p>Baixas efetivas, manuais ou automáticas. Esta aba não mistura valores ainda não pagos.</p></div></div>';
            echo '<div class="vfos-grid vfos-grid-2"><div class="vfos-panel"><h3>Registrar recebimento manual</h3><form method="get" class="vfos-quick-select"><input type="hidden" name="page" value="vfos-financial"><input type="hidden" name="tab" value="receipts"><select name="financial_id"><option value="0">Selecione a cobrança</option>';foreach($incomes as $inc){$rem=max(0,(float)$inc->amount-(float)$inc->paid_amount);if($rem>0)echo '<option value="'.$inc->id.'" '.selected($selected_id,$inc->id,false).'>'.esc_html($inc->client_name?:'Sem cliente').' — '.esc_html($inc->description).' (R$ '.number_format($rem,2,',','.').')</option>';}echo '</select><button class="button">Selecionar</button></form>';
            if($selected){$remaining=max(0,(float)$selected->amount-(float)$selected->paid_amount);if($remaining>0){echo '<form class="vfos-add-payment-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_add_financial_payment"><input type="hidden" name="financial_id" value="'.$selected->id.'">';wp_nonce_field('vfos_add_financial_payment_'.$selected->id);echo '<div class="vfos-form-grid"><label>Valor recebido<input type="number" name="amount" min="0.01" max="'.esc_attr($remaining).'" step="0.01" required></label><label>Data<input type="date" name="payment_date" value="'.esc_attr(date('Y-m-d')).'" required></label><label>Forma<input name="method" placeholder="Pix, dinheiro, transferência..."></label><label class="vfos-grow">Observação<input name="notes" placeholder="Ex.: Mensalidade agosto"></label></div><button class="button button-primary vfos-btn">Dar baixa manual</button></form>';}else echo '<div class="vfos-paid-banner">Cobrança já quitada.</div>';}
            echo '</div><div class="vfos-panel"><div class="vfos-panel-head"><div><h3>Recebimentos recentes</h3><p>Histórico cronológico do que efetivamente entrou.</p></div></div><div class="vfos-payment-history">';if(!$recent)echo '<div class="vfos-empty">Nenhum recebimento ainda.</div>';foreach($recent as $r){$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_financial_payment&id='.$r->id),'vfos_delete_financial_payment_'.$r->id);echo '<article><div><strong>+ R$ '.number_format((float)$r->amount,2,',','.').'</strong><small>'.esc_html($r->client_name?:'Sem cliente').' • '.date_i18n('d/m/Y H:i',strtotime($r->payment_date)).'</small><p>'.esc_html($r->description).($r->method?' • '.esc_html($r->method):'').'</p></div><div><small>'.(!empty($r->provider)&&$r->provider!=='manual'?'Automático • '.esc_html(ucfirst($r->provider)):'Manual • '.esc_html($r->created_by_name?:'Sistema')).'</small>'.((empty($r->provider)||$r->provider==='manual')?'<a class="vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir esta baixa? O saldo será recalculado.\')">Excluir</a>':'<span class="vfos-online-badge">Conciliado</span>').'</div></article>';}echo '</div></div></div>';

        }elseif($tab==='recurring'){
            $rt=VFOS_Recurring::table();$edit_rec=absint($_GET['edit_recurring']??0);$er=$edit_rec?$wpdb->get_row($wpdb->prepare("SELECT * FROM $rt WHERE id=%d",$edit_rec)):null;
            $rows=$wpdb->get_results("SELECT r.*,c.name client_name,p.name project_name,co.number contract_number FROM $rt r LEFT JOIN $ct c ON c.id=r.client_id LEFT JOIN ".VFOS_DB::table('projects')." p ON p.id=r.project_id LEFT JOIN ".VFOS_DB::table('contracts')." co ON co.id=r.contract_id ORDER BY FIELD(r.status,'active','pending_authorization','paused','cancelled'),r.next_due_date,r.id DESC");
            echo '<div class="vfos-recurring-hero"><div><span class="vfos-kicker">ASSINATURAS AUTOMÁTICAS</span><h2>Cobranças recorrentes pelo gateway</h2><p>Cartão recorrente funciona de forma transparente. O Pix Automático exige uma API específica de autorização de recorrência do PSP; o VisionForge não transforma Pix comum em débito automático.</p></div><div class="vfos-recurring-hero-badges"><span>Cartão recorrente transparente</span><span>AJAX + baixa automática</span><span>Atualização de cartão</span></div></div>';
            echo '<div class="vfos-grid vfos-grid-2"><div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">CONFIGURAÇÃO</span><h2>'.($er?'Editar assinatura':'Nova assinatura').'</h2><p>Configure o contrato recorrente e gere o link de autorização para o cliente.</p></div></div><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_recurring">'.($er?'<input type="hidden" name="id" value="'.$er->id.'">':'');wp_nonce_field('vfos_save_recurring');
            echo '<div class="vfos-form-grid"><label>Cliente<select name="client_id">';$this->clients_options($er->client_id??absint($_GET['client_id']??0));echo '</select></label><label>Título<input name="title" required value="'.esc_attr($er->title??'').'" placeholder="Ex.: Gestão mensal do Instagram"></label><label>Valor por cobrança (R$)<input type="number" min="0.01" step="0.01" name="amount" value="'.esc_attr($er->amount??'').'" required></label><label>E-mail do pagador<input type="email" name="payer_email" value="'.esc_attr($er->payer_email??'').'" placeholder="Pode usar o e-mail do cliente"></label><label>Periodicidade<select name="frequency">';foreach(['weekly'=>'Semanal','monthly'=>'Mensal','quarterly'=>'Trimestral','semiannual'=>'Semestral','annual'=>'Anual'] as $k=>$v)echo '<option value="'.$k.'" '.selected($er->frequency??'monthly',$k,false).'>'.$v.'</option>';echo '</select></label><label>A cada<input type="number" name="interval_count" min="1" max="24" value="'.esc_attr($er->interval_count??1).'"><small>1 = todo mês; 2 = a cada 2 meses.</small></label><label>Primeiro vencimento<input type="date" name="next_due_date" value="'.esc_attr($er->next_due_date??date('Y-m-d',strtotime('+1 month'))).'" required></label><label>Encerrar em <small>opcional</small><input type="date" name="end_date" value="'.esc_attr($er->end_date??'').'"></label></div>';
            echo '<div class="vfos-recurring-first-charge"><span class="vfos-kicker">PRIMEIRA MENSALIDADE</span><h3>Quando cobrar a primeira vez?</h3><div><label><input type="radio" name="first_charge_mode" value="now" '.checked($er->first_charge_mode??'now','now',false).'> <strong>Iniciar cobrança na autorização</strong><small>A assinatura entra no ciclo imediatamente. No cartão, o Mercado Pago informa que a primeira parcela pode levar aproximadamente até 1 hora para ser debitada e confirmada.</small></label><label><input type="radio" name="first_charge_mode" value="due" '.checked($er->first_charge_mode??'now','due',false).'> <strong>Cobrar só no primeiro vencimento</strong><small>O cliente autoriza agora, mas a primeira cobrança fica programada para a data acima.</small></label></div></div>';
            echo '<div class="vfos-recurring-method-choice"><span class="vfos-kicker">FORMA DE AUTORIZAÇÃO</span><h3>Gateway recorrente</h3><div><label><input type="radio" name="subscription_method" value="card" checked> Cartão de crédito recorrente transparente</label></div><p class="description"><strong>Pix Automático:</strong> não é habilitado como Pix comum. Para funcionar automaticamente, o PSP precisa fornecer a jornada oficial de autorização/QR composto do Pix Automático. A integração pública de Assinaturas do Mercado Pago usada aqui não fornece esse QR de autorização; por isso o sistema não exibirá um Pix “falso recorrente”.</p></div>';
            echo '<label>Observações<textarea name="notes" data-vfos-ai="generic" data-vfos-ai-label="Observações da assinatura recorrente">'.esc_textarea($er->notes??'').'</textarea></label><div class="vfos-form-actions"><button class="button button-primary vfos-btn">Salvar assinatura</button></div></form>';
            if($er){
                $link=VFOS_Recurring::url($er->public_token);$mail=wp_nonce_url(admin_url('admin-post.php?action=vfos_email_recurring&id='.$er->id),'vfos_email_recurring_'.$er->id);$sync=wp_nonce_url(admin_url('admin-post.php?action=vfos_sync_recurring&id='.$er->id),'vfos_sync_recurring_'.$er->id);
                echo '<div class="vfos-recurring-linkbox"><div><span class="vfos-kicker">AUTORIZAÇÃO DO CLIENTE</span><h3>Link da assinatura</h3><p>Envie este link para autorizar ou atualizar o cartão. Enquanto estiver pendente, ou se uma cobrança falhar, você pode reenviar o mesmo link ao cliente.</p></div><input readonly value="'.esc_attr($link).'"><div><button type="button" class="button vfos-copy-payment-link" data-link="'.esc_attr($link).'">Copiar link</button><a class="button button-primary" target="_blank" href="'.esc_url($link).'">Abrir</a><a class="button" href="'.esc_url($mail).'">Enviar por e-mail</a>'.($er->gateway_subscription_id?'<a class="button" href="'.esc_url($sync).'">Sincronizar</a>':'').'</div></div>';
                echo '<div class="vfos-recurring-status-card"><div><span>Status no VisionForge</span><strong>'.esc_html($this->status_label($er->status)).'</strong></div><div><span>Status no gateway</span><strong>'.esc_html($er->gateway_status?:'Aguardando autorização').'</strong></div><div><span>Próxima cobrança</span><strong>'.($er->next_due_date?date_i18n('d/m/Y',strtotime($er->next_due_date)):'—').'</strong></div><div><span>Último recebimento</span><strong>'.($er->last_paid_at?date_i18n('d/m/Y H:i',strtotime($er->last_paid_at)):'—').'</strong></div></div>';
            }
            echo '</div>';
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">ASSINATURAS</span><h2>Clientes recorrentes</h2><p>Veja quem já autorizou e quem ainda precisa concluir a autorização.</p></div><span class="vfos-pill">'.count($rows).' assinatura(s)</span></div><div class="vfos-recurring-list">';
            if(!$rows)echo '<div class="vfos-empty">Nenhuma assinatura cadastrada.</div>';
            foreach($rows as $r){
                $edit=admin_url('admin.php?page=vfos-financial&tab=recurring&edit_recurring='.$r->id);$toggle=wp_nonce_url(admin_url('admin-post.php?action=vfos_toggle_recurring&id='.$r->id),'vfos_toggle_recurring_'.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_recurring&id='.$r->id),'vfos_delete_recurring_'.$r->id);$link=VFOS_Recurring::url($r->public_token);$sync=wp_nonce_url(admin_url('admin-post.php?action=vfos_sync_recurring&id='.$r->id),'vfos_sync_recurring_'.$r->id);$mail=wp_nonce_url(admin_url('admin-post.php?action=vfos_email_recurring&id='.$r->id),'vfos_email_recurring_'.$r->id);
                $label=$r->gateway_status==='payment_failed'?'Falha no pagamento — atualizar cartão':($r->status==='active'?'Ativa':($r->status==='pending_authorization'?'Aguardando autorização':($r->status==='paused'?'Pausada':ucfirst($r->status))));
                echo '<article class="vfos-recurring-card is-'.esc_attr($r->status).'"><div><strong>'.esc_html($r->title).'</strong><small>'.esc_html($r->client_name?:'Sem cliente').' • '.esc_html($label).'</small>'.($r->gateway_subscription_id?'<em>ID gateway: '.esc_html($r->gateway_subscription_id).'</em>':'').'</div><div><b>R$ '.number_format((float)$r->amount,2,',','.').'</b><small>'.esc_html($r->frequency).' • próxima '.date_i18n('d/m/Y',strtotime($r->next_due_date)).'</small></div><div class="vfos-recurring-actions"><a class="button" href="'.esc_url($edit).'">Editar</a><a class="button" target="_blank" href="'.esc_url($link).'">Link</a><a class="button" href="'.esc_url($mail).'">'.($r->gateway_status==='payment_failed'?'Enviar atualização':'Enviar autorização').'</a>'.($r->gateway_subscription_id?'<a class="button" href="'.esc_url($sync).'">Sync</a>':'').($r->status==='active'||$r->status==='paused'?'<a class="button" href="'.esc_url($toggle).'">'.($r->status==='active'?'Pausar':'Reativar').'</a>':'').'<a class="button vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Cancelar esta assinatura no gateway e excluir do VisionForge?\')">Excluir</a></div></article>';
            }
            echo '</div></div></div>';

        }elseif($tab==='split'){
            $selected_id=absint($_GET['financial_id']??0);
            $incomes=$wpdb->get_results("SELECT f.*,c.name client_name FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.type='income' AND f.paid_amount>0 ORDER BY f.id DESC LIMIT 300");
            $selected=$selected_id?$wpdb->get_row($wpdb->prepare("SELECT f.*,c.name client_name FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.id=%d AND f.type='income'",$selected_id)):null;
            $team_table=VFOS_DB::table('team');
            $members=$wpdb->get_results("SELECT tm.user_id,u.display_name,tm.job_title FROM $team_table tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE tm.status='active' ORDER BY u.display_name");
            $total_partner=(float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM $splitt WHERE split_type='partner'");
            $total_cash=(float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM $splitt WHERE split_type='company_cash'");
            echo '<div class="vfos-stats"><div class="vfos-stat"><span>Distribuído aos sócios</span><strong>R$ '.number_format($total_partner,2,',','.').'</strong></div><div class="vfos-stat"><span>Reservado no caixa</span><strong>R$ '.number_format($total_cash,2,',','.').'</strong></div></div>';
            echo '<div class="vfos-grid vfos-grid-2 vfos-financial-split-layout"><div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VALORES REALMENTE RECEBIDOS</span><h2>Escolha uma receita</h2><p>A divisão usa somente o dinheiro que já entrou, nunca o valor ainda a receber.</p></div></div><div class="vfos-split-income-list">';
            if(!$incomes)echo '<div class="vfos-empty">Ainda não há receitas com pagamentos recebidos.</div>';
            foreach($incomes as $inc){
                $distributed=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM $splitt WHERE financial_id=%d",$inc->id));
                $url=admin_url('admin.php?page=vfos-financial&tab=split&financial_id='.$inc->id);
                echo '<a class="'.($selected_id===$inc->id?'is-active':'').'" href="'.esc_url($url).'"><div><strong>'.esc_html($inc->description).'</strong><small>'.esc_html($inc->client_name?:'Sem cliente').'</small></div><div><strong>Recebido R$ '.number_format((float)$inc->paid_amount,2,',','.').'</strong><small>Dividido R$ '.number_format($distributed,2,',','.').'</small></div></a>';
            }
            echo '</div></div><div class="vfos-panel">';
            if(!$selected){
                echo '<div class="vfos-empty"><strong>Selecione uma receita recebida</strong><p>Se o cliente pagou apenas uma entrada, é somente essa entrada que será dividida.</p></div>';
            }elseif((float)$selected->paid_amount<=0){
                echo '<div class="vfos-empty"><strong>Nenhum valor recebido</strong><p>Registre uma entrada ou pagamento antes de fazer a divisão.</p><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.$selected->id)).'">Registrar pagamento</a></div>';
            }else{
                $existing=$wpdb->get_results($wpdb->prepare("SELECT * FROM $splitt WHERE financial_id=%d ORDER BY sort_order,id",$selected->id));
                $partner_rows=array_values(array_filter($existing,fn($x)=>$x->split_type==='partner'));
                $cash_row=null;foreach($existing as $x)if($x->split_type==='company_cash'){$cash_row=$x;break;}
                $allocated=array_sum(array_map(fn($x)=>(float)$x->amount,$existing));
                $available=(float)$selected->paid_amount;
                echo '<div class="vfos-panel-head"><div><span class="vfos-kicker">DIVISÃO DO RECEBIDO</span><h2>'.esc_html($selected->description).'</h2><p>Contrato: R$ '.number_format((float)$selected->amount,2,',','.').' • Já recebido: <strong>R$ '.number_format($available,2,',','.').'</strong></p></div></div>';
                echo '<div class="vfos-split-summary"><div><span>Disponível para divisão</span><strong id="vfos-split-total" data-total="'.esc_attr($available).'">R$ '.number_format($available,2,',','.').'</strong></div><div><span>Distribuído</span><strong id="vfos-split-allocated">R$ '.number_format($allocated,2,',','.').'</strong></div><div><span>Diferença</span><strong id="vfos-split-remaining">R$ '.number_format($available-$allocated,2,',','.').'</strong></div></div>';
                echo '<form id="vfos-split-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_financial_split"><input type="hidden" name="financial_id" value="'.$selected->id.'">';wp_nonce_field('vfos_save_financial_split_'.$selected->id);
                echo '<div class="vfos-split-mode"><strong>Modo</strong><label><input type="radio" name="split_mode" value="amount" checked> Valores em R$</label><label><input type="radio" name="split_mode" value="percent"> Percentuais</label></div>';
                echo '<div class="vfos-split-section"><div class="vfos-panel-head"><div><span class="vfos-kicker">SÓCIOS</span><h3>Quanto vai para cada pessoa?</h3></div><button type="button" class="button vfos-add-split-partner">+ Adicionar sócio</button></div><div id="vfos-split-partners">';
                $seed=$partner_rows?:[(object)['user_id'=>0,'label'=>'','percentage'=>0,'amount'=>0]];
                foreach($seed as $i=>$r){
                    echo '<div class="vfos-split-partner-row"><label>Sócio<select name="partners['.$i.'][user_id]"><option value="0">Selecione...</option>';foreach($members as $m)echo '<option value="'.$m->user_id.'" '.selected($r->user_id??0,$m->user_id,false).'>'.esc_html($m->display_name.($m->job_title?' — '.$m->job_title:'')).'</option>';echo '</select></label><label>Nome livre<input name="partners['.$i.'][label]" value="'.esc_attr($r->label??'').'"></label><label>Valor R$<input class="vfos-split-amount" type="number" step="0.01" min="0" name="partners['.$i.'][amount]" value="'.esc_attr($r->amount??0).'"></label><label>%<input class="vfos-split-percent" type="number" step="0.01" min="0" max="100" name="partners['.$i.'][percentage]" value="'.esc_attr($r->percentage??0).'"></label><button type="button" class="button vfos-remove-split-partner">×</button></div>';
                }
                echo '</div></div>';
                echo '<div class="vfos-split-section vfos-company-cash-box"><span class="vfos-kicker">CAIXA DA EMPRESA</span><h3>Reserva para investimento</h3><div class="vfos-form-grid"><label>Valor no caixa R$<input id="vfos-company-cash-amount" class="vfos-split-amount" type="number" step="0.01" min="0" name="company_cash_amount" value="'.esc_attr($cash_row->amount??0).'"></label><label>Percentual %<input id="vfos-company-cash-percent" class="vfos-split-percent" type="number" step="0.01" min="0" max="100" name="company_cash_percentage" value="'.esc_attr($cash_row->percentage??0).'"></label></div></div>';
                echo '<div class="vfos-split-validation"><strong>A distribuição precisa fechar o valor recebido.</strong><p id="vfos-split-validation-text"></p></div><div class="vfos-form-actions"><button class="button button-primary">Salvar divisão</button></div></form>';
            }
            echo '</div></div>';

        }else{
            $search=$this->q('s');$status=sanitize_key($_GET['status']??'');$type=sanitize_key($_GET['type']??'');$client=absint($_GET['client']??0);$period=sanitize_key($_GET['period']??'');$where=['1=1'];$args=[];
            if($search!==''){$where[]='(f.description LIKE %s OR c.name LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like);}
            if(in_array($status,['pending','partial','paid'],true)){$where[]='f.status=%s';$args[]=$status;}
            if(in_array($type,['income','expense'],true)){$where[]='f.type=%s';$args[]=$type;}
            if($client){$where[]='f.client_id=%d';$args[]=$client;}
            if($period==='overdue')$where[]="f.due_date<CURDATE() AND f.status IN ('pending','partial')";
            elseif($period==='month')$where[]='YEAR(f.created_at)=YEAR(CURDATE()) AND MONTH(f.created_at)=MONTH(CURDATE())';
            $sql="SELECT f.*,c.name client_name FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE ".implode(' AND ',$where).' ORDER BY f.id DESC LIMIT 400';
            $rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);

            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISUALIZAÇÃO</span><h2>Movimentações</h2><p>Receitas mostram o valor contratado, quanto já entrou e quanto ainda falta.</p></div>'.(VFOS_Team::can_permission('financial.create')?'<a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=new')).'">+ Novo lançamento</a>':'').'</div>';
            $this->filter_start('vfos-financial');
            echo '<label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Descrição ou cliente"></label><label>Cliente<select name="client">';$this->client_filter_select($client);echo '</select></label><label>Tipo<select name="type"><option value="">Todos</option><option value="income" '.selected($type,'income',false).'>Receita</option><option value="expense" '.selected($type,'expense',false).'>Despesa</option></select></label><label>Status<select name="status"><option value="">Todos</option><option value="pending" '.selected($status,'pending',false).'>Pendente</option><option value="partial" '.selected($status,'partial',false).'>Parcialmente pago</option><option value="paid" '.selected($status,'paid',false).'>Pago</option></select></label>';
            $this->filter_end();

            $contracted=0;$received=0;$expenses=0;$receivable=0;
            foreach($rows as $r){if($r->type==='income'){$contracted+=(float)$r->amount;$received+=(float)$r->paid_amount;$receivable+=max(0,(float)$r->amount-(float)$r->paid_amount);}else $expenses+=(float)$r->amount;}
            $cash=VFOS_DB::financial_cash_stats();
            echo '<div class="vfos-cash-overview"><div class="is-main"><span>Saldo atual em caixa</span><strong>R$ '.number_format($cash['cash'],2,',','.').'</strong><small>Recebimentos - despesas pagas - retiradas dos sócios</small></div><div><span>Total recebido</span><strong>R$ '.number_format($cash['received'],2,',','.').'</strong></div><div><span>Despesas operacionais</span><strong>R$ '.number_format($cash['operational_expenses'],2,',','.').'</strong></div><div><span>Retiradas dos sócios</span><strong>R$ '.number_format($cash['partner_withdrawals'],2,',','.').'</strong></div></div>';
            echo '<div class="vfos-finance-actions"><a href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=charges')).'"><span>⌁</span><strong>Cobrar cliente</strong><small>Pix, cartão e link de pagamento</small></a><a href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=new')).'"><span>＋</span><strong>Novo lançamento</strong><small>Receita ou despesa</small></a><a href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=statement')).'"><span>≡</span><strong>Extrato do caixa</strong><small>Veja tudo que entrou e saiu</small></a>'.(VFOS_Team::can_permission('financial.split')?'<a href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=split')).'"><span>⇄</span><strong>Sócios e caixa</strong><small>Distribuição dos recebimentos</small></a>':'').'</div>';
            echo '<div class="vfos-filter-summary"><span>Contratado <strong>R$ '.number_format($contracted,2,',','.').'</strong></span><span>Recebido <strong>R$ '.number_format($received,2,',','.').'</strong></span><span>A receber <strong>R$ '.number_format($receivable,2,',','.').'</strong></span><span>Despesas <strong>R$ '.number_format($expenses,2,',','.').'</strong></span></div>';
            $month_received=(float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM $payt WHERE payment_date>=DATE_FORMAT(CURDATE(),'%Y-%m-01') AND payment_date<DATE_ADD(LAST_DAY(CURDATE()),INTERVAL 1 DAY)");
            $overdue_total=(float)$wpdb->get_var("SELECT COALESCE(SUM(GREATEST(amount-paid_amount,0)),0) FROM $ft WHERE type='income' AND status IN ('pending','partial') AND due_date<CURDATE()");
            $due_7=(float)$wpdb->get_var("SELECT COALESCE(SUM(GREATEST(amount-paid_amount,0)),0) FROM $ft WHERE type='income' AND status IN ('pending','partial') AND due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY)");
            $active_recurring=$wpdb->get_results("SELECT amount,frequency,interval_count FROM ".VFOS_Recurring::table()." WHERE status='active'");
            $mrr=0.0;foreach($active_recurring as $rr){$n=max(1,(int)$rr->interval_count);$a=(float)$rr->amount;if($rr->frequency==='weekly')$mrr+=($a*52/12)/$n;elseif($rr->frequency==='quarterly')$mrr+=($a/3)/$n;elseif($rr->frequency==='semiannual')$mrr+=($a/6)/$n;elseif($rr->frequency==='annual')$mrr+=($a/12)/$n;else $mrr+=$a/$n;}
            echo '<div class="vfos-finance-intelligence"><div><span>Recebido neste mês</span><strong>R$ '.number_format($month_received,2,',','.').'</strong><small>Entradas confirmadas no mês atual</small></div><div class="is-alert"><span>Vencido</span><strong>R$ '.number_format($overdue_total,2,',','.').'</strong><small>Saldo de cobranças já vencidas</small></div><div><span>Vence em até 7 dias</span><strong>R$ '.number_format($due_7,2,',','.').'</strong><small>Previsão de curto prazo</small></div><div class="is-recurring"><span>Receita recorrente mensal estimada</span><strong>R$ '.number_format($mrr,2,',','.').'</strong><small>Equivalência mensal das recorrências ativas</small></div></div>';

            echo '<div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Descrição</th><th>Cliente</th><th>Tipo</th><th>Status</th><th>Financeiro</th><th>Vencimento</th><th>Ações</th></tr></thead><tbody>';
            if(!$rows)echo '<tr><td colspan="7">Nenhum lançamento encontrado.</td></tr>';
            foreach($rows as $r){
                $delete=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_financial&id='.$r->id),'vfos_delete_financial_'.$r->id);
                echo '<tr><td><strong>'.esc_html($r->description).'</strong><small>#'.(int)$r->id.($r->is_partner_withdrawal?' • Gerada pela divisão':'').'</small></td><td>'.esc_html($r->client_name?:'—').'</td><td>'.($r->type==='income'?'Receita':($r->is_partner_withdrawal?'Retirada de sócio':'Despesa')).'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span></td><td>';
                if($r->type==='income'){
                    $remaining=max(0,(float)$r->amount-(float)$r->paid_amount);
                    echo '<strong>R$ '.number_format((float)$r->amount,2,',','.').'</strong><small>Recebido: R$ '.number_format((float)$r->paid_amount,2,',','.').' • Falta: R$ '.number_format($remaining,2,',','.').'</small>';
                }else echo '<strong>R$ '.number_format((float)$r->amount,2,',','.').'</strong>';
                echo '</td><td>'.($r->due_date?esc_html(date_i18n('d/m/Y',strtotime($r->due_date))):'—').'</td><td>';
                if($r->type==='income'&&VFOS_Team::can_permission('financial.payments'))echo '<a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.$r->id)).'">Abrir cobrança</a> ';
                if($r->type==='income'&&(float)$r->paid_amount>0&&VFOS_Team::can_permission('financial.split'))echo '<a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-financial&tab=split&financial_id='.$r->id)).'">Dividir recebido</a> ';
                if($r->is_partner_withdrawal)echo '<span class="vfos-muted-action">Gerenciado pela divisão</span>';
                elseif(VFOS_Team::can_permission('financial.delete'))echo '<a class="button vfos-danger" href="'.esc_url($delete).'" onclick="return confirm(\'Excluir permanentemente este lançamento financeiro?\')">Excluir</a>';
                echo '</td></tr>';
            }
            echo '</tbody></table></div></div>';
        }
        $this->end();
    }

    public function ajax_payment_live(){
        check_ajax_referer('vfos_ajax','nonce');VFOS_Team::require_permission('financial.view');global $wpdb;
        $fid=absint($_GET['financial_id']??$_POST['financial_id']??0);if(!$fid)wp_send_json_error('Cobrança inválida.');
        $ft=VFOS_DB::table('financial');$f=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ft WHERE id=%d AND type='income'",$fid));
        if(!$f)wp_send_json_error('Cobrança não encontrada.');
        if(class_exists('VFOS_MercadoPago')){
            $charges=$wpdb->get_results($wpdb->prepare("SELECT id,provider_payment_id,status FROM ".VFOS_MercadoPago::table()." WHERE financial_id=%d AND provider='mercadopago' AND status NOT IN ('approved','cancelled','rejected') ORDER BY id DESC LIMIT 4",$fid));
            foreach($charges as $ch)if($ch->provider_payment_id)VFOS_MercadoPago::sync_charge($ch->id);
        }
        $f=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ft WHERE id=%d",$fid));
        $remaining=max(0,(float)$f->amount-(float)$f->paid_amount);
        $charge_rows=[];
        if(class_exists('VFOS_MercadoPago')){
            foreach($wpdb->get_results($wpdb->prepare("SELECT id,status,provider_payment_id,provider_preference_id,paid_at FROM ".VFOS_MercadoPago::table()." WHERE financial_id=%d ORDER BY id DESC LIMIT 15",$fid)) as $ch)$charge_rows[]=[
                'id'=>(int)$ch->id,'status'=>$ch->status,'provider_id'=>$ch->provider_payment_id?:$ch->provider_preference_id,'paid_at'=>$ch->paid_at
            ];
        }
        wp_send_json_success([
            'financial_id'=>$fid,'amount'=>(float)$f->amount,'paid'=>(float)$f->paid_amount,'remaining'=>$remaining,
            'status'=>$f->status,'status_label'=>$this->status_label($f->status),'charges'=>$charge_rows,'checked_at'=>current_time('H:i:s')
        ]);
    }

    private function contract_editor($content,$editor_id='vfos_contract_content',$name='content'){
        wp_editor((string)$content,$editor_id,[
            'textarea_name'=>$name,'textarea_rows'=>24,'media_buttons'=>false,'quicktags'=>true,'teeny'=>false,
            'tinymce'=>[
                'toolbar1'=>'formatselect,fontsizeselect,bold,italic,underline,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,undo,redo',
                'toolbar2'=>'removeformat,outdent,indent,charmap,hr',
                'fontsize_formats'=>'8pt 9pt 10pt 11pt 12pt 14pt 16pt 18pt 20pt 24pt',
                'forced_root_block'=>'p',
                'force_p_newlines'=>true,
                'force_br_newlines'=>false,
                'content_style'=>'body{font-family:Arial,sans-serif;font-size:14px;line-height:1.45;color:#222} p{margin:0 0 8px} h1,h2,h3,h4{line-height:1.3;margin:18px 0 10px} li{margin-bottom:6px}'
            ]
        ]);
    }
    public function contracts(){
        VFOS_Team::require_permission('contracts.view');global $wpdb;
        $tt=VFOS_DB::table('contracts');$ct=VFOS_DB::table('clients');$pt=VFOS_DB::table('projects');$mt=VFOS_DB::table('contract_templates');
        $edit=absint($_GET['edit']??0);$template_edit=absint($_GET['template_edit']??0);$tab=$edit?'new':sanitize_key($_GET['tab']??'list');if($template_edit)$tab='template_new';
        if(!in_array($tab,['list','new','templates','template_new'],true))$tab='list';
        $e=$edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $tt WHERE id=%d",$edit)):null;$contract_recurring=$e?$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_Recurring::table()." WHERE contract_id=%d ORDER BY id DESC LIMIT 1",$e->id)):null;$tpl_edit=$template_edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $mt WHERE id=%d",$template_edit)):null;
        $template_id=absint($_GET['template_id']??0);$selected_template=(!$e&&$template_id)?$wpdb->get_row($wpdb->prepare("SELECT * FROM $mt WHERE id=%d AND status='active'",$template_id)):null;
        $this->header('Contratos','Contratos personalizados no papel timbrado oficial da VisionForge e conectados ao VisionForge Sign.');
        if($tab==='new')VFOS_Team::require_permission($edit?'contracts.edit':'contracts.create');if(in_array($tab,['templates','template_new'],true))VFOS_Team::require_permission('contracts.templates');
        echo '<nav class="vfos-tabs">';$this->module_tab('vfos-contracts','list','Visualização',$tab);if(VFOS_Team::can_permission('contracts.create')||($edit&&VFOS_Team::can_permission('contracts.edit')))$this->module_tab('vfos-contracts','new',$edit?'Editar contrato':'Novo contrato',$tab);if(VFOS_Team::can_permission('contracts.templates'))$this->module_tab('vfos-contracts','templates','Modelos de contrato',in_array($tab,['templates','template_new'],true)?'templates':$tab);echo '</nav>';
        if($tab==='new'){
            $templates=$wpdb->get_results("SELECT * FROM $mt WHERE status='active' ORDER BY name");$content=$e?$e->content:($selected_template?$selected_template->content:'');$title=$e?$e->title:'';
            echo '<div class="vfos-contract-workspace"><aside class="vfos-letterhead-preview"><div class="vfos-letterhead-page"><img src="'.esc_url(VFOS_URL.'admin/assets/images/visionforge-letterhead.jpg').'" alt="Papel timbrado"><div><strong>Papel timbrado VisionForge</strong><small>O conteúdo será aplicado nessa área no PDF final.</small></div></div>';
            if($templates){echo '<div class="vfos-contract-model-picker"><span class="vfos-kicker">MODELOS</span><h3>Começar por um modelo</h3><a class="'.(!$selected_template&&!$e?'is-active':'').'" href="'.esc_url(admin_url('admin.php?page=vfos-contracts&tab=new')).'">Documento em branco</a>';foreach($templates as $m)echo '<a class="'.($selected_template&&$selected_template->id==$m->id?'is-active':'').'" href="'.esc_url(admin_url('admin.php?page=vfos-contracts&tab=new&template_id='.$m->id)).'">'.esc_html($m->name).'</a>';echo '</div>';}
            echo '</aside><div class="vfos-panel vfos-contract-editor-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">CONTRATO</span><h2>'.($e?'Editar contrato':'Novo contrato').'</h2><p>O conteúdo começa vazio. Use somente o texto e a formatação que você quiser.</p></div><span class="vfos-status '.(VFOS_Sign::local_available()?'ok':'off').'">'.(VFOS_Sign::local_available()?'VF Sign conectado':'VF Sign não detectado').'</span></div>';$this->form_start('vfos_save_contract');if($e)echo '<input type="hidden" name="id" value="'.$e->id.'">';
            echo '<div class="vfos-form-grid"><label>Cliente<select name="client_id">';$this->clients_options($e->client_id??absint($_GET['client_id']??0));echo '</select></label><label>Projeto<select name="project_id"><option value="0">Sem projeto</option>';foreach($wpdb->get_results("SELECT id,name FROM $pt ORDER BY id DESC") as $pr)echo '<option value="'.$pr->id.'" '.selected($e->project_id??absint($_GET['project_id']??0),$pr->id,false).'>'.esc_html($pr->name).'</option>';echo '</select></label><label>Título interno do contrato<input name="title" required value="'.esc_attr($title).'" placeholder="Ex.: Contrato - Site Institucional"></label><label>Valor (R$)<input type="number" step="0.01" name="value" value="'.esc_attr($e->value??'').'"></label><label>Status<select name="status">';foreach(['draft'=>'Rascunho','pending_signature'=>'Aguardando assinatura','sent'=>'Enviado','signed'=>'Assinado','cancelled'=>'Cancelado'] as $k=>$v)echo '<option value="'.$k.'" '.selected($e->status??'draft',$k,false).'>'.$v.'</option>';echo '</select></label></div>';
            echo '<div class="vfos-rich-editor"><div class="vfos-editor-head"><div><span class="vfos-kicker">CONTEÚDO</span><h3>Texto do contrato</h3></div><span>Negrito, itálico, sublinhado, títulos, listas, alinhamento e tamanho de fonte.</span></div>';$this->contract_editor($content);echo '</div>';
            echo '<div class="vfos-flow-builder"><div><span class="vfos-kicker">CONTINUIDADE</span><h3>Depois deste contrato</h3><p>Mesmo que o atendimento comece diretamente pelo contrato, o fluxo pode continuar normalmente.</p></div><div class="vfos-flow-options"><label><input type="checkbox" name="flow_create_project" value="1" '.checked($e->flow_create_project??0,1,false).'> Criar projeto quando o contrato for assinado</label><label><input type="checkbox" name="flow_create_financial" value="1" '.checked($e->flow_create_financial??0,1,false).'> Criar cobrança no financeiro quando assinado</label></div></div>';
            echo '<div class="vfos-contract-recurring"><div><span class="vfos-kicker">CONTRATO RECORRENTE</span><h3>Mensalidade automática pelo gateway</h3><p>Use para gestão de Instagram, manutenção, suporte e outros serviços contínuos. O cliente autoriza cartão ou Pix Automático uma vez e o Mercado Pago faz as próximas cobranças.</p></div><label class="vfos-switch-row"><input type="checkbox" name="contract_recurring_enabled" value="1" '.checked($contract_recurring?1:0,1,false).'> Este contrato possui cobrança recorrente</label><div class="vfos-form-grid"><label>Valor recorrente (R$)<input type="number" step="0.01" min="0" name="contract_recurring_amount" value="'.esc_attr($contract_recurring->amount??($e->value??'')).'"></label><label>Periodicidade<select name="contract_recurring_frequency">';foreach(['monthly'=>'Mensal','quarterly'=>'Trimestral','semiannual'=>'Semestral','annual'=>'Anual'] as $rk=>$rv)echo '<option value="'.$rk.'" '.selected($contract_recurring->frequency??'monthly',$rk,false).'>'.$rv.'</option>';echo '</select></label><label>Primeiro vencimento<input type="date" name="contract_recurring_next_due" value="'.esc_attr($contract_recurring->next_due_date??date('Y-m-d',strtotime('+1 month'))).'"></label><label>Primeira mensalidade<select name="contract_recurring_first_charge"><option value="now" '.selected($contract_recurring->first_charge_mode??'now','now',false).'>Cobrar na autorização</option><option value="due" '.selected($contract_recurring->first_charge_mode??'now','due',false).'>Cobrar só no primeiro vencimento</option></select></label><label>Forma permitida<select name="contract_recurring_method"><option value="choose" '.selected($contract_recurring->subscription_method??'choose','choose',false).'>Cliente escolhe cartão de crédito ou Pix Automático</option><option value="card" '.selected($contract_recurring->subscription_method??'choose','card',false).'>Somente cartão de crédito</option><option value="pix" '.selected($contract_recurring->subscription_method??'choose','pix',false).'>Somente Pix Automático</option></select></label></div>'.($contract_recurring&&$contract_recurring->public_token?'<div class="vfos-contract-recurring-link"><span>Link de autorização</span><a target="_blank" href="'.esc_url(VFOS_Recurring::url($contract_recurring->public_token)).'">Abrir assinatura</a></div>':'').'</div>';
            echo '<div class="vfos-save-as-model"><label><input type="checkbox" name="save_as_template" value="1"> Salvar este conteúdo também como um modelo reutilizável</label><input name="template_name" placeholder="Nome do novo modelo (ex.: Contrato de Site)"></div>';
            if($e&&$e->sign_external_id)echo '<div class="vfos-sign-link-box"><strong>VisionForge Sign: '.esc_html($e->sign_public_code?:'#'.$e->sign_external_id).'</strong><span>Status: '.esc_html($e->sign_status?:'—').'</span>'.($e->sign_admin_url?'<a class="button" target="_blank" href="'.esc_url($e->sign_admin_url).'">Configurar no Sign</a>':'').($e->sign_signed_url?'<a class="button button-primary" target="_blank" href="'.esc_url($e->sign_signed_url).'">Abrir PDF assinado</a>':'').'</div>';
            if($e){echo '<div class="vfos-flow-manual-actions"><span>Continuar fluxo manualmente:</span>';if(VFOS_Team::can_permission('projects.create')){$u=wp_nonce_url(admin_url('admin-post.php?action=vfos_flow_contract_project&id='.$e->id),'vfos_flow_contract_project');echo '<a class="button" href="'.esc_url($u).'">'.($e->project_id?'Abrir projeto':'Criar projeto').'</a>';}if(VFOS_Team::can_permission('financial.create')){$u=wp_nonce_url(admin_url('admin-post.php?action=vfos_flow_contract_financial&id='.$e->id),'vfos_flow_contract_financial');echo '<a class="button" href="'.esc_url($u).'">'.($e->converted_financial_id?'Abrir financeiro':'Criar cobrança').'</a>';}echo '</div>';}
            echo '<div class="vfos-form-actions"><button class="button button-primary vfos-btn">'.($e?'Salvar e atualizar PDF':'Criar contrato e gerar PDF').'</button>';
            if($e){$pdf=wp_nonce_url(admin_url('admin-post.php?action=vfos_contract_pdf&id='.$e->id),'vfos_contract_pdf');echo '<a class="button" target="_blank" href="'.esc_url($pdf).'">Visualizar PDF timbrado</a>';}
            echo '<a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-contracts')).'">Cancelar</a></div></form></div></div>';
        }elseif($tab==='templates'||$tab==='template_new'){
            if($tab==='template_new'){
                echo '<div class="vfos-panel vfos-contract-template-editor"><div class="vfos-panel-head"><div><span class="vfos-kicker">MODELO</span><h2>'.($tpl_edit?'Editar modelo':'Novo modelo de contrato').'</h2><p>O modelo só será usado quando você escolher aplicá-lo em um contrato.</p></div></div>';$this->form_start('vfos_save_contract_template');if($tpl_edit)echo '<input type="hidden" name="id" value="'.$tpl_edit->id.'">';echo '<div class="vfos-form-grid"><label>Nome do modelo<input name="name" required value="'.esc_attr($tpl_edit->name??'').'" placeholder="Ex.: Contrato de Criação de Site"></label><label>Status<select name="status"><option value="active" '.selected($tpl_edit->status??'active','active',false).'>Ativo</option><option value="inactive" '.selected($tpl_edit->status??'active','inactive',false).'>Inativo</option></select></label></div><label>Descrição <small>(opcional)</small><input name="description" value="'.esc_attr($tpl_edit->description??'').'" placeholder="Quando utilizar este modelo"></label><div class="vfos-rich-editor"><div class="vfos-editor-head"><div><span class="vfos-kicker">CONTEÚDO DO MODELO</span><h3>Texto reutilizável</h3></div></div>';$this->contract_editor($tpl_edit->content??'','vfos_contract_template_content','content');echo '</div><div class="vfos-form-actions"><button class="button button-primary vfos-btn">'.($tpl_edit?'Salvar modelo':'Criar modelo').'</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-contracts&tab=templates')).'">Cancelar</a></div></form></div>';
            }else{
                $search=$this->q('s');$status=sanitize_key($_GET['status']??'');$where=['1=1'];$args=[];if($search!==''){$where[]='(name LIKE %s OR description LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like);}if(in_array($status,['active','inactive'],true)){$where[]='status=%s';$args[]=$status;}$sql="SELECT * FROM $mt WHERE ".implode(' AND ',$where).' ORDER BY status DESC,name';$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
                echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">BIBLIOTECA</span><h2>Modelos de contrato</h2><p>Salve textos prontos sem obrigar o uso em novos contratos.</p></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-contracts&tab=template_new')).'">+ Novo modelo</a></div><form class="vfos-filters" method="get"><input type="hidden" name="page" value="vfos-contracts"><input type="hidden" name="tab" value="templates"><label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Nome ou descrição"></label><label>Status<select name="status"><option value="">Todos</option><option value="active" '.selected($status,'active',false).'>Ativos</option><option value="inactive" '.selected($status,'inactive',false).'>Inativos</option></select></label><div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Filtrar</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-contracts&tab=templates')).'">Limpar</a></div></form><div class="vfos-contract-template-grid">';if(!$rows)echo '<div class="vfos-empty">Nenhum modelo encontrado.</div>';foreach($rows as $r){$use=admin_url('admin.php?page=vfos-contracts&tab=new&template_id='.$r->id);$ed=admin_url('admin.php?page=vfos-contracts&tab=template_new&template_edit='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_contract_template&id='.$r->id),'vfos_delete_contract_template');echo '<article><div class="vfos-template-doc">DOC</div><span class="vfos-pill">'.($r->status==='active'?'Ativo':'Inativo').'</span><h3>'.esc_html($r->name).'</h3><p>'.esc_html($r->description?:'Modelo reutilizável de contrato.').'</p><small>'.esc_html(wp_trim_words(wp_strip_all_tags($r->content),18)).'</small><div class="vfos-team-actions"><a class="button button-primary vfos-btn" href="'.esc_url($use).'">Usar modelo</a><a class="button" href="'.esc_url($ed).'">Editar</a><a class="button vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir este modelo?\')">Excluir</a></div></article>';}echo '</div></div>';
            }
        }else{
            $search=$this->q('s');$status=sanitize_key($_GET['status']??'');$sign=sanitize_key($_GET['sign']??'');$client=absint($_GET['client']??0);$where=['1=1'];$args=[];if($search!==''){$where[]='(x.number LIKE %s OR x.title LIKE %s OR c.name LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like,$like);}if($status!==''){$where[]='x.status=%s';$args[]=$status;}if($client){$where[]='x.client_id=%d';$args[]=$client;}if($sign==='not_sent')$where[]="(x.sign_external_id='' OR x.sign_external_id IS NULL)";elseif($sign==='sent')$where[]="x.sign_external_id<>'' AND x.status<>'signed'";elseif($sign==='signed')$where[]="x.status='signed'";$sql="SELECT x.*,c.name client_name,p.name project_name FROM $tt x LEFT JOIN $ct c ON c.id=x.client_id LEFT JOIN $pt p ON p.id=x.project_id WHERE ".implode(' AND ',$where).' ORDER BY x.id DESC';$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISUALIZAÇÃO</span><h2>Contratos</h2></div>'.(VFOS_Team::can_permission('contracts.create')?'<a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-contracts&tab=new')).'">+ Novo contrato</a>':'').'</div>';$this->filter_start('vfos-contracts');echo '<label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Número, título ou cliente"></label><label>Cliente<select name="client">';$this->client_filter_select($client);echo '</select></label><label>Status<select name="status"><option value="">Todos</option>';foreach(['draft'=>'Rascunho','pending_signature'=>'Aguardando assinatura','sent'=>'Enviado','signed'=>'Assinado','cancelled'=>'Cancelado'] as $k=>$v)echo '<option value="'.$k.'" '.selected($status,$k,false).'>'.$v.'</option>';echo '</select></label><label>VisionForge Sign<select name="sign"><option value="">Todos</option><option value="not_sent" '.selected($sign,'not_sent',false).'>Não enviados</option><option value="sent" '.selected($sign,'sent',false).'>Em assinatura</option><option value="signed" '.selected($sign,'signed',false).'>Assinados</option></select></label>';$this->filter_end();
            echo '<div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Número</th><th>Cliente</th><th>Projeto</th><th>Status</th><th>Valor</th><th>Ações</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="6">Nenhum contrato encontrado.</td></tr>';foreach($rows as $r){$ed=admin_url('admin.php?page=vfos-contracts&tab=new&edit='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_contract&id='.$r->id),'vfos_delete_contract');$send=wp_nonce_url(admin_url('admin-post.php?action=vfos_send_sign&id='.$r->id),'vfos_send_sign');$sync=wp_nonce_url(admin_url('admin-post.php?action=vfos_sign_sync&id='.$r->id),'vfos_sign_sync');$invite=wp_nonce_url(admin_url('admin-post.php?action=vfos_sign_invite&id='.$r->id),'vfos_sign_invite');$pdf=wp_nonce_url(admin_url('admin-post.php?action=vfos_contract_pdf&id='.$r->id),'vfos_contract_pdf');echo '<tr><td><strong>'.esc_html($r->number).'</strong><small>'.esc_html($r->title).'</small></td><td>'.esc_html($r->client_name?:'—').'</td><td>'.esc_html($r->project_name?:'—').'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->status)).'</span>'.($r->sign_status?'<small>Sign: '.esc_html($r->sign_status).'</small>':'').'</td><td>R$ '.number_format((float)$r->value,2,',','.').'</td><td><a href="'.esc_url($ed).'">Editar</a> · <a target="_blank" href="'.esc_url($pdf).'">PDF timbrado</a>';if(!$r->sign_external_id)echo ' · <a href="'.esc_url($send).'">Criar no Sign</a>';else{if($r->sign_admin_url)echo ' · <a target="_blank" href="'.esc_url($r->sign_admin_url).'">Configurar Sign</a>';echo ' · <a href="'.esc_url($sync).'">Sincronizar</a> · <a href="'.esc_url($invite).'">Enviar convite</a>';if($r->sign_url)echo ' · <a target="_blank" href="'.esc_url($r->sign_url).'">Assinatura</a>';if($r->sign_signed_url)echo ' · <a target="_blank" href="'.esc_url($r->sign_signed_url).'">PDF assinado</a>';}echo ' · <a class="vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir contrato?\')">Excluir</a></td></tr>';}echo '</tbody></table></div></div>';
        }$this->end();
    }

    public function sign_page(){
        VFOS_Team::require_permission('sign.view');global $wpdb;$t=VFOS_DB::table('contracts');$c=VFOS_DB::table('clients');$rows=$wpdb->get_results("SELECT x.*,c.name client_name FROM $t x LEFT JOIN $c c ON c.id=x.client_id WHERE x.sign_external_id<>'' ORDER BY x.id DESC");$this->header('VisionForge Sign','Integração nativa entre o VisionForge OS e o VisionForge Sign.');
        echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">CONEXÃO</span><h2>'.(VFOS_Sign::local_available()?'Integração nativa ativa':'Integração local indisponível').'</h2></div><span class="vfos-status '.(VFOS_Sign::local_available()?'ok':'off').'">'.(VFOS_Sign::local_available()?'Conectado':'Desconectado').'</span></div><p>'.(VFOS_Sign::local_available()?'O VisionForge Sign foi detectado neste WordPress. Não é necessário configurar endpoint ou token: os plugins conversam diretamente.':'Ative o VisionForge Sign atualizado. O endpoint remoto continua disponível em Configurações como alternativa para instalações separadas.').'</p></div><div class="vfos-panel"><h2>Documentos vinculados</h2><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Contrato</th><th>Cliente</th><th>Código Sign</th><th>Status</th><th>Última atualização</th><th>Acesso</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="6">Nenhum documento conectado ao Sign.</td></tr>';foreach($rows as $r)echo '<tr><td><strong>'.esc_html($r->number).'</strong><small>'.esc_html($r->title).'</small></td><td>'.esc_html($r->client_name).'</td><td>'.esc_html($r->sign_public_code?:$r->sign_external_id).'</td><td><span class="vfos-pill">'.esc_html($r->sign_status?:'—').'</span></td><td>'.($r->sign_updated_at?date_i18n('d/m/Y H:i',strtotime($r->sign_updated_at)):'—').'</td><td>'.($r->sign_admin_url?'<a target="_blank" href="'.esc_url($r->sign_admin_url).'">Abrir Sign</a>':'').($r->sign_signed_url?' · <a target="_blank" href="'.esc_url($r->sign_signed_url).'">PDF assinado</a>':'').'</td></tr>';echo '</tbody></table></div></div>';$this->end();
    }
    private static function notification_thread_html($notification,$viewer_is_sender=false){
        global $wpdb;$nid=absint($notification->id);$replies=$wpdb->get_results($wpdb->prepare("SELECT r.*,u.display_name FROM ".VFOS_DB::table('notification_replies')." r LEFT JOIN {$wpdb->users} u ON u.ID=r.user_id WHERE r.notification_id=%d ORDER BY r.id ASC",$nid));
        ob_start();
        echo '<div class="vfos-notification-thread">';
        if($replies){
            echo '<div class="vfos-thread-messages">';
            foreach($replies as $reply){
                $mine=(int)$reply->user_id===get_current_user_id();
                echo '<div class="vfos-thread-message '.($mine?'is-mine':'').'"><div><strong>'.esc_html($reply->display_name?:'Usuário').'</strong><small>'.esc_html(date_i18n('d/m/Y H:i',strtotime($reply->created_at))).'</small></div><p>'.nl2br(esc_html($reply->message)).'</p></div>';
            }
            echo '</div>';
        }
        if(!empty($notification->allow_replies)){
            echo '<form class="vfos-thread-reply-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_reply_notification"><input type="hidden" name="notification_id" value="'.$nid.'">';wp_nonce_field('vfos_reply_notification_'.$nid);
            echo '<label>Responder<textarea name="message" required maxlength="2000" rows="3" placeholder="'.($viewer_is_sender?'Responder para este destinatário...':'Escreva sua resposta...').'"></textarea></label><button class="button button-primary vfos-btn">Enviar resposta</button></form>';
        }elseif($viewer_is_sender){
            echo '<div class="vfos-replies-disabled"><span>Respostas desativadas neste envio.</span></div>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    public function notifications(){
        VFOS_Team::require_permission('notifications.view');global $wpdb;$uid=get_current_user_id();
        $tab=sanitize_key($_GET['tab']??'inbox');$allowed=['inbox','activity','settings'];
        if(VFOS_Team::can_permission('notifications.send')){$allowed[]='send';$allowed[]='sent';}
        if(!in_array($tab,$allowed,true))$tab='inbox';

        $this->header('Notificações','Avisos, respostas e comunicação interna da equipe.');
        echo '<nav class="vfos-tabs">';
        $this->module_tab('vfos-notifications','inbox','Minha central',$tab);
        if(VFOS_Team::can_permission('notifications.send'))$this->module_tab('vfos-notifications','sent','Enviadas',$tab);
        $this->module_tab('vfos-notifications','activity','Atividades',$tab);
        $this->module_tab('vfos-notifications','settings','Preferências',$tab);
        if(VFOS_Team::can_permission('notifications.send'))$this->module_tab('vfos-notifications','send','Enviar notificação',$tab);
        echo '</nav>';

        if($tab==='send'){
            VFOS_Team::require_permission('notifications.send');
            $team=VFOS_DB::table('team');$gm=VFOS_DB::table('team_group_members');$groups_table=VFOS_DB::table('team_groups');
            $personal_scope=VFOS_Team::permission_scope_groups('notifications.send');$general_scope=VFOS_Team::permission_scope_groups('notifications.send_general');
            $member_where="tm.status='active'";if($personal_scope)$member_where.=" AND tm.user_id IN (SELECT user_id FROM $gm WHERE group_id IN (".implode(',',array_map('absint',$personal_scope))."))";
            $members=$wpdb->get_results("SELECT tm.user_id,u.display_name,u.user_email,tm.job_title,tm.department FROM $team tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE $member_where ORDER BY u.display_name");
            $can_general=VFOS_Team::can_permission('notifications.send_general');$general_groups=[];
            if($can_general){$ids=$general_scope?:array_map(fn($g)=>(int)$g->id,VFOS_Team::groups(true));if($ids)$general_groups=$wpdb->get_results("SELECT * FROM $groups_table WHERE status='active' AND id IN (".implode(',',array_map('absint',$ids)).") ORDER BY name");}
            echo '<div class="vfos-grid vfos-grid-2 vfos-notification-send-grid"><div class="vfos-panel vfos-notification-composer"><div class="vfos-panel-head"><div><span class="vfos-kicker">COMUNICAÇÃO INTERNA</span><h2>Nova notificação</h2><p>Escolha o destino e defina se os destinatários poderão responder.</p></div></div>';
            $this->form_start('vfos_send_notification');
            echo '<div class="vfos-notification-scope"><label><input type="radio" name="scope" value="personal" checked><span><strong>Pessoal</strong><small>Uma pessoa dentro do seu escopo</small></span></label>';
            if($can_general)echo '<label><input type="radio" name="scope" value="general"><span><strong>Grupo</strong><small>Todos de um grupo autorizado</small></span></label>';
            echo '</div><div class="vfos-form-grid"><label class="vfos-recipient-field">Destinatário<select name="recipient_user_id"><option value="0">Selecione o usuário</option>';
            foreach($members as $m)echo '<option value="'.$m->user_id.'">'.esc_html($m->display_name.($m->job_title?' — '.$m->job_title:'')).'</option>';
            echo '</select></label>';
            if($can_general){echo '<label class="vfos-group-recipient-field" style="display:none">Grupo destinatário<select name="recipient_group_id"><option value="0">Selecione o grupo</option>';if(!$general_scope)echo '<option value="-1">Toda a equipe</option>';foreach($general_groups as $g)echo '<option value="'.$g->id.'">'.esc_html($g->name).'</option>';echo '</select></label>';}
            echo '<label>Tipo<select name="notification_type"><option value="info">Informação</option><option value="important">Importante</option><option value="reminder">Lembrete</option><option value="deadline">Prazo</option><option value="meeting">Reunião</option><option value="announcement">Comunicado</option></select></label></div>';
            echo '<label>Título<input name="title" maxlength="190" required placeholder="Ex.: Fechamento financeiro hoje às 17h"></label><label class="vfos-notification-message-label">Mensagem<div class="vfos-mention-tip"><strong>@ Citar item</strong><span>Digite @ no texto para pesquisar e vincular projeto, cliente, tarefa, orçamento, contrato e mais.</span></div><div class="vfos-mention-editor"><textarea id="vfos-notification-message" name="message" rows="6" required maxlength="2000" placeholder="Ex.: Fulano, por favor confira o @Projeto Site Cliente..."></textarea><div id="vfos-mention-results" class="vfos-mention-results"></div></div></label>';
            echo '<div class="vfos-reply-choice"><span>Permitir respostas?</span><label><input type="radio" name="allow_replies" value="1" checked><strong>Sim</strong><small>O destinatário poderá responder dentro da notificação.</small></label><label><input type="radio" name="allow_replies" value="0"><strong>Não</strong><small>A notificação será apenas informativa.</small></label></div>';
            echo '<div class="vfos-notification-linker is-prominent"><div class="vfos-linker-head"><div><span class="vfos-kicker">ITEM CITADO</span><h3>Vincular algo do VisionForge OS</h3><p>Use o @ na mensagem ou pesquise manualmente aqui. O destinatário poderá abrir o item com um clique.</p></div><span class="vfos-linker-at">@</span></div><div class="vfos-resource-picker"><input id="vfos-notification-resource-search" autocomplete="off" placeholder="Pesquisar projeto, cliente, tarefa, orçamento, contrato..."><div id="vfos-notification-resource-results"></div></div><div id="vfos-notification-resource-selected" class="vfos-resource-selected" style="display:none"></div><input type="hidden" name="entity_type" id="vfos-notification-entity-type"><input type="hidden" name="entity_id" id="vfos-notification-entity-id"><input type="hidden" name="url" id="vfos-notification-url"><input type="hidden" name="context_label" id="vfos-notification-context-label"></div>';
            echo '<div class="vfos-notification-send-note"><strong>Privacidade das respostas</strong><p>Em envios para grupo, cada integrante responde em uma conversa privada com o remetente. Os demais integrantes não veem essas respostas.</p></div>';
            echo '<button class="button button-primary vfos-btn">Enviar notificação</button></form></div>';
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">SEU ESCOPO</span><h2>Destinatários disponíveis</h2></div><span class="vfos-pill">'.count($members).' pessoa(s)</span></div><div class="vfos-notification-members">';
            foreach($members as $m){$ugs=VFOS_Team::user_groups($m->user_id);$names=[];foreach(VFOS_Team::groups(true) as $g)if(in_array((int)$g->id,$ugs,true))$names[]=$g->name;echo '<article><span class="vfos-notification-member-avatar">'.esc_html(strtoupper(mb_substr($m->display_name,0,2))).'</span><div><strong>'.esc_html($m->display_name).'</strong><small>'.esc_html(($m->job_title?:'Equipe VisionForge').($names?' • '.implode(', ',$names):'')).'</small></div></article>';}
            if(!$members)echo '<div class="vfos-empty">Nenhum integrante dentro do seu escopo.</div>';
            echo '</div></div></div>';

        }elseif($tab==='sent'){
            VFOS_Team::require_permission('notifications.send');$nt=VFOS_DB::table('notifications');$rt=VFOS_DB::table('notification_replies');
            $rows=$wpdb->get_results($wpdb->prepare("SELECT n.*,u.display_name recipient_name,(SELECT COUNT(*) FROM $rt r WHERE r.notification_id=n.id) reply_count FROM $nt n LEFT JOIN {$wpdb->users} u ON u.ID=n.user_id WHERE n.sender_user_id=%d AND n.entity_type<>'notification_reply' ORDER BY n.created_at DESC,n.id DESC LIMIT 250",$uid));
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">ENVIADAS</span><h2>Notificações que você enviou</h2><p>Veja destinatários, respostas e apague envios quando necessário.</p></div></div><div class="vfos-sent-notifications">';
            if(!$rows)echo '<div class="vfos-empty">Você ainda não enviou notificações.</div>';
            foreach($rows as $r){
                $delete=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_sent_notification&id='.$r->id),'vfos_delete_sent_notification_'.$r->id);
                $delete_batch=$r->batch_id?wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_sent_notification&id='.$r->id.'&batch=1'),'vfos_delete_sent_notification_'.$r->id):'';
                echo '<article id="vfos-notification-'.$r->id.'" class="vfos-sent-card"><div class="vfos-sent-card-head"><div><span class="vfos-kicker">'.esc_html(strtoupper($r->type)).'</span><h3>'.esc_html($r->title).'</h3><p>'.nl2br(esc_html($r->message)).'</p></div><div class="vfos-sent-status"><span class="vfos-pill">'.($r->allow_replies?'Respostas permitidas':'Somente leitura').'</span><small>'.esc_html(date_i18n('d/m/Y H:i',strtotime($r->created_at))).'</small></div></div>';
                echo '<div class="vfos-sent-meta"><span>Destinatário: <strong>'.esc_html($r->recipient_name?:'Usuário').'</strong></span><span>Respostas: <strong>'.(int)$r->reply_count.'</strong></span><span>'.($r->is_read?'Visualizada':'Ainda não lida').'</span></div>'.($r->context_label?'<a class="vfos-notification-context-chip" href="'.esc_url($r->url?:'#').'"><span>↗</span><strong>'.esc_html($r->context_label).'</strong><small>Item citado</small></a>':'');
                echo self::notification_thread_html($r,true);
                if(VFOS_Team::can_permission('notifications.delete_sent')){
                    echo '<div class="vfos-sent-delete-actions"><a class="button vfos-danger" href="'.esc_url($delete).'" onclick="return confirm(\'Apagar esta notificação do destinatário e todo o histórico de respostas?\')">Apagar deste destinatário</a>';
                    if($delete_batch)echo '<a class="button vfos-danger" href="'.esc_url($delete_batch).'" onclick="return confirm(\'Apagar este envio de todos os destinatários e todas as respostas?\')">Apagar envio completo</a>';
                    echo '</div>';
                }
                echo '</article>';
            }
            echo '</div></div>';

        }elseif($tab==='settings'){
            $email_enabled=VFOS_Notifications::email_enabled($uid);
            echo '<div class="vfos-grid vfos-grid-2"><div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">PREFERÊNCIAS PESSOAIS</span><h2>Como você quer receber notificações?</h2><p>Estas preferências são individuais e cada integrante decide se também quer receber por e-mail.</p></div></div>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_notification_preferences">';wp_nonce_field('vfos_save_notification_preferences');
            echo '<label class="vfos-notification-email-toggle"><input type="checkbox" name="email_enabled" value="1" '.checked($email_enabled,true,false).'><span><strong>Receber notificações do VisionForge OS por e-mail</strong><small>Quando ativado, avisos, tarefas, menções e notificações internas também chegam ao e-mail da sua conta.</small></span></label>';
            echo '<button class="button button-primary vfos-btn">Salvar minhas preferências</button></form></div><div class="vfos-panel"><span class="vfos-kicker">E-MAIL ATUAL</span><h2>'.esc_html(wp_get_current_user()->user_email).'</h2><p>O VisionForge OS utiliza o e-mail da sua conta de usuário. Para alterar o endereço, edite seus dados de perfil/equipe conforme suas permissões.</p><div class="vfos-notification-send-note"><strong>Importante</strong><p>Desativar o e-mail não remove as notificações internas. Elas continuam aparecendo normalmente na Central de Notificações.</p></div></div></div>';

        }elseif($tab==='activity'){
            $t=VFOS_DB::table('activity_feed');$rows=$wpdb->get_results($wpdb->prepare("SELECT a.*,u.display_name actor_name FROM $t a LEFT JOIN {$wpdb->users} u ON u.ID=a.actor_user_id WHERE a.user_id IN (0,%d) ORDER BY a.created_at DESC LIMIT 100",$uid));
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">HISTÓRICO</span><h2>Central de atividades</h2></div></div><div class="vfos-activity-feed">';
            if(!$rows)echo '<div class="vfos-empty">As próximas ações importantes aparecerão aqui.</div>';
            foreach($rows as $r)echo '<article><div class="vfos-activity-dot"></div><div><strong>'.esc_html($r->title).'</strong><p>'.esc_html($r->description).'</p><small>'.esc_html($r->actor_name?:'VisionForge OS').' • '.esc_html(date_i18n('d/m/Y H:i',strtotime($r->created_at))).'</small></div>'.($r->url?'<a class="button" href="'.esc_url($r->url).'">Abrir</a>':'').'</article>';
            echo '</div></div>';

        }else{
            $type=sanitize_key($_GET['type']??'');$state=sanitize_key($_GET['state']??'');$where=['n.user_id=%d'];$args=[$uid];
            if($type){$where[]='n.type=%s';$args[]=$type;}if($state==='unread')$where[]='n.is_read=0';elseif($state==='read')$where[]='n.is_read=1';
            $t=VFOS_DB::table('notifications');$rt=VFOS_DB::table('notification_replies');
            $sql="SELECT n.*,u.display_name sender_name,(SELECT COUNT(*) FROM $rt r WHERE r.notification_id=n.id) reply_count FROM $t n LEFT JOIN {$wpdb->users} u ON u.ID=n.sender_user_id WHERE ".implode(' AND ',$where)." ORDER BY n.is_read ASC,n.created_at DESC LIMIT 150";
            $rows=$wpdb->get_results($wpdb->prepare($sql,$args));$unread=VFOS_Notifications::unread_count($uid);
            echo '<div class="vfos-stats"><div class="vfos-stat"><span>Não lidas</span><strong>'.$unread.'</strong></div><div class="vfos-stat"><span>Hoje</span><strong>'.(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE user_id=%d AND DATE(created_at)=CURDATE()",$uid)).'</strong></div><div class="vfos-stat"><span>Com respostas</span><strong>'.(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT n.id) FROM $t n JOIN $rt r ON r.notification_id=n.id WHERE n.user_id=%d",$uid)).'</strong></div></div>';
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">MINHA CENTRAL</span><h2>Atenção necessária</h2></div>'.($unread&&VFOS_Team::can_permission('notifications.manage')?'<a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=vfos_mark_all_notifications'),'vfos_mark_all_notifications')).'">Marcar todas como lidas</a>':'').'</div><form class="vfos-filters" method="get"><input type="hidden" name="page" value="vfos-notifications"><input type="hidden" name="tab" value="inbox"><label>Tipo<select name="type"><option value="">Todos</option>';foreach(['deadline'=>'Prazos','calendar'=>'Agenda','task'=>'Tarefas','project'=>'Projetos','quote'=>'Propostas','contract'=>'Contratos','payment'=>'Financeiro','comment'=>'Comentários','approval'=>'Aprovações','important'=>'Importante','reminder'=>'Lembrete','meeting'=>'Reunião','announcement'=>'Comunicado','info'=>'Outros'] as $k=>$v)echo '<option value="'.$k.'" '.selected($type,$k,false).'>'.$v.'</option>';echo '</select></label><label>Leitura<select name="state"><option value="">Todas</option><option value="unread" '.selected($state,'unread',false).'>Não lidas</option><option value="read" '.selected($state,'read',false).'>Lidas</option></select></label><div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Filtrar</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-notifications')).'">Limpar</a></div></form><div class="vfos-notification-center">';
            if(!$rows)echo '<div class="vfos-empty">Nenhuma notificação encontrada.</div>';
            foreach($rows as $r){
                $mark=wp_nonce_url(admin_url('admin-post.php?action=vfos_mark_notification&id='.$r->id),'vfos_mark_notification');$sender=$r->sender_user_id?($r->sender_name?:'Equipe VisionForge'):'VisionForge OS';$scope=in_array($r->delivery_scope,['general','group'],true)?' • Envio em grupo':'';
                echo '<article id="vfos-notification-'.$r->id.'" class="'.(!$r->is_read?'is-unread':'').'"><div class="vfos-notification-icon is-'.esc_attr($r->type).'"></div><div><div class="vfos-notification-title"><strong>'.esc_html($r->title).'</strong>'.(!$r->is_read?'<span>Novo</span>':'').($r->allow_replies?'<span class="is-replyable">Aceita resposta</span>':'').'</div><p>'.nl2br(esc_html($r->message)).'</p>'.($r->context_label?'<a class="vfos-notification-context-chip" href="'.esc_url($r->url?:'#').'"><span>↗</span><strong>'.esc_html($r->context_label).'</strong><small>Abrir item citado</small></a>':'').'<small>Enviado por '.esc_html($sender).$scope.' • '.esc_html(date_i18n('d/m/Y H:i',strtotime($r->created_at))).($r->reply_count?' • '.(int)$r->reply_count.' resposta(s)':'').'</small>';
                echo self::notification_thread_html($r,false);
                echo '</div><div class="vfos-notification-actions">'.($r->url?'<a class="button button-primary vfos-btn" href="'.esc_url($r->url).'">Abrir</a>':'').(!$r->is_read&&VFOS_Team::can_permission('notifications.manage')?'<a class="button" href="'.esc_url($mark).'">Marcar como lida</a>':'').'</div></article>';
            }
            echo '</div></div>';
        }$this->end();
    }

    public function send_notification(){
        check_admin_referer('vfos_send_notification');VFOS_Team::require_permission('notifications.send');global $wpdb;
        $scope=sanitize_key($_POST['scope']??'personal');if(!in_array($scope,['personal','general'],true))$scope='personal';
        if($scope==='general'&&!VFOS_Team::can_permission('notifications.send_general'))wp_die('Você não possui permissão para enviar notificações em massa.');
        $title=sanitize_text_field(wp_unslash($_POST['title']??''));$message=sanitize_textarea_field(wp_unslash($_POST['message']??''));$type=sanitize_key($_POST['notification_type']??'info');$url=esc_url_raw(wp_unslash($_POST['url']??''));$context=sanitize_text_field(wp_unslash($_POST['context_label']??''));$entity_type=sanitize_key($_POST['entity_type']??'notification_message');$entity_id=absint($_POST['entity_id']??0);$allow_replies=!empty($_POST['allow_replies'])?1:0;
        if(!$title||!$message)$this->go('vfos-notifications','Informe título e mensagem.');
        $valid_types=['info','important','reminder','deadline','meeting','announcement'];if(!in_array($type,$valid_types,true))$type='info';
        $sender=get_current_user_id();$recipients=[];$label='';
        if($scope==='general'){
            $gid=(int)($_POST['recipient_group_id']??0);
            if($gid===-1){
                if(VFOS_Team::permission_is_scoped('notifications.send_general'))wp_die('Seu usuário só pode enviar notificações gerais para grupos específicos.');
                $recipients=array_map('absint',$wpdb->get_col("SELECT user_id FROM ".VFOS_DB::table('team')." WHERE status='active'"));$label='Toda a equipe';
            }else{
                if(!$gid||!VFOS_Team::can_target_group('notifications.send_general',$gid))wp_die('Você não possui permissão para enviar notificações para este grupo.');
                $group=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('team_groups')." WHERE id=%d AND status='active'",$gid));if(!$group)$this->go('vfos-notifications','Grupo não encontrado.');
                $recipients=VFOS_Team::group_members($gid);$active=array_map('absint',$wpdb->get_col("SELECT user_id FROM ".VFOS_DB::table('team')." WHERE status='active'"));$recipients=array_values(array_intersect($recipients,$active));$label='Grupo '.$group->name;
            }
            $recipients=array_values(array_unique(array_filter($recipients)));if(!$recipients)$this->go('vfos-notifications','Não há integrantes ativos neste destino.');
        }else{
            $recipient=absint($_POST['recipient_user_id']??0);$active=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('team')." WHERE user_id=%d AND status='active'",$recipient));
            if(!$recipient||!$active)$this->go('vfos-notifications','Selecione um integrante ativo da equipe.');
            if(!VFOS_Team::user_in_scope('notifications.send',$recipient))wp_die('Você só pode enviar notificações individuais para os grupos autorizados.');
            $recipients=[$recipient];$u=get_userdata($recipient);$label=$u?$u->display_name:'Usuário';
        }
        $batch_id=wp_generate_uuid4();$sent=0;$failed=[];
        foreach($recipients as $rid){
            if(VFOS_Notifications::notify($rid,$type,$title,$message,'notifications',$entity_type?:'notification_message',$entity_id,$url,$sender,$scope==='general'?'group':'personal',$batch_id,$allow_replies,$context))$sent++;else$failed[]=$rid;
        }
        if($sent===0){
            $db_error=$wpdb->last_error?:'O banco recusou a gravação sem retornar uma mensagem detalhada.';
            VFOS_DB::log('notification_send_error','notification',0,$db_error,null,['recipients'=>$recipients,'scope'=>$scope,'title'=>$title],$title);
            $this->go('vfos-notifications','Nenhuma notificação foi enviada. Erro do banco: '.$db_error);
        }
        VFOS_DB::log('send_notification','notification',0,'Destino: '.$label.' | '.$title.' | respostas='.($allow_replies?'sim':'não').($context?' | '.$context:''),null,['scope'=>$scope,'recipients'=>$recipients,'title'=>$title,'type'=>$type,'allow_replies'=>$allow_replies,'batch_id'=>$batch_id],$title);
        VFOS_Notifications::activity('notification_sent','Notificação enviada',$title.' • '.$label,'notifications','notification',0,admin_url('admin.php?page=vfos-notifications&tab=sent'),$sender);
        wp_safe_redirect(admin_url('admin.php?page=vfos-notifications&tab=sent&vfos_msg='.rawurlencode($sent.' notificação(ões) enviada(s) com sucesso para '.$label.($allow_replies?' • Respostas permitidas.':' • Somente leitura.').($failed?' • '.count($failed).' falharam.':''))));exit;
    }

    public function save_notification_preferences(){
        check_admin_referer('vfos_save_notification_preferences');VFOS_Team::require_permission('notifications.view');
        $enabled=!empty($_POST['email_enabled'])?1:0;
        update_user_meta(get_current_user_id(),'_vfos_notification_email_enabled',$enabled);
        VFOS_DB::log('notification_preferences','notification',0,'Preferência de e-mail: '.($enabled?'ativada':'desativada'),null,['email_enabled'=>$enabled],'Preferências de notificações');
        wp_safe_redirect(admin_url('admin.php?page=vfos-notifications&tab=settings&vfos_msg='.rawurlencode('Preferências salvas com sucesso.')));exit;
    }

    public function reply_notification(){
        global $wpdb;$id=absint($_POST['notification_id']??0);check_admin_referer('vfos_reply_notification_'.$id);VFOS_Team::require_permission('notifications.view');$uid=get_current_user_id();
        $nt=VFOS_DB::table('notifications');$n=$wpdb->get_row($wpdb->prepare("SELECT * FROM $nt WHERE id=%d",$id));if(!$n)wp_die('Notificação não encontrada.');
        if(empty($n->allow_replies))wp_die('Esta notificação não aceita respostas.');
        $is_recipient=(int)$n->user_id===$uid;$is_sender=(int)$n->sender_user_id===$uid;
        if(!$is_recipient&&!$is_sender)wp_die('Você não participa desta conversa.');
        $message=sanitize_textarea_field(wp_unslash($_POST['message']??''));if(!$message)wp_die('Digite uma resposta.');
        $rt=VFOS_DB::table('notification_replies');$wpdb->insert($rt,['notification_id'=>$id,'user_id'=>$uid,'message'=>$message,'created_at'=>current_time('mysql')]);$reply_id=$wpdb->insert_id;
        if(!$reply_id)wp_die('Não foi possível salvar a resposta: '.esc_html($wpdb->last_error));
        $other=$is_recipient?(int)$n->sender_user_id:(int)$n->user_id;
        if($other){
            $author=wp_get_current_user();$target_tab=$is_recipient?'sent':'inbox';$focus=admin_url('admin.php?page=vfos-notifications&tab='.$target_tab.'&focus='.$id.'#vfos-notification-'.$id);
            VFOS_Notifications::notify($other,'comment','Nova resposta: '.$n->title,($author->display_name?:'Um usuário').' respondeu: '.wp_trim_words($message,24),'notifications','notification_reply',$id,$focus,$uid,'personal','',0);
        }
        VFOS_DB::log('reply_notification','notification',$id,'Resposta enviada por '.$uid,null,['reply_id'=>$reply_id,'message'=>$message],$n->title);
        wp_safe_redirect(admin_url('admin.php?page=vfos-notifications&tab='.($is_sender?'sent':'inbox').'&focus='.$id.'&vfos_msg='.rawurlencode('Resposta enviada com sucesso.').'#vfos-notification-'.$id));exit;
    }

    public function delete_sent_notification(){
        global $wpdb;$id=absint($_GET['id']??0);check_admin_referer('vfos_delete_sent_notification_'.$id);VFOS_Team::require_permission('notifications.delete_sent');$uid=get_current_user_id();
        $nt=VFOS_DB::table('notifications');$rt=VFOS_DB::table('notification_replies');$n=$wpdb->get_row($wpdb->prepare("SELECT * FROM $nt WHERE id=%d AND sender_user_id=%d",$id,$uid));if(!$n)wp_die('Notificação enviada não encontrada ou você não é o remetente.');
        $delete_batch=!empty($_GET['batch'])&&!empty($n->batch_id);$ids=[];
        if($delete_batch)$ids=array_map('absint',$wpdb->get_col($wpdb->prepare("SELECT id FROM $nt WHERE sender_user_id=%d AND batch_id=%s",$uid,$n->batch_id)));
        else $ids=[$id];
        $ids=array_values(array_filter($ids));if(!$ids)wp_die('Nenhuma notificação encontrada para exclusão.');
        $before=['title'=>$n->title,'batch_id'=>$n->batch_id,'ids'=>$ids,'recipients'=>array_map('absint',$wpdb->get_col("SELECT user_id FROM $nt WHERE id IN (".implode(',',$ids).")"))];
        $wpdb->query("DELETE FROM $rt WHERE notification_id IN (".implode(',',$ids).")");
        $wpdb->query("DELETE FROM $nt WHERE entity_type='notification_reply' AND entity_id IN (".implode(',',$ids).")");
        $deleted=$wpdb->query("DELETE FROM $nt WHERE id IN (".implode(',',$ids).") AND sender_user_id=".absint($uid));
        VFOS_DB::log('delete_sent_notification','notification',$id,($delete_batch?'Envio completo apagado':'Notificação apagada').' | registros='.(int)$deleted,$before,null,$n->title);
        wp_safe_redirect(admin_url('admin.php?page=vfos-notifications&tab=sent&vfos_msg='.rawurlencode(($delete_batch?'Envio completo':'Notificação').' apagado com sucesso.')));exit;
    }

    public function mark_notification(){
        VFOS_Team::require_permission('notifications.manage');check_admin_referer('vfos_mark_notification');global $wpdb;$id=absint($_GET['id']??0);$wpdb->update(VFOS_DB::table('notifications'),['is_read'=>1,'read_at'=>current_time('mysql')],['id'=>$id,'user_id'=>get_current_user_id()]);wp_safe_redirect(admin_url('admin.php?page=vfos-notifications'));exit;
    }
    public function mark_all_notifications(){
        VFOS_Team::require_permission('notifications.manage');check_admin_referer('vfos_mark_all_notifications');global $wpdb;$wpdb->query($wpdb->prepare("UPDATE ".VFOS_DB::table('notifications')." SET is_read=1,read_at=%s WHERE user_id=%d AND is_read=0",current_time('mysql'),get_current_user_id()));wp_safe_redirect(admin_url('admin.php?page=vfos-notifications'));exit;
    }


    public function audit(){
        VFOS_Team::require_permission('audit.view');global $wpdb;$t=VFOS_DB::table('activity_logs');$users=$wpdb->get_results("SELECT ID,display_name FROM {$wpdb->users} ORDER BY display_name");
        $user=absint($_GET['user_id']??0);$type=sanitize_key($_GET['object_type']??'');$action=sanitize_text_field($_GET['audit_action']??'');$from=$this->date($_GET['from']??'');$to=$this->date($_GET['to']??'');$search=$this->q('s');
        $where=['1=1'];$args=[];if($user){$where[]='l.user_id=%d';$args[]=$user;}if($type){$where[]='l.object_type=%s';$args[]=$type;}if($action){$where[]='l.action=%s';$args[]=$action;}if($from){$where[]='DATE(l.created_at)>=%s';$args[]=$from;}if($to){$where[]='DATE(l.created_at)<=%s';$args[]=$to;}if($search){$like='%'.$wpdb->esc_like($search).'%';$where[]='(l.action_label LIKE %s OR l.object_label LIKE %s OR l.details LIKE %s OR u.display_name LIKE %s)';array_push($args,$like,$like,$like,$like);}
        $sql="SELECT l.*,u.display_name,u.user_email FROM $t l LEFT JOIN {$wpdb->users} u ON u.ID=l.user_id WHERE ".implode(' AND ',$where)." ORDER BY l.id DESC LIMIT 500";$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
        $actions=$wpdb->get_results("SELECT action,MAX(action_label) label FROM $t GROUP BY action ORDER BY label");$types=$wpdb->get_col("SELECT DISTINCT object_type FROM $t WHERE object_type<>'' ORDER BY object_type");
        $this->header('Auditoria','Histórico completo de quem fez o quê dentro do VisionForge OS.');
        echo '<div class="vfos-stats"><div class="vfos-stat"><span>Registros exibidos</span><strong>'.count($rows).'</strong></div><div class="vfos-stat"><span>Usuários</span><strong>'.count($users).'</strong></div><div class="vfos-stat"><span>Retenção</span><strong>Permanente</strong></div></div>';
        echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">TRILHA DE AUDITORIA</span><h2>Ações dos usuários</h2><p>Exclusões continuam registradas mesmo depois que o item deixa de existir.</p></div></div><form class="vfos-filters" method="get"><input type="hidden" name="page" value="vfos-audit"><label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Usuário, cliente, ação ou detalhe"></label><label>Usuário<select name="user_id"><option value="0">Todos</option>';foreach($users as $u)echo '<option value="'.$u->ID.'" '.selected($user,$u->ID,false).'>'.esc_html($u->display_name).'</option>';echo '</select></label><label>Área<select name="object_type"><option value="">Todas</option>';foreach($types as $x)echo '<option value="'.esc_attr($x).'" '.selected($type,$x,false).'>'.esc_html(ucfirst($x)).'</option>';echo '</select></label><label>Ação<select name="audit_action"><option value="">Todas</option>';foreach($actions as $a)echo '<option value="'.esc_attr($a->action).'" '.selected($action,$a->action,false).'>'.esc_html($a->label?:$a->action).'</option>';echo '</select></label><label>De<input type="date" name="from" value="'.esc_attr($from).'"></label><label>Até<input type="date" name="to" value="'.esc_attr($to).'"></label><div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Filtrar</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-audit')).'">Limpar</a></div></form>';
        echo '<div class="vfos-audit-list">';if(!$rows)echo '<div class="vfos-empty">Nenhum registro encontrado.</div>';foreach($rows as $r){$before=$r->before_data?json_decode($r->before_data,true):null;$after=$r->after_data?json_decode($r->after_data,true):null;$diff=[];if(is_array($before)&&is_array($after)){foreach($after as $k=>$v){if(in_array($k,['updated_at','updated_by'],true))continue;$old=$before[$k]??null;if((string)$old!==(string)$v)$diff[]=$k;}}echo '<article class="vfos-audit-row"><div class="vfos-audit-avatar">'.esc_html(strtoupper(mb_substr($r->display_name?:'S',0,2))).'</div><div><div class="vfos-audit-title"><strong>'.esc_html($r->display_name?:'Sistema').'</strong> <span>'.esc_html(mb_strtolower($r->action_label?:$r->action)).'</span>'.($r->object_label?' <b>'.esc_html($r->object_label).'</b>':'').'</div><p>'.esc_html($r->details?:'Sem observações adicionais.').'</p><div class="vfos-audit-meta"><span>'.esc_html(date_i18n('d/m/Y H:i:s',strtotime($r->created_at))).'</span><span>IP: '.esc_html($r->ip_address?:'—').'</span>'.($diff?'<span>Campos alterados: '.esc_html(implode(', ',$diff)).'</span>':'').'</div></div><span class="vfos-pill">'.esc_html($r->object_type?:'sistema').'</span></article>';}echo '</div></div>';
        $this->end();
    }

    public function team(){
        VFOS_Team::require_module('team');global $wpdb;
        $table=VFOS_DB::table('team');$edit=absint($_GET['edit']??0);$tab=$edit?'new':sanitize_key($_GET['tab']??'list');
        if(!in_array($tab,['list','new','productivity','groups'],true))$tab='list';
        $profile=$edit?$wpdb->get_row($wpdb->prepare("SELECT tm.*,u.display_name,u.user_email,u.user_login FROM $table tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE tm.id=%d",$edit)):null;
        $self_edit_exception=$profile&&((int)$profile->user_id===get_current_user_id())&&VFOS_Team::self_permission_edit_enabled($profile->user_id);
        if($profile&&!$self_edit_exception&&!VFOS_Team::user_in_scope('team.edit',$profile->user_id))wp_die('Este membro está fora dos grupos que você pode editar.');
        $this->header('Equipe','Pessoas, acessos, responsabilidades e capacidade operacional da VisionForge.');
        echo '<nav class="vfos-tabs">';$this->module_tab('vfos-team','list','Visualização',$tab);if(VFOS_Team::can_permission('team.create')||($edit&&(VFOS_Team::can_permission('team.edit')||$self_edit_exception)))$this->module_tab('vfos-team','new',$edit?'Editar membro':'Novo membro',$tab);$this->module_tab('vfos-team','productivity','Produtividade',$tab);if(VFOS_Team::can_permission('team.groups')||VFOS_Team::can_permission('team.group_members'))$this->module_tab('vfos-team','groups','Grupos',$tab);echo '</nav>';

        if($tab==='new'){
            if($profile&&!VFOS_Team::can_permission('team.edit')&&!$self_edit_exception)wp_die('Sem permissão para editar membros.');
            if(!$profile&&!VFOS_Team::can_permission('team.create'))wp_die('Sem permissão para cadastrar membros.');
            $presets=VFOS_Team::presets();$has_custom=$profile&&!empty($profile->custom_permissions);$groups=VFOS_Team::groups(true);$member_groups=$profile?VFOS_Team::user_groups($profile->user_id):[];
            $selected_permissions=$profile?VFOS_Team::allowed_permissions($profile->user_id):($presets['production']['permissions']??[]);
            $editing_self=$profile&&((int)$profile->user_id===get_current_user_id());
            $self_permission_enabled=$profile?VFOS_Team::self_permission_edit_enabled($profile->user_id):false;
            $can_edit_access=$profile?VFOS_Team::can_edit_permissions_of($profile->user_id):VFOS_Team::can_permission('team.permissions');
            echo '<div class="vfos-panel vfos-team-editor"><div class="vfos-panel-head"><div><span class="vfos-kicker">EQUIPE E ACESSOS</span><h2>'.($profile?'Editar membro':'Novo membro').'</h2><p>Defina o que esta pessoa pode visualizar e também exatamente o que pode fazer dentro de cada área.</p></div><div class="vfos-brand-chip"><span></span> Controle detalhado</div></div>';
            $this->form_start('vfos_save_team_member');if($profile)echo '<input type="hidden" name="id" value="'.$profile->id.'"><input type="hidden" name="user_id" value="'.$profile->user_id.'">';
            if($profile&&current_user_can('manage_options')){
                $allow=(bool)get_user_meta($profile->user_id,'_vfos_allow_self_permission_edit',true);
                echo '<div class="vfos-self-permission-admin"><div><span class="vfos-kicker">CONTROLE DO ADMINISTRADOR PRINCIPAL</span><h3>Permitir alteração das próprias permissões</h3><p>Quando ativado, este usuário poderá alterar o próprio perfil de acesso, permissões, grupos e escopos. Quando desativado, somente outro usuário autorizado ou o administrador principal poderá fazer isso.</p></div><label class="vfos-switch-row"><input type="checkbox" name="allow_self_permission_edit" value="1" '.checked($allow,true,false).'> Permitir que este usuário altere o próprio acesso</label></div>';
            }
            if($editing_self&&!$can_edit_access){
                echo '<div class="vfos-self-access-locked"><strong>Suas configurações de acesso estão protegidas</strong><p>Você pode atualizar seus dados pessoais, mas não pode alterar suas próprias permissões, perfil de acesso, grupos ou escopos. O administrador principal pode liberar essa opção individualmente.</p></div>';
            }
            echo '<div class="vfos-form-grid">';
            if(!$profile)echo '<label>Usuário de acesso<input name="user_login" required placeholder="nome.sobrenome"></label>';
            echo '<label>Nome completo<input name="display_name" required value="'.esc_attr($profile->display_name??'').'"></label><label>E-mail<input type="email" name="user_email" required value="'.esc_attr($profile->user_email??'').'"></label>';
            if(!$profile)echo '<label>Senha temporária<input type="text" name="password" placeholder="Deixe vazio para gerar automaticamente"><small>Se ficar vazio, o WordPress gera uma senha segura.</small></label>';
            else echo '<label>Nova senha<input type="text" name="password" placeholder="Deixe vazio para manter a atual"></label>';
            echo '<label>Cargo<input name="job_title" value="'.esc_attr($profile->job_title??'').'" placeholder="Ex.: Designer"></label><label>Departamento<input name="department" value="'.esc_attr($profile->department??'').'" placeholder="Ex.: Criação"></label><label>Carga diária (horas)<input type="number" min="1" max="24" step="0.5" name="capacity_hours" value="'.esc_attr($profile->capacity_hours??8).'"></label>';
            if($can_edit_access)echo '<label>Status<select name="status"><option value="active" '.selected($profile->status??'active','active',false).'>Ativo</option><option value="inactive" '.selected($profile->status??'','inactive',false).'>Inativo</option></select></label><label>Perfil base<select name="role_key" id="vfos-role-key">';
            if($can_edit_access){foreach($presets as $k=>$pr)echo '<option value="'.$k.'" '.selected($profile->role_key??'production',$k,false).'>'.esc_html($pr['label']).'</option>';echo '</select><small>O perfil é um ponto de partida. Abaixo você pode personalizar ação por ação.</small></label>';}else{echo '<input type="hidden" name="status" value="'.esc_attr($profile->status??'active').'"><input type="hidden" name="role_key" value="'.esc_attr($profile->role_key??'production').'">';}
            echo '</div>';
            if($can_edit_access){echo '<div class="vfos-member-groups-box"><div><span class="vfos-kicker">GRUPOS DO USUÁRIO</span><h3>Onde esta pessoa faz parte?</h3><p>Um usuário pode participar de um ou vários grupos, como Financeiro, Comercial, Criação ou Gestão.</p></div><div class="vfos-group-checks">';if(!$groups)echo '<small>Nenhum grupo criado ainda. Crie grupos na aba Grupos.</small>';foreach($groups as $g)echo '<label><input type="checkbox" name="member_groups[]" value="'.$g->id.'" '.checked(in_array((int)$g->id,$member_groups,true),true,false).'><span><strong>'.esc_html($g->name).'</strong><small>'.esc_html($g->description?:'Grupo da equipe').'</small></span></label>';echo '</div></div>';
            echo '<div class="vfos-access-box vfos-granular-access"><div class="vfos-panel-head"><div><span class="vfos-kicker">PERMISSÕES GRANULARES</span><h3>O que este usuário pode fazer?</h3><p>Exemplo: pode visualizar Clientes, mas você pode desmarcar “Cadastrar clientes” e “Excluir clientes”.</p></div><label class="vfos-switch-row"><input type="checkbox" name="use_custom_permissions" value="1" '.checked($has_custom,true,false).'> Personalizar permissões deste usuário</label></div><div class="vfos-permission-groups">';
            foreach(VFOS_Team::permissions() as $module=>$actions){
                $moduleLabel=VFOS_Team::modules()[$module]??ucfirst($module);
                echo '<section class="vfos-permission-group"><header><div><strong>'.esc_html($moduleLabel).'</strong><small>'.($module==='sign'?'Acesso direto ao plugin VisionForge Sign':'Permissões desta área do VisionForge OS').'</small></div><button type="button" class="button vfos-perm-toggle" data-module="'.esc_attr($module).'">Marcar tudo</button></header><div>';
                foreach($actions as $action=>$label){$key=$module.'.'.$action;$checked=in_array($key,$selected_permissions,true);echo '<label><input type="checkbox" class="vfos-perm-checkbox" data-module="'.esc_attr($module).'" name="permissions[]" value="'.esc_attr($key).'" '.checked($checked,true,false).'><span><strong>'.esc_html($label).'</strong><small>'.esc_html($key).'</small></span></label>';}
                echo '</div></section>';
            }
            echo '</div></div>';
            if($groups){
                $scope_permissions=['team.view'=>'Visualizar equipe','team.create'=>'Cadastrar membros','team.edit'=>'Editar membros','team.delete'=>'Remover membros','team.permissions'=>'Alterar permissões','team.group_members'=>'Gerenciar integrantes dos grupos','notifications.send'=>'Enviar notificações individuais','notifications.send_general'=>'Enviar notificações gerais'];
                echo '<div class="vfos-scope-box"><div class="vfos-panel-head"><div><span class="vfos-kicker">ESCOPO POR GRUPO</span><h3>Em quais grupos essas permissões funcionam?</h3><p>Sem grupo marcado = permissão global. Marcando grupos, a ação fica limitada somente às pessoas desses grupos.</p></div></div><div class="vfos-scope-grid">';
                foreach($scope_permissions as $perm=>$label){$current=$profile?VFOS_Team::permission_scope_groups($perm,$profile->user_id):[];echo '<section><header><strong>'.esc_html($label).'</strong><small>'.esc_html($perm).'</small></header><div>';foreach($groups as $g)echo '<label><input type="checkbox" name="permission_scopes['.esc_attr($perm).'][]" value="'.$g->id.'" '.checked(in_array((int)$g->id,$current,true),true,false).'> '.esc_html($g->name).'</label>';echo '</div><p>Nenhum selecionado = todos os grupos.</p></section>';}echo '</div></div>';
            }
            echo '<div class="vfos-sign-access-note"><strong>VisionForge Sign</strong><p>Para permitir que este usuário entre diretamente no VF Sign, marque pelo menos <b>“Acessar o VF Sign”</b>. Você pode liberar criação, signatários, campos, convites, downloads e configurações separadamente.</p></div>';}else if($profile){echo '<div class="vfos-access-readonly-summary"><span class="vfos-kicker">ACESSO ATUAL</span><h3>Permissões administradas por outro usuário</h3><p>Seu perfil de acesso permanece inalterado ao salvar seus dados pessoais.</p></div>';}
            if(!$profile)echo '<label class="vfos-switch-row"><input type="checkbox" name="send_invite" value="1" checked> Enviar e-mail do WordPress para definição/acesso da conta</label>';
            echo '<div class="vfos-form-actions"><button class="button button-primary vfos-btn">'.($profile?'Salvar membro':'Adicionar à equipe').'</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-team')).'">Cancelar</a></div></form></div>';
        } elseif($tab==='groups'){
            if(!VFOS_Team::can_permission('team.groups')&&!VFOS_Team::can_permission('team.group_members'))wp_die('Sem permissão para gerenciar grupos.');
            $groups=VFOS_Team::groups(false);$team_table=VFOS_DB::table('team');$gm=VFOS_DB::table('team_group_members');
            echo '<div class="vfos-grid vfos-grid-2 vfos-groups-admin">';if(VFOS_Team::can_permission('team.groups')){echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">GRUPOS DA EQUIPE</span><h2>Criar grupo</h2><p>Use grupos para limitar permissões e comunicações por área.</p></div></div>';$this->form_start('vfos_save_team_group');echo '<label>Nome do grupo<input name="name" required placeholder="Ex.: Financeiro"></label><label>Descrição<textarea name="description" rows="4" placeholder="Ex.: Responsáveis pelo financeiro da VisionForge"></textarea></label><button class="button button-primary vfos-btn">Criar grupo</button></form></div>';}echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">ESTRUTURA</span><h2>Grupos existentes</h2></div><span class="vfos-pill">'.count($groups).' grupo(s)</span></div><div class="vfos-team-groups-list">';
            if(!$groups)echo '<div class="vfos-empty">Nenhum grupo criado.</div>';
            foreach($groups as $g){
                $members=$wpdb->get_results($wpdb->prepare("SELECT tm.user_id,u.display_name,tm.job_title FROM $gm gm JOIN $team_table tm ON tm.user_id=gm.user_id JOIN {$wpdb->users} u ON u.ID=gm.user_id WHERE gm.group_id=%d AND tm.status='active' ORDER BY u.display_name",$g->id));
                $del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_team_group&id='.$g->id),'vfos_delete_team_group');
                $can_manage_members=VFOS_Team::can_permission('team.group_members')&&VFOS_Team::can_target_group('team.group_members',$g->id);
                echo '<article><div class="vfos-group-card-head"><div><strong>'.esc_html($g->name).'</strong><small>'.esc_html($g->description?:'Sem descrição').'</small></div><span class="vfos-pill">'.count($members).' membro(s)</span></div><div class="vfos-group-members-mini">';
                foreach($members as $m)echo '<span>'.esc_html($m->display_name).'</span>';if(!$members)echo '<small>Nenhum integrante.</small>';echo '</div>';
                if($can_manage_members){
                    echo '<details><summary>Gerenciar integrantes</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_save_group_members"><input type="hidden" name="group_id" value="'.$g->id.'">';wp_nonce_field('vfos_save_group_members');
                    $all=$wpdb->get_results("SELECT tm.user_id,u.display_name,tm.job_title FROM $team_table tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE tm.status='active' ORDER BY u.display_name");$ids=array_map(fn($x)=>(int)$x->user_id,$members);
                    echo '<div class="vfos-group-member-checks">';foreach($all as $m)echo '<label><input type="checkbox" name="members[]" value="'.$m->user_id.'" '.checked(in_array((int)$m->user_id,$ids,true),true,false).'> <span><strong>'.esc_html($m->display_name).'</strong><small>'.esc_html($m->job_title?:'Equipe VisionForge').'</small></span></label>';echo '</div><button class="button button-primary">Salvar integrantes</button></form></details>';
                }
                echo '<div class="vfos-team-actions">'.(VFOS_Team::can_permission('team.groups')?'<a class="button vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir este grupo? Os usuários não serão excluídos.\')">Excluir grupo</a>':'').'</div></article>';
            }
            echo '</div></div></div>';
        } elseif($tab==='productivity'){
            $from=$this->date($_GET['from']??'')?:date('Y-m-01');$to=$this->date($_GET['to']??'')?:date('Y-m-t');$rows=VFOS_Team::workload($from,$to);$view_scope=VFOS_Team::permission_scope_groups('team.view');if($view_scope)$rows=array_values(array_filter($rows,fn($x)=>(bool)array_intersect($view_scope,VFOS_Team::user_groups($x->user_id))));
            $open=array_sum(array_map(fn($x)=>(int)$x->open_tasks,$rows));$done=array_sum(array_map(fn($x)=>(int)$x->done_tasks,$rows));$late=array_sum(array_map(fn($x)=>(int)$x->overdue_tasks,$rows));
            echo '<div class="vfos-stats"><div class="vfos-stat"><span>Membros ativos</span><strong>'.count($rows).'</strong></div><div class="vfos-stat"><span>Tarefas abertas</span><strong>'.$open.'</strong></div><div class="vfos-stat"><span>Concluídas no período</span><strong>'.$done.'</strong></div><div class="vfos-stat"><span>Vencidas</span><strong>'.$late.'</strong></div></div>';
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">PRODUTIVIDADE</span><h2>Carga de trabalho</h2></div></div><form class="vfos-filters" method="get"><input type="hidden" name="page" value="vfos-team"><input type="hidden" name="tab" value="productivity"><label>De<input type="date" name="from" value="'.esc_attr($from).'"></label><label>Até<input type="date" name="to" value="'.esc_attr($to).'"></label><div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Aplicar</button></div></form><div class="vfos-workload-grid">';
            if(!$rows)echo '<div class="vfos-empty">Nenhum membro ativo cadastrado.</div>';
            foreach($rows as $r){$total=max(1,(int)$r->total_tasks);$donepct=(int)round(((int)$r->done_tasks/$total)*100);$pressure=min(100,(int)$r->open_tasks*18);echo '<article class="vfos-workload-card"><div class="vfos-member-head"><div class="vfos-avatar">'.esc_html(strtoupper(mb_substr($r->display_name,0,2))).'</div><div><strong>'.esc_html($r->display_name).'</strong><small>'.esc_html($r->job_title?:VFOS_Team::presets()[$r->role_key]['label']??'Equipe').'</small></div></div><div class="vfos-workload-numbers"><div><strong>'.(int)$r->open_tasks.'</strong><span>Abertas</span></div><div><strong>'.(int)$r->done_tasks.'</strong><span>Concluídas</span></div><div><strong>'.(int)$r->overdue_tasks.'</strong><span>Vencidas</span></div></div><div class="vfos-meter"><span>Conclusão</span><div><i style="width:'.$donepct.'%"></i></div><b>'.$donepct.'%</b></div><div class="vfos-meter pressure"><span>Carga atual</span><div><i style="width:'.$pressure.'%"></i></div><b>'.($pressure>=85?'Alta':($pressure>=45?'Média':'Leve')).'</b></div><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab=list&assigned='.$r->user_id)).'">Ver tarefas</a></article>';}
            echo '</div></div>';
        } else {
            $search=$this->q('s');$role=sanitize_key($_GET['role']??'');$status=sanitize_key($_GET['status']??'');$where=['1=1'];$args=[];$view_scope=VFOS_Team::permission_scope_groups('team.view');if($view_scope){$gm=VFOS_DB::table('team_group_members');$where[]='tm.user_id IN (SELECT user_id FROM '.$gm.' WHERE group_id IN ('.implode(',',array_map('absint',$view_scope)).'))';}
            if($search!==''){$like='%'.$wpdb->esc_like($search).'%';$where[]='(u.display_name LIKE %s OR u.user_email LIKE %s OR tm.job_title LIKE %s)';array_push($args,$like,$like,$like);}
            if($role!==''){$where[]='tm.role_key=%s';$args[]=$role;}if($status!==''){$where[]='tm.status=%s';$args[]=$status;}
            $sql="SELECT tm.*,u.display_name,u.user_email,u.user_login FROM $table tm JOIN {$wpdb->users} u ON u.ID=tm.user_id WHERE ".implode(' AND ',$where)." ORDER BY tm.status='inactive',u.display_name";
            $rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
            echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISUALIZAÇÃO</span><h2>Equipe VisionForge</h2></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-team&tab=new')).'">+ Novo membro</a></div><form class="vfos-filters" method="get"><input type="hidden" name="page" value="vfos-team"><input type="hidden" name="tab" value="list"><label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Nome, e-mail ou cargo"></label><label>Perfil<select name="role"><option value="">Todos</option>';foreach(VFOS_Team::presets() as $k=>$pr)echo '<option value="'.$k.'" '.selected($role,$k,false).'>'.esc_html($pr['label']).'</option>';echo '</select></label><label>Status<select name="status"><option value="">Todos</option><option value="active" '.selected($status,'active',false).'>Ativos</option><option value="inactive" '.selected($status,'inactive',false).'>Inativos</option></select></label><div class="vfos-filter-actions"><button class="button button-primary vfos-btn">Filtrar</button><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-team')).'">Limpar</a></div></form><div class="vfos-team-grid">';
            if(!$rows)echo '<div class="vfos-empty">Nenhum membro encontrado.</div>';
            foreach($rows as $r){$preset=VFOS_Team::presets()[$r->role_key]??VFOS_Team::presets()['custom'];$open=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('tasks')." WHERE assigned_user_id=%d AND status NOT IN ('done','cancelled')",$r->user_id));$late=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('tasks')." WHERE assigned_user_id=%d AND due_date<CURDATE() AND status NOT IN ('done','cancelled')",$r->user_id));$ed=admin_url('admin.php?page=vfos-team&tab=new&edit='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_team_member&id='.$r->id),'vfos_delete_team_member');$can_edit_member=VFOS_Team::can_permission('team.edit')&&VFOS_Team::user_in_scope('team.edit',$r->user_id);$can_delete_member=VFOS_Team::can_permission('team.delete')&&VFOS_Team::user_in_scope('team.delete',$r->user_id);echo '<article class="vfos-team-card '.($r->status==='inactive'?'is-inactive':'').'"><div class="vfos-member-head"><div class="vfos-avatar">'.esc_html(strtoupper(mb_substr($r->display_name,0,2))).'</div><div><strong>'.esc_html($r->display_name).'</strong><small>'.esc_html($r->job_title?:$preset['label']).'</small></div><span class="vfos-pill">'.($r->status==='active'?'Ativo':'Inativo').'</span></div><p>'.esc_html($r->user_email).'</p><div class="vfos-team-tags"><span>'.esc_html($preset['label']).'</span>'.($r->department?'<span>'.esc_html($r->department).'</span>':'').'<span>'.number_format((float)$r->capacity_hours,1,',','.').'h/dia</span></div><div class="vfos-workload-numbers"><div><strong>'.$open.'</strong><span>Abertas</span></div><div><strong>'.$late.'</strong><span>Vencidas</span></div></div><div class="vfos-team-actions">'.($can_edit_member?'<a class="button" href="'.esc_url($ed).'">Editar</a>':'').'<a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-tasks&tab=list&assigned='.$r->user_id)).'">Tarefas</a>'.($can_delete_member?'<a class="button vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\\\'Remover este membro do VisionForge OS? A conta WordPress será mantida.\\\')">Remover</a>':'').'</div></article>';}
            echo '</div></div>';
        }
        $this->end();
    }

    public function ai_page(){
        VFOS_Team::require_permission('ai.use');$this->header('VisionForge AI','Converse com a inteligência do seu sistema.');$this->ai_box(true);
        echo '<div class="vfos-grid vfos-grid-3 vfos-ai-info-grid"><div class="vfos-panel"><span class="vfos-kicker">OPERAÇÃO</span><h3>Executa tarefas no sistema</h3><p>Peça para criar clientes, leads, projetos, tarefas, orçamentos, contratos, lançamentos e recebimentos. A IA prepara a ação e você confirma.</p></div><div class="vfos-panel"><span class="vfos-kicker">CAMPOS COM IA</span><h3>Escreve dentro dos formulários</h3><p>Orçamentos e contratos possuem botões de IA em campos estratégicos, com escolha entre OpenRouter e Gemini.</p></div><div class="vfos-panel"><span class="vfos-kicker">SEGURANÇA</span><h3>Respeita permissões</h3><p>A IA só consulta e executa ações que o usuário atual realmente possui permissão para acessar.</p></div></div>';$this->end();
    }
    public function company_info(){
        VFOS_Team::require_permission('company.view');
        $d=get_option('vfos_company_info',[]);
        if(!is_array($d))$d=[];
        $responsibles=is_array($d['responsibles']??null)?$d['responsibles']:[];
        if(!$responsibles)$responsibles=[['name'=>'','role'=>'','email'=>'','phone'=>'']];
        $this->header('Dados da VisionForge','Informações institucionais usadas automaticamente nos orçamentos e propostas.');
        echo '<div class="vfos-panel vfos-company-settings"><div class="vfos-panel-head"><div><span class="vfos-kicker">IDENTIDADE INSTITUCIONAL</span><h2>VisionForge Digital</h2><p>Cadastre uma única vez. As propostas passam a utilizar estes dados automaticamente.</p></div><img class="vfos-company-settings-logo" src="'.esc_url(VFOS_URL.'admin/assets/images/visionforge-logo-horizontal.png').'" alt="VisionForge Digital"></div>';
        if(!VFOS_Team::can_permission('company.edit')){
            echo '<div class="vfos-notice">Seu usuário possui permissão apenas para visualizar estas informações.</div>';
        }
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('vfos_save_company_info');echo '<input type="hidden" name="action" value="vfos_save_company_info">';
        $disabled=VFOS_Team::can_permission('company.edit')?'':' disabled';

        echo '<section class="vfos-company-section"><div class="vfos-section-title"><span>01</span><div><h3>Identificação da empresa</h3><p>Nome comercial, razão social e documentos.</p></div></div><div class="vfos-form-grid">';
        echo '<label>Nome / marca<input name="company[name]" value="'.esc_attr($d['name']??'VisionForge Digital').'" placeholder="VisionForge Digital"'.$disabled.'></label>';
        echo '<label>Razão social<input name="company[legal_name]" value="'.esc_attr($d['legal_name']??'').'" placeholder="Se houver"'.$disabled.'></label>';
        echo '<label>Tipo de documento<select name="company[document_type]"'.$disabled.'><option value="cnpj" '.selected($d['document_type']??'cnpj','cnpj',false).'>CNPJ</option><option value="cpf" '.selected($d['document_type']??'cnpj','cpf',false).'>CPF</option><option value="none" '.selected($d['document_type']??'cnpj','none',false).'>Não informar</option></select></label>';
        echo '<label>CNPJ / CPF<input class="vfos-company-document" name="company[document]" value="'.esc_attr($d['document']??'').'" placeholder="00.000.000/0000-00"'.$disabled.'></label>';
        echo '<label class="vfos-grow">Descrição institucional<textarea name="company[description]" rows="4" placeholder="Breve apresentação da VisionForge Digital..."'.$disabled.'>'.esc_textarea($d['description']??'Soluções digitais desenvolvidas com estratégia, inovação e foco em resultados.').'</textarea></label>';
        echo '<label>Slogan<input name="company[slogan]" value="'.esc_attr($d['slogan']??'Transformando ideias em experiências digitais.').'"'.$disabled.'></label>';
        echo '</div></section>';

        echo '<section class="vfos-company-section"><div class="vfos-section-title"><span>02</span><div><h3>Contatos</h3><p>Informações que aparecerão no fechamento e na página institucional da proposta.</p></div></div><div class="vfos-form-grid">';
        echo '<label>Site<input type="url" name="company[website]" value="'.esc_attr($d['website']??'').'" placeholder="https://visionforgedigital.online"'.$disabled.'></label>';
        echo '<label>E-mail<input type="email" name="company[email]" value="'.esc_attr($d['email']??'').'" placeholder="contato@..."'.$disabled.'></label>';
        echo '<label>Telefone<input class="vfos-phone-mask" name="company[phone]" value="'.esc_attr($d['phone']??'').'" placeholder="(63) 00000-0000"'.$disabled.'></label>';
        echo '<label>WhatsApp<input class="vfos-phone-mask" name="company[whatsapp]" value="'.esc_attr($d['whatsapp']??'').'" placeholder="(63) 00000-0000"'.$disabled.'></label>';
        echo '<label>CEP<input name="company[zip]" value="'.esc_attr($d['zip']??'').'" placeholder="00000-000"'.$disabled.'></label>';
        echo '<label>Endereço<input name="company[address]" value="'.esc_attr($d['address']??'').'" placeholder="Rua, número, bairro"'.$disabled.'></label>';
        echo '<label>Cidade<input name="company[city]" value="'.esc_attr($d['city']??'').'"'.$disabled.'></label>';
        echo '<label>Estado<input name="company[state]" value="'.esc_attr($d['state']??'').'" placeholder="TO"'.$disabled.'></label>';
        echo '</div></section>';

        echo '<section class="vfos-company-section"><div class="vfos-section-title"><span>03</span><div><h3>Redes sociais</h3><p>Cadastre os perfis oficiais que poderão aparecer nas propostas.</p></div></div><div class="vfos-form-grid">';
        foreach(['instagram'=>'Instagram','facebook'=>'Facebook','linkedin'=>'LinkedIn','youtube'=>'YouTube','tiktok'=>'TikTok','x'=>'X / Twitter'] as $key=>$label){
            echo '<label>'.$label.'<input type="url" name="company[socials]['.$key.']" value="'.esc_attr($d['socials'][$key]??'').'" placeholder="https://..."'.$disabled.'></label>';
        }
        echo '</div></section>';

        echo '<section class="vfos-company-section"><div class="vfos-panel-head"><div class="vfos-section-title"><span>04</span><div><h3>Pessoas responsáveis</h3><p>Cadastre sócios, responsáveis comerciais ou pessoas que representam a VisionForge.</p></div></div>'.(VFOS_Team::can_permission('company.edit')?'<button type="button" class="button button-primary vfos-add-company-responsible">+ Adicionar responsável</button>':'').'</div><div id="vfos-company-responsibles">';
        foreach($responsibles as $i=>$r){
            echo '<div class="vfos-company-responsible" data-index="'.$i.'"><div class="vfos-company-responsible-number">'.($i+1).'</div><label>Nome<input name="company[responsibles]['.$i.'][name]" value="'.esc_attr($r['name']??'').'" placeholder="Nome completo"'.$disabled.'></label><label>Cargo / função<input name="company[responsibles]['.$i.'][role]" value="'.esc_attr($r['role']??'').'" placeholder="Ex.: Responsável comercial"'.$disabled.'></label><label>E-mail<input type="email" name="company[responsibles]['.$i.'][email]" value="'.esc_attr($r['email']??'').'"'.$disabled.'></label><label>Telefone<input class="vfos-phone-mask" name="company[responsibles]['.$i.'][phone]" value="'.esc_attr($r['phone']??'').'"'.$disabled.'></label>';
            if(VFOS_Team::can_permission('company.edit'))echo '<button type="button" class="button vfos-remove-company-responsible">×</button>';
            echo '</div>';
        }
        echo '</div></section>';

        echo '<section class="vfos-company-section"><div class="vfos-section-title"><span>05</span><div><h3>Exibição nas propostas</h3><p>Controle quais informações institucionais podem aparecer para o cliente.</p></div></div><div class="vfos-company-visibility">';
        foreach(['show_document'=>'CNPJ/CPF','show_address'=>'Endereço','show_responsibles'=>'Responsáveis','show_socials'=>'Redes sociais'] as $key=>$label){
            $checked=array_key_exists($key,$d)?!empty($d[$key]):true;
            echo '<label><input type="checkbox" name="company['.$key.']" value="1" '.checked($checked,true,false).$disabled.'><span><strong>'.$label.'</strong><small>Exibir esta informação nas propostas comerciais.</small></span></label>';
        }
        echo '</div></section>';

        if(VFOS_Team::can_permission('company.edit'))echo '<div class="vfos-form-actions"><button class="button button-primary vfos-btn">Salvar informações da VisionForge</button></div>';
        echo '</form></div>';
        $this->end();
    }

    public function settings(){
        $this->header('Configurações','Integrações e preferências do VisionForge OS.');
        $provider=VFOS_AI::default_provider();
        $or_key=get_option('vfos_openrouter_api_key',''); $or_model=get_option('vfos_openrouter_model','openrouter/free');
        $ge_key=get_option('vfos_gemini_api_key',''); $ge_model=get_option('vfos_gemini_model','gemini-2.5-flash');
        $ep=get_option('vfos_sign_endpoint',''); $tok=get_option('vfos_sign_token','');
        echo '<div class="vfos-panel"><span class="vfos-kicker">✦ VISIONFORGE AI</span><h2>Provedores de inteligência artificial</h2>';
        $this->form_start('vfos_save_settings');
        echo '<div class="vfos-form-grid">';
        echo '<label>Provedor padrão<select name="ai_provider"><option value="openrouter" '.selected($provider,'openrouter',false).'>OpenRouter</option><option value="gemini" '.selected($provider,'gemini',false).'>Google Gemini</option></select><small>Você ainda pode trocar a IA dentro de cada conversa.</small></label><div></div>';
        echo '<label>OpenRouter — API Key<input type="password" name="openrouter_key" value="'.esc_attr($or_key).'" autocomplete="new-password" placeholder="sk-or-..."></label><label>OpenRouter — modelo<input name="openrouter_model" value="'.esc_attr($or_model).'" placeholder="openrouter/free"></label>';
        echo '<label>Gemini — API Key<input type="password" name="gemini_key" value="'.esc_attr($ge_key).'" autocomplete="new-password" placeholder="AIza..."></label><label>Gemini — modelo<input name="gemini_model" value="'.esc_attr($ge_model).'" placeholder="gemini-2.5-flash"></label>';
        echo '<label>VisionForge Sign — endpoint remoto (opcional)<input type="url" name="sign_endpoint" value="'.esc_attr($ep).'" placeholder="https://..."></label><label>VisionForge Sign — token remoto (opcional)<input type="password" name="sign_token" value="'.esc_attr($tok).'" autocomplete="new-password"></label>';
        echo '</div><button class="button button-primary vfos-btn">Salvar configurações</button> <button type="button" class="button vfos-btn-secondary vfos-ai-test" data-provider="openrouter">Testar OpenRouter</button> <button type="button" class="button vfos-btn-secondary vfos-ai-test" data-provider="gemini">Testar Gemini</button><span id="vfos-test-result"></span></form></div>';
        $this->end();
    }
    public function ajax_ai(){
        check_ajax_referer('vfos_ajax','nonce');VFOS_Team::require_permission('ai.use');$p=sanitize_textarea_field(wp_unslash($_POST['prompt']??''));if(!$p)wp_send_json_error('Digite uma mensagem.');
        $provider=sanitize_key($_POST['provider']??'');$client_id=absint($_POST['client_id']??0);$conversation=sanitize_text_field($_POST['conversation_id']??'');
        $r=VFOS_AI::ask($p,$provider,$client_id,$conversation);if(is_wp_error($r))wp_send_json_error($r->get_error_message());wp_send_json_success($r);
    }
    public function ajax_ai_field(){
        check_ajax_referer('vfos_ajax','nonce');
        VFOS_Team::require_permission('ai.use');
        $provider=sanitize_key($_POST['provider']??'');
        $field_type=sanitize_key($_POST['field_type']??'generic');
        $context=sanitize_textarea_field(wp_unslash($_POST['context']??''));
        $current=sanitize_textarea_field(wp_unslash($_POST['current']??''));
        $r=VFOS_AI::generate_field($field_type,$context,$current,$provider);
        if(is_wp_error($r))wp_send_json_error($r->get_error_message());
        wp_send_json_success(['text'=>$r,'provider'=>$provider?:VFOS_AI::default_provider()]);
    }

    public function ajax_ai_history(){
        check_ajax_referer('vfos_ajax','nonce');VFOS_Team::require_permission('ai.use');$client_id=absint($_POST['client_id']??0);$conversation=sanitize_text_field($_POST['conversation_id']??'');
        wp_send_json_success(['conversation_id'=>$conversation,'messages'=>VFOS_AI::chat_history($conversation,$client_id,50)]);
    }
    public function ajax_ai_test(){check_ajax_referer('vfos_ajax','nonce');VFOS_Team::require_permission('ai.use');$provider=sanitize_key($_POST['provider']??'');$r=VFOS_AI::test($provider);if(is_wp_error($r))wp_send_json_error($r->get_error_message());wp_send_json_success('Conexão realizada com sucesso com '.(VFOS_AI::providers()[$provider]??'a IA').'.');}
    public function ajax_ai_execute(){check_ajax_referer('vfos_ajax','nonce');VFOS_Team::require_permission('ai.execute');$raw=wp_unslash($_POST['proposal']??'');$p=json_decode($raw,true);$r=VFOS_AI::execute_proposal($p);if(is_wp_error($r))wp_send_json_error($r->get_error_message());wp_send_json_success($r);}
    public function sign_callback(){ $token=(string)get_option('vfos_sign_token',''); $auth=$_SERVER['HTTP_AUTHORIZATION']??''; if($token && !hash_equals('Bearer '.$token,$auth)) wp_send_json_error('Não autorizado.',401); $raw=file_get_contents('php://input'); $data=json_decode($raw,true); if(!is_array($data))$data=$_POST; $local=absint($data['local_id']??$data['contract_id']??0); $external=sanitize_text_field($data['id']??$data['document_id']??''); $status=sanitize_key($data['status']??''); if(!$local && !$external)wp_send_json_error('Contrato não identificado.',400); global $wpdb;$t=VFOS_DB::table('contracts'); $row=$local?$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$local)):$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE sign_external_id=%s",$external)); if(!$row)wp_send_json_error('Contrato não encontrado.',404); $local_status=in_array($status,['signed','completed'],true)?'signed':(in_array($status,['viewed','opened'],true)?'pending_signature':'sent'); $wpdb->update($t,['sign_status'=>$status,'status'=>$local_status,'updated_at'=>current_time('mysql')],['id'=>$row->id]); if($local_status==='signed'){if(!empty($row->flow_create_project))VFOS_Workflow::contract_to_project($row->id);if(!empty($row->flow_create_financial))VFOS_Workflow::contract_to_financial($row->id);} VFOS_DB::log('sign_callback','contract',$row->id,$status); wp_send_json_success(['updated'=>true]); }
    private function lead_stages(){return ['new'=>'Novo lead','contacted'=>'Contato realizado','qualified'=>'Qualificado','proposal'=>'Orçamento enviado','negotiation'=>'Negociação','won'=>'Ganho','lost'=>'Perdido'];}
    public function leads(){
        global $wpdb;$t=VFOS_DB::table('leads');$edit=absint($_GET['edit']??0);$tab=$edit?'new':sanitize_key($_GET['tab']??'pipeline');$e=$edit?$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$edit)):null;$stages=$this->lead_stages();$this->header('Leads / CRM','Pipeline comercial da VisionForge: acompanhe oportunidades do primeiro contato até o fechamento.');$this->module_tabs('vfos-leads',$tab,$edit?'Editar lead':'Novo lead',['pipeline'=>'Pipeline']);
        if($tab==='new'){echo '<div class="vfos-panel"><span class="vfos-kicker">CADASTRO</span><h2>'.($e?'Editar lead':'Novo lead').'</h2>';$this->form_start('vfos_save_lead');if($e)echo '<input type="hidden" name="id" value="'.$e->id.'">';echo '<div class="vfos-form-grid"><label>Nome<input name="name" required value="'.esc_attr($e->name??'').'"></label><label>Empresa<input name="company" value="'.esc_attr($e->company??'').'"></label><label>E-mail<input type="email" name="email" value="'.esc_attr($e->email??'').'"></label><label>Telefone / WhatsApp<input name="phone" value="'.esc_attr($e->phone??'').'"></label><label>Origem<select name="source">';foreach([''=>'Não informado','Instagram'=>'Instagram','WhatsApp'=>'WhatsApp','Indicação'=>'Indicação','Site'=>'Site','Google'=>'Google','Outro'=>'Outro'] as $k=>$v)echo '<option value="'.esc_attr($k).'" '.selected($e->source??'',$k,false).'>'.esc_html($v).'</option>';echo '</select></label><label>Serviço de interesse<input name="service_interest" value="'.esc_attr($e->service_interest??'').'" placeholder="Ex.: Site institucional"></label><label>Valor estimado (R$)<input type="number" step="0.01" min="0" name="estimated_value" value="'.esc_attr($e->estimated_value??0).'"></label><label>Etapa<select name="stage">';foreach($stages as $k=>$v)echo '<option value="'.$k.'" '.selected($e->stage??'new',$k,false).'>'.$v.'</option>';echo '</select></label><label>Probabilidade (%)<input type="number" min="0" max="100" name="probability" value="'.esc_attr($e->probability??10).'"></label><label>Próximo acompanhamento<input type="date" name="next_followup" value="'.esc_attr($e->next_followup??'').'"></label></div><label>Observações<textarea name="notes" rows="4" data-vfos-ai="generic" data-vfos-ai-label="Observações do lead">'.esc_textarea($e->notes??'').'</textarea></label><div class="vfos-flow-box"><div><span class="vfos-kicker">FLUXO COMERCIAL</span><strong>Permitir seguir para Orçamento</strong><small>Quando este lead chegar em Qualificado, Proposta, Negociação ou Ganho, o VisionForge pode preparar o orçamento sem você recadastrar tudo.</small></div><label class="vfos-switch-row"><input type="checkbox" name="flow_quote_enabled" value="1" '.checked($e->flow_quote_enabled??0,1,false).'> Ativar Lead → Orçamento</label></div><button class="button button-primary vfos-btn">'.($e?'Salvar alterações':'Adicionar ao pipeline').'</button> <a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-leads&tab=pipeline')).'">Cancelar</a></form></div>';$this->end();return;}
        $search=$this->q('s');$stage=sanitize_key($_GET['stage']??'');$source=$this->q('source');$follow=sanitize_key($_GET['follow']??'');$where=['1=1'];$args=[];if($search!==''){$where[]='(name LIKE %s OR company LIKE %s OR email LIKE %s OR phone LIKE %s OR service_interest LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';array_push($args,$like,$like,$like,$like,$like);}if(isset($stages[$stage])){$where[]='stage=%s';$args[]=$stage;}if($source!==''){$where[]='source=%s';$args[]=$source;}if($follow==='overdue')$where[]="next_followup<CURDATE() AND stage NOT IN ('won','lost')";elseif($follow==='today')$where[]='next_followup=CURDATE()';elseif($follow==='week')$where[]='next_followup BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY)';$sql="SELECT * FROM $t WHERE ".implode(' AND ',$where)." ORDER BY FIELD(stage,'new','contacted','qualified','proposal','negotiation','won','lost'),next_followup IS NULL,next_followup ASC,id DESC";$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
        echo '<div class="vfos-panel vfos-filter-panel">';$this->filter_start('vfos-leads');echo '<input type="hidden" name="tab" value="'.esc_attr($tab).'"><label>Buscar<input name="s" value="'.esc_attr($search).'" placeholder="Lead, empresa, contato ou serviço"></label><label>Etapa<select name="stage"><option value="">Todas</option>';foreach($stages as $k=>$v)echo '<option value="'.$k.'" '.selected($stage,$k,false).'>'.$v.'</option>';echo '</select></label><label>Origem<select name="source"><option value="">Todas</option>';foreach(['Instagram','WhatsApp','Indicação','Site','Google','Outro'] as $v)echo '<option value="'.$v.'" '.selected($source,$v,false).'>'.$v.'</option>';echo '</select></label><label>Acompanhamento<select name="follow"><option value="">Qualquer data</option><option value="overdue" '.selected($follow,'overdue',false).'>Atrasado</option><option value="today" '.selected($follow,'today',false).'>Hoje</option><option value="week" '.selected($follow,'week',false).'>Próximos 7 dias</option></select></label>';$this->filter_end();echo '</div>';
        if($tab==='list'){echo '<div class="vfos-panel"><div class="vfos-panel-head"><div><span class="vfos-kicker">VISUALIZAÇÃO</span><h2>Lista de leads</h2></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-leads&tab=new')).'">+ Novo lead</a></div><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Lead</th><th>Serviço</th><th>Origem</th><th>Etapa</th><th>Valor</th><th>Próximo contato</th><th>Ações</th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="7">Nenhum lead encontrado.</td></tr>';foreach($rows as $r){$editurl=admin_url('admin.php?page=vfos-leads&tab=new&edit='.$r->id);$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_lead&id='.$r->id),'vfos_delete_lead');echo '<tr><td><strong>'.esc_html($r->name).'</strong><small>'.esc_html($r->company).'</small></td><td>'.esc_html($r->service_interest?:'—').'</td><td>'.esc_html($r->source?:'—').'</td><td><span class="vfos-pill">'.esc_html($this->status_label($r->stage)).'</span></td><td>R$ '.number_format($r->estimated_value,2,',','.').'</td><td>'.($r->next_followup?esc_html(date_i18n('d/m/Y',strtotime($r->next_followup))):'—').'</td><td><a href="'.esc_url($editurl).'">Editar</a> · <a class="vfos-danger" href="'.esc_url($del).'" onclick="return confirm(\'Excluir este lead?\')">Excluir</a></td></tr>';}echo '</tbody></table></div></div>';}
        else{$grouped=[];foreach($stages as $k=>$v)$grouped[$k]=[];foreach($rows as $r)$grouped[$r->stage][]=$r;echo '<div class="vfos-panel-head vfos-pipeline-head"><div><span class="vfos-kicker">PIPELINE</span><h2>Funil comercial</h2></div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-leads&tab=new')).'">+ Novo lead</a></div><div id="vfos-pipeline" class="vfos-pipeline">';foreach($stages as $key=>$label){$sum=0;foreach($grouped[$key] as $x)$sum+=(float)$x->estimated_value;echo '<section class="vfos-stage vfos-stage-'.$key.'"><header><div><strong>'.esc_html($label).'</strong><small>'.count($grouped[$key]).' lead(s)</small></div><span>R$ '.number_format($sum,2,',','.').'</span></header><div class="vfos-stage-list">';if(!$grouped[$key])echo '<div class="vfos-stage-empty">Nenhum lead</div>';foreach($grouped[$key] as $r){$editurl=admin_url('admin.php?page=vfos-leads&tab=new&edit='.$r->id);echo '<article class="vfos-lead-card"><div class="vfos-lead-top"><strong>'.esc_html($r->name).'</strong><span>'.absint($r->probability).'%</span></div>'.($r->company?'<small>'.esc_html($r->company).'</small>':'').'<p>'.esc_html($r->service_interest?:'Serviço não informado').'</p><b>R$ '.number_format((float)$r->estimated_value,2,',','.').'</b>'.($r->next_followup?'<em>Próximo: '.esc_html(date_i18n('d/m/Y',strtotime($r->next_followup))).'</em>':'').'<div class="vfos-lead-actions"><a href="'.esc_url($editurl).'">Editar</a>';if(!in_array($r->stage,['won','lost'],true)){echo '<details><summary>Mover</summary><div class="vfos-move-menu">';foreach($stages as $sk=>$sl){if($sk===$r->stage)continue;$u=wp_nonce_url(admin_url('admin-post.php?action=vfos_lead_stage&id='.$r->id.'&stage='.$sk),'vfos_lead_stage');echo '<a href="'.esc_url($u).'">'.esc_html($sl).'</a>';}echo '</div></details>';}if(!$r->converted_client_id){$conv=wp_nonce_url(admin_url('admin-post.php?action=vfos_convert_lead&id='.$r->id.'&quote=0'),'vfos_convert_lead');$convq=wp_nonce_url(admin_url('admin-post.php?action=vfos_convert_lead&id='.$r->id.'&quote=1'),'vfos_convert_lead');echo '<a href="'.esc_url($conv).'">Virar cliente</a><a href="'.esc_url($convq).'">Cliente + orçamento</a>';}else {echo '<span class="vfos-converted">✓ Cliente #'.absint($r->converted_client_id).'</span>';if(!empty($r->converted_quote_id))echo '<a href="'.esc_url(admin_url('admin.php?page=vfos-quotes&tab=new&edit='.$r->converted_quote_id)).'">Abrir orçamento</a>';}$del=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_lead&id='.$r->id),'vfos_delete_lead');echo '<a class="vfos-danger" onclick="return confirm(\'Excluir este lead?\')" href="'.esc_url($del).'">Excluir</a></div></article>';}echo '</div></section>';}echo '</div>';}$this->end();
    }
    public function save_lead(){check_admin_referer('vfos_save_lead');$id=absint($_POST['id']??0);VFOS_Team::require_permission($id?'crm.edit':'crm.create');global $wpdb;$t=VFOS_DB::table('leads');$d=['name'=>sanitize_text_field($_POST['name']??''),'company'=>sanitize_text_field($_POST['company']??''),'email'=>sanitize_email($_POST['email']??''),'phone'=>sanitize_text_field($_POST['phone']??''),'source'=>sanitize_text_field($_POST['source']??''),'service_interest'=>sanitize_text_field($_POST['service_interest']??''),'estimated_value'=>(float)($_POST['estimated_value']??0),'stage'=>sanitize_key($_POST['stage']??'new'),'probability'=>min(100,max(0,absint($_POST['probability']??10))),'next_followup'=>$this->date($_POST['next_followup']??''),'notes'=>sanitize_textarea_field($_POST['notes']??''),'flow_quote_enabled'=>!empty($_POST['flow_quote_enabled'])?1:0,'updated_at'=>current_time('mysql')];if(!array_key_exists($d['stage'],$this->lead_stages()))$d['stage']='new';if($id)$wpdb->update($t,$d,['id'=>$id]);else{$d['created_at']=current_time('mysql');$wpdb->insert($t,$d);$id=$wpdb->insert_id;}VFOS_DB::log('save_lead','lead',$id);
        $fresh=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));
        if($fresh&&!empty($fresh->flow_quote_enabled)&&empty($fresh->converted_quote_id)&&in_array($fresh->stage,['qualified','proposal','negotiation','won'],true)){
            $qid=VFOS_Workflow::lead_to_quote($id);
            if(!is_wp_error($qid)){wp_safe_redirect(admin_url('admin.php?page=vfos-quotes&edit='.$qid.'&vfos_msg='.rawurlencode('Lead salvo e encaminhado para Orçamento.')));exit;}
        }
        $this->go('vfos-leads','Lead salvo no pipeline.');}
    public function delete_lead(){$this->delete_generic('lead','vfos-leads');}
    public function lead_stage(){$this->guard('vfos_lead_stage');global $wpdb;$id=absint($_GET['id']??0);$stage=sanitize_key($_GET['stage']??'new');if(!array_key_exists($stage,$this->lead_stages()))$stage='new';$d=['stage'=>$stage,'updated_at'=>current_time('mysql')];if($stage==='won')$d['probability']=100;elseif($stage==='lost')$d['probability']=0;$wpdb->update(VFOS_DB::table('leads'),$d,['id'=>$id]);VFOS_DB::log('lead_stage','lead',$id,$stage);$this->go('vfos-leads','Etapa do lead atualizada.');}
    public function convert_lead(){$this->guard('vfos_convert_lead');global $wpdb;$id=absint($_GET['id']??0);$make_quote=!empty($_GET['quote']);$lt=VFOS_DB::table('leads');$lead=$wpdb->get_row($wpdb->prepare("SELECT * FROM $lt WHERE id=%d",$id));if(!$lead)$this->go('vfos-leads','Lead não encontrado.');$client_id=absint($lead->converted_client_id);$now=current_time('mysql');if(!$client_id){$wpdb->insert(VFOS_DB::table('clients'),['name'=>$lead->name,'company'=>$lead->company,'email'=>$lead->email,'phone'=>$lead->phone,'status'=>'active','notes'=>'Convertido do lead #'.$lead->id.($lead->notes?"\n\n".$lead->notes:''),'created_at'=>$now,'updated_at'=>$now]);$client_id=$wpdb->insert_id;}$wpdb->update($lt,['stage'=>'won','probability'=>100,'converted_client_id'=>$client_id,'updated_at'=>$now],['id'=>$id]);VFOS_DB::log('convert_lead','lead',$id,'client='.$client_id);if($make_quote){$qid=VFOS_Workflow::lead_to_quote($id);if(is_wp_error($qid))$this->go('vfos-leads',$qid->get_error_message());wp_safe_redirect(admin_url('admin.php?page=vfos-quotes&edit='.$qid.'&vfos_msg='.rawurlencode('Cliente e orçamento criados a partir do lead.')));exit;}$this->go('vfos-clients','Lead convertido em cliente.');}
    public function save_client_note(){$this->guard('vfos_save_client_note');global $wpdb;$id=absint($_POST['client_id']??0);$content=sanitize_textarea_field($_POST['content']??'');if($id&&$content){$wpdb->insert(VFOS_DB::table('client_notes'),['client_id'=>$id,'user_id'=>get_current_user_id(),'content'=>$content,'created_at'=>current_time('mysql')]);VFOS_DB::log('client_note','client',$id,$content);}wp_safe_redirect(admin_url('admin.php?page=vfos-client-view&id='.$id));exit;}
    public function upload_client_file(){$this->guard('vfos_upload_client_file');global $wpdb;$id=absint($_POST['client_id']??0);if(!$id||empty($_FILES['client_file']['name'])){wp_safe_redirect(admin_url('admin.php?page=vfos-client-view&id='.$id.'&vfos_msg='.rawurlencode('Selecione um arquivo.')));exit;}require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';$attachment_id=media_handle_upload('client_file',0);if(is_wp_error($attachment_id)){wp_safe_redirect(admin_url('admin.php?page=vfos-client-view&id='.$id.'&vfos_msg='.rawurlencode('Erro no envio: '.$attachment_id->get_error_message())));exit;}$url=wp_get_attachment_url($attachment_id);$mime=get_post_mime_type($attachment_id);$title=sanitize_text_field($_POST['title']??'');if(!$title)$title=get_the_title($attachment_id);$wpdb->insert(VFOS_DB::table('client_files'),['client_id'=>$id,'attachment_id'=>$attachment_id,'title'=>$title,'file_url'=>$url,'mime_type'=>$mime,'created_at'=>current_time('mysql')]);VFOS_DB::log('client_file_upload','client',$id,$title);wp_safe_redirect(admin_url('admin.php?page=vfos-client-view&id='.$id.'&vfos_msg='.rawurlencode('Arquivo adicionado ao cliente.')));exit;}
    public function delete_client_file(){$this->guard('vfos_delete_client_file');global $wpdb;$fid=absint($_GET['id']??0);$cid=absint($_GET['client_id']??0);$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.VFOS_DB::table('client_files').' WHERE id=%d',$fid));if($row){$wpdb->delete(VFOS_DB::table('client_files'),['id'=>$fid]);VFOS_DB::log('client_file_remove','client',$cid,$row->title);}wp_safe_redirect(admin_url('admin.php?page=vfos-client-view&id='.$cid.'&vfos_msg='.rawurlencode('Arquivo removido do vínculo com o cliente.')));exit;}

    private function guard($a){$permission=VFOS_Team::action_permission($a);if(!VFOS_Team::can_permission($permission))wp_die('Sem permissão para esta ação.');check_admin_referer($a);} private function go($p,$m='Salvo com sucesso.'){wp_safe_redirect(add_query_arg(['page'=>$p,'vfos_msg'=>$m],admin_url('admin.php')));exit;} private function date($v){$v=sanitize_text_field($v);return preg_match('/^\d{4}-\d{2}-\d{2}$/',$v)?$v:null;}
    private function decimal($v){
        $v=trim((string)$v);
        if($v==='')return 0.0;
        $v=preg_replace('/[^0-9,.-]/','',$v);
        if(strpos($v,',')!==false && strpos($v,'.')!==false){
            $lastComma=strrpos($v,',');$lastDot=strrpos($v,'.');
            if($lastComma>$lastDot){$v=str_replace('.','',$v);$v=str_replace(',','.',$v);}
            else{$v=str_replace(',','',$v);}
        }elseif(strpos($v,',')!==false){
            $v=str_replace(',','.',$v);
        }
        return (float)$v;
    }
    public function save_team_group(){
        check_admin_referer('vfos_save_team_group');VFOS_Team::require_permission('team.groups');global $wpdb;$name=sanitize_text_field($_POST['name']??'');if(!$name)$this->go('vfos-team','Informe o nome do grupo.');
        $slug=sanitize_title($name);$t=VFOS_DB::table('team_groups');$exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE slug=%s",$slug));if($exists)$this->go('vfos-team','Já existe um grupo com esse nome.');
        $now=current_time('mysql');$wpdb->insert($t,['name'=>$name,'slug'=>$slug,'description'=>sanitize_textarea_field($_POST['description']??''),'status'=>'active','created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now]);$id=$wpdb->insert_id;
        VFOS_DB::log('save_team_group','team_group',$id,'Grupo criado',null,null,$name);wp_safe_redirect(admin_url('admin.php?page=vfos-team&tab=groups&vfos_msg='.rawurlencode('Grupo criado com sucesso.')));exit;
    }
    public function delete_team_group(){
        check_admin_referer('vfos_delete_team_group');VFOS_Team::require_permission('team.groups');global $wpdb;$id=absint($_GET['id']??0);$t=VFOS_DB::table('team_groups');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));if(!$row)$this->go('vfos-team','Grupo não encontrado.');
        $wpdb->delete(VFOS_DB::table('team_group_members'),['group_id'=>$id]);$wpdb->delete(VFOS_DB::table('permission_scopes'),['group_id'=>$id]);$wpdb->delete($t,['id'=>$id]);VFOS_DB::log('delete_team_group','team_group',$id,'Grupo excluído', (array)$row,null,$row->name);
        wp_safe_redirect(admin_url('admin.php?page=vfos-team&tab=groups&vfos_msg='.rawurlencode('Grupo excluído. Os usuários foram mantidos.')));exit;
    }
    public function save_group_members(){
        check_admin_referer('vfos_save_group_members');VFOS_Team::require_permission('team.group_members');global $wpdb;$gid=absint($_POST['group_id']??0);if(!$gid)$this->go('vfos-team','Grupo inválido.');
        if(!VFOS_Team::can_target_group('team.group_members',$gid))wp_die('Você não possui autorização para gerenciar integrantes deste grupo.');
        $gt=VFOS_DB::table('team_groups');$group=$wpdb->get_row($wpdb->prepare("SELECT * FROM $gt WHERE id=%d",$gid));if(!$group)$this->go('vfos-team','Grupo não encontrado.');
        $members=array_values(array_unique(array_map('absint',(array)($_POST['members']??[]))));$valid=array_map('absint',$wpdb->get_col("SELECT user_id FROM ".VFOS_DB::table('team')." WHERE status='active'"));$members=array_values(array_intersect($members,$valid));
        $gmt=VFOS_DB::table('team_group_members');$before=VFOS_Team::group_members($gid);$wpdb->delete($gmt,['group_id'=>$gid]);$now=current_time('mysql');foreach($members as $uid)$wpdb->insert($gmt,['group_id'=>$gid,'user_id'=>$uid,'created_at'=>$now]);
        VFOS_DB::log('save_group_members','team_group',$gid,'Integrantes: '.count($members),$before,$members,$group->name);wp_safe_redirect(admin_url('admin.php?page=vfos-team&tab=groups&vfos_msg='.rawurlencode('Integrantes do grupo atualizados.')));exit;
    }

    public function save_team_member(){
        check_admin_referer('vfos_save_team_member');$team_id=absint($_POST['id']??0);global $wpdb;
        $target_user=$team_id?(int)$wpdb->get_var($wpdb->prepare("SELECT user_id FROM ".VFOS_DB::table('team')." WHERE id=%d",$team_id)):0;
        $self_edit_exception=$team_id&&$target_user===get_current_user_id()&&VFOS_Team::self_permission_edit_enabled($target_user);
        if($team_id){if(!VFOS_Team::can_permission('team.edit')&&!$self_edit_exception)wp_die('Você não possui permissão para editar este membro.');if($target_user&&!$self_edit_exception&&!VFOS_Team::user_in_scope('team.edit',$target_user))wp_die('Você pode editar membros apenas dos grupos autorizados.');}
        else VFOS_Team::require_permission('team.create');
        $table=VFOS_DB::table('team');$id=absint($_POST['id']??0);$user_id=absint($_POST['user_id']??0);$now=current_time('mysql');$requested_member_groups=array_values(array_unique(array_map('absint',(array)($_POST['member_groups']??[]))));if(!$id){$create_scope=VFOS_Team::permission_scope_groups('team.create');if($create_scope){$requested_member_groups=array_values(array_intersect($requested_member_groups,$create_scope));if(!$requested_member_groups)wp_die('Você só pode cadastrar membros nos grupos autorizados.');}}
        $display=sanitize_text_field($_POST['display_name']??'');$email=sanitize_email($_POST['user_email']??'');$password=(string)($_POST['password']??'');
        if(!$display||!is_email($email))$this->go('vfos-team','Informe nome e e-mail válidos.');
        if(!$user_id){
            $login=sanitize_user($_POST['user_login']??'',true);if(!$login)$this->go('vfos-team','Informe um usuário de acesso válido.');
            if(username_exists($login))$this->go('vfos-team','Esse usuário de acesso já existe.');
            if(email_exists($email))$this->go('vfos-team','Esse e-mail já está vinculado a outro usuário do WordPress.');
            if(!$password)$password=wp_generate_password(16,true,true);
            $user_id=wp_create_user($login,$password,$email);if(is_wp_error($user_id))$this->go('vfos-team','Erro ao criar usuário: '.$user_id->get_error_message());
            $u=new WP_User($user_id);$u->set_role('vfos_team_member');
            wp_update_user(['ID'=>$user_id,'display_name'=>$display,'first_name'=>$display]);
            if(!empty($_POST['send_invite']))wp_new_user_notification($user_id,null,'user');
        }else{
            $data=['ID'=>$user_id,'display_name'=>$display,'user_email'=>$email];if($password!=='')$data['user_pass']=$password;$r=wp_update_user($data);if(is_wp_error($r))$this->go('vfos-team','Erro ao atualizar usuário: '.$r->get_error_message());
            $u=new WP_User($user_id);if(!$u->has_cap('manage_options')&&!in_array('vfos_team_member',$u->roles,true))$u->set_role('vfos_team_member');
        }
        $existing_profile=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$id)):null;
        $is_self=$user_id&&($user_id===get_current_user_id());

        // Somente o administrador principal do WordPress pode conceder ou
        // revogar a exceção de autoedição de acesso.
        if($id&&current_user_can('manage_options')){
            $before_self=(bool)get_user_meta($user_id,'_vfos_allow_self_permission_edit',true);
            $after_self=!empty($_POST['allow_self_permission_edit']);
            update_user_meta($user_id,'_vfos_allow_self_permission_edit',$after_self?1:0);
            if($before_self!==$after_self){
                VFOS_DB::log('self_permission_toggle','team',$id,'Autoedição de acesso '.($after_self?'liberada':'bloqueada').' pelo administrador principal',['enabled'=>$before_self],['enabled'=>$after_self],$display);
            }
        }

        if($id){
            $can_change_permissions=VFOS_Team::can_edit_permissions_of($user_id);
        }else{
            $can_change_permissions=VFOS_Team::can_permission('team.permissions');
            if($can_change_permissions){
                $perm_scope=VFOS_Team::permission_scope_groups('team.permissions');
                if($perm_scope)$can_change_permissions=(bool)array_intersect($perm_scope,$requested_member_groups);
            }
        }

        $role=$can_change_permissions?sanitize_key($_POST['role_key']??'production'):($existing_profile->role_key??'production');
        if(!isset(VFOS_Team::presets()[$role]))$role='production';

        $custom=$can_change_permissions?null:($existing_profile->custom_permissions??null);
        if($can_change_permissions&&!empty($_POST['use_custom_permissions'])){
            $allowed=VFOS_Team::all_permission_keys();
            $requested=array_map('sanitize_text_field',(array)($_POST['permissions']??[]));
            $custom=array_values(array_intersect($allowed,$requested));
            if(!in_array('dashboard.view',$custom,true))$custom[]='dashboard.view';
            $custom=wp_json_encode($custom);
        }

        // Status, grupos e escopos também fazem parte do acesso. O próprio
        // usuário não consegue alterá-los quando a exceção estiver desligada.
        $status=$can_change_permissions?sanitize_key($_POST['status']??'active'):($existing_profile->status??'active');
        if(!in_array($status,['active','inactive'],true))$status='active';

        $data=[
            'user_id'=>$user_id,'role_key'=>$role,
            'job_title'=>sanitize_text_field($_POST['job_title']??''),
            'department'=>sanitize_text_field($_POST['department']??''),
            'capacity_hours'=>max(1,min(24,(float)($_POST['capacity_hours']??8))),
            'status'=>$status,'custom_permissions'=>$custom,'updated_at'=>$now
        ];

        if($id)$wpdb->update($table,$data,['id'=>$id]);
        else{$data['created_at']=$now;$wpdb->replace($table,$data);$id=$wpdb->insert_id;}

        $can_change_groups=VFOS_Team::can_permission('team.group_members')&&(!$is_self||$can_change_permissions);
        if($can_change_groups){
            $groups_to_save=$requested_member_groups;
            $group_scope=VFOS_Team::permission_scope_groups('team.group_members');
            if($group_scope){
                if($id){
                    $existing_groups=VFOS_Team::user_groups($user_id);
                    $outside=array_diff($existing_groups,$group_scope);
                    $groups_to_save=array_values(array_unique(array_merge($outside,array_intersect($groups_to_save,$group_scope))));
                }else{
                    $groups_to_save=array_values(array_intersect($groups_to_save,$group_scope));
                }
            }
            VFOS_Team::sync_user_groups($user_id,$groups_to_save);
        }

        if($can_change_permissions)VFOS_Team::sync_permission_scopes($user_id,(array)($_POST['permission_scopes']??[]));

        VFOS_Team::sync_external_caps($user_id);
        VFOS_DB::log('save_team_member','team',$id,'user='.$user_id.' | self='.(int)$is_self.' | alterou_acesso='.(int)$can_change_permissions.' | grupos='.implode(',',VFOS_Team::user_groups($user_id)));
        $this->go('vfos-team',$is_self&&!$can_change_permissions?'Seus dados pessoais foram salvos. Suas permissões e configurações de acesso permaneceram inalteradas.':'Membro, grupos e permissões salvos com sucesso.');
    }
    public function delete_team_member(){
        $this->guard('vfos_delete_team_member');global $wpdb;$id=absint($_GET['id']??0);$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('team')." WHERE id=%d",$id));
        if($row){if(!VFOS_Team::user_in_scope('team.delete',$row->user_id))wp_die('Você pode remover membros apenas dos grupos autorizados.');$wpdb->delete(VFOS_DB::table('team_group_members'),['user_id'=>$row->user_id]);$wpdb->delete(VFOS_DB::table('permission_scopes'),['user_id'=>$row->user_id]);$wpdb->delete(VFOS_DB::table('team'),['id'=>$id]);$u=new WP_User($row->user_id);if(!$u->has_cap('manage_options')){$u->remove_role('vfos_team_member');if(empty($u->roles))$u->add_role('subscriber');}VFOS_DB::log('delete_team_member','team',$id,'user='.$row->user_id);}
        $this->go('vfos-team','Membro removido do VisionForge OS. A conta WordPress foi mantida.');
    }

    public function save_company_info(){
        $this->guard('vfos_save_company_info');
        $raw=is_array($_POST['company']??null)?wp_unslash($_POST['company']):[];
        $socials=[];foreach(['instagram','facebook','linkedin','youtube','tiktok','x'] as $key)$socials[$key]=esc_url_raw($raw['socials'][$key]??'');
        $responsibles=[];
        foreach((array)($raw['responsibles']??[]) as $r){
            if(!is_array($r))continue;$name=sanitize_text_field($r['name']??'');if(!$name)continue;
            $responsibles[]=['name'=>$name,'role'=>sanitize_text_field($r['role']??''),'email'=>sanitize_email($r['email']??''),'phone'=>sanitize_text_field($r['phone']??'')];
        }
        $type=sanitize_key($raw['document_type']??'cnpj');if(!in_array($type,['cnpj','cpf','none'],true))$type='cnpj';
        $data=[
            'name'=>sanitize_text_field($raw['name']??'VisionForge Digital'),
            'legal_name'=>sanitize_text_field($raw['legal_name']??''),
            'document_type'=>$type,'document'=>sanitize_text_field($raw['document']??''),
            'description'=>sanitize_textarea_field($raw['description']??''),
            'slogan'=>sanitize_text_field($raw['slogan']??''),
            'website'=>esc_url_raw($raw['website']??''),'email'=>sanitize_email($raw['email']??''),
            'phone'=>sanitize_text_field($raw['phone']??''),'whatsapp'=>sanitize_text_field($raw['whatsapp']??''),
            'zip'=>sanitize_text_field($raw['zip']??''),'address'=>sanitize_text_field($raw['address']??''),
            'city'=>sanitize_text_field($raw['city']??''),'state'=>sanitize_text_field($raw['state']??''),
            'socials'=>$socials,'responsibles'=>$responsibles,
            'show_document'=>empty($raw['show_document'])?0:1,'show_address'=>empty($raw['show_address'])?0:1,
            'show_responsibles'=>empty($raw['show_responsibles'])?0:1,'show_socials'=>empty($raw['show_socials'])?0:1,
            'updated_at'=>current_time('mysql'),'updated_by'=>get_current_user_id()
        ];
        $before=get_option('vfos_company_info',[]);
        $result=update_option('vfos_company_info',$data,false);
        $saved=get_option('vfos_company_info',[]);
        if(!is_array($saved)||($saved['name']??'')!==$data['name']){
            wp_die('Não foi possível salvar os dados institucionais da VisionForge. Verifique as permissões do banco de dados e tente novamente.');
        }
        VFOS_DB::log('save_company_info','company',0,'Dados institucionais atualizados',is_array($before)?$before:null,$data,$data['name']);
        $this->go('vfos-company','Informações da VisionForge salvas com sucesso.');
    }

public function save_settings(){$this->guard('vfos_save_settings');$provider=sanitize_key($_POST['ai_provider']??'openrouter');if(!isset(VFOS_AI::providers()[$provider]))$provider='openrouter';update_option('vfos_ai_provider',$provider);update_option('vfos_openrouter_api_key',trim(wp_unslash($_POST['openrouter_key']??'')));update_option('vfos_openrouter_model',sanitize_text_field($_POST['openrouter_model']??'openrouter/free'));update_option('vfos_gemini_api_key',trim(wp_unslash($_POST['gemini_key']??'')));update_option('vfos_gemini_model',sanitize_text_field($_POST['gemini_model']??'gemini-2.5-flash'));update_option('vfos_sign_endpoint',esc_url_raw($_POST['sign_endpoint']??''));update_option('vfos_sign_token',trim(wp_unslash($_POST['sign_token']??'')));$this->go('vfos-settings','Configurações salvas.');}
    public function save_client(){
        check_admin_referer('vfos_save_client');$id=absint($_POST['id']??0);VFOS_Team::require_permission($id?'clients.edit':'clients.create');global $wpdb;$t=VFOS_DB::table('clients');$now=current_time('mysql');
        $before=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id),ARRAY_A):null;
        $type=in_array(sanitize_key($_POST['person_type']??'pf'),['pf','pj'],true)?sanitize_key($_POST['person_type']??'pf'):'pf';
        $name=sanitize_text_field($_POST['name']??'');$legal=sanitize_text_field($_POST['legal_name']??'');$trade=sanitize_text_field($_POST['trade_name']??'');
        if($type==='pj'&&!$name)$name=$trade?:$legal;if(!$name)$this->go('vfos-clients','Informe o nome do cliente.');
        $document=$type==='pj'?sanitize_text_field($_POST['pj_document']??''):sanitize_text_field($_POST['document']??'');
        $d=[
            'person_type'=>$type,'name'=>$name,'company'=>$type==='pj'?($trade?:$legal):'','legal_name'=>$type==='pj'?$legal:'',
            'trade_name'=>$type==='pj'?$trade:'','document'=>$document,'state_registration'=>$type==='pj'?sanitize_text_field($_POST['state_registration']??''):'',
            'municipal_registration'=>$type==='pj'?sanitize_text_field($_POST['municipal_registration']??''):'',
            'email'=>sanitize_email($_POST['email']??''),'billing_email'=>sanitize_email($_POST['billing_email']??''),'phone'=>sanitize_text_field($_POST['phone']??''),
            'whatsapp'=>sanitize_text_field($_POST['whatsapp']??''),'website'=>esc_url_raw($_POST['website']??''),
            'birth_date'=>$type==='pf'?$this->date($_POST['birth_date']??''):null,'profession'=>$type==='pf'?sanitize_text_field($_POST['profession']??''):'',
            'nationality'=>$type==='pf'?sanitize_text_field($_POST['nationality']??''):'','marital_status'=>$type==='pf'?sanitize_text_field($_POST['marital_status']??''):'',
            'rg'=>$type==='pf'?sanitize_text_field($_POST['rg']??''):'',
            'address_zip'=>sanitize_text_field($_POST['address_zip']??''),'address_street'=>sanitize_text_field($_POST['address_street']??''),
            'address_number'=>sanitize_text_field($_POST['address_number']??''),'address_complement'=>sanitize_text_field($_POST['address_complement']??''),
            'address_neighborhood'=>sanitize_text_field($_POST['address_neighborhood']??''),'address_city'=>sanitize_text_field($_POST['address_city']??''),
            'address_state'=>sanitize_text_field($_POST['address_state']??''),
            'responsible_name'=>$type==='pj'?sanitize_text_field($_POST['responsible_name']??''):'',
            'responsible_role'=>$type==='pj'?sanitize_text_field($_POST['responsible_role']??''):'',
            'responsible_cpf'=>$type==='pj'?sanitize_text_field($_POST['responsible_cpf']??''):'',
            'responsible_rg'=>$type==='pj'?sanitize_text_field($_POST['responsible_rg']??''):'',
            'responsible_birth_date'=>$type==='pj'?$this->date($_POST['responsible_birth_date']??''):null,
            'responsible_email'=>$type==='pj'?sanitize_email($_POST['responsible_email']??''):'',
            'responsible_phone'=>$type==='pj'?sanitize_text_field($_POST['responsible_phone']??''):'',
            'responsible_whatsapp'=>$type==='pj'?sanitize_text_field($_POST['responsible_whatsapp']??''):'',
            'responsible_nationality'=>$type==='pj'?sanitize_text_field($_POST['responsible_nationality']??''):'',
            'responsible_marital_status'=>$type==='pj'?sanitize_text_field($_POST['responsible_marital_status']??''):'',
            'responsible_profession'=>$type==='pj'?sanitize_text_field($_POST['responsible_profession']??''):'',
            'notes'=>sanitize_textarea_field($_POST['notes']??''),'status'=>sanitize_key($_POST['status']??'active'),
            'updated_by'=>get_current_user_id(),'updated_at'=>$now
        ];
        if($type==='pj'&&empty($d['responsible_name']))$this->go('vfos-clients','Para pessoa jurídica, informe o responsável pela empresa.');
        if($id){$wpdb->update($t,$d,['id'=>$id]);}else{$d['created_by']=get_current_user_id();$d['created_at']=$now;$wpdb->insert($t,$d);$id=$wpdb->insert_id;}
        $after=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id),ARRAY_A);
        $label=$type==='pj'?($trade?:$legal?:$name):$name;
        VFOS_DB::log('save_client','client',$id,$id&&$before?'Cadastro atualizado':'Cliente cadastrado',$before,$after,$label);
        $this->go('vfos-clients',$before?'Cliente atualizado com sucesso.':'Cliente cadastrado com sucesso.');
    }
    public function save_service(){check_admin_referer('vfos_save_service');VFOS_Team::require_permission('services.create');global $wpdb;$now=current_time('mysql');$wpdb->insert(VFOS_DB::table('services'),['name'=>sanitize_text_field($_POST['name']??''),'description'=>sanitize_textarea_field($_POST['description']??''),'price'=>(float)($_POST['price']??0),'status'=>'active','created_at'=>$now,'updated_at'=>$now]);$this->go('vfos-services');}
    public function save_project(){check_admin_referer('vfos_save_project');$project_save_id=absint($_POST['id']??0);VFOS_Team::require_permission($project_save_id?'projects.edit':'projects.create');if(VFOS_Team::limited_to_assigned())wp_die('Seu perfil não permite criar ou editar projetos.');global $wpdb;$t=VFOS_DB::table('projects');$id=absint($_POST['id']??0);$d=['client_id'=>absint($_POST['client_id']??0),'service_id'=>absint($_POST['service_id']??0),'name'=>sanitize_text_field($_POST['name']??''),'status'=>sanitize_key($_POST['status']??'planning'),'priority'=>sanitize_key($_POST['priority']??'normal'),'value'=>(float)($_POST['value']??0),'due_date'=>$this->date($_POST['due_date']??''),'progress'=>min(100,max(0,absint($_POST['progress']??0))),'notes'=>sanitize_textarea_field($_POST['notes']??''),'flow_create_financial'=>!empty($_POST['flow_create_financial'])?1:0,'updated_at'=>current_time('mysql')];if($id)$wpdb->update($t,$d,['id'=>$id]);else{$d['created_at']=current_time('mysql');$wpdb->insert($t,$d);$id=$wpdb->insert_id;$template_id=absint($_POST['template_id']??0);if($template_id)$this->apply_template_items($id,$template_id);}VFOS_DB::log('save_project','project',$id);if(!empty($d['flow_create_financial']))VFOS_Workflow::project_to_financial($id);if(!$id)$this->go('vfos-projects');wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$id));exit;}
    public function save_project_template(){
        $this->guard('vfos_save_project_template');global $wpdb;$t=VFOS_DB::table('project_templates');$it=VFOS_DB::table('project_template_items');$id=absint($_POST['id']??0);
        $d=['name'=>sanitize_text_field($_POST['name']??''),'description'=>sanitize_textarea_field($_POST['description']??''),'service_id'=>absint($_POST['service_id']??0),'default_duration'=>max(1,absint($_POST['default_duration']??30)),'default_priority'=>sanitize_key($_POST['default_priority']??'normal'),'default_value'=>(float)($_POST['default_value']??0),'status'=>sanitize_key($_POST['status']??'active'),'updated_at'=>current_time('mysql')];
        if($id)$wpdb->update($t,$d,['id'=>$id]);else{$d['created_at']=current_time('mysql');$wpdb->insert($t,$d);$id=$wpdb->insert_id;}
        $wpdb->delete($it,['template_id'=>$id]);$items=$_POST['items']??[];$order=0;
        foreach($items as $x){$title=sanitize_text_field($x['title']??'');if(!$title)continue;$wpdb->insert($it,['template_id'=>$id,'title'=>$title,'item_type'=>sanitize_key($x['item_type']??'task'),'description'=>sanitize_text_field($x['description']??''),'day_offset'=>max(0,absint($x['day_offset']??0)),'priority'=>sanitize_key($x['priority']??'normal'),'sort_order'=>$order++,'created_at'=>current_time('mysql')]);}
        VFOS_DB::log('save_project_template','project_template',$id);$this->go('vfos-project-templates');
    }
    public function delete_project_template(){
        if(!VFOS_Team::can_permission('projects.edit'))wp_die('Sem permissão.');check_admin_referer('vfos_delete_project_template');global $wpdb;$id=absint($_GET['id']??0);$wpdb->delete(VFOS_DB::table('project_template_items'),['template_id'=>$id]);$wpdb->delete(VFOS_DB::table('project_templates'),['id'=>$id]);VFOS_DB::log('delete_project_template','project_template',$id);$this->go('vfos-project-templates');
    }
    private function apply_template_items($project_id,$template_id){
        global $wpdb;$project_id=absint($project_id);$template_id=absint($template_id);if(!$project_id||!$template_id)return;
        $p=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('projects')." WHERE id=%d",$project_id));if(!$p)return;
        $items=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_template_items')." WHERE template_id=%d ORDER BY sort_order,id",$template_id));$tt=VFOS_DB::table('tasks');
        foreach($items as $x){$due=$p->created_at?date('Y-m-d',strtotime($p->created_at.' +'.(int)$x->day_offset.' days')):null;$prefix=$x->item_type==='milestone'?'Etapa: ':($x->item_type==='approval'?'Aprovação: ':'');$wpdb->insert($tt,['project_id'=>$project_id,'client_id'=>$p->client_id,'title'=>$prefix.$x->title,'description'=>$x->description,'status'=>'pending','priority'=>$x->priority,'start_date'=>$due,'due_date'=>$due,'assigned_user_id'=>0,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);}$this->recalc_project_progress($project_id);
        VFOS_DB::log('apply_project_template','project',$project_id,'template='.$template_id);
    }
    public function apply_project_template(){
        if(!VFOS_Team::can_permission('projects.edit'))wp_die('Sem permissão.');check_admin_referer('vfos_apply_project_template');$project=absint($_POST['project_id']??0);$template=absint($_POST['template_id']??0);$this->apply_template_items($project,$template);wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project));exit;
    }

    private function recalc_project_progress($project_id){
        global $wpdb;$project_id=absint($project_id);if(!$project_id)return 0;
        $tt=VFOS_DB::table('tasks');$pt=VFOS_DB::table('projects');
        $total=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE project_id=%d AND status<>'cancelled'",$project_id));
        $done=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tt WHERE project_id=%d AND status='done'",$project_id));
        $progress=$total?(int)round(($done/$total)*100):0;
        $wpdb->update($pt,['progress'=>$progress,'updated_at'=>current_time('mysql')],['id'=>$project_id]);
        return $progress;
    }
    public function ajax_task_status(){
        if(!VFOS_Team::can_permission('tasks.status'))wp_send_json_error(['message'=>'Sem permissão.'],403);
        check_ajax_referer('vfos_task_status','nonce');global $wpdb;
        $id=absint($_POST['task_id']??0);$status=sanitize_key($_POST['status']??'');
        if(!$id||!in_array($status,['pending','in_progress','review','done'],true))wp_send_json_error(['message'=>'Dados inválidos.']);
        $t=VFOS_DB::table('tasks');$task=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));
        if(!$task)wp_send_json_error(['message'=>'Tarefa não encontrada.'],404);
        $wpdb->update($t,['status'=>$status,'updated_at'=>current_time('mysql')],['id'=>$id]);
        $progress=$this->recalc_project_progress($task->project_id);
        VFOS_DB::log('task_status','task',$id,$status);
        wp_send_json_success(['progress'=>$progress,'status'=>$status]);
    }
    public function save_project_comment(){
        $this->guard('vfos_save_project_comment');global $wpdb;$project=absint($_POST['project_id']??0);$content=sanitize_textarea_field($_POST['content']??'');
        if($project&&$content)$wpdb->insert(VFOS_DB::table('project_comments'),['project_id'=>$project,'task_id'=>absint($_POST['task_id']??0),'user_id'=>get_current_user_id(),'content'=>$content,'created_at'=>current_time('mysql')]);
        VFOS_DB::log('project_comment','project',$project);
        if($project&&$content){$users=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT assigned_user_id FROM ".VFOS_DB::table('tasks')." WHERE project_id=%d AND assigned_user_id>0 AND assigned_user_id<>%d",$project,get_current_user_id()));foreach($users as $u)VFOS_Notifications::notify($u,'comment','Novo comentário em projeto',wp_trim_words($content,18),'projects','project',$project,admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=files'));VFOS_Notifications::activity('project_comment','Novo comentário no projeto',wp_trim_words($content,18),'projects','project',$project,admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=files'));}
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=files'));exit;
    }
    public function upload_project_file(){
        $this->guard('vfos_upload_project_file');global $wpdb;$project=absint($_POST['project_id']??0);
        if(!$project||empty($_FILES['project_file']['name'])){wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=files'));exit;}
        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
        $attachment=media_handle_upload('project_file',0);
        if(!is_wp_error($attachment)){
            $url=wp_get_attachment_url($attachment);$mime=get_post_mime_type($attachment);
            $wpdb->insert(VFOS_DB::table('project_files'),['project_id'=>$project,'task_id'=>absint($_POST['task_id']??0),'attachment_id'=>$attachment,'title'=>sanitize_text_field($_POST['title']??'')?:get_the_title($attachment),'file_url'=>$url,'mime_type'=>$mime,'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
            VFOS_DB::log('project_file','project',$project,'attachment='.$attachment);
        }
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=files'));exit;
    }
    public function delete_project_file(){
        if(!VFOS_Team::can_permission('projects.files'))wp_die('Sem permissão.');check_admin_referer('vfos_delete_project_file');global $wpdb;
        $id=absint($_GET['id']??0);$project=absint($_GET['project_id']??0);$wpdb->delete(VFOS_DB::table('project_files'),['id'=>$id]);
        VFOS_DB::log('delete_project_file','project',$project,'file='.$id);wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project.'&tab=files'));exit;
    }
    public function add_checklist_item(){
        $this->guard('vfos_add_checklist_item');global $wpdb;$task=absint($_POST['task_id']??0);$project=absint($_POST['project_id']??0);$title=sanitize_text_field($_POST['title']??'');
        if($task&&$title){$sort=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(MAX(sort_order),-1)+1 FROM ".VFOS_DB::table('task_checklist')." WHERE task_id=%d",$task));$wpdb->insert(VFOS_DB::table('task_checklist'),['task_id'=>$task,'title'=>$title,'is_done'=>0,'sort_order'=>$sort,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);}
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project));exit;
    }
    public function toggle_checklist_item(){
        if(!VFOS_Team::can_permission('tasks.checklist'))wp_die('Sem permissão.');check_admin_referer('vfos_toggle_checklist_item');global $wpdb;
        $id=absint($_GET['id']??0);$project=absint($_GET['project_id']??0);$table=VFOS_DB::table('task_checklist');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$id));
        if($row)$wpdb->update($table,['is_done'=>$row->is_done?0:1,'updated_at'=>current_time('mysql')],['id'=>$id]);
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project));exit;
    }
    public function delete_checklist_item(){
        if(!VFOS_Team::can_permission('tasks.checklist'))wp_die('Sem permissão.');check_admin_referer('vfos_delete_checklist_item');global $wpdb;
        $id=absint($_GET['id']??0);$project=absint($_GET['project_id']??0);$wpdb->delete(VFOS_DB::table('task_checklist'),['id'=>$id]);
        wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project));exit;
    }

    public function save_task(){check_admin_referer('vfos_save_task');$id=absint($_POST['id']??0);VFOS_Team::require_permission($id?'tasks.edit':'tasks.create');global $wpdb;$t=VFOS_DB::table('tasks');$old=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id)):null;$project_id=absint($_POST['project_id']??0);$assigned_user_id=absint($_POST['assigned_user_id']??0);
        if($old && (int)$old->assigned_user_id!==$assigned_user_id && !VFOS_Team::can_permission('tasks.transfer'))wp_die('Você não possui permissão para transferir tarefas para outro usuário.');
        if(VFOS_Team::limited_to_assigned()){$assigned_user_id=get_current_user_id();if($project_id){$allowed=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE project_id=%d AND assigned_user_id=%d",$project_id,get_current_user_id()));if(!$allowed && !$id)wp_die('Você não pode criar tarefas em um projeto que não está atribuído a você.');}}$d=['project_id'=>$project_id,'client_id'=>absint($_POST['client_id']??0),'stage_id'=>absint($_POST['stage_id']??0),'depends_on_task_id'=>absint($_POST['depends_on_task_id']??0),'estimated_hours'=>max(0,(float)($_POST['estimated_hours']??0)),'actual_hours'=>max(0,(float)($_POST['actual_hours']??0)),'title'=>sanitize_text_field($_POST['title']??''),'description'=>sanitize_textarea_field($_POST['description']??''),'status'=>sanitize_key($_POST['status']??'pending'),'priority'=>sanitize_key($_POST['priority']??'normal'),'start_date'=>$this->date($_POST['start_date']??''),'due_date'=>$this->date($_POST['due_date']??''),'assigned_user_id'=>$assigned_user_id,'updated_at'=>current_time('mysql')];if($id)$wpdb->update($t,$d,['id'=>$id]);else{$d['created_at']=current_time('mysql');$wpdb->insert($t,$d);$id=$wpdb->insert_id;}if($old&&$old->project_id&&$old->project_id!=$project_id)$this->recalc_project_progress($old->project_id);if($project_id)$this->recalc_project_progress($project_id);VFOS_DB::log('save_task','task',$id);
        $task_url=admin_url('admin.php?page=vfos-tasks&tab=new&edit='.$id);
        if($old && (int)$old->assigned_user_id!==$assigned_user_id){
            $from=$old->assigned_user_id?get_userdata((int)$old->assigned_user_id):null;$to=$assigned_user_id?get_userdata($assigned_user_id):null;
            VFOS_DB::log('task_transfer','task',$id,'Tarefa transferida de '.($from?$from->display_name:'Não atribuído').' para '.($to?$to->display_name:'Não atribuído'),['assigned_user_id'=>(int)$old->assigned_user_id],['assigned_user_id'=>$assigned_user_id],$d['title']);
            VFOS_Notifications::activity('task_transferred','Tarefa transferida',$d['title'].' → '.($to?$to->display_name:'Não atribuído'),'tasks','task',$id,$task_url);
        }
        VFOS_Notifications::activity($old?'task_updated':'task_created',$old?'Tarefa atualizada':'Nova tarefa criada',$d['title'],'tasks','task',$id,$task_url);
        if($assigned_user_id && (!$old || (int)$old->assigned_user_id!==$assigned_user_id)) VFOS_Notifications::notify($assigned_user_id,'task','Nova tarefa atribuída a você',$d['title'].($d['due_date']?' • prazo '.date_i18n('d/m/Y',strtotime($d['due_date'])):''),'tasks','task',$id,$task_url);
        if($old && (int)$old->assigned_user_id && (int)$old->assigned_user_id!==$assigned_user_id) VFOS_Notifications::notify((int)$old->assigned_user_id,'task','Tarefa transferida',$d['title'].' foi transferida para outro responsável.','tasks','task',$id,$task_url,get_current_user_id(),'personal','',0);
        if($project_id){wp_safe_redirect(admin_url('admin.php?page=vfos-project-view&id='.$project_id));exit;}$this->go('vfos-tasks');}
    public function save_quote(){
        check_admin_referer('vfos_save_quote');
        $id=absint($_POST['id']??0);
        VFOS_Team::require_permission($id?'quotes.edit':'quotes.create');
        global $wpdb;

        $t=VFOS_DB::table('quotes');
        $it=VFOS_DB::table('quote_items');
        $st=VFOS_DB::table('quote_sections');
        $ct=VFOS_DB::table('quote_costs');
        $cot=VFOS_DB::table('quote_cost_options');
        $pt=VFOS_DB::table('quote_payment_options');
        $now=current_time('mysql');
        $original_id=$id;

        // Mantém uma cópia temporária do formulário até o COMMIT. Se algo der
        // errado, o registro antigo permanece intacto e o navegador pode voltar
        // ao formulário sem que o sistema tenha apagado dados já existentes.
        $recovery_key='_vfos_quote_recovery_'.get_current_user_id();
        update_option($recovery_key,[
            'created_at'=>$now,
            'quote_id'=>$id,
            'payload'=>wp_json_encode(wp_unslash($_POST),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)
        ],false);

        try{
            $client_id=absint($_POST['client_id']??0);
            $title=sanitize_text_field(wp_unslash($_POST['title']??''));
            if($client_id&&!(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('clients')." WHERE id=%d",$client_id)))throw new Exception('O cliente selecionado não é válido.');
            if(!$title)throw new Exception('Informe o título do orçamento.');

            $items_raw=is_array($_POST['items']??null)?wp_unslash($_POST['items']):[];
            $clean=[];$subtotal=0.0;$order=0;
            foreach($items_raw as $x){
                if(!is_array($x))continue;
                $item_title=sanitize_text_field($x['title']??'');
                if($item_title==='')continue;
                $qty=max(0.01,$this->decimal($x['quantity']??1));
                $unit=max(0,$this->decimal($x['unit_price']??0));
                $line=round($qty*$unit,2);
                $subtotal=round($subtotal+$line,2);
                $clean[]=[
                    'service_id'=>absint($x['service_id']??0),
                    'title'=>$item_title,
                    'description'=>sanitize_textarea_field($x['description']??''),
                    'quantity'=>$qty,'unit_price'=>$unit,'total'=>$line,
                    'sort_order'=>$order++,'created_at'=>$now
                ];
            }
            if(!$clean)throw new Exception('Adicione pelo menos um item da VisionForge ao orçamento.');

            $sections=[];$order=0;
            foreach((array)wp_unslash($_POST['sections']??[]) as $x){
                if(!is_array($x))continue;
                $stitle=sanitize_text_field($x['title']??'');
                $content=sanitize_textarea_field($x['content']??'');
                if(!$stitle&&!$content)continue;
                $sections[]=['title'=>$stitle?:'Informações','content'=>$content,'section_type'=>sanitize_key($x['section_type']??'custom'),'sort_order'=>$order++,'created_at'=>$now];
            }

            $costs=[];$order=0;
            foreach((array)wp_unslash($_POST['costs']??[]) as $x){
                if(!is_array($x))continue;
                $ctitle=sanitize_text_field($x['title']??'');
                if(!$ctitle)continue;
                $options=[];$oorder=0;
                foreach((array)($x['options']??[]) as $o){
                    if(!is_array($o))continue;
                    $otitle=sanitize_text_field($o['title']??'');
                    if(!$otitle)continue;
                    $cycle=sanitize_key($o['billing_cycle']??'monthly');
                    if(!in_array($cycle,['one_time','monthly','quarterly','semiannual','annual','biennial','variable'],true))$cycle='monthly';
                    $options[]=[
                        'title'=>$otitle,'amount'=>max(0,$this->decimal($o['amount']??0)),
                        'billing_cycle'=>$cycle,'duration_months'=>max(1,min(120,absint($o['duration_months']??1))),
                        'condition_text'=>sanitize_textarea_field($o['condition_text']??''),
                        'benefits'=>sanitize_textarea_field($o['benefits']??''),
                        'highlight'=>empty($o['highlight'])?0:1,'sort_order'=>$oorder++,'created_at'=>$now
                    ];
                }
                if(!$options)$options[]=['title'=>'Opção principal','amount'=>0,'billing_cycle'=>'variable','duration_months'=>1,'condition_text'=>'Valor a consultar','benefits'=>'','highlight'=>0,'sort_order'=>0,'created_at'=>$now];
                $positive=array_values(array_filter($options,fn($o)=>(float)$o['amount']>0));
                $base=$positive?$positive[0]:$options[0];
                foreach($positive as $po)if((float)$po['amount']<(float)$base['amount'])$base=$po;
                $costs[]=[
                    'row'=>[
                        'title'=>$ctitle,'description'=>sanitize_textarea_field($x['description']??''),
                        'provider'=>sanitize_text_field($x['provider']??''),
                        'amount'=>(float)$base['amount'],'billing_cycle'=>$base['billing_cycle'],
                        'is_external'=>1,'is_required'=>empty($x['is_required'])?0:1,
                        'sort_order'=>$order++,'created_at'=>$now
                    ],
                    'options'=>$options
                ];
            }

            $payments=[];$order=0;
            foreach((array)wp_unslash($_POST['payments']??[]) as $x){
                if(!is_array($x))continue;
                $ptitle=sanitize_text_field($x['title']??'');
                if(!$ptitle)continue;
                $cycle=sanitize_key($x['billing_cycle']??'one_time');
                if(!in_array($cycle,['one_time','monthly','annual','recurring'],true))$cycle='one_time';
                $payments[]=[
                    'title'=>$ptitle,'description'=>sanitize_textarea_field($x['description']??''),
                    'amount'=>max(0,$this->decimal($x['amount']??0)),'billing_cycle'=>$cycle,
                    'installments'=>max(1,min(36,absint($x['installments']??1))),
                    'highlight'=>empty($x['highlight'])?0:1,'sort_order'=>$order++,'created_at'=>$now
                ];
            }

            $dtype=sanitize_key($_POST['discount_type']??'fixed');
            if(!in_array($dtype,['fixed','percent'],true))$dtype='fixed';
            $dvalue=max(0,$this->decimal($_POST['discount_value']??0));
            $damount=$dtype==='percent'?round($subtotal*min(100,$dvalue)/100,2):min($subtotal,$dvalue);
            $total=max(0,round($subtotal-$damount,2));
            $status=sanitize_key($_POST['status']??'draft');
            if(!in_array($status,['draft','sent','accepted','rejected'],true))$status='draft';

            $old=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id)):null;
            if($id&&!$old)throw new Exception('Orçamento não encontrado.');
            $token=$old&&$old->public_token?$old->public_token:wp_generate_password(40,false,false);

            $vis_raw=is_array($_POST['proposal_visibility']??null)?wp_unslash($_POST['proposal_visibility']):[];
            $allowed_order=['custom_sections','deliverables','external_costs','payment_options','summary','company_info'];
            $requested_order=array_values(array_unique(array_map('sanitize_key',(array)($_POST['proposal_order']??[]))));
            $proposal_order=[];
            foreach($requested_order as $key)if(in_array($key,$allowed_order,true))$proposal_order[]=$key;
            foreach($allowed_order as $key)if(!in_array($key,$proposal_order,true))$proposal_order[]=$key;
            $proposal_visibility=wp_json_encode([
                'custom_sections'=>empty($vis_raw['custom_sections'])?0:1,
                'external_costs'=>empty($vis_raw['external_costs'])?0:1,
                'payment_options'=>empty($vis_raw['payment_options'])?0:1,
                'company_info'=>empty($vis_raw['company_info'])?0:1,
                'order'=>$proposal_order
            ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            if($proposal_visibility===false)throw new Exception('Não foi possível preparar a configuração visual da proposta.');

            $d=[
                'client_id'=>$client_id,'title'=>$title,
                'description'=>sanitize_textarea_field(wp_unslash($_POST['description']??'')),
                'subtotal'=>$subtotal,'discount_type'=>$dtype,'discount_value'=>$dvalue,
                'discount_amount'=>$damount,'total'=>$total,
                'payment_terms'=>sanitize_textarea_field(wp_unslash($_POST['payment_terms']??'')),
                'valid_until'=>$this->date($_POST['valid_until']??''),
                'notes'=>sanitize_textarea_field(wp_unslash($_POST['notes']??'')),
                'status'=>$status,'public_token'=>$token,
                'proposal_visibility'=>$proposal_visibility,'updated_at'=>$now
            ];

            // Tudo abaixo faz parte de uma única operação. Se qualquer INSERT,
            // UPDATE ou DELETE falhar, o ROLLBACK restaura o estado anterior.
            $wpdb->query('START TRANSACTION');

            if($id){
                $result=$wpdb->update($t,$d,['id'=>$id]);
                if($result===false)throw new Exception('Falha ao salvar os dados principais: '.($wpdb->last_error?:'erro desconhecido no banco.'));
            }else{
                $d['number']=VFOS_DB::next_number('quote');
                $d['created_at']=$now;
                if(!$wpdb->insert($t,$d))throw new Exception('Falha ao criar o orçamento: '.($wpdb->last_error?:'erro desconhecido no banco.'));
                $id=(int)$wpdb->insert_id;
                if(!$id)throw new Exception('O banco não retornou o identificador do novo orçamento.');
            }

            $old_cost_ids=array_map('absint',$wpdb->get_col($wpdb->prepare("SELECT id FROM $ct WHERE quote_id=%d",$id)));
            if($wpdb->last_error)throw new Exception('Falha ao consultar custos anteriores: '.$wpdb->last_error);
            if($old_cost_ids){
                $result=$wpdb->query("DELETE FROM $cot WHERE cost_id IN (".implode(',',$old_cost_ids).")");
                if($result===false)throw new Exception('Falha ao atualizar opções de custos externos: '.($wpdb->last_error?:'erro no banco.'));
            }

            foreach([$it,$st,$ct,$pt] as $table){
                $result=$wpdb->delete($table,['quote_id'=>$id]);
                if($result===false)throw new Exception('Falha ao preparar uma área complementar da proposta: '.($wpdb->last_error?:'erro no banco.'));
            }

            foreach($clean as $row){
                $row['quote_id']=$id;
                if(!$wpdb->insert($it,$row))throw new Exception('Falha ao salvar item “'.$row['title'].'”: '.($wpdb->last_error?:'erro no banco.'));
            }
            foreach($sections as $row){
                $row['quote_id']=$id;
                if(!$wpdb->insert($st,$row))throw new Exception('Falha ao salvar a seção “'.$row['title'].'”: '.($wpdb->last_error?:'erro no banco.'));
            }
            foreach($costs as $cost){
                $row=$cost['row'];$row['quote_id']=$id;
                if(!$wpdb->insert($ct,$row))throw new Exception('Falha ao salvar o custo externo “'.$row['title'].'”: '.($wpdb->last_error?:'erro no banco.'));
                $cost_id=(int)$wpdb->insert_id;
                foreach($cost['options'] as $option){
                    $option['cost_id']=$cost_id;
                    if(!$wpdb->insert($cot,$option))throw new Exception('Falha ao salvar o plano “'.$option['title'].'”: '.($wpdb->last_error?:'erro no banco.'));
                }
            }
            foreach($payments as $row){
                $row['quote_id']=$id;
                if(!$wpdb->insert($pt,$row))throw new Exception('Falha ao salvar a forma de pagamento “'.$row['title'].'”: '.($wpdb->last_error?:'erro no banco.'));
            }

            if($status==='accepted'&&$client_id&&(!$old||$old->status!=='accepted')){
                $result=$wpdb->update($t,['decided_at'=>$now],['id'=>$id]);
                if($result===false)throw new Exception('Falha ao registrar o aceite da proposta: '.($wpdb->last_error?:'erro no banco.'));
            }

            $wpdb->query('COMMIT');
            if($wpdb->last_error)throw new Exception('O banco não confirmou a gravação completa: '.$wpdb->last_error);

            // Só converte após o COMMIT para não misturar criação de projeto/
            // contrato/financeiro com a transação principal do orçamento.
            if($status==='accepted'&&$client_id&&(!$old||$old->status!=='accepted'))VFOS_Proposal::convert_accepted_quote($id);

            delete_option($recovery_key);
            $after=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id),ARRAY_A);
            VFOS_DB::log('save_quote','quote',$id,'Orçamento salvo integralmente | Total VisionForge: R$ '.number_format($total,2,',','.'),$old?(array)$old:null,$after,$d['number']??($old->number??$title));

            wp_safe_redirect(admin_url('admin.php?page=vfos-quotes&tab=new&edit='.$id.'&vfos_msg='.rawurlencode('Orçamento salvo por completo com sucesso.')));exit;

        }catch(Throwable $ex){
            $wpdb->query('ROLLBACK');
            $error=trim($ex->getMessage())?:($wpdb->last_error?:'Erro desconhecido ao salvar.');
            VFOS_DB::log('quote_save_error','quote',$original_id,'ROLLBACK executado | '.$error,null,['quote_id'=>$original_id,'recovery_key'=>$recovery_key],sanitize_text_field(wp_unslash($_POST['title']??'Orçamento')));

            // Não redireciona para uma tela vazia: exibe o erro mantendo o
            // histórico do navegador, de modo que “Voltar” recupere o formulário.
            wp_die(
                '<h1>O orçamento não foi alterado</h1>'.
                '<p><strong>Motivo:</strong> '.esc_html($error).'</p>'.
                '<p>Nenhuma alteração parcial foi mantida. Se era um orçamento já existente, a versão anterior continua intacta.</p>'.
                '<p><a href="javascript:history.back()" class="button button-primary">Voltar ao orçamento preenchido</a></p>',
                'VisionForge OS — Falha ao salvar orçamento',
                ['response'=>500,'back_link'=>true]
            );
        }
    }

    public function save_quote_template(){
        $quote_id=absint($_POST['quote_id']??0);check_admin_referer('vfos_save_quote_template_'.$quote_id);VFOS_Team::require_permission('quotes.templates');global $wpdb;
        $q=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quotes')." WHERE id=%d",$quote_id),ARRAY_A);if(!$q)wp_die('Orçamento não encontrado.');
        $name=sanitize_text_field($_POST['template_name']??'');if(!$name)wp_die('Informe o nome do modelo.');$description=sanitize_text_field($_POST['template_description']??'');
        foreach(['id','client_id','number','public_token','status','sent_at','decided_at','decision_ip','converted_project_id','converted_contract_id','converted_financial_id','created_at','updated_at'] as $f)unset($q[$f]);
        $template_costs=$wpdb->get_results($wpdb->prepare("SELECT id,title,description,provider,amount,billing_cycle,is_required FROM ".VFOS_DB::table('quote_costs')." WHERE quote_id=%d ORDER BY sort_order,id",$quote_id),ARRAY_A);
        foreach($template_costs as &$tc){$tc['options']=$wpdb->get_results($wpdb->prepare("SELECT title,amount,billing_cycle,duration_months,condition_text,benefits,highlight FROM ".VFOS_DB::table('quote_cost_options')." WHERE cost_id=%d ORDER BY sort_order,id",$tc['id']),ARRAY_A);unset($tc['id']);}unset($tc);
        $data=['quote'=>$q,'items'=>$wpdb->get_results($wpdb->prepare("SELECT service_id,title,description,quantity,unit_price FROM ".VFOS_DB::table('quote_items')." WHERE quote_id=%d ORDER BY sort_order,id",$quote_id),ARRAY_A),'sections'=>$wpdb->get_results($wpdb->prepare("SELECT title,content,section_type FROM ".VFOS_DB::table('quote_sections')." WHERE quote_id=%d ORDER BY sort_order,id",$quote_id),ARRAY_A),'costs'=>$template_costs,'payments'=>$wpdb->get_results($wpdb->prepare("SELECT title,description,amount,billing_cycle,installments,highlight FROM ".VFOS_DB::table('quote_payment_options')." WHERE quote_id=%d ORDER BY sort_order,id",$quote_id),ARRAY_A)];
        $json=wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if($json===false)wp_die('Não foi possível preparar os dados do modelo para salvamento.');
        $t=VFOS_DB::table('quote_templates');$now=current_time('mysql');
        $ok=$wpdb->insert($t,['name'=>$name,'description'=>$description,'data_json'=>$json,'status'=>'active','created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now]);
        $id=$wpdb->insert_id;
        if(!$ok||!$id)wp_die('Não foi possível salvar o modelo: '.esc_html($wpdb->last_error?:'o banco de dados recusou a gravação.'));VFOS_DB::log('save_quote_template','quote_template',$id,'Criado a partir de '.$quote_id,null,null,$name);
        wp_safe_redirect(admin_url('admin.php?page=vfos-quotes&tab=templates&vfos_msg='.rawurlencode('Modelo salvo com sucesso.')));exit;
    }

    public function update_quote_template(){
        check_admin_referer('vfos_update_quote_template');
        VFOS_Team::require_permission('quotes.templates');
        global $wpdb;

        $id=absint($_POST['template_id']??0);
        $t=VFOS_DB::table('quote_templates');
        $old=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));
        if(!$old)wp_die('Modelo de orçamento não encontrado.');

        $name=sanitize_text_field(wp_unslash($_POST['template_name']??''));
        $template_description=sanitize_text_field(wp_unslash($_POST['template_description']??''));
        $title=sanitize_text_field(wp_unslash($_POST['title']??''));
        if(!$name)wp_die('Informe o nome do modelo.');
        if(!$title)wp_die('Informe o título da proposta do modelo.');

        $items=[];$order=0;
        foreach((array)wp_unslash($_POST['items']??[]) as $x){
            if(!is_array($x))continue;
            $item_title=sanitize_text_field($x['title']??'');
            if(!$item_title)continue;
            $items[]=[
                'service_id'=>absint($x['service_id']??0),
                'title'=>$item_title,
                'description'=>sanitize_textarea_field($x['description']??''),
                'quantity'=>max(0.01,$this->decimal($x['quantity']??1)),
                'unit_price'=>max(0,$this->decimal($x['unit_price']??0)),
                'sort_order'=>$order++
            ];
        }
        if(!$items)wp_die('O modelo precisa ter pelo menos um serviço ou entregável.');

        $sections=[];$order=0;
        foreach((array)wp_unslash($_POST['sections']??[]) as $x){
            if(!is_array($x))continue;
            $stitle=sanitize_text_field($x['title']??'');
            $content=sanitize_textarea_field($x['content']??'');
            if(!$stitle&&!$content)continue;
            $sections[]=[
                'title'=>$stitle?:'Informações',
                'content'=>$content,
                'section_type'=>sanitize_key($x['section_type']??'custom'),
                'sort_order'=>$order++
            ];
        }

        $costs=[];$order=0;
        foreach((array)wp_unslash($_POST['costs']??[]) as $x){
            if(!is_array($x))continue;
            $ctitle=sanitize_text_field($x['title']??'');
            if(!$ctitle)continue;
            $options=[];$oorder=0;
            foreach((array)($x['options']??[]) as $o){
                if(!is_array($o))continue;
                $otitle=sanitize_text_field($o['title']??'');
                if(!$otitle)continue;
                $cycle=sanitize_key($o['billing_cycle']??'monthly');
                if(!in_array($cycle,['one_time','monthly','quarterly','semiannual','annual','biennial','variable'],true))$cycle='monthly';
                $options[]=[
                    'title'=>$otitle,
                    'amount'=>max(0,$this->decimal($o['amount']??0)),
                    'billing_cycle'=>$cycle,
                    'duration_months'=>max(1,min(120,absint($o['duration_months']??1))),
                    'condition_text'=>sanitize_textarea_field($o['condition_text']??''),
                    'benefits'=>sanitize_textarea_field($o['benefits']??''),
                    'highlight'=>empty($o['highlight'])?0:1,
                    'sort_order'=>$oorder++
                ];
            }
            $costs[]=[
                'title'=>$ctitle,
                'description'=>sanitize_textarea_field($x['description']??''),
                'provider'=>sanitize_text_field($x['provider']??''),
                'amount'=>0,
                'billing_cycle'=>'variable',
                'is_required'=>empty($x['is_required'])?0:1,
                'sort_order'=>$order++,
                'options'=>$options
            ];
        }

        $payments=[];$order=0;
        foreach((array)wp_unslash($_POST['payments']??[]) as $x){
            if(!is_array($x))continue;
            $ptitle=sanitize_text_field($x['title']??'');
            if(!$ptitle)continue;
            $cycle=sanitize_key($x['billing_cycle']??'one_time');
            if(!in_array($cycle,['one_time','monthly','annual','recurring'],true))$cycle='one_time';
            $payments[]=[
                'title'=>$ptitle,
                'description'=>sanitize_textarea_field($x['description']??''),
                'amount'=>max(0,$this->decimal($x['amount']??0)),
                'billing_cycle'=>$cycle,
                'installments'=>max(1,min(36,absint($x['installments']??1))),
                'highlight'=>empty($x['highlight'])?0:1,
                'sort_order'=>$order++
            ];
        }

        $vis_raw=is_array($_POST['proposal_visibility']??null)?wp_unslash($_POST['proposal_visibility']):[];
        $allowed_order=['custom_sections','deliverables','external_costs','payment_options','summary','company_info'];
        $requested_order=array_values(array_unique(array_map('sanitize_key',(array)($_POST['proposal_order']??[]))));
        $proposal_order=[];
        foreach($requested_order as $key)if(in_array($key,$allowed_order,true))$proposal_order[]=$key;
        foreach($allowed_order as $key)if(!in_array($key,$proposal_order,true))$proposal_order[]=$key;
        $proposal_visibility=wp_json_encode([
            'custom_sections'=>empty($vis_raw['custom_sections'])?0:1,
            'external_costs'=>empty($vis_raw['external_costs'])?0:1,
            'payment_options'=>empty($vis_raw['payment_options'])?0:1,
            'company_info'=>empty($vis_raw['company_info'])?0:1,
            'order'=>$proposal_order
        ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

        $quote=[
            'title'=>$title,
            'description'=>sanitize_textarea_field(wp_unslash($_POST['description']??'')),
            'discount_type'=>in_array(sanitize_key($_POST['discount_type']??'fixed'),['fixed','percent'],true)?sanitize_key($_POST['discount_type']??'fixed'):'fixed',
            'discount_value'=>max(0,$this->decimal($_POST['discount_value']??0)),
            'payment_terms'=>sanitize_textarea_field(wp_unslash($_POST['payment_terms']??'')),
            'valid_until'=>$this->date($_POST['valid_until']??''),
            'notes'=>sanitize_textarea_field(wp_unslash($_POST['notes']??'')),
            'proposal_visibility'=>$proposal_visibility
        ];

        $data=['quote'=>$quote,'items'=>$items,'sections'=>$sections,'costs'=>$costs,'payments'=>$payments];
        $json=wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if($json===false)wp_die('Não foi possível preparar os dados atualizados do modelo.');

        $updated=$wpdb->update($t,[
            'name'=>$name,
            'description'=>$template_description,
            'data_json'=>$json,
            'updated_at'=>current_time('mysql')
        ],['id'=>$id]);

        if($updated===false)wp_die('Não foi possível atualizar o modelo: '.esc_html($wpdb->last_error?:'erro desconhecido no banco.'));
        VFOS_DB::log('save_quote_template','quote_template',$id,'Modelo editado diretamente no editor',(array)$old,['name'=>$name,'description'=>$template_description],$name);

        wp_safe_redirect(admin_url('admin.php?page=vfos-quotes&tab=templates&vfos_msg='.rawurlencode('Modelo atualizado com sucesso.')));exit;
    }

    public function delete_quote_template(){
        $id=absint($_GET['id']??0);check_admin_referer('vfos_delete_quote_template_'.$id);VFOS_Team::require_permission('quotes.templates');global $wpdb;$t=VFOS_DB::table('quote_templates');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));if(!$row)wp_die('Modelo não encontrado.');$wpdb->delete($t,['id'=>$id]);VFOS_DB::log('delete_quote_template','quote_template',$id,'Modelo excluído',(array)$row,null,$row->name);wp_safe_redirect(admin_url('admin.php?page=vfos-quotes&tab=templates&vfos_msg='.rawurlencode('Modelo excluído.')));exit;
    }

    public function send_quote(){
        $this->guard('vfos_send_quote');global $wpdb;$id=absint($_GET['id']??0);
        $q=$wpdb->get_row($wpdb->prepare("SELECT q.*,c.name client_name,c.email client_email FROM ".VFOS_DB::table('quotes')." q LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=q.client_id WHERE q.id=%d",$id));
        if(!$q)$this->go('vfos-quotes','Proposta não encontrada.');
        if(!$q->client_email || !is_email($q->client_email))$this->go('vfos-quotes','O cliente não possui um e-mail válido cadastrado.');
        $url=VFOS_Proposal::url($q);$subject='Proposta '.$q->number.' • VisionForge Digital';
        $message='<div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;color:#17364d"><div style="padding:28px;border-radius:18px;background:linear-gradient(120deg,#eef9ff,#fff7ed)"><h2 style="margin:0 0 8px">Olá, '.esc_html($q->client_name).'.</h2><p>A VisionForge Digital preparou uma proposta para <strong>'.esc_html($q->title).'</strong>.</p><p style="font-size:22px;font-weight:700">R$ '.number_format((float)$q->total,2,',','.').'</p><p><a href="'.esc_url($url).'" style="display:inline-block;background:#078fd6;color:#fff;text-decoration:none;padding:13px 20px;border-radius:10px;font-weight:700">Visualizar proposta</a></p><p style="color:#71818d;font-size:13px">No link você poderá conferir os detalhes e registrar o aceite ou a recusa.</p></div></div>';
        $sent=wp_mail($q->client_email,$subject,$message,['Content-Type: text/html; charset=UTF-8']);
        if($sent){$wpdb->update(VFOS_DB::table('quotes'),['status'=>$q->status==='draft'?'sent':$q->status,'sent_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],['id'=>$id]);VFOS_DB::log('send_quote','quote',$id,$q->client_email);$this->go('vfos-quotes','Proposta enviada para '.$q->client_email.'.');}
        $this->go('vfos-quotes','Não foi possível enviar o e-mail. Verifique a configuração de e-mail do WordPress.');
    }

    public function save_contract(){
        check_admin_referer('vfos_save_contract');$id=absint($_POST['id']??0);VFOS_Team::require_permission($id?'contracts.edit':'contracts.create');global $wpdb;$t=VFOS_DB::table('contracts');$old=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id)):null;$now=current_time('mysql');
        $d=['client_id'=>absint($_POST['client_id']??0),'project_id'=>absint($_POST['project_id']??0),'title'=>sanitize_text_field($_POST['title']??''),'content'=>wp_kses_post(wp_unslash($_POST['content']??'')),'value'=>(float)($_POST['value']??0),'status'=>sanitize_key($_POST['status']??'draft'),'flow_create_project'=>!empty($_POST['flow_create_project'])?1:0,'flow_create_financial'=>!empty($_POST['flow_create_financial'])?1:0,'updated_at'=>$now];
        if($id)$wpdb->update($t,$d,['id'=>$id]);else{$d['number']=VFOS_DB::next_number('contract');$d['created_at']=$now;$wpdb->insert($t,$d);$id=$wpdb->insert_id;}
        $row=$wpdb->get_row($wpdb->prepare("SELECT x.*,c.name client_name FROM $t x LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=x.client_id WHERE x.id=%d",$id),ARRAY_A);
        $pdf=VFOS_PDF::contract($row['title'],$row['content'],$row['number'],$row['client_name']??'');if(!is_wp_error($pdf))$wpdb->update($t,['pdf_path'=>$pdf,'updated_at'=>$now],['id'=>$id]);
        if(!empty($_POST['save_as_template'])){$name=sanitize_text_field($_POST['template_name']??'');if($name){$mt=VFOS_DB::table('contract_templates');$wpdb->insert($mt,['name'=>$name,'description'=>'Salvo a partir do contrato '.$row['number'],'content'=>$row['content'],'status'=>'active','created_at'=>$now,'updated_at'=>$now]);}}
        VFOS_DB::log('save_contract','contract',$id);VFOS_Notifications::activity('contract_saved','Contrato salvo',$d['title'],'contracts','contract',$id,admin_url('admin.php?page=vfos-contracts&tab=new&edit='.$id));
        if($d['status']==='signed'){
            if(!empty($d['flow_create_project']))VFOS_Workflow::contract_to_project($id);
            if(!empty($d['flow_create_financial']))VFOS_Workflow::contract_to_financial($id);
        }
        $rt=VFOS_Recurring::table();$existing_rec=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM $rt WHERE contract_id=%d ORDER BY id DESC LIMIT 1",$id));
        if(!empty($_POST['contract_recurring_enabled'])){
            $rf=sanitize_key($_POST['contract_recurring_frequency']??'monthly');if(!in_array($rf,['monthly','quarterly','semiannual','annual'],true))$rf='monthly';
            $first=sanitize_key($_POST['contract_recurring_first_charge']??'now');if(!in_array($first,['now','due'],true))$first='now';
            $sm=sanitize_key($_POST['contract_recurring_method']??'choose');if(!in_array($sm,['choose','card','pix'],true))$sm='choose';
            $oldrec=$existing_rec?$wpdb->get_row($wpdb->prepare("SELECT * FROM $rt WHERE id=%d",$existing_rec)):null;
            $public=$oldrec&&$oldrec->public_token?$oldrec->public_token:wp_generate_password(54,false,false);
            $payer=(string)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(NULLIF(billing_email,''),email) FROM ".VFOS_DB::table('clients')." WHERE id=%d",$d['client_id']));
            $rd=['client_id'=>$d['client_id'],'project_id'=>$d['project_id'],'contract_id'=>$id,'title'=>$d['title'].' — mensalidade','amount'=>max(0,$this->decimal($_POST['contract_recurring_amount']??$d['value'])),'frequency'=>$rf,'interval_count'=>1,'next_due_date'=>$this->date($_POST['contract_recurring_next_due']??'')?:date('Y-m-d',strtotime('+1 month')),'auto_generate'=>1,'gateway'=>'mercadopago','payment_method'=>'Mercado Pago Assinaturas','subscription_method'=>$sm,'first_charge_mode'=>$first,'payer_email'=>sanitize_email($payer),'public_token'=>$public,'status'=>$oldrec&&in_array($oldrec->status,['active','paused'],true)?$oldrec->status:'pending_authorization','updated_at'=>$now];
            if($existing_rec)$wpdb->update($rt,$rd,['id'=>$existing_rec]);else{$rd['created_by']=get_current_user_id();$rd['created_at']=$now;$wpdb->insert($rt,$rd);}
        }elseif($existing_rec){$oldrec=$wpdb->get_row($wpdb->prepare("SELECT * FROM $rt WHERE id=%d",$existing_rec));if($oldrec&&$oldrec->gateway_subscription_id){$wpdb->update($rt,['status'=>'paused','updated_at'=>$now],['id'=>$existing_rec]);}else{$wpdb->update($rt,['status'=>'pending_authorization','updated_at'=>$now],['id'=>$existing_rec]);}}
        $msg=is_wp_error($pdf)?'Contrato salvo, mas o PDF não pôde ser gerado: '.$pdf->get_error_message():'Contrato salvo e PDF timbrado atualizado.';$this->go('vfos-contracts',$msg);
    }
    public function save_contract_template(){
        $this->guard('vfos_save_contract_template');global $wpdb;$t=VFOS_DB::table('contract_templates');$id=absint($_POST['id']??0);$now=current_time('mysql');$d=['name'=>sanitize_text_field($_POST['name']??''),'description'=>sanitize_text_field($_POST['description']??''),'content'=>wp_kses_post(wp_unslash($_POST['content']??'')),'status'=>sanitize_key($_POST['status']??'active'),'updated_at'=>$now];if(!$d['name'])$this->go('vfos-contracts','Informe o nome do modelo.');if($id)$wpdb->update($t,$d,['id'=>$id]);else{$d['created_at']=$now;$wpdb->insert($t,$d);$id=$wpdb->insert_id;}VFOS_DB::log('save_contract_template','contract_template',$id);wp_safe_redirect(admin_url('admin.php?page=vfos-contracts&tab=templates&vfos_msg='.rawurlencode('Modelo de contrato salvo.')));exit;
    }
    public function delete_contract_template(){
        $this->guard('vfos_delete_contract_template');global $wpdb;$id=absint($_GET['id']??0);$wpdb->delete(VFOS_DB::table('contract_templates'),['id'=>$id]);VFOS_DB::log('delete_contract_template','contract_template',$id);wp_safe_redirect(admin_url('admin.php?page=vfos-contracts&tab=templates&vfos_msg='.rawurlencode('Modelo excluído.')));exit;
    }
    public function contract_pdf(){
        VFOS_Team::require_permission('contracts.pdf');check_admin_referer('vfos_contract_pdf');global $wpdb;$id=absint($_GET['id']??0);$t=VFOS_DB::table('contracts');$row=$wpdb->get_row($wpdb->prepare("SELECT x.*,c.name client_name FROM $t x LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=x.client_id WHERE x.id=%d",$id),ARRAY_A);if(!$row)wp_die('Contrato não encontrado.');$pdf=VFOS_PDF::contract($row['title'],$row['content'],$row['number'],$row['client_name']??'');if(is_wp_error($pdf))wp_die(esc_html($pdf->get_error_message()));$wpdb->update($t,['pdf_path'=>$pdf,'updated_at'=>current_time('mysql')],['id'=>$id]);nocache_headers();header('Content-Type: application/pdf');header('Content-Disposition: inline; filename="'.sanitize_file_name($row['number']).'.pdf"');header('Content-Length: '.filesize($pdf));readfile($pdf);exit;
    }
    private function refresh_financial_payment_totals($financial_id){
        global $wpdb;
        $ft=VFOS_DB::table('financial');$pt=VFOS_DB::table('financial_payments');
        $f=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ft WHERE id=%d",$financial_id));
        if(!$f)return false;
        $received=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM $pt WHERE financial_id=%d",$financial_id));
        $received=min((float)$f->amount,max(0,$received));
        $status=$received<=0?'pending':($received+0.001>=(float)$f->amount?'paid':'partial');
        $last_paid=$received>0?$wpdb->get_var($wpdb->prepare("SELECT MAX(payment_date) FROM $pt WHERE financial_id=%d",$financial_id)):null;
        return $wpdb->update($ft,['paid_amount'=>$received,'status'=>$status,'paid_at'=>$status==='paid'?$last_paid:null,'updated_at'=>current_time('mysql')],['id'=>$financial_id])!==false;
    }

    public function save_financial(){
        check_admin_referer('vfos_save_financial');VFOS_Team::require_permission('financial.create');global $wpdb;
        $ft=VFOS_DB::table('financial');$pt=VFOS_DB::table('financial_payments');$now=current_time('mysql');
        $type=sanitize_key($_POST['type']??'income');if(!in_array($type,['income','expense'],true))$type='income';
        $amount=max(0,$this->decimal($_POST['amount']??0));$description=sanitize_text_field(wp_unslash($_POST['description']??''));
        if(!$description)$this->go('vfos-financial','Informe a descrição do lançamento.');
        if($amount<=0)$this->go('vfos-financial','Informe um valor maior que zero.');

        $method=sanitize_text_field(wp_unslash($_POST['method']??''));
        $status=$type==='expense'?sanitize_key($_POST['expense_status']??'pending'):'pending';
        if(!in_array($status,['pending','paid'],true))$status='pending';

        $wpdb->query('START TRANSACTION');
        try{
            $ok=$wpdb->insert($ft,[
                'client_id'=>absint($_POST['client_id']??0),'type'=>$type,'description'=>$description,
                'amount'=>$amount,'paid_amount'=>0,'status'=>$status,'due_date'=>$this->date($_POST['due_date']??''),
                'paid_at'=>$type==='expense'&&$status==='paid'?$now:null,'method'=>$method,
                'created_at'=>$now,'updated_at'=>$now
            ]);
            $fid=(int)$wpdb->insert_id;
            if(!$ok||!$fid)throw new Exception($wpdb->last_error?:'Falha ao criar lançamento.');

            if($type==='income'){
                $initial=max(0,$this->decimal($_POST['initial_payment']??0));
                if($initial>$amount+0.001)throw new Exception('A entrada não pode ser maior que o valor total da cobrança.');
                if($initial>0){
                    $date=$this->date($_POST['initial_payment_date']??'')?:date('Y-m-d');
                    if(!$wpdb->insert($pt,[
                        'financial_id'=>$fid,'amount'=>$initial,'payment_date'=>$date.' '.date('H:i:s'),
                        'method'=>sanitize_text_field(wp_unslash($_POST['initial_payment_method']??'')),
                        'notes'=>sanitize_textarea_field(wp_unslash($_POST['initial_payment_notes']??'')),
                        'created_by'=>get_current_user_id(),'created_at'=>$now
                    ]))throw new Exception($wpdb->last_error?:'Falha ao registrar a entrada.');
                    if(!$this->refresh_financial_payment_totals($fid))throw new Exception('Falha ao recalcular o saldo após a entrada.');
                }
            }
            $wpdb->query('COMMIT');
        }catch(Throwable $ex){
            $wpdb->query('ROLLBACK');
            $this->go('vfos-financial','Não foi possível salvar o lançamento: '.$ex->getMessage());
        }

        VFOS_DB::log('save_financial','financial',$fid,'Lançamento criado | valor total=R$ '.number_format($amount,2,',','.'),null,null,$description);
        VFOS_Notifications::activity('financial_saved','Lançamento financeiro criado',$description,'financial','financial',$fid,admin_url('admin.php?page=vfos-financial'));

        $f=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ft WHERE id=%d",$fid));
        if($type==='income'&&!empty($_POST['create_split'])&&VFOS_Team::can_permission('financial.split')&&(float)$f->paid_amount>0){
            wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=split&financial_id='.$fid.'&vfos_msg='.rawurlencode('Lançamento e entrada salvos. Agora divida o valor recebido.')));exit;
        }
        if($type==='income'&&(float)$f->paid_amount>0&&VFOS_Team::can_permission('financial.payments')){
            wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.$fid.'&vfos_msg='.rawurlencode('Lançamento salvo com o recebimento inicial.')));exit;
        }
        $this->go('vfos-financial','Lançamento salvo com sucesso.');
    }

    public function add_financial_payment(){
        global $wpdb;
        $financial_id=absint($_POST['financial_id']??0);
        check_admin_referer('vfos_add_financial_payment_'.$financial_id);
        VFOS_Team::require_permission('financial.payments');
        $ft=VFOS_DB::table('financial');$pt=VFOS_DB::table('financial_payments');
        $f=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ft WHERE id=%d AND type='income'",$financial_id));
        if(!$f)wp_die('Cobrança não encontrada.');

        $remaining=max(0,(float)$f->amount-(float)$f->paid_amount);
        $amount=max(0,$this->decimal($_POST['amount']??0));
        if($amount<=0)wp_die('Informe um valor de recebimento maior que zero.');
        if($amount>$remaining+0.001)wp_die('O pagamento não pode ser maior que o saldo restante de R$ '.esc_html(number_format($remaining,2,',','.')).'.');

        $date=$this->date($_POST['payment_date']??'')?:date('Y-m-d');
        $ok=$wpdb->insert($pt,[
            'financial_id'=>$financial_id,'amount'=>$amount,'payment_date'=>$date.' '.date('H:i:s'),
            'method'=>sanitize_text_field(wp_unslash($_POST['method']??'')),
            'notes'=>sanitize_textarea_field(wp_unslash($_POST['notes']??'')),
            'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')
        ]);
        if(!$ok)wp_die('Não foi possível registrar o recebimento: '.esc_html($wpdb->last_error?:'erro no banco.'));
        if(!$this->refresh_financial_payment_totals($financial_id))wp_die('O recebimento foi gravado, mas não foi possível recalcular o saldo.');

        VFOS_DB::log('financial_payment_added','financial',$financial_id,'Recebimento registrado: R$ '.number_format($amount,2,',','.'),null,['payment_id'=>$wpdb->insert_id,'amount'=>$amount],$f->description);
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=receipts&financial_id='.$financial_id.'&vfos_msg='.rawurlencode('Recebimento registrado com sucesso.')));exit;
    }

    public function delete_financial_payment(){
        global $wpdb;
        $id=absint($_GET['id']??0);
        check_admin_referer('vfos_delete_financial_payment_'.$id);
        VFOS_Team::require_permission('financial.payments');
        $pt=VFOS_DB::table('financial_payments');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $pt WHERE id=%d",$id));
        if(!$row)wp_die('Recebimento não encontrado.');
        if(!empty($row->provider)&&$row->provider!=='manual')wp_die('Este recebimento foi conciliado automaticamente pelo '.esc_html(ucfirst($row->provider)).'. Para preservar a conciliação, faça estorno/cancelamento pelo provedor em vez de apagar a baixa.');
        if($wpdb->delete($pt,['id'=>$id])===false)wp_die('Não foi possível excluir o recebimento.');
        $this->refresh_financial_payment_totals((int)$row->financial_id);

        // Se o valor recebido diminuiu, a divisão antiga pode ter ficado acima
        // do disponível. Nesse caso, limpa a divisão para evitar inconsistência.
        $f=VFOS_DB::table('financial');$st=VFOS_DB::table('financial_splits');
        $received=(float)$wpdb->get_var($wpdb->prepare("SELECT paid_amount FROM $f WHERE id=%d",$row->financial_id));
        $distributed=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM $st WHERE financial_id=%d",$row->financial_id));
        if($distributed>$received+0.001)$wpdb->delete($st,['financial_id'=>$row->financial_id]);

        VFOS_DB::log('financial_payment_deleted','financial',$row->financial_id,'Recebimento excluído: R$ '.number_format((float)$row->amount,2,',','.'),(array)$row,null,'Recebimento');
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=receipts&financial_id='.$row->financial_id.'&vfos_msg='.rawurlencode('Recebimento excluído e saldo recalculado.')));exit;
    }

    public function save_financial_split(){
        global $wpdb;
        $financial_id=absint($_POST['financial_id']??0);
        check_admin_referer('vfos_save_financial_split_'.$financial_id);
        VFOS_Team::require_permission('financial.split');

        $ft=VFOS_DB::table('financial');$st=VFOS_DB::table('financial_splits');
        $financial=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ft WHERE id=%d AND type='income'",$financial_id));
        if(!$financial)wp_die('Receita financeira não encontrada.');

        $total=(float)$financial->paid_amount;
        if($total<=0)wp_die('Nenhum valor foi recebido ainda. Registre uma entrada ou pagamento antes de dividir.');

        $mode=sanitize_key($_POST['split_mode']??'amount');
        if(!in_array($mode,['amount','percent'],true))$mode='amount';
        $rows=[];$order=0;$sum=0.0;

        foreach((array)wp_unslash($_POST['partners']??[]) as $r){
            if(!is_array($r))continue;
            $uid=absint($r['user_id']??0);$label=sanitize_text_field($r['label']??'');
            if(!$uid&&!$label)continue;
            if($uid){$u=get_userdata($uid);if(!$u)continue;if(!$label)$label=$u->display_name;}
            $percentage=max(0,min(100,$this->decimal($r['percentage']??0)));
            $amount=max(0,$this->decimal($r['amount']??0));
            if($mode==='percent')$amount=round($total*$percentage/100,2);
            else $percentage=$total>0?round($amount/$total*100,4):0;
            if($amount<=0)continue;
            $sum=round($sum+$amount,2);
            $rows[]=['financial_id'=>$financial_id,'split_type'=>'partner','user_id'=>$uid,'label'=>$label,'percentage'=>$percentage,'amount'=>$amount,'sort_order'=>$order++,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')];
        }

        $cash_pct=max(0,min(100,$this->decimal($_POST['company_cash_percentage']??0)));
        $cash_amount=max(0,$this->decimal($_POST['company_cash_amount']??0));
        if($mode==='percent')$cash_amount=round($total*$cash_pct/100,2);
        else $cash_pct=$total>0?round($cash_amount/$total*100,4):0;
        if($cash_amount>0){
            $sum=round($sum+$cash_amount,2);
            $rows[]=['financial_id'=>$financial_id,'split_type'=>'company_cash','user_id'=>0,'label'=>'Caixa da VisionForge','percentage'=>$cash_pct,'amount'=>$cash_amount,'sort_order'=>$order++,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')];
        }

        if(!$rows)wp_die('Informe pelo menos uma divisão para sócio ou caixa da empresa.');
        $difference=round($total-$sum,2);
        if($mode==='percent'&&abs($difference)>0&&abs($difference)<=0.05){
            $last=count($rows)-1;$rows[$last]['amount']=round((float)$rows[$last]['amount']+$difference,2);$sum=round($sum+$difference,2);
        }
        if(abs($sum-$total)>0.001)wp_die('A divisão precisa fechar o valor já recebido. Recebido: R$ '.esc_html(number_format($total,2,',','.')).' • Distribuído: R$ '.esc_html(number_format($sum,2,',','.')).'.');

        $before=$wpdb->get_results($wpdb->prepare("SELECT * FROM $st WHERE financial_id=%d ORDER BY sort_order,id",$financial_id),ARRAY_A);
        $wpdb->query('START TRANSACTION');
        try{
            if($wpdb->delete($st,['financial_id'=>$financial_id])===false)throw new Exception($wpdb->last_error?:'Falha ao limpar divisão anterior.');
            foreach($rows as $row)if(!$wpdb->insert($st,$row))throw new Exception($wpdb->last_error?:'Falha ao salvar uma divisão.');

            // Retiradas dos sócios são saídas reais do caixa. O valor reservado
            // para a empresa permanece no caixa e não gera despesa.
            $wpdb->delete($ft,['source_type'=>'partner_split','source_id'=>$financial_id,'is_partner_withdrawal'=>1]);
            foreach($rows as $row){
                if($row['split_type']!=='partner')continue;
                if(!$wpdb->insert($ft,[
                    'client_id'=>0,'project_id'=>0,'type'=>'expense',
                    'description'=>'Retirada de sócio — '.$row['label'],
                    'amount'=>(float)$row['amount'],'paid_amount'=>0,'status'=>'paid',
                    'due_date'=>date('Y-m-d'),'paid_at'=>current_time('mysql'),'method'=>'Distribuição de receita',
                    'source_type'=>'partner_split','source_id'=>$financial_id,'is_partner_withdrawal'=>1,
                    'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')
                ]))throw new Exception($wpdb->last_error?:'Falha ao registrar a retirada do sócio no caixa.');
            }
            $wpdb->query('COMMIT');
        }catch(Throwable $ex){
            $wpdb->query('ROLLBACK');wp_die('Não foi possível salvar a divisão: '.esc_html($ex->getMessage()));
        }

        VFOS_DB::log('save_financial_split','financial',$financial_id,'Divisão do valor recebido salva | R$ '.number_format($total,2,',','.'),$before,$rows,$financial->description);
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=split&financial_id='.$financial_id.'&vfos_msg='.rawurlencode('Divisão salva com sucesso.')));exit;
    }

    public function delete_financial(){
        global $wpdb;
        $id=absint($_GET['id']??0);
        check_admin_referer('vfos_delete_financial_'.$id);
        VFOS_Team::require_permission('financial.delete');
        if(!$id)$this->go('vfos-financial','Lançamento financeiro inválido.');

        $t=VFOS_DB::table('financial');
        $before=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id),ARRAY_A);
        if(!$before)$this->go('vfos-financial','Lançamento financeiro não encontrado.');
        if(!empty($before['is_partner_withdrawal']))$this->go('vfos-financial','Esta retirada é controlada pela divisão entre sócios. Edite a divisão da receita de origem.');

        // Se o lançamento foi gerado automaticamente por um orçamento, libera
        // o vínculo para evitar referência a um registro que deixou de existir.
        $quotes=VFOS_DB::table('quotes');
        $linked_quotes=$wpdb->get_col($wpdb->prepare("SELECT id FROM $quotes WHERE converted_financial_id=%d",$id));
        if($linked_quotes)$wpdb->update($quotes,['converted_financial_id'=>0,'updated_at'=>current_time('mysql')],['converted_financial_id'=>$id]);

        $wpdb->delete(VFOS_DB::table('financial_payments'),['financial_id'=>$id]);
        $wpdb->delete(VFOS_DB::table('financial_splits'),['financial_id'=>$id]);
        $wpdb->delete(VFOS_DB::table('financial'),['source_type'=>'partner_split','source_id'=>$id,'is_partner_withdrawal'=>1]);
        $deleted=$wpdb->delete($t,['id'=>$id]);
        if($deleted===false)$this->go('vfos-financial','Não foi possível excluir o lançamento: '.($wpdb->last_error?:'erro no banco de dados').'.');

        $label=$before['description']??('Lançamento #'.$id);
        VFOS_DB::log(
            'delete_financial',
            'financial',
            $id,
            'Lançamento excluído permanentemente | tipo='.($before['type']??'').' | valor=R$ '.number_format((float)($before['amount']??0),2,',','.'),
            $before,
            null,
            $label
        );
        if(class_exists('VFOS_Notifications'))VFOS_Notifications::activity(
            'financial_deleted',
            'Lançamento financeiro excluído',
            $label.' • R$ '.number_format((float)($before['amount']??0),2,',','.'),
            'financial','financial',$id,admin_url('admin.php?page=vfos-financial')
        );
        $this->go('vfos-financial','Lançamento financeiro excluído. A ação foi registrada na Auditoria.');
    }

    private function delete_generic($type,$page){$a='vfos_delete_'.$type;$this->guard($a);global $wpdb;$id=absint($_GET['id']??0);$table=VFOS_DB::table($type==='client'?'clients':$type.'s');$before=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$id),ARRAY_A);$label='';if($before){foreach(['name','title','number'] as $f)if(!empty($before[$f])){$label=$before[$f];break;}}$wpdb->delete($table,['id'=>$id]);VFOS_DB::log('delete_'.$type,$type,$id,'Registro excluído permanentemente',$before,null,$label);$this->go($page,'Registro excluído. A ação foi registrada na Auditoria.');}
    public function delete_client(){$this->delete_generic('client','vfos-clients');} public function delete_project(){$this->delete_generic('project','vfos-projects');} public function delete_task(){$this->guard('vfos_delete_task');global $wpdb;$id=absint($_GET['id']??0);$t=VFOS_DB::table('tasks');$project=(int)$wpdb->get_var($wpdb->prepare("SELECT project_id FROM $t WHERE id=%d",$id));$wpdb->delete($t,['id'=>$id]);$wpdb->delete(VFOS_DB::table('task_checklist'),['task_id'=>$id]);if($project)$this->recalc_project_progress($project);VFOS_DB::log('delete_task','task',$id);$this->go('vfos-tasks','Registro excluído.');} public function delete_quote(){
        check_admin_referer('vfos_delete_quote');VFOS_Team::require_permission('quotes.delete');global $wpdb;$id=absint($_GET['id']??0);$t=VFOS_DB::table('quotes');$before=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id),ARRAY_A);if(!$before)$this->go('vfos-quotes','Orçamento não encontrado.');
        $cost_ids=array_map('absint',$wpdb->get_col($wpdb->prepare("SELECT id FROM ".VFOS_DB::table('quote_costs')." WHERE quote_id=%d",$id)));if($cost_ids)$wpdb->query("DELETE FROM ".VFOS_DB::table('quote_cost_options')." WHERE cost_id IN (".implode(',',$cost_ids).")");foreach(['quote_items','quote_sections','quote_costs','quote_payment_options'] as $child)$wpdb->delete(VFOS_DB::table($child),['quote_id'=>$id]);
        $wpdb->delete($t,['id'=>$id]);VFOS_DB::log('delete_quote','quote',$id,'Proposta e dados complementares excluídos',$before,null,$before['title']??'');$this->go('vfos-quotes','Orçamento excluído.');
    } public function delete_contract(){$this->delete_generic('contract','vfos-contracts');}
    public function quote_to_contract(){
        $this->guard('vfos_quote_to_contract');global $wpdb;$id=absint($_GET['id']??0);
        $q=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.VFOS_DB::table('quotes').' WHERE id=%d',$id));
        if(!$q)$this->go('vfos-quotes','Proposta não encontrada.');
        if($q->converted_contract_id){wp_safe_redirect(admin_url('admin.php?page=vfos-contracts&edit='.(int)$q->converted_contract_id));exit;}
        $now=current_time('mysql');$content='';
        $wpdb->insert(VFOS_DB::table('contracts'),['client_id'=>$q->client_id,'quote_id'=>$id,'number'=>VFOS_DB::next_number('contract'),'title'=>'Contrato - '.$q->title,'content'=>$content,'value'=>$q->total,'status'=>'draft','created_at'=>$now,'updated_at'=>$now]);
        $cid=$wpdb->insert_id;$wpdb->update(VFOS_DB::table('quotes'),['converted_contract_id'=>$cid,'updated_at'=>$now],['id'=>$id]);
        VFOS_DB::log('quote_to_contract','contract',$cid,'quote='.$id);wp_safe_redirect(admin_url('admin.php?page=vfos-contracts&edit='.$cid));exit;
    }
    public function send_sign(){$this->guard('vfos_send_sign');$id=absint($_GET['id']??0);$r=VFOS_Sign::send_contract($id);$this->go('vfos-contracts',is_wp_error($r)?'Erro: '.$r->get_error_message():'Documento criado no VisionForge Sign. Abra “Configurar Sign” para posicionar os campos de assinatura.');}
    public function sign_sync(){$this->guard('vfos_sign_sync');$id=absint($_GET['id']??0);$r=VFOS_Sign::sync($id);$this->go('vfos-contracts',is_wp_error($r)?'Erro: '.$r->get_error_message():'Status sincronizado com o VisionForge Sign.');}
    public function sign_invite(){$this->guard('vfos_sign_invite');$id=absint($_GET['id']??0);$r=VFOS_Sign::send_invite($id);$this->go('vfos-contracts',is_wp_error($r)?'Erro: '.$r->get_error_message():'Convite de assinatura enviado pelo VisionForge Sign.');}
    public function reports(){ VFOS_Reports::render(); }
    public function automations(){ VFOS_Automations::render(); }

}
