<?php
if (!defined('ABSPATH')) exit;

class VFOS_AI {
    public static function providers(){
        return [
            'openrouter' => 'OpenRouter',
            'gemini'     => 'Google Gemini',
        ];
    }

    public static function default_provider(){
        $p = sanitize_key(get_option('vfos_ai_provider','openrouter'));
        return isset(self::providers()[$p]) ? $p : 'openrouter';
    }

    public static function get_key($provider){
        if ($provider === 'openrouter') {
            if (defined('VFOS_OPENROUTER_API_KEY') && VFOS_OPENROUTER_API_KEY) return VFOS_OPENROUTER_API_KEY;
            return (string) get_option('vfos_openrouter_api_key','');
        }
        if ($provider === 'gemini') {
            if (defined('VFOS_GEMINI_API_KEY') && VFOS_GEMINI_API_KEY) return VFOS_GEMINI_API_KEY;
            return (string) get_option('vfos_gemini_api_key','');
        }
        return '';
    }

    public static function get_model($provider){
        if ($provider === 'gemini') return sanitize_text_field(get_option('vfos_gemini_model','gemini-2.5-flash'));
        return sanitize_text_field(get_option('vfos_openrouter_model','openrouter/free'));
    }

    public static function is_configured($provider=''){
        if ($provider) return self::get_key($provider) !== '';
        foreach(array_keys(self::providers()) as $p) if(self::get_key($p)!=='') return true;
        return false;
    }

    private static function raw_tools(){
        return [
            ['name'=>'propor_criar_cliente','description'=>'Prepara um novo cliente PF ou PJ no CRM. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['person_type'=>['type'=>'string','enum'=>['pf','pj']],'name'=>['type'=>'string'],'legal_name'=>['type'=>'string'],'trade_name'=>['type'=>'string'],'document'=>['type'=>'string'],'responsible_name'=>['type'=>'string'],'responsible_cpf'=>['type'=>'string'],'email'=>['type'=>'string'],'phone'=>['type'=>'string'],'whatsapp'=>['type'=>'string'],'notes'=>['type'=>'string']],'required'=>['name']]],
            ['name'=>'propor_criar_lead','description'=>'Prepara um novo lead no pipeline comercial. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['name'=>['type'=>'string'],'company'=>['type'=>'string'],'email'=>['type'=>'string'],'phone'=>['type'=>'string'],'source'=>['type'=>'string'],'service_interest'=>['type'=>'string'],'estimated_value'=>['type'=>'number'],'stage'=>['type'=>'string','enum'=>['new','contacted','qualified','proposal','negotiation']],'probability'=>['type'=>'integer'],'next_followup'=>['type'=>'string'],'notes'=>['type'=>'string']],'required'=>['name']]],
            ['name'=>'propor_criar_projeto','description'=>'Prepara um projeto. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['name'=>['type'=>'string'],'client_id'=>['type'=>'integer'],'value'=>['type'=>'number'],'due_date'=>['type'=>'string'],'status'=>['type'=>'string','enum'=>['planning','in_progress','review','completed']],'notes'=>['type'=>'string']],'required'=>['name']]],
            ['name'=>'propor_criar_tarefa','description'=>'Prepara uma tarefa. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['title'=>['type'=>'string'],'project_id'=>['type'=>'integer'],'client_id'=>['type'=>'integer'],'priority'=>['type'=>'string','enum'=>['low','normal','high','urgent']],'due_date'=>['type'=>'string'],'description'=>['type'=>'string']],'required'=>['title']]],
            ['name'=>'propor_criar_compromisso','description'=>'Prepara um compromisso na Agenda VisionForge. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['title'=>['type'=>'string'],'event_type'=>['type'=>'string','enum'=>['meeting','delivery','internal','reminder']],'start_at'=>['type'=>'string'],'end_at'=>['type'=>'string'],'client_id'=>['type'=>'integer'],'project_id'=>['type'=>'integer'],'assigned_user_id'=>['type'=>'integer'],'location'=>['type'=>'string'],'meeting_url'=>['type'=>'string'],'description'=>['type'=>'string']],'required'=>['title','start_at']]],
            ['name'=>'propor_criar_orcamento','description'=>'Prepara um orçamento comercial no VisionForge OS. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['client_id'=>['type'=>'integer'],'title'=>['type'=>'string'],'description'=>['type'=>'string'],'total'=>['type'=>'number'],'payment_terms'=>['type'=>'string'],'valid_until'=>['type'=>'string']],'required'=>['title','total']]],
            ['name'=>'propor_criar_contrato','description'=>'Redige e prepara um contrato completo para salvar no módulo Contratos. O conteúdo deve vir pronto, profissional e adaptado aos dados informados. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['client_id'=>['type'=>'integer'],'project_id'=>['type'=>'integer'],'quote_id'=>['type'=>'integer'],'title'=>['type'=>'string'],'content'=>['type'=>'string'],'value'=>['type'=>'number']],'required'=>['title','content']]],
            ['name'=>'propor_criar_lancamento_financeiro','description'=>'Prepara receita ou despesa no Financeiro. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['client_id'=>['type'=>'integer'],'type'=>['type'=>'string','enum'=>['income','expense']],'description'=>['type'=>'string'],'amount'=>['type'=>'number'],'due_date'=>['type'=>'string'],'method'=>['type'=>'string'],'initial_payment'=>['type'=>'number']],'required'=>['type','description','amount']]],
            ['name'=>'propor_registrar_recebimento','description'=>'Prepara um recebimento parcial ou integral em uma cobrança existente. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['financial_id'=>['type'=>'integer'],'amount'=>['type'=>'number'],'payment_date'=>['type'=>'string'],'method'=>['type'=>'string'],'notes'=>['type'=>'string']],'required'=>['financial_id','amount']]],
            ['name'=>'propor_atualizar_status_projeto','description'=>'Prepara alteração do status e progresso de um projeto existente. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['project_id'=>['type'=>'integer'],'status'=>['type'=>'string','enum'=>['planning','in_progress','review','completed']],'progress'=>['type'=>'integer']],'required'=>['project_id','status']]],
            ['name'=>'propor_atualizar_status_tarefa','description'=>'Prepara alteração do status de uma tarefa existente. Não executa sem confirmação.','parameters'=>['type'=>'object','properties'=>['task_id'=>['type'=>'integer'],'status'=>['type'=>'string','enum'=>['pending','in_progress','done','cancelled']]],'required'=>['task_id','status']]],
        ];
    }

    private static function instructions($client_id=0){
        $context = $client_id ? ['client_360'=>VFOS_DB::client_context($client_id)] : VFOS_DB::ai_context();
        if(class_exists('VFOS_Team')) $context=self::filter_context_by_permissions($context,$client_id);
        return "Você é a VisionForge AI, o copiloto operacional da VisionForge Digital. Converse naturalmente em português do Brasil como um chat moderno e mantenha continuidade com as mensagens anteriores. Seja útil, clara e prática. Organize respostas quando isso ajudar, mas não seja robótica. Use somente os dados do contexto para afirmações sobre a empresa e nunca invente IDs, clientes, valores, documentos ou datas. Se faltar informação para executar uma ação, pergunte antes de propor. Quando o usuário pedir para criar ou registrar algo que possua função disponível — cliente, lead, projeto, tarefa, compromisso, orçamento, contrato, lançamento financeiro, recebimento ou atualização de projeto/tarefa — use a função correspondente. A função prepara a ação e exige confirmação humana antes da gravação. Se o usuário disser “crie um contrato”, redija o conteúdo completo do contrato com base apenas nos dados disponíveis e nos dados fornecidos na conversa, sem inventar CPF/CNPJ, endereço, valores, prazos ou partes. Se faltar dado essencial, pergunte. Atue como um operador do sistema: além de responder, procure executar o pedido pela ferramenta adequada quando houver permissão. Considere as permissões do usuário. Você pode resumir, comparar, sugerir prioridades, redigir textos e ajudar a decidir com base no contexto. CONTEXTO JSON: ".wp_json_encode($context,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }

    private static function filter_context_by_permissions($context,$client_id=0){
        if(user_can(get_current_user_id(),'manage_options')) return $context;
        if($client_id && isset($context['client_360'])){
            $c=$context['client_360'];
            if(!VFOS_Team::can('financial')){unset($c['financial']);if(isset($c['summary'])){unset($c['summary']['received'],$c['summary']['receivable']);}}
            if(!VFOS_Team::can('contracts'))unset($c['contracts']);
            if(!VFOS_Team::can('quotes'))unset($c['quotes']);
            if(!VFOS_Team::can('projects'))unset($c['projects']);
            if(!VFOS_Team::can('tasks'))unset($c['tasks']);
            return ['client_360'=>$c];
        }
        if(isset($context['stats'])){
            if(!VFOS_Team::can('financial')){unset($context['stats']['received'],$context['stats']['receivable'],$context['overdue_receivable']);}
            if(!VFOS_Team::can('crm')){unset($context['stats']['leads'],$context['stats']['pipeline_value'],$context['open_leads']);}
            if(!VFOS_Team::can('quotes')){unset($context['stats']['quotes'],$context['recent_quotes']);}
            if(!VFOS_Team::can('projects')){unset($context['stats']['projects'],$context['recent_projects']);}
            if(!VFOS_Team::can('tasks')){unset($context['stats']['tasks'],$context['open_tasks']);}
            if(!VFOS_Team::can('clients'))unset($context['stats']['clients']);
            if(!VFOS_Team::can('contracts'))unset($context['stats']['contracts']);
            if(!VFOS_Team::can('calendar'))unset($context['upcoming_calendar']);
        }
        if(VFOS_Team::limited_to_assigned()){
            global $wpdb;$uid=get_current_user_id();$pt=VFOS_DB::table('projects');$ct=VFOS_DB::table('clients');$tt=VFOS_DB::table('tasks');
            $context['recent_projects']=$wpdb->get_results($wpdb->prepare("SELECT DISTINCT p.id,p.name,p.status,p.due_date,c.name client FROM $pt p JOIN $tt t ON t.project_id=p.id LEFT JOIN $ct c ON c.id=p.client_id WHERE t.assigned_user_id=%d ORDER BY p.updated_at DESC LIMIT 12",$uid),ARRAY_A);
            $context['open_tasks']=$wpdb->get_results($wpdb->prepare("SELECT id,title,status,priority,due_date FROM $tt WHERE assigned_user_id=%d AND status NOT IN ('done','cancelled') ORDER BY due_date IS NULL,due_date ASC LIMIT 12",$uid),ARRAY_A);
        }
        return $context;
    }

    private static function history($conversation_id,$client_id=0,$limit=12){
        global $wpdb;$conversation_id=sanitize_text_field($conversation_id);if(!$conversation_id)return [];
        $rows=$wpdb->get_results($wpdb->prepare("SELECT prompt,response FROM ".VFOS_DB::table('ai_logs')." WHERE user_id=%d AND conversation_id=%s AND client_id=%d ORDER BY id DESC LIMIT %d",get_current_user_id(),$conversation_id,absint($client_id),absint($limit)),ARRAY_A);
        return array_reverse($rows?:[]);
    }
    public static function chat_history($conversation_id,$client_id=0,$limit=40){
        global $wpdb;$conversation_id=sanitize_text_field($conversation_id);if(!$conversation_id)return [];
        return $wpdb->get_results($wpdb->prepare("SELECT id,prompt,response,provider,model,status,proposal,created_at FROM ".VFOS_DB::table('ai_logs')." WHERE user_id=%d AND conversation_id=%s AND client_id=%d ORDER BY id ASC LIMIT %d",get_current_user_id(),$conversation_id,absint($client_id),absint($limit)),ARRAY_A)?:[];
    }
    public static function latest_conversation($client_id=0){
        global $wpdb;$id=$wpdb->get_var($wpdb->prepare("SELECT conversation_id FROM ".VFOS_DB::table('ai_logs')." WHERE user_id=%d AND client_id=%d AND conversation_id<>'' ORDER BY id DESC LIMIT 1",get_current_user_id(),absint($client_id)));
        return $id?:wp_generate_uuid4();
    }
    public static function ask($prompt,$provider='',$client_id=0,$conversation_id=''){
        $provider=sanitize_key($provider?:self::default_provider());$conversation_id=sanitize_text_field($conversation_id?:wp_generate_uuid4());
        if(!isset(self::providers()[$provider]))return new WP_Error('invalid_provider','Provedor de IA inválido.');
        if(!self::get_key($provider))return new WP_Error('no_key','Configure a API Key do '.self::providers()[$provider].' em VisionForge OS → Configurações.');
        $history=self::history($conversation_id,$client_id,10);
        $result=$provider==='gemini'?self::ask_gemini($prompt,$client_id,$history):self::ask_openrouter($prompt,$client_id,$history);
        if(is_wp_error($result))return $result;
        global $wpdb;$wpdb->insert(VFOS_DB::table('ai_logs'),[
            'user_id'=>get_current_user_id(),'conversation_id'=>$conversation_id,'client_id'=>absint($client_id),'provider'=>$provider,'prompt'=>$prompt,
            'response'=>$result['text'],'proposal'=>$result['proposal']?wp_json_encode($result['proposal'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):'',
            'model'=>self::get_model($provider),'status'=>$result['proposal']?'proposal':'success','created_at'=>current_time('mysql')
        ]);
        $result['provider']=$provider;$result['provider_label']=self::providers()[$provider];$result['model']=self::get_model($provider);$result['conversation_id']=$conversation_id;
        return $result;
    }
    private static function ask_openrouter($prompt,$client_id=0,$history=[]){
        $tools=[];foreach(self::raw_tools() as $t)$tools[]=['type'=>'function','function'=>$t];
        $messages=[['role'=>'system','content'=>self::instructions($client_id)]];
        foreach($history as $h){$messages[]=['role'=>'user','content'=>(string)$h['prompt']];$messages[]=['role'=>'assistant','content'=>(string)$h['response']];}
        $messages[]=['role'=>'user','content'=>(string)$prompt];
        $body=['model'=>self::get_model('openrouter'),'messages'=>$messages,'tools'=>$tools,'tool_choice'=>'auto','temperature'=>0.35];
        $res=wp_remote_post('https://openrouter.ai/api/v1/chat/completions',['timeout'=>75,'headers'=>['Authorization'=>'Bearer '.self::get_key('openrouter'),'Content-Type'=>'application/json','HTTP-Referer'=>home_url('/'),'X-Title'=>'VisionForge OS'],'body'=>wp_json_encode($body)]);
        if(is_wp_error($res))return $res;$code=wp_remote_retrieve_response_code($res);$json=json_decode(wp_remote_retrieve_body($res),true);
        if($code<200||$code>=300)return new WP_Error('openrouter_error',$json['error']['message']??'Falha ao conectar com o OpenRouter.');
        $msg=$json['choices'][0]['message']??[];$text=is_string($msg['content']??null)?trim($msg['content']):'';$proposal=null;
        if(!empty($msg['tool_calls'][0]['function'])){$f=$msg['tool_calls'][0]['function'];$args=json_decode($f['arguments']??'{}',true);if(!is_array($args))$args=[];$proposal=['action'=>$f['name']??'','args'=>$args];}
        if($proposal&&!$text)$text=self::proposal_summary($proposal);if(is_wp_error($text))return $text;if(!$text)$text='Não recebi conteúdo suficiente para responder. Tente reformular a mensagem.';
        return ['text'=>$text,'proposal'=>$proposal];
    }
    private static function ask_gemini($prompt,$client_id=0,$history=[]){
        $decl=[];foreach(self::raw_tools() as $t)$decl[]=$t;$contents=[];
        foreach($history as $h){$contents[]=['role'=>'user','parts'=>[['text'=>(string)$h['prompt']]]];$contents[]=['role'=>'model','parts'=>[['text'=>(string)$h['response']]]];}
        $contents[]=['role'=>'user','parts'=>[['text'=>(string)$prompt]]];
        $body=['systemInstruction'=>['parts'=>[['text'=>self::instructions($client_id)]]],'contents'=>$contents,'tools'=>[['functionDeclarations'=>$decl]],'toolConfig'=>['functionCallingConfig'=>['mode'=>'AUTO']],'generationConfig'=>['temperature'=>0.35]];
        $model=rawurlencode(self::get_model('gemini'));$url='https://generativelanguage.googleapis.com/v1beta/models/'.$model.':generateContent';
        $res=wp_remote_post($url,['timeout'=>75,'headers'=>['x-goog-api-key'=>self::get_key('gemini'),'Content-Type'=>'application/json'],'body'=>wp_json_encode($body)]);
        if(is_wp_error($res))return $res;$code=wp_remote_retrieve_response_code($res);$json=json_decode(wp_remote_retrieve_body($res),true);
        if($code<200||$code>=300)return new WP_Error('gemini_error',$json['error']['message']??'Falha ao conectar com o Google Gemini.');
        $parts=$json['candidates'][0]['content']['parts']??[];$text='';$proposal=null;foreach($parts as $part){if(isset($part['text']))$text.=$part['text'];if(isset($part['functionCall'])){$f=$part['functionCall'];$args=$f['args']??[];if(!is_array($args))$args=[];$proposal=['action'=>$f['name']??'','args'=>$args];}}
        $text=trim($text);if($proposal&&!$text)$text=self::proposal_summary($proposal);if(is_wp_error($text))return $text;if(!$text)$text='Não recebi conteúdo suficiente para responder. Tente reformular a mensagem.';
        return ['text'=>$text,'proposal'=>$proposal];
    }

    private static function proposal_summary($p){
        $a=$p['args'];
        switch($p['action']){
            case 'propor_criar_lead':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can('crm'))return new WP_Error('forbidden','Seu perfil não permite criar leads.'); return 'Preparei o novo lead “'.($a['name']??'').'”. Confira os dados e confirme para adicionar ao pipeline.';
            case 'propor_criar_cliente':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can('clients'))return new WP_Error('forbidden','Seu perfil não permite criar clientes.'); return 'Preparei o novo cliente “'.($a['name']??'').'”. Confira os dados e confirme para salvar no CRM.';
            case 'propor_criar_projeto':
                if(class_exists('VFOS_Team')&&(!VFOS_Team::can('projects')||VFOS_Team::limited_to_assigned()))return new WP_Error('forbidden','Seu perfil não permite criar projetos.'); return 'Preparei o projeto “'.($a['name']??'').'”. Confira os dados e confirme para criar.';
            case 'propor_criar_tarefa':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can('tasks'))return new WP_Error('forbidden','Seu perfil não permite criar tarefas.'); return 'Preparei a tarefa “'.($a['title']??'').'”. Confira e confirme para adicionar.';
            case 'propor_criar_compromisso':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can('calendar'))return new WP_Error('forbidden','Seu perfil não permite criar compromissos.');
                $title=sanitize_text_field($a['title']??'');if(!$title)return new WP_Error('missing_title','Título do compromisso é obrigatório.');
                $start=sanitize_text_field($a['start_at']??'');if(!$start)return new WP_Error('missing_date','Data de início é obrigatória.');
                $start_ts=strtotime($start);if(!$start_ts)return new WP_Error('invalid_date','Data de início inválida.');
                $end=sanitize_text_field($a['end_at']??'');$end_ts=$end?strtotime($end):false;
                $assigned=absint($a['assigned_user_id']??0);if(class_exists('VFOS_Team')&&VFOS_Team::limited_to_assigned())$assigned=get_current_user_id();
                $wpdb->insert(VFOS_DB::table('calendar_events'),[
                    'title'=>$title,'description'=>sanitize_textarea_field($a['description']??''),'event_type'=>sanitize_key($a['event_type']??'meeting'),
                    'start_at'=>date('Y-m-d H:i:s',$start_ts),'end_at'=>$end_ts?date('Y-m-d H:i:s',$end_ts):null,'all_day'=>0,
                    'client_id'=>absint($a['client_id']??0),'project_id'=>absint($a['project_id']??0),'assigned_user_id'=>$assigned,
                    'status'=>'scheduled','location'=>sanitize_text_field($a['location']??''),'meeting_url'=>esc_url_raw($a['meeting_url']??''),
                    'created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now
                ]);
                $id=$wpdb->insert_id;VFOS_DB::log('ai_create_calendar_event','calendar_event',$id);return ['message'=>'Compromisso criado na Agenda VisionForge.','page'=>'vfos-calendar'];
            case 'propor_criar_compromisso':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('calendar.create'))return new WP_Error('forbidden','Seu perfil não permite criar compromissos.');
                $title=sanitize_text_field($a['title']??'');if(!$title)return new WP_Error('missing_title','Título do compromisso é obrigatório.');
                $start=sanitize_text_field($a['start_at']??'');$start_ts=$start?strtotime($start):false;if(!$start_ts)return new WP_Error('invalid_date','Informe uma data/hora válida para o compromisso.');
                $end=sanitize_text_field($a['end_at']??'');$end_ts=$end?strtotime($end):false;
                $assigned=absint($a['assigned_user_id']??0);if(class_exists('VFOS_Team')&&VFOS_Team::limited_to_assigned())$assigned=get_current_user_id();
                $wpdb->insert(VFOS_DB::table('calendar_events'),['title'=>$title,'description'=>sanitize_textarea_field($a['description']??''),'event_type'=>sanitize_key($a['event_type']??'meeting'),'start_at'=>date('Y-m-d H:i:s',$start_ts),'end_at'=>$end_ts?date('Y-m-d H:i:s',$end_ts):null,'all_day'=>0,'client_id'=>absint($a['client_id']??0),'project_id'=>absint($a['project_id']??0),'assigned_user_id'=>$assigned,'status'=>'scheduled','location'=>sanitize_text_field($a['location']??''),'meeting_url'=>esc_url_raw($a['meeting_url']??''),'created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now]);
                $id=$wpdb->insert_id;VFOS_DB::log('ai_create_calendar_event','calendar_event',$id,'Compromisso criado pela VisionForge AI',null,null,$title);return ['message'=>'Compromisso criado na Agenda com sucesso.','page'=>'vfos-calendar'];
            case 'propor_atualizar_status_projeto':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('projects.edit'))return new WP_Error('forbidden','Seu perfil não permite editar projetos.');
                return 'Preparei a atualização do projeto #'.absint($a['project_id']??0).' para “'.sanitize_text_field($a['status']??'').'” com progresso de '.max(0,min(100,absint($a['progress']??0))).'%. Confira e confirme.';
            case 'propor_atualizar_status_tarefa':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('tasks.edit'))return new WP_Error('forbidden','Seu perfil não permite editar tarefas.');
                return 'Preparei a atualização da tarefa #'.absint($a['task_id']??0).' para “'.sanitize_text_field($a['status']??'').'”. Confira e confirme.';
            case 'propor_criar_contrato':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('contracts.create'))return new WP_Error('forbidden','Seu perfil não permite criar contratos.');
                return 'Redigi o contrato “'.($a['title']??'').'”. Confira o conteúdo preparado e confirme para salvá-lo em Contratos.';
            case 'propor_criar_lancamento_financeiro':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('financial.create'))return new WP_Error('forbidden','Seu perfil não permite criar lançamentos financeiros.');
                return 'Preparei o lançamento financeiro “'.($a['description']??'').'” no valor de R$ '.number_format((float)($a['amount']??0),2,',','.').'. Confira e confirme.';
            case 'propor_registrar_recebimento':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('financial.payments'))return new WP_Error('forbidden','Seu perfil não permite registrar recebimentos.');
                return 'Preparei o recebimento de R$ '.number_format((float)($a['amount']??0),2,',','.').' para a cobrança #'.absint($a['financial_id']??0).'. Confira e confirme.';
            case 'propor_criar_orcamento':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can('quotes'))return new WP_Error('forbidden','Seu perfil não permite criar propostas.'); return 'Preparei o orçamento “'.($a['title']??'').'” no valor de R$ '.number_format((float)($a['total']??0),2,',','.').'. Confira e confirme para salvar.';
        }
        return 'Preparei uma ação para sua confirmação.';
    }

    public static function execute_proposal($proposal){
        if(!is_array($proposal)||empty($proposal['action'])||!isset($proposal['args'])) return new WP_Error('invalid','Proposta inválida.');
        global $wpdb; $a=$proposal['args']; $now=current_time('mysql');
        switch($proposal['action']){
            case 'propor_criar_lead':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('crm.create'))return new WP_Error('forbidden','Seu perfil não permite cadastrar leads.');
                $name=sanitize_text_field($a['name']??''); if(!$name)return new WP_Error('missing_name','Nome do lead é obrigatório.');
                $stage=sanitize_key($a['stage']??'new'); if(!in_array($stage,['new','contacted','qualified','proposal','negotiation'],true))$stage='new';
                $wpdb->insert(VFOS_DB::table('leads'),['name'=>$name,'company'=>sanitize_text_field($a['company']??''),'email'=>sanitize_email($a['email']??''),'phone'=>sanitize_text_field($a['phone']??''),'source'=>sanitize_text_field($a['source']??''),'service_interest'=>sanitize_text_field($a['service_interest']??''),'estimated_value'=>(float)($a['estimated_value']??0),'stage'=>$stage,'probability'=>min(100,max(0,absint($a['probability']??10))),'next_followup'=>self::date($a['next_followup']??''),'notes'=>sanitize_textarea_field($a['notes']??''),'created_at'=>$now,'updated_at'=>$now]);
                $id=$wpdb->insert_id; VFOS_DB::log('ai_create_lead','lead',$id); return ['message'=>'Lead criado no pipeline com sucesso.','page'=>'vfos-leads'];
            case 'propor_criar_cliente':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('clients.create'))return new WP_Error('forbidden','Seu perfil não permite cadastrar clientes.');
                $name=sanitize_text_field($a['name']??''); if(!$name)return new WP_Error('missing_name','Nome do cliente é obrigatório.');
                $type=in_array(sanitize_key($a['person_type']??'pf'),['pf','pj'],true)?sanitize_key($a['person_type']??'pf'):'pf';
                $wpdb->insert(VFOS_DB::table('clients'),['person_type'=>$type,'name'=>$name,'company'=>$type==='pj'?sanitize_text_field($a['trade_name']??''):'','legal_name'=>$type==='pj'?sanitize_text_field($a['legal_name']??''):'','trade_name'=>$type==='pj'?sanitize_text_field($a['trade_name']??''):'','document'=>sanitize_text_field($a['document']??''),'responsible_name'=>$type==='pj'?sanitize_text_field($a['responsible_name']??''):'','responsible_cpf'=>$type==='pj'?sanitize_text_field($a['responsible_cpf']??''):'','email'=>sanitize_email($a['email']??''),'phone'=>sanitize_text_field($a['phone']??''),'whatsapp'=>sanitize_text_field($a['whatsapp']??''),'notes'=>sanitize_textarea_field($a['notes']??''),'status'=>'active','created_by'=>get_current_user_id(),'updated_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now]);
                $id=$wpdb->insert_id; VFOS_DB::log('ai_create_client','client',$id,'Cliente criado pela VisionForge AI',null,null,$name); return ['message'=>'Cliente criado com sucesso.','page'=>'vfos-clients'];
            case 'propor_criar_projeto':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('projects.create'))return new WP_Error('forbidden','Seu perfil não permite criar projetos.');
                $name=sanitize_text_field($a['name']??''); if(!$name)return new WP_Error('missing_name','Nome do projeto é obrigatório.');
                $wpdb->insert(VFOS_DB::table('projects'),['client_id'=>absint($a['client_id']??0),'name'=>$name,'status'=>sanitize_key($a['status']??'planning'),'value'=>(float)($a['value']??0),'due_date'=>self::date($a['due_date']??''),'notes'=>sanitize_textarea_field($a['notes']??''),'created_at'=>$now,'updated_at'=>$now]);
                $id=$wpdb->insert_id; VFOS_DB::log('ai_create_project','project',$id); return ['message'=>'Projeto criado com sucesso.','page'=>'vfos-projects'];
            case 'propor_criar_tarefa':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('tasks.create'))return new WP_Error('forbidden','Seu perfil não permite criar tarefas.');
                $title=sanitize_text_field($a['title']??''); if(!$title)return new WP_Error('missing_title','Título da tarefa é obrigatório.');
                $wpdb->insert(VFOS_DB::table('tasks'),['project_id'=>absint($a['project_id']??0),'client_id'=>absint($a['client_id']??0),'title'=>$title,'description'=>sanitize_textarea_field($a['description']??''),'status'=>'pending','priority'=>sanitize_key($a['priority']??'normal'),'due_date'=>self::date($a['due_date']??''),'assigned_user_id'=>(class_exists('VFOS_Team')&&VFOS_Team::limited_to_assigned()?get_current_user_id():0),'created_at'=>$now,'updated_at'=>$now]);
                $id=$wpdb->insert_id; VFOS_DB::log('ai_create_task','task',$id); return ['message'=>'Tarefa criada com sucesso.','page'=>'vfos-tasks'];
            case 'propor_atualizar_status_projeto':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('projects.edit'))return new WP_Error('forbidden','Seu perfil não permite editar projetos.');
                $id=absint($a['project_id']??0);$status=sanitize_key($a['status']??'planning');$progress=max(0,min(100,absint($a['progress']??0)));
                if(!in_array($status,['planning','in_progress','review','completed'],true))return new WP_Error('invalid_status','Status de projeto inválido.');
                if(!$wpdb->update(VFOS_DB::table('projects'),['status'=>$status,'progress'=>$progress,'updated_at'=>$now],['id'=>$id]))return new WP_Error('db_error','Não foi possível atualizar o projeto ou ele já estava com esses dados.');
                VFOS_DB::log('ai_update_project','project',$id,'Status/progresso alterados pela VisionForge AI');
                return ['message'=>'Projeto atualizado com sucesso.','page'=>'vfos-project-view','id'=>$id];
            case 'propor_atualizar_status_tarefa':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('tasks.edit'))return new WP_Error('forbidden','Seu perfil não permite editar tarefas.');
                $id=absint($a['task_id']??0);$status=sanitize_key($a['status']??'pending');
                if(!in_array($status,['pending','in_progress','done','cancelled'],true))return new WP_Error('invalid_status','Status de tarefa inválido.');
                if(!$wpdb->update(VFOS_DB::table('tasks'),['status'=>$status,'updated_at'=>$now],['id'=>$id]))return new WP_Error('db_error','Não foi possível atualizar a tarefa ou ela já estava com esse status.');
                VFOS_DB::log('ai_update_task','task',$id,'Status alterado pela VisionForge AI');
                return ['message'=>'Tarefa atualizada com sucesso.','page'=>'vfos-tasks','id'=>$id];
            case 'propor_criar_contrato':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('contracts.create'))return new WP_Error('forbidden','Seu perfil não permite criar contratos.');
                $title=sanitize_text_field($a['title']??'');$content=wp_kses_post($a['content']??'');
                if(!$title||!trim(wp_strip_all_tags($content)))return new WP_Error('missing_contract','Título e conteúdo do contrato são obrigatórios.');
                $num=VFOS_DB::next_number('contract');
                $ok=$wpdb->insert(VFOS_DB::table('contracts'),[
                    'client_id'=>absint($a['client_id']??0),'project_id'=>absint($a['project_id']??0),'quote_id'=>absint($a['quote_id']??0),
                    'number'=>$num,'title'=>$title,'content'=>$content,'value'=>max(0,(float)($a['value']??0)),
                    'status'=>'draft','created_at'=>$now,'updated_at'=>$now
                ]);
                if(!$ok)return new WP_Error('db_error',$wpdb->last_error?:'Não foi possível salvar o contrato.');
                $id=$wpdb->insert_id;VFOS_DB::log('ai_create_contract','contract',$id,'Contrato redigido e criado pela VisionForge AI',null,null,$title);
                return ['message'=>'Contrato '.$num.' criado como rascunho.','page'=>'vfos-contracts','id'=>$id];
            case 'propor_criar_lancamento_financeiro':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('financial.create'))return new WP_Error('forbidden','Seu perfil não permite criar lançamentos financeiros.');
                $type=in_array(sanitize_key($a['type']??'income'),['income','expense'],true)?sanitize_key($a['type']??'income'):'income';
                $amount=max(0,(float)($a['amount']??0));$description=sanitize_text_field($a['description']??'');
                if(!$description||$amount<=0)return new WP_Error('missing_financial','Descrição e valor são obrigatórios.');
                $initial=$type==='income'?max(0,min($amount,(float)($a['initial_payment']??0))):0;
                $status=$type==='expense'?'pending':($initial<=0?'pending':($initial+0.001>=$amount?'paid':'partial'));
                $wpdb->insert(VFOS_DB::table('financial'),[
                    'client_id'=>absint($a['client_id']??0),'type'=>$type,'description'=>$description,'amount'=>$amount,'paid_amount'=>$initial,
                    'status'=>$status,'due_date'=>self::date($a['due_date']??''),'method'=>sanitize_text_field($a['method']??''),
                    'paid_at'=>$status==='paid'?$now:null,'created_at'=>$now,'updated_at'=>$now
                ]);
                $id=$wpdb->insert_id;if(!$id)return new WP_Error('db_error',$wpdb->last_error?:'Não foi possível criar o lançamento.');
                if($initial>0)$wpdb->insert(VFOS_DB::table('financial_payments'),['financial_id'=>$id,'amount'=>$initial,'payment_date'=>$now,'method'=>sanitize_text_field($a['method']??''),'notes'=>'Recebimento criado pela VisionForge AI','created_by'=>get_current_user_id(),'created_at'=>$now]);
                VFOS_DB::log('ai_create_financial','financial',$id,'Lançamento criado pela VisionForge AI',null,null,$description);
                return ['message'=>'Lançamento financeiro criado com sucesso.','page'=>'vfos-financial','id'=>$id];
            case 'propor_registrar_recebimento':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('financial.payments'))return new WP_Error('forbidden','Seu perfil não permite registrar recebimentos.');
                $fid=absint($a['financial_id']??0);$ft=VFOS_DB::table('financial');$pt=VFOS_DB::table('financial_payments');
                $f=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ft WHERE id=%d AND type='income'",$fid));if(!$f)return new WP_Error('not_found','Cobrança financeira não encontrada.');
                $amount=max(0,(float)($a['amount']??0));$remaining=max(0,(float)$f->amount-(float)$f->paid_amount);
                if($amount<=0||$amount>$remaining+0.001)return new WP_Error('invalid_amount','O recebimento precisa ser maior que zero e não pode ultrapassar o saldo a receber.');
                $date=self::date($a['payment_date']??'')?:date('Y-m-d');
                $wpdb->insert($pt,['financial_id'=>$fid,'amount'=>$amount,'payment_date'=>$date.' '.date('H:i:s'),'method'=>sanitize_text_field($a['method']??''),'notes'=>sanitize_textarea_field($a['notes']??''),'created_by'=>get_current_user_id(),'created_at'=>$now]);
                $received=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM $pt WHERE financial_id=%d",$fid));
                $status=$received<=0?'pending':($received+0.001>=(float)$f->amount?'paid':'partial');
                $wpdb->update($ft,['paid_amount'=>min((float)$f->amount,$received),'status'=>$status,'paid_at'=>$status==='paid'?$now:null,'updated_at'=>$now],['id'=>$fid]);
                VFOS_DB::log('ai_financial_payment','financial',$fid,'Recebimento registrado pela VisionForge AI: R$ '.number_format($amount,2,',','.'));
                return ['message'=>'Recebimento registrado com sucesso.','page'=>'vfos-financial','id'=>$fid];
            case 'propor_criar_orcamento':
                if(class_exists('VFOS_Team')&&!VFOS_Team::can_permission('quotes.create'))return new WP_Error('forbidden','Seu perfil não permite criar propostas.');
                $title=sanitize_text_field($a['title']??''); if(!$title)return new WP_Error('missing_title','Título do orçamento é obrigatório.');
                $num=VFOS_DB::next_number('quote');
                $total=max(0,(float)($a['total']??0));$token=wp_generate_password(40,false,false);
                $wpdb->insert(VFOS_DB::table('quotes'),['client_id'=>absint($a['client_id']??0),'number'=>$num,'title'=>$title,'description'=>sanitize_textarea_field($a['description']??''),'subtotal'=>$total,'discount_type'=>'fixed','discount_value'=>0,'discount_amount'=>0,'total'=>$total,'payment_terms'=>sanitize_textarea_field($a['payment_terms']??''),'valid_until'=>self::date($a['valid_until']??''),'status'=>'draft','public_token'=>$token,'created_at'=>$now,'updated_at'=>$now]);
                $id=$wpdb->insert_id;$wpdb->insert(VFOS_DB::table('quote_items'),['quote_id'=>$id,'service_id'=>0,'title'=>$title,'description'=>sanitize_textarea_field($a['description']??''),'quantity'=>1,'unit_price'=>$total,'total'=>$total,'sort_order'=>0,'created_at'=>$now]); VFOS_DB::log('ai_create_quote','quote',$id); return ['message'=>'Orçamento '.$num.' criado com sucesso.','page'=>'vfos-quotes'];
        }
        return new WP_Error('unsupported','Ação não suportada.');
    }

    private static function date($v){ $v=sanitize_text_field($v); return preg_match('/^\d{4}-\d{2}-\d{2}$/',$v)?$v:null; }

    public static function generate_field($field_type,$context='',$current='',$provider=''){
        $provider=sanitize_key($provider?:self::default_provider());
        if(!isset(self::providers()[$provider]))return new WP_Error('invalid_provider','Provedor de IA inválido.');
        if(!self::get_key($provider))return new WP_Error('no_key','Configure a API Key do '.self::providers()[$provider].' em Configurações.');
        $labels=[
            'quote_intro'=>'apresentação inicial de uma proposta comercial',
            'quote_section'=>'conteúdo de uma seção persuasiva do orçamento',
            'quote_payment_terms'=>'condições gerais de pagamento',
            'quote_notes'=>'observações finais comerciais',
            'quote_item_description'=>'descrição objetiva de um entregável',
            'external_condition'=>'condição comercial de um plano externo',
            'external_benefits'=>'benefícios inclusos em um plano externo',
            'contract_content'=>'conteúdo de contrato de prestação de serviços',
            'generic'=>'texto profissional para o campo informado'
        ];
        $label=$labels[$field_type]??$labels['generic'];
        $system="Você é a VisionForge AI preenchendo {$label}. Responda SOMENTE com o conteúdo final que deve ser inserido no campo. Português do Brasil, escrita profissional, natural e adequada ao contexto comercial da VisionForge Digital. Não use introduções do tipo 'segue abaixo'. Não invente nomes, documentos, valores, prazos, garantias ou benefícios que não estejam no contexto.";
        $prompt="Contexto:\n".sanitize_textarea_field($context);
        if(trim($current)!=='')$prompt.="\n\nTexto atual para melhorar ou completar:\n".sanitize_textarea_field($current);

        if($provider==='openrouter'){
            $body=['model'=>self::get_model('openrouter'),'messages'=>[['role'=>'system','content'=>$system],['role'=>'user','content'=>$prompt]],'temperature'=>0.45];
            $res=wp_remote_post('https://openrouter.ai/api/v1/chat/completions',['timeout'=>75,'headers'=>['Authorization'=>'Bearer '.self::get_key('openrouter'),'Content-Type'=>'application/json','HTTP-Referer'=>home_url('/'),'X-Title'=>'VisionForge OS'],'body'=>wp_json_encode($body)]);
            if(is_wp_error($res))return $res;$code=wp_remote_retrieve_response_code($res);$json=json_decode(wp_remote_retrieve_body($res),true);
            if($code<200||$code>=300)return new WP_Error('openrouter_error',$json['error']['message']??'Falha ao conectar com o OpenRouter.');
            $text=trim((string)($json['choices'][0]['message']['content']??''));
        }else{
            $body=['systemInstruction'=>['parts'=>[['text'=>$system]]],'contents'=>[['role'=>'user','parts'=>[['text'=>$prompt]]]],'generationConfig'=>['temperature'=>0.45]];
            $model=rawurlencode(self::get_model('gemini'));$url='https://generativelanguage.googleapis.com/v1beta/models/'.$model.':generateContent';
            $res=wp_remote_post($url,['timeout'=>75,'headers'=>['x-goog-api-key'=>self::get_key('gemini'),'Content-Type'=>'application/json'],'body'=>wp_json_encode($body)]);
            if(is_wp_error($res))return $res;$code=wp_remote_retrieve_response_code($res);$json=json_decode(wp_remote_retrieve_body($res),true);
            if($code<200||$code>=300)return new WP_Error('gemini_error',$json['error']['message']??'Falha ao conectar com o Google Gemini.');
            $text='';foreach(($json['candidates'][0]['content']['parts']??[]) as $part)if(isset($part['text']))$text.=$part['text'];$text=trim($text);
        }
        if(!$text)return new WP_Error('empty_ai','A IA não retornou conteúdo para o campo.');
        return $text;
    }

    public static function test($provider=''){
        $provider=sanitize_key($provider?:self::default_provider());
        $r=self::ask('Responda somente: Conexão realizada com sucesso.',$provider);
        if(is_wp_error($r))return $r;
        return $r['text'];
    }
}
