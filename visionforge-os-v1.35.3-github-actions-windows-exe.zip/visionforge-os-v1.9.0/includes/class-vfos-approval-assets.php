<?php
if(!defined('ABSPATH'))exit;

class VFOS_Approval_Assets{
    public static function init(){
        add_action('admin_post_vfos_approval_original',[__CLASS__,'admin_original']);
        add_action('admin_post_vfos_portal_approval_original',[__CLASS__,'portal_original']);
        add_action('admin_post_nopriv_vfos_portal_approval_original',[__CLASS__,'portal_original']);
    }

    private static function protected_dir(){
        $dir=WP_CONTENT_DIR.'/vfos-protected/approvals';
        if(!is_dir($dir))wp_mkdir_p($dir);
        if(is_dir($dir)){
            $base=dirname($dir);
            if(!file_exists($base.'/index.php'))@file_put_contents($base.'/index.php',"<?php\nhttp_response_code(404);exit;");
            if(!file_exists($base.'/.htaccess'))@file_put_contents($base.'/.htaccess',"Require all denied\nDeny from all\n");
            if(!file_exists($dir.'/index.php'))@file_put_contents($dir.'/index.php',"<?php\nhttp_response_code(404);exit;");
            if(!file_exists($dir.'/.htaccess'))@file_put_contents($dir.'/.htaccess',"Require all denied\nDeny from all\n");
        }
        return $dir;
    }

    public static function handle_upload($field,$client_name='',$watermark=true,$watermark_text=''){
        if(empty($_FILES[$field]['name'])||empty($_FILES[$field]['tmp_name']))return [
            'original_path'=>'','preview_url'=>'','file_url'=>'','mime_type'=>'','original_name'=>'','is_image'=>0,'watermark_text'=>''
        ];
        $f=$_FILES[$field];
        if(!empty($f['error']))return new WP_Error('upload_error','Falha no upload do arquivo (código '.absint($f['error']).').');
        $max=30*1024*1024;if((int)$f['size']>$max)return new WP_Error('too_large','O arquivo ultrapassa o limite de 30 MB.');

        require_once ABSPATH.'wp-admin/includes/file.php';
        $checked=wp_check_filetype_and_ext($f['tmp_name'],$f['name']);
        $mime=$checked['type']?:($f['type']??'');
        $ext=$checked['ext']?:pathinfo($f['name'],PATHINFO_EXTENSION);
        $allowed=get_allowed_mime_types();
        if(!$mime||!in_array($mime,$allowed,true))return new WP_Error('invalid_type','Este tipo de arquivo não é permitido pelo WordPress.');

        $is_image=strpos($mime,'image/')===0;
        if(!$is_image){
            $uploaded=wp_handle_upload($f,['test_form'=>false]);
            if(!empty($uploaded['error']))return new WP_Error('upload_error',$uploaded['error']);
            return [
                'original_path'=>$uploaded['file'],'preview_url'=>$uploaded['url'],'file_url'=>$uploaded['url'],
                'mime_type'=>$uploaded['type'],'original_name'=>sanitize_file_name($f['name']),'is_image'=>0,'watermark_text'=>''
            ];
        }

        $dir=self::protected_dir();if(!is_dir($dir)||!is_writable($dir))return new WP_Error('protected_dir','Não foi possível preparar a pasta protegida das aprovações.');
        $safe=wp_unique_filename($dir,wp_generate_password(16,false,false).'-'.sanitize_file_name($f['name']));
        $original=$dir.'/'.$safe;
        if(!@move_uploaded_file($f['tmp_name'],$original)){
            if(!@copy($f['tmp_name'],$original))return new WP_Error('move_failed','Não foi possível proteger a imagem original.');
        }

        $wm=trim(sanitize_text_field($watermark_text));
        if(!$wm)$wm='VISIONFORGE • APENAS PARA APROVAÇÃO';
        if($client_name)$wm.=' • '.mb_strtoupper(sanitize_text_field($client_name));

        $uploads=wp_upload_dir();$preview_dir=trailingslashit($uploads['basedir']).'visionforge-approvals';
        if(!is_dir($preview_dir))wp_mkdir_p($preview_dir);
        $preview_name=wp_unique_filename($preview_dir,'preview-'.pathinfo($safe,PATHINFO_FILENAME).'.jpg');
        $preview_path=$preview_dir.'/'.$preview_name;
        $ok=$watermark?self::watermark_image($original,$preview_path,$wm):self::copy_as_preview($original,$preview_path);
        if(is_wp_error($ok)){@unlink($original);return $ok;}
        $preview_url=trailingslashit($uploads['baseurl']).'visionforge-approvals/'.rawurlencode($preview_name);

        return [
            'original_path'=>$original,'preview_url'=>$preview_url,'file_url'=>$preview_url,'mime_type'=>$mime,
            'original_name'=>sanitize_file_name($f['name']),'is_image'=>1,'watermark_text'=>$wm
        ];
    }

    private static function copy_as_preview($source,$dest){
        $data=@file_get_contents($source);if($data===false)return new WP_Error('image_read','Não foi possível ler a imagem.');
        $im=@imagecreatefromstring($data);if(!$im)return new WP_Error('image_invalid','A imagem enviada não pôde ser processada.');
        imagealphablending($im,true);imagesavealpha($im,true);
        $ok=imagejpeg($im,$dest,90);imagedestroy($im);
        return $ok?true:new WP_Error('image_save','Não foi possível criar a prévia.');
    }

    private static function watermark_image($source,$dest,$text){
        if(class_exists('Imagick')){
            try{
                $img=new Imagick($source);$img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
                if(method_exists($img,'autoOrient'))$img->autoOrient();
                $w=$img->getImageWidth();$h=$img->getImageHeight();
                if($w>1800||$h>1800){$img->thumbnailImage(1800,1800,true,true);$w=$img->getImageWidth();$h=$img->getImageHeight();}
                $draw=new ImagickDraw();$draw->setFillColor(new ImagickPixel('rgba(255,255,255,0.28)'));
                $draw->setStrokeColor(new ImagickPixel('rgba(0,0,0,0.10)'));$draw->setStrokeWidth(1);
                $draw->setFontSize(max(18,min(42,(int)round($w/32))));
                $stepX=max(320,(int)round($w*.48));$stepY=max(190,(int)round($h*.28));
                for($y=-$h;$y<$h*2;$y+=$stepY){
                    for($x=-$w;$x<$w*2;$x+=$stepX)$img->annotateImage($draw,$x,$y,-28,$text);
                }
                $band=new ImagickDraw();$band->setFillColor(new ImagickPixel('rgba(8,127,199,0.72)'));
                $bandH=max(42,(int)round($h*.055));$band->rectangle(0,$h-$bandH,$w,$h);$img->drawImage($band);
                $footer=new ImagickDraw();$footer->setFillColor('white');$footer->setFontSize(max(15,min(27,(int)round($w/45))));
                $img->annotateImage($footer,18,$h-max(12,(int)round($bandH*.28)),0,'PRÉVIA PARA APROVAÇÃO • USO NÃO AUTORIZADO');
                $img->setImageFormat('jpeg');$img->setImageCompressionQuality(88);$img->stripImage();$img->writeImage($dest);$img->clear();$img->destroy();
                return true;
            }catch(Throwable $e){}
        }
        if(!function_exists('imagecreatefromstring'))return new WP_Error('image_lib','O servidor não possui GD/Imagick para gerar a marca d’água.');
        $data=@file_get_contents($source);$im=@imagecreatefromstring($data);if(!$im)return new WP_Error('image_invalid','A imagem enviada não pôde ser processada.');
        $w=imagesx($im);$h=imagesy($im);
        if($w>1800||$h>1800){
            $scale=min(1800/$w,1800/$h);$nw=(int)round($w*$scale);$nh=(int)round($h*$scale);
            $res=imagecreatetruecolor($nw,$nh);imagecopyresampled($res,$im,0,0,0,0,$nw,$nh,$w,$h);imagedestroy($im);$im=$res;$w=$nw;$h=$nh;
        }
        imagealphablending($im,true);
        $white=imagecolorallocatealpha($im,255,255,255,75);$dark=imagecolorallocatealpha($im,0,0,0,92);$blue=imagecolorallocatealpha($im,8,127,199,25);
        $font=5;$tw=imagefontwidth($font)*strlen($text);$th=imagefontheight($font);
        for($y=50;$y<$h;$y+=max(120,(int)($h/6))){
            for($x=-$tw/3;$x<$w;$x+=max(300,$tw+80)){
                imagestring($im,$font,(int)$x,$y,$text,$dark);imagestring($im,$font,(int)$x+1,$y+1,$text,$white);
            }
        }
        imagefilledrectangle($im,0,max(0,$h-54),$w,$h,$blue);
        imagestring($im,5,14,max(4,$h-36),'PREVIA PARA APROVACAO - USO NAO AUTORIZADO',$white);
        $ok=imagejpeg($im,$dest,88);imagedestroy($im);
        return $ok?true:new WP_Error('image_save','Não foi possível salvar a prévia com marca d’água.');
    }

    public static function admin_original(){
        if(!current_user_can('manage_options')&&!VFOS_Team::can_permission('projects.edit'))wp_die('Sem permissão.');
        $table=sanitize_key($_GET['table']??'client_approvals');if(!in_array($table,['client_approvals','project_approvals'],true))wp_die('Origem inválida.');
        $id=absint($_GET['id']??0);check_admin_referer('vfos_approval_original_'.$table.'_'.$id);
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table($table)." WHERE id=%d",$id));if(!$r||empty($r->original_path))wp_die('Arquivo original não encontrado.');
        self::stream($r->original_path,$r->original_name?:basename($r->original_path),$r->mime_type?:'application/octet-stream');
    }

    public static function portal_original(){
        $cid=VFOS_Portal::client_id();if(!$cid)wp_die('Sessão da Área do Cliente inválida ou expirada.');
        $table=sanitize_key($_GET['table']??'client_approvals');if(!in_array($table,['client_approvals','project_approvals'],true))wp_die('Origem inválida.');
        $id=absint($_GET['id']??0);check_admin_referer('vfos_portal_approval_original_'.$table.'_'.$id);
        global $wpdb;
        if($table==='client_approvals')$r=$wpdb->get_row($wpdb->prepare("SELECT a.* FROM ".VFOS_DB::table($table)." a WHERE a.id=%d AND a.client_id=%d",$id,$cid));
        else $r=$wpdb->get_row($wpdb->prepare("SELECT a.* FROM ".VFOS_DB::table($table)." a JOIN ".VFOS_DB::table('projects')." p ON p.id=a.project_id WHERE a.id=%d AND p.client_id=%d",$id,$cid));
        if(!$r||empty($r->release_original)||$r->status!=='approved'||empty($r->original_path))wp_die('O arquivo final ainda não foi liberado pela VisionForge.');
        self::stream($r->original_path,$r->original_name?:basename($r->original_path),$r->mime_type?:'application/octet-stream');
    }

    private static function stream($path,$name,$mime){
        if(!$path||!is_file($path)||!is_readable($path))wp_die('Arquivo indisponível.');
        nocache_headers();header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));
        header('Content-Disposition: attachment; filename="'.str_replace('"','',sanitize_file_name($name)).'"');
        readfile($path);exit;
    }
}
