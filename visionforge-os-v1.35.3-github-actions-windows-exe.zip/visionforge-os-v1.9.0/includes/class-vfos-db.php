<?php
if (!defined('ABSPATH')) exit;
class VFOS_DB {
    public static function table($name){ global $wpdb; return $wpdb->prefix.'vfos_'.$name; }
    private static function column_exists($table,$column){
        global $wpdb;
        return (bool)$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$table}` LIKE %s",$column));
    }
    private static function ensure_column($table,$column,$definition){
        global $wpdb;
        if(self::column_exists($table,$column))return true;
        $sql="ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}";
        $result=$wpdb->query($sql);
        return $result!==false && self::column_exists($table,$column);
    }
    private static function ensure_notification_schema($p){
        global $wpdb;
        $t=$p.'notifications';
        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$t))!==$t)return;
        $columns=[
            'sender_user_id'=>"BIGINT UNSIGNED DEFAULT 0 AFTER `user_id`",
            'delivery_scope'=>"VARCHAR(20) DEFAULT 'system' AFTER `sender_user_id`",
            'batch_id'=>"VARCHAR(64) DEFAULT '' AFTER `delivery_scope`",
            'allow_replies'=>"TINYINT(1) NOT NULL DEFAULT 0 AFTER `batch_id`",
            'context_label'=>"VARCHAR(190) DEFAULT '' AFTER `entity_id`",
        ];
        foreach($columns as $column=>$definition)self::ensure_column($t,$column,$definition);
        foreach(array_keys($columns) as $column){
            if(!self::column_exists($t,$column))error_log('[VisionForge OS] Falha ao criar coluna '.$column.' em '.$t.': '.$wpdb->last_error);
        }
        // Índices são opcionais para funcionamento, mas ajudam a central de notificações.
        $indexes=$wpdb->get_col("SHOW INDEX FROM `{$t}`",2);
        if(!in_array('sender_user_id',$indexes,true))$wpdb->query("ALTER TABLE `{$t}` ADD KEY `sender_user_id` (`sender_user_id`)");
        if(!in_array('delivery_scope',$indexes,true))$wpdb->query("ALTER TABLE `{$t}` ADD KEY `delivery_scope` (`delivery_scope`)");
        if(!in_array('batch_id',$indexes,true))$wpdb->query("ALTER TABLE `{$t}` ADD KEY `batch_id` (`batch_id`)");
        if(!in_array('allow_replies',$indexes,true))$wpdb->query("ALTER TABLE `{$t}` ADD KEY `allow_replies` (`allow_replies`)");
        $rt=$p.'notification_replies';
        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$rt))!==$rt){
            $c=$wpdb->get_charset_collate();
            $wpdb->query("CREATE TABLE `{$rt}` (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                notification_id BIGINT UNSIGNED NOT NULL,
                user_id BIGINT UNSIGNED NOT NULL,
                message TEXT NOT NULL,
                created_at DATETIME NOT NULL,
                PRIMARY KEY(id),
                KEY notification_id(notification_id),
                KEY user_id(user_id),
                KEY created_at(created_at)
            ) {$c}");
        }
    }
    private static function ensure_quote_schema($p){
        global $wpdb;
        $q=$p.'quotes';
        $qi=$p.'quote_items';

        // Instalações antigas do VisionForge OS tiveram versões diferentes da tabela
        // de orçamentos. Por isso esta migração confere TODOS os campos usados
        // atualmente, e não somente os campos introduzidos mais recentemente.
        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$q))===$q){
            $columns=[
                'client_id'=>"BIGINT UNSIGNED DEFAULT 0",
                'lead_id'=>"BIGINT UNSIGNED DEFAULT 0",
                'number'=>"VARCHAR(50) NOT NULL DEFAULT ''",
                'title'=>"VARCHAR(190) NOT NULL DEFAULT ''",
                'description'=>"LONGTEXT NULL",
                'subtotal'=>"DECIMAL(12,2) NOT NULL DEFAULT 0",
                'discount_type'=>"VARCHAR(20) DEFAULT 'fixed'",
                'discount_value'=>"DECIMAL(12,2) NOT NULL DEFAULT 0",
                'discount_amount'=>"DECIMAL(12,2) NOT NULL DEFAULT 0",
                'total'=>"DECIMAL(12,2) NOT NULL DEFAULT 0",
                'payment_terms'=>"LONGTEXT NULL",
                'valid_until'=>"DATE NULL",
                'notes'=>"LONGTEXT NULL",
                'status'=>"VARCHAR(30) DEFAULT 'draft'",
                'public_token'=>"VARCHAR(80) DEFAULT ''",
                'sent_at'=>"DATETIME NULL",
                'decided_at'=>"DATETIME NULL",
                'decision_ip'=>"VARCHAR(80) DEFAULT ''",
                'client_observations'=>"LONGTEXT NULL",
                'rejection_reason'=>"LONGTEXT NULL",
                'revision_suggestion'=>"LONGTEXT NULL",
                'feedback_updated_at'=>"DATETIME NULL",
            'proposal_visibility'=>'LONGTEXT NULL',
                'converted_project_id'=>"BIGINT UNSIGNED DEFAULT 0",
                'converted_contract_id'=>"BIGINT UNSIGNED DEFAULT 0",
                'converted_financial_id'=>"BIGINT UNSIGNED DEFAULT 0",
                'created_at'=>"DATETIME NULL",
                'updated_at'=>"DATETIME NULL",
            ];
            foreach($columns as $column=>$definition){
                self::ensure_column($q,$column,$definition);
            }

            // Colunas de texto de propostas não podem ficar presas aos limites
            // de versões antigas (ex.: payment_terms VARCHAR(255)).
            $text_upgrades=[
                'description'=>'LONGTEXT NULL',
                'payment_terms'=>'LONGTEXT NULL',
                'notes'=>'LONGTEXT NULL',
                'client_observations'=>'LONGTEXT NULL',
                'rejection_reason'=>'LONGTEXT NULL',
                'revision_suggestion'=>'LONGTEXT NULL',
                'proposal_visibility'=>'LONGTEXT NULL',
            ];
            foreach($text_upgrades as $column=>$definition){
                if(self::column_exists($q,$column)){
                    $wpdb->query("ALTER TABLE `{$q}` MODIFY COLUMN `{$column}` {$definition}");
                    if($wpdb->last_error)error_log('[VisionForge OS] Falha ao ampliar '.$q.'.'.$column.': '.$wpdb->last_error);
                }
            }

            // Índices importantes. São adicionados apenas quando não existem.
            $indexes=array_map('strtolower',(array)$wpdb->get_col("SHOW INDEX FROM `{$q}`",2));
            if(!in_array('client_id',$indexes,true))$wpdb->query("ALTER TABLE `{$q}` ADD KEY `client_id` (`client_id`)");
            if(!in_array('lead_id',$indexes,true))$wpdb->query("ALTER TABLE `{$q}` ADD KEY `lead_id` (`lead_id`)");
            if(!in_array('status',$indexes,true))$wpdb->query("ALTER TABLE `{$q}` ADD KEY `status` (`status`)");
            if(!in_array('public_token',$indexes,true))$wpdb->query("ALTER TABLE `{$q}` ADD KEY `public_token` (`public_token`)");

            foreach(array_keys($columns) as $column){
                if(!self::column_exists($q,$column)){
                    error_log('[VisionForge OS] Coluna obrigatória ausente em orçamentos: '.$column.' | '.$wpdb->last_error);
                }
            }
        }

        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$qi))!==$qi){
            $c=$wpdb->get_charset_collate();
            $wpdb->query("CREATE TABLE `{$qi}` (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                quote_id BIGINT UNSIGNED NOT NULL,
                service_id BIGINT UNSIGNED DEFAULT 0,
                title VARCHAR(190) NOT NULL,
                description LONGTEXT NULL,
                quantity DECIMAL(12,2) NOT NULL DEFAULT 1,
                unit_price DECIMAL(12,2) NOT NULL DEFAULT 0,
                total DECIMAL(12,2) NOT NULL DEFAULT 0,
                sort_order INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL,
                PRIMARY KEY(id),
                KEY quote_id(quote_id),
                KEY service_id(service_id)
            ) {$c}");
        }else{
            $item_columns=[
                'quote_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",
                'service_id'=>"BIGINT UNSIGNED DEFAULT 0",
                'title'=>"VARCHAR(190) NOT NULL DEFAULT ''",
                'description'=>"LONGTEXT NULL",
                'quantity'=>"DECIMAL(12,2) NOT NULL DEFAULT 1",
                'unit_price'=>"DECIMAL(12,2) NOT NULL DEFAULT 0",
                'total'=>"DECIMAL(12,2) NOT NULL DEFAULT 0",
                'sort_order'=>"INT NOT NULL DEFAULT 0",
                'created_at'=>"DATETIME NULL",
            ];
            foreach($item_columns as $column=>$definition){
                self::ensure_column($qi,$column,$definition);
            }
        }

        // Estrutura avançada das propostas comerciais.
        $c=$wpdb->get_charset_collate();
        $extra=[
            $p.'quote_sections'=>"CREATE TABLE `{$p}quote_sections` (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,quote_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,content LONGTEXT NULL,section_type VARCHAR(40) DEFAULT 'custom',sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY quote_id(quote_id),KEY sort_order(sort_order)) {$c}",
            $p.'quote_costs'=>"CREATE TABLE `{$p}quote_costs` (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,quote_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,description TEXT NULL,provider VARCHAR(120) DEFAULT '',amount DECIMAL(12,2) NOT NULL DEFAULT 0,billing_cycle VARCHAR(30) DEFAULT 'one_time',is_external TINYINT(1) NOT NULL DEFAULT 1,is_required TINYINT(1) NOT NULL DEFAULT 1,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY quote_id(quote_id),KEY billing_cycle(billing_cycle),KEY sort_order(sort_order)) {$c}",
            $p.'quote_cost_options'=>"CREATE TABLE `{$p}quote_cost_options` (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,cost_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,amount DECIMAL(12,2) NOT NULL DEFAULT 0,billing_cycle VARCHAR(30) DEFAULT 'monthly',duration_months INT NOT NULL DEFAULT 1,condition_text TEXT NULL,benefits TEXT NULL,highlight TINYINT(1) NOT NULL DEFAULT 0,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY cost_id(cost_id),KEY billing_cycle(billing_cycle),KEY sort_order(sort_order)) {$c}",
            $p.'quote_payment_options'=>"CREATE TABLE `{$p}quote_payment_options` (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,quote_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,description TEXT NULL,amount DECIMAL(12,2) NOT NULL DEFAULT 0,billing_cycle VARCHAR(30) DEFAULT 'one_time',installments INT NOT NULL DEFAULT 1,highlight TINYINT(1) NOT NULL DEFAULT 0,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY quote_id(quote_id),KEY sort_order(sort_order)) {$c}",
            $p.'quote_templates'=>"CREATE TABLE `{$p}quote_templates` (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(190) NOT NULL,description TEXT NULL,data_json LONGTEXT NOT NULL,status VARCHAR(20) DEFAULT 'active',created_by BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY status(status),KEY name(name)) {$c}",
        ];
        foreach($extra as $table=>$sql){
            if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$table))!==$table)$wpdb->query($sql);
        }

        // Amplia campos textuais das áreas complementares para evitar rejeição
        // de propostas detalhadas.
        $longtext_columns=[
            $p.'quote_items'=>['description'],
            $p.'quote_sections'=>['content'],
            $p.'quote_costs'=>['description'],
            $p.'quote_cost_options'=>['condition_text','benefits'],
            $p.'quote_payment_options'=>['description'],
            $p.'quote_templates'=>['description','data_json'],
        ];
        foreach($longtext_columns as $table=>$fields){
            if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$table))!==$table)continue;
            foreach($fields as $field){
                $wpdb->query("ALTER TABLE `{$table}` MODIFY COLUMN `{$field}` LONGTEXT NULL");
                if($wpdb->last_error)error_log('[VisionForge OS] Falha ao ampliar '.$table.'.'.$field.': '.$wpdb->last_error);
            }
        }
    }
    private static function ensure_financial_schema($p){
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $c=$wpdb->get_charset_collate();
        $f=$p.'financial';$payments=$p.'financial_payments';$splits=$p.'financial_splits';

        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$f))===$f){
            if(!self::column_exists($f,'paid_amount')){
                $wpdb->query("ALTER TABLE `{$f}` ADD COLUMN `paid_amount` DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER `amount`");
            }
            if(!self::column_exists($f,'source_type'))$wpdb->query("ALTER TABLE `{$f}` ADD COLUMN `source_type` VARCHAR(40) DEFAULT '' AFTER `method`");
            if(!self::column_exists($f,'source_id'))$wpdb->query("ALTER TABLE `{$f}` ADD COLUMN `source_id` BIGINT UNSIGNED DEFAULT 0 AFTER `source_type`");
            if(!self::column_exists($f,'is_partner_withdrawal'))$wpdb->query("ALTER TABLE `{$f}` ADD COLUMN `is_partner_withdrawal` TINYINT(1) NOT NULL DEFAULT 0 AFTER `source_id`");
        }

        dbDelta("CREATE TABLE {$payments} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            financial_id BIGINT UNSIGNED NOT NULL,
            amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            payment_date DATETIME NOT NULL,
            method VARCHAR(50) DEFAULT '',
            notes TEXT NULL,
            created_by BIGINT UNSIGNED DEFAULT 0,
            provider VARCHAR(40) DEFAULT 'manual',
            provider_payment_id VARCHAR(100) DEFAULT '',
            charge_id BIGINT UNSIGNED DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            KEY financial_id(financial_id),
            KEY payment_date(payment_date),
            KEY provider_payment_id(provider_payment_id),
            KEY charge_id(charge_id),
            KEY created_by(created_by)
        ) {$c};");
        if(self::column_exists($payments,'id')){
            if(!self::column_exists($payments,'provider'))$wpdb->query("ALTER TABLE `{$payments}` ADD COLUMN `provider` VARCHAR(40) DEFAULT 'manual' AFTER `created_by`");
            if(!self::column_exists($payments,'provider_payment_id'))$wpdb->query("ALTER TABLE `{$payments}` ADD COLUMN `provider_payment_id` VARCHAR(100) DEFAULT '' AFTER `provider`");
            if(!self::column_exists($payments,'charge_id'))$wpdb->query("ALTER TABLE `{$payments}` ADD COLUMN `charge_id` BIGINT UNSIGNED DEFAULT 0 AFTER `provider_payment_id`");
        }
        $charges=$p.'payment_charges';
        dbDelta("CREATE TABLE {$charges} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            financial_id BIGINT UNSIGNED NOT NULL,
            provider VARCHAR(40) NOT NULL DEFAULT 'mercadopago',
            method VARCHAR(30) NOT NULL DEFAULT 'pix',
            amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            currency VARCHAR(10) DEFAULT 'BRL',
            status VARCHAR(40) DEFAULT 'pending',
            external_reference VARCHAR(190) DEFAULT '',
            public_token VARCHAR(100) NOT NULL,
            provider_payment_id VARCHAR(100) DEFAULT '',
            provider_preference_id VARCHAR(120) DEFAULT '',
            payer_email VARCHAR(190) DEFAULT '',
            qr_code LONGTEXT NULL,
            qr_code_base64 LONGTEXT NULL,
            checkout_url LONGTEXT NULL,
            expires_at DATETIME NULL,
            paid_at DATETIME NULL,
            raw_response LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            KEY public_token(public_token),
            KEY financial_id(financial_id),
            KEY provider_payment_id(provider_payment_id),
            KEY external_reference(external_reference),
            KEY status(status)
        ) {$c};");

        // A tabela de divisão teve versões em que dependia apenas do dbDelta
        // geral. Criá-la explicitamente evita a aba quebrar em instalações antigas.
        dbDelta("CREATE TABLE {$splits} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            financial_id BIGINT UNSIGNED NOT NULL,
            split_type VARCHAR(20) NOT NULL DEFAULT 'partner',
            user_id BIGINT UNSIGNED DEFAULT 0,
            label VARCHAR(190) DEFAULT '',
            percentage DECIMAL(7,4) NOT NULL DEFAULT 0,
            amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            sort_order INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            KEY financial_id(financial_id),
            KEY split_type(split_type),
            KEY user_id(user_id),
            KEY sort_order(sort_order)
        ) {$c};");

        // Migra receitas antigas: se estavam marcadas como pagas e não havia
        // histórico, cria um recebimento integral. Assim nada some do financeiro.
        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$payments))===$payments){
            $legacy=$wpdb->get_results("SELECT id,amount,paid_amount,status,paid_at,method,created_at FROM {$f} WHERE type='income'");
            foreach($legacy as $row){
                $received=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$payments} WHERE financial_id=%d",$row->id));
                if($received<=0 && $row->status==='paid' && (float)$row->amount>0){
                    $wpdb->insert($payments,[
                        'financial_id'=>$row->id,'amount'=>(float)$row->amount,
                        'payment_date'=>$row->paid_at?:$row->created_at,
                        'method'=>$row->method?:'','notes'=>'Migração automática de lançamento já quitado.',
                        'created_by'=>0,'created_at'=>current_time('mysql')
                    ]);
                    $received=(float)$row->amount;
                }
                if(abs((float)$row->paid_amount-$received)>0.001){
                    $new_status=$received<=0?'pending':($received+0.001>=(float)$row->amount?'paid':'partial');
                    $wpdb->update($f,[
                        'paid_amount'=>min((float)$row->amount,$received),
                        'status'=>$new_status,
                        'paid_at'=>$new_status==='paid'?($row->paid_at?:current_time('mysql')):null
                    ],['id'=>$row->id]);
                }
            }
        }
    }

    private static function ensure_workflow_finance_schema($p){
        global $wpdb;
        $defs=[
            'leads'=>[
                'converted_quote_id'=>"BIGINT UNSIGNED DEFAULT 0 AFTER `converted_client_id`",
                'flow_quote_enabled'=>"TINYINT(1) NOT NULL DEFAULT 0 AFTER `converted_quote_id`",
            ],
            'quotes'=>[
                'flow_create_contract'=>"TINYINT(1) NOT NULL DEFAULT 1 AFTER `proposal_visibility`",
                'flow_create_project'=>"TINYINT(1) NOT NULL DEFAULT 1 AFTER `flow_create_contract`",
                'flow_create_financial'=>"TINYINT(1) NOT NULL DEFAULT 1 AFTER `flow_create_project`",
            ],
            'contracts'=>[
                'flow_create_project'=>"TINYINT(1) NOT NULL DEFAULT 0 AFTER `sign_updated_at`",
                'flow_create_financial'=>"TINYINT(1) NOT NULL DEFAULT 0 AFTER `flow_create_project`",
                'converted_financial_id'=>"BIGINT UNSIGNED DEFAULT 0 AFTER `flow_create_financial`",
            ],
            'projects'=>[
                'source_type'=>"VARCHAR(40) DEFAULT '' AFTER `notes`",
                'source_id'=>"BIGINT UNSIGNED DEFAULT 0 AFTER `source_type`",
                'flow_create_financial'=>"TINYINT(1) NOT NULL DEFAULT 0 AFTER `source_id`",
                'converted_financial_id'=>"BIGINT UNSIGNED DEFAULT 0 AFTER `flow_create_financial`",
            ],
        ];
        foreach($defs as $name=>$cols){
            $t=$p.$name;if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$t))!==$t)continue;
            foreach($cols as $col=>$definition)self::ensure_column($t,$col,$definition);
        }
        $rt=$p.'financial_recurring';
        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$rt))===$rt){
            $rcols=[
                'gateway'=>"VARCHAR(40) DEFAULT 'mercadopago' AFTER `payment_method`",
                'subscription_method'=>"VARCHAR(30) DEFAULT 'choose' AFTER `gateway`",
                'first_charge_mode'=>"VARCHAR(30) DEFAULT 'now' AFTER `subscription_method`",
                'billing_day'=>"TINYINT UNSIGNED DEFAULT 0 AFTER `first_charge_mode`",
                'payer_email'=>"VARCHAR(190) DEFAULT '' AFTER `billing_day`",
                'public_token'=>"VARCHAR(100) DEFAULT '' AFTER `payer_email`",
                'gateway_subscription_id'=>"VARCHAR(160) DEFAULT '' AFTER `public_token`",
                'gateway_plan_id'=>"VARCHAR(160) DEFAULT '' AFTER `gateway_subscription_id`",
                'checkout_url'=>"LONGTEXT NULL AFTER `gateway_plan_id`",
                'gateway_status'=>"VARCHAR(60) DEFAULT '' AFTER `checkout_url`",
                'gateway_raw'=>"LONGTEXT NULL AFTER `gateway_status`",
                'authorized_at'=>"DATETIME NULL AFTER `gateway_raw`",
                'last_payment_id'=>"VARCHAR(120) DEFAULT '' AFTER `authorized_at`",
                'last_paid_at'=>"DATETIME NULL AFTER `last_payment_id`",
                'last_sync_at'=>"DATETIME NULL AFTER `last_paid_at`",
            ];
            foreach($rcols as $col=>$definition)self::ensure_column($rt,$col,$definition);
            $missing=$wpdb->get_col("SELECT id FROM $rt WHERE public_token IS NULL OR public_token=''");
            foreach($missing as $rid)$wpdb->update($rt,['public_token'=>wp_generate_password(54,false,false)],['id'=>(int)$rid]);
            $wpdb->query("UPDATE $rt SET status='pending_authorization', gateway='mercadopago', payment_method='Mercado Pago Assinaturas' WHERE (gateway_subscription_id IS NULL OR gateway_subscription_id='') AND status='active'");
        }
        require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$p}financial_recurring (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id BIGINT UNSIGNED DEFAULT 0,
            project_id BIGINT UNSIGNED DEFAULT 0,
            contract_id BIGINT UNSIGNED DEFAULT 0,
            title VARCHAR(255) NOT NULL,
            amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            frequency VARCHAR(30) NOT NULL DEFAULT 'monthly',
            interval_count INT NOT NULL DEFAULT 1,
            next_due_date DATE NOT NULL,
            end_date DATE NULL,
            auto_generate TINYINT(1) NOT NULL DEFAULT 1,
            payment_method VARCHAR(80) DEFAULT '',
            gateway VARCHAR(40) DEFAULT 'mercadopago',
            subscription_method VARCHAR(30) DEFAULT 'choose',
            first_charge_mode VARCHAR(30) DEFAULT 'now',
            billing_day TINYINT UNSIGNED DEFAULT 0,
            payer_email VARCHAR(190) DEFAULT '',
            public_token VARCHAR(100) DEFAULT '',
            gateway_subscription_id VARCHAR(160) DEFAULT '',
            gateway_plan_id VARCHAR(160) DEFAULT '',
            checkout_url LONGTEXT NULL,
            gateway_status VARCHAR(60) DEFAULT '',
            gateway_raw LONGTEXT NULL,
            authorized_at DATETIME NULL,
            last_payment_id VARCHAR(120) DEFAULT '',
            last_paid_at DATETIME NULL,
            last_sync_at DATETIME NULL,
            notes TEXT NULL,
            status VARCHAR(30) DEFAULT 'pending_authorization',
            last_financial_id BIGINT UNSIGNED DEFAULT 0,
            created_by BIGINT UNSIGNED DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            KEY public_token(public_token),
            KEY client_id(client_id),
            KEY next_due_date(next_due_date),
            KEY status(status),
            KEY contract_id(contract_id),
            KEY gateway_subscription_id(gateway_subscription_id),
            KEY gateway_plan_id(gateway_plan_id)
        ) {$c};");
    }

    private static function ensure_client_portal_schema($p){
        global $wpdb;$t=$p.'clients';
        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$t))!==$t)return;
        $columns=[
            'portal_access_mode'=>"VARCHAR(30) DEFAULT 'direct_link' AFTER `responsible_profession`",
            'portal_token_hash'=>"VARCHAR(64) DEFAULT '' AFTER `portal_access_mode`",
            'portal_token_hint'=>"VARCHAR(16) DEFAULT '' AFTER `portal_token_hash`",
            'portal_token_expires'=>"DATETIME NULL AFTER `portal_token_hint`",
            'portal_token_created_at'=>"DATETIME NULL AFTER `portal_token_expires`",
            'portal_token_created_by'=>"BIGINT UNSIGNED DEFAULT 0 AFTER `portal_token_created_at`",
            'portal_identifier_enabled'=>"TINYINT(1) NOT NULL DEFAULT 1 AFTER `portal_token_created_by`",
            'portal_sensitive_confirm'=>"TINYINT(1) NOT NULL DEFAULT 0 AFTER `portal_identifier_enabled`",
        ];
        foreach($columns as $column=>$definition)self::ensure_column($t,$column,$definition);
    }

    private static function ensure_approval_schema($p){
        global $wpdb;
        foreach(['client_approvals','project_approvals'] as $name){
            $t=$p.$name;if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$t))!==$t)continue;
            $columns=[
                'original_path'=>"TEXT NULL AFTER `file_url`",
                'original_name'=>"VARCHAR(255) DEFAULT '' AFTER `original_path`",
                'preview_url'=>"TEXT NULL AFTER `original_name`",
                'mime_type'=>"VARCHAR(120) DEFAULT '' AFTER `preview_url`",
                'watermark_enabled'=>"TINYINT(1) NOT NULL DEFAULT 0 AFTER `mime_type`",
                'watermark_text'=>"VARCHAR(255) DEFAULT '' AFTER `watermark_enabled`",
                'release_original'=>"TINYINT(1) NOT NULL DEFAULT 0 AFTER `watermark_text`",
                'approval_group'=>"VARCHAR(64) DEFAULT '' AFTER `release_original`",
                'selection_mode'=>"VARCHAR(30) DEFAULT 'single' AFTER `approval_group`",
                'option_label'=>"VARCHAR(190) DEFAULT '' AFTER `selection_mode`",
                'option_order'=>"INT NOT NULL DEFAULT 0 AFTER `option_label`",
            ];
            foreach($columns as $column=>$definition)self::ensure_column($t,$column,$definition);
        }
    }

    public static function ensure_desktop_schema(){
        global $wpdb;
        $c=$wpdb->get_charset_collate();
        $tokens=self::table('desktop_tokens');
        $ops=self::table('desktop_sync_ops');
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$tokens}` (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            token_hash CHAR(64) NOT NULL,
            device_name VARCHAR(190) DEFAULT '',
            created_at DATETIME NOT NULL,
            last_used_at DATETIME NULL,
            expires_at DATETIME NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY token_hash(token_hash), KEY user_id(user_id), KEY expires_at(expires_at)
        ) {$c}");
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$ops}` (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            client_op_id CHAR(64) NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            table_name VARCHAR(80) NOT NULL,
            action VARCHAR(20) NOT NULL,
            server_id BIGINT UNSIGNED DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY client_op_id(client_op_id), KEY user_id(user_id), KEY table_name(table_name), KEY created_at(created_at)
        ) {$c}");
    }

    public static function activate(){
        global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $c=$wpdb->get_charset_collate(); $p=$wpdb->prefix.'vfos_';
        $sql=[];
        $sql[]="CREATE TABLE {$p}leads (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(190) NOT NULL,company VARCHAR(190) DEFAULT '',email VARCHAR(190) DEFAULT '',phone VARCHAR(60) DEFAULT '',source VARCHAR(80) DEFAULT '',service_interest VARCHAR(190) DEFAULT '',estimated_value DECIMAL(12,2) NOT NULL DEFAULT 0,stage VARCHAR(30) DEFAULT 'new',probability TINYINT UNSIGNED NOT NULL DEFAULT 10,next_followup DATE NULL,notes LONGTEXT NULL,converted_client_id BIGINT UNSIGNED DEFAULT 0,converted_quote_id BIGINT UNSIGNED DEFAULT 0,flow_quote_enabled TINYINT(1) NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY stage(stage),KEY next_followup(next_followup),KEY name(name)) $c;";
        $sql[]="CREATE TABLE {$p}lead_activities (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,lead_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED DEFAULT 0,type VARCHAR(40) DEFAULT 'note',content TEXT NOT NULL,activity_date DATETIME NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY lead_id(lead_id),KEY activity_date(activity_date)) $c;";
        $sql[]="CREATE TABLE {$p}clients (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
person_type VARCHAR(10) DEFAULT 'pf',
name VARCHAR(190) NOT NULL,
company VARCHAR(190) DEFAULT '',
legal_name VARCHAR(190) DEFAULT '',
trade_name VARCHAR(190) DEFAULT '',
document VARCHAR(80) DEFAULT '',
state_registration VARCHAR(80) DEFAULT '',
municipal_registration VARCHAR(80) DEFAULT '',
email VARCHAR(190) DEFAULT '',
billing_email VARCHAR(190) DEFAULT '',
phone VARCHAR(60) DEFAULT '',
whatsapp VARCHAR(60) DEFAULT '',
website VARCHAR(190) DEFAULT '',
birth_date DATE NULL,
profession VARCHAR(120) DEFAULT '',
nationality VARCHAR(100) DEFAULT '',
marital_status VARCHAR(60) DEFAULT '',
rg VARCHAR(80) DEFAULT '',
address_zip VARCHAR(20) DEFAULT '',
address_street VARCHAR(190) DEFAULT '',
address_number VARCHAR(30) DEFAULT '',
address_complement VARCHAR(120) DEFAULT '',
address_neighborhood VARCHAR(120) DEFAULT '',
address_city VARCHAR(120) DEFAULT '',
address_state VARCHAR(30) DEFAULT '',
responsible_name VARCHAR(190) DEFAULT '',
responsible_role VARCHAR(120) DEFAULT '',
responsible_cpf VARCHAR(80) DEFAULT '',
responsible_rg VARCHAR(80) DEFAULT '',
responsible_birth_date DATE NULL,
responsible_email VARCHAR(190) DEFAULT '',
responsible_phone VARCHAR(60) DEFAULT '',
responsible_whatsapp VARCHAR(60) DEFAULT '',
responsible_nationality VARCHAR(100) DEFAULT '',
responsible_marital_status VARCHAR(60) DEFAULT '',
responsible_profession VARCHAR(120) DEFAULT '',
status VARCHAR(30) DEFAULT 'active',
notes LONGTEXT NULL,
created_by BIGINT UNSIGNED DEFAULT 0,
updated_by BIGINT UNSIGNED DEFAULT 0,
created_at DATETIME NOT NULL,
updated_at DATETIME NOT NULL,
PRIMARY KEY(id),KEY person_type(person_type),KEY status(status),KEY name(name),KEY document(document)) $c;";
        $sql[]="CREATE TABLE {$p}services (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(190) NOT NULL,description TEXT NULL,price DECIMAL(12,2) NOT NULL DEFAULT 0,status VARCHAR(30) DEFAULT 'active',created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}projects (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,client_id BIGINT UNSIGNED DEFAULT 0,service_id BIGINT UNSIGNED DEFAULT 0,name VARCHAR(190) NOT NULL,status VARCHAR(40) DEFAULT 'planning',priority VARCHAR(20) DEFAULT 'normal',value DECIMAL(12,2) NOT NULL DEFAULT 0,due_date DATE NULL,progress TINYINT UNSIGNED NOT NULL DEFAULT 0,notes LONGTEXT NULL,source_type VARCHAR(40) DEFAULT '',source_id BIGINT UNSIGNED DEFAULT 0,flow_create_financial TINYINT(1) NOT NULL DEFAULT 0,converted_financial_id BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY client_id(client_id),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}tasks (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,project_id BIGINT UNSIGNED DEFAULT 0,client_id BIGINT UNSIGNED DEFAULT 0,stage_id BIGINT UNSIGNED DEFAULT 0,parent_task_id BIGINT UNSIGNED DEFAULT 0,depends_on_task_id BIGINT UNSIGNED DEFAULT 0,title VARCHAR(190) NOT NULL,description TEXT NULL,status VARCHAR(30) DEFAULT 'pending',priority VARCHAR(20) DEFAULT 'normal',start_date DATE NULL,due_date DATE NULL,assigned_user_id BIGINT UNSIGNED DEFAULT 0,estimated_hours DECIMAL(8,2) NOT NULL DEFAULT 0,actual_hours DECIMAL(8,2) NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY project_id(project_id),KEY status(status),KEY due_date(due_date),KEY assigned_user_id(assigned_user_id)) $c;";
        $sql[]="CREATE TABLE {$p}quotes (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,client_id BIGINT UNSIGNED DEFAULT 0,lead_id BIGINT UNSIGNED DEFAULT 0,number VARCHAR(50) NOT NULL,title VARCHAR(190) NOT NULL,description LONGTEXT NULL,subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,discount_type VARCHAR(20) DEFAULT 'fixed',discount_value DECIMAL(12,2) NOT NULL DEFAULT 0,discount_amount DECIMAL(12,2) NOT NULL DEFAULT 0,total DECIMAL(12,2) NOT NULL DEFAULT 0,payment_terms LONGTEXT NULL,valid_until DATE NULL,notes LONGTEXT NULL,status VARCHAR(30) DEFAULT 'draft',public_token VARCHAR(80) DEFAULT '',sent_at DATETIME NULL,decided_at DATETIME NULL,decision_ip VARCHAR(80) DEFAULT '',client_observations LONGTEXT NULL,rejection_reason LONGTEXT NULL,revision_suggestion LONGTEXT NULL,feedback_updated_at DATETIME NULL,proposal_visibility LONGTEXT NULL,flow_create_contract TINYINT(1) NOT NULL DEFAULT 1,flow_create_project TINYINT(1) NOT NULL DEFAULT 1,flow_create_financial TINYINT(1) NOT NULL DEFAULT 1,converted_project_id BIGINT UNSIGNED DEFAULT 0,converted_contract_id BIGINT UNSIGNED DEFAULT 0,converted_financial_id BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),UNIQUE KEY number(number),KEY public_token(public_token),KEY client_id(client_id),KEY lead_id(lead_id),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}contract_templates (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(190) NOT NULL,description TEXT NULL,content LONGTEXT NULL,status VARCHAR(20) DEFAULT 'active',created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY status(status),KEY name(name)) $c;";
        $sql[]="CREATE TABLE {$p}contracts (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,client_id BIGINT UNSIGNED DEFAULT 0,project_id BIGINT UNSIGNED DEFAULT 0,quote_id BIGINT UNSIGNED DEFAULT 0,number VARCHAR(50) NOT NULL,title VARCHAR(190) NOT NULL,content LONGTEXT NULL,value DECIMAL(12,2) NOT NULL DEFAULT 0,status VARCHAR(40) DEFAULT 'draft',pdf_path TEXT NULL,sign_external_id VARCHAR(190) DEFAULT '',sign_public_code VARCHAR(80) DEFAULT '',sign_url TEXT NULL,sign_admin_url TEXT NULL,sign_signed_url TEXT NULL,sign_status VARCHAR(60) DEFAULT '',sign_opened_at DATETIME NULL,sign_signed_at DATETIME NULL,sign_updated_at DATETIME NULL,flow_create_project TINYINT(1) NOT NULL DEFAULT 0,flow_create_financial TINYINT(1) NOT NULL DEFAULT 0,converted_financial_id BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),UNIQUE KEY number(number),KEY client_id(client_id),KEY project_id(project_id),KEY status(status),KEY sign_external_id(sign_external_id)) $c;";
        $sql[]="CREATE TABLE {$p}financial (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,client_id BIGINT UNSIGNED DEFAULT 0,project_id BIGINT UNSIGNED DEFAULT 0,type VARCHAR(20) NOT NULL DEFAULT 'income',description VARCHAR(255) NOT NULL,amount DECIMAL(12,2) NOT NULL DEFAULT 0,paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,status VARCHAR(30) NOT NULL DEFAULT 'pending',due_date DATE NULL,paid_at DATETIME NULL,method VARCHAR(50) DEFAULT '',source_type VARCHAR(40) DEFAULT '',source_id BIGINT UNSIGNED DEFAULT 0,is_partner_withdrawal TINYINT(1) NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY type(type),KEY status(status),KEY client_id(client_id)) $c;";
        $sql[]="CREATE TABLE {$p}financial_recurring (    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,    client_id BIGINT UNSIGNED DEFAULT 0,    project_id BIGINT UNSIGNED DEFAULT 0,    contract_id BIGINT UNSIGNED DEFAULT 0,    title VARCHAR(255) NOT NULL,    amount DECIMAL(12,2) NOT NULL DEFAULT 0,    frequency VARCHAR(30) NOT NULL DEFAULT 'monthly',    interval_count INT NOT NULL DEFAULT 1,    next_due_date DATE NOT NULL,    end_date DATE NULL,    auto_generate TINYINT(1) NOT NULL DEFAULT 1,    payment_method VARCHAR(80) DEFAULT '',    gateway VARCHAR(40) DEFAULT 'mercadopago',    subscription_method VARCHAR(30) DEFAULT 'choose',    first_charge_mode VARCHAR(30) DEFAULT 'now',    billing_day TINYINT UNSIGNED DEFAULT 0,    payer_email VARCHAR(190) DEFAULT '',    public_token VARCHAR(100) DEFAULT '',    gateway_subscription_id VARCHAR(160) DEFAULT '',    gateway_plan_id VARCHAR(160) DEFAULT '',    checkout_url LONGTEXT NULL,    gateway_status VARCHAR(60) DEFAULT '',    gateway_raw LONGTEXT NULL,    authorized_at DATETIME NULL,    last_payment_id VARCHAR(120) DEFAULT '',    last_paid_at DATETIME NULL,    last_sync_at DATETIME NULL,    notes TEXT NULL,    status VARCHAR(30) DEFAULT 'pending_authorization',    last_financial_id BIGINT UNSIGNED DEFAULT 0,    created_by BIGINT UNSIGNED DEFAULT 0,    created_at DATETIME NOT NULL,    updated_at DATETIME NOT NULL,    PRIMARY KEY(id),    KEY public_token(public_token),    KEY client_id(client_id),    KEY next_due_date(next_due_date),    KEY status(status),    KEY contract_id(contract_id),    KEY gateway_subscription_id(gateway_subscription_id),    KEY gateway_plan_id(gateway_plan_id))  $c;";
        $sql[]="CREATE TABLE {$p}financial_payments (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,financial_id BIGINT UNSIGNED NOT NULL,amount DECIMAL(12,2) NOT NULL DEFAULT 0,payment_date DATETIME NOT NULL,method VARCHAR(100) DEFAULT '',notes TEXT NULL,created_by BIGINT UNSIGNED DEFAULT 0,provider VARCHAR(40) DEFAULT 'manual',provider_payment_id VARCHAR(100) DEFAULT '',charge_id BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY financial_id(financial_id),KEY payment_date(payment_date),KEY provider_payment_id(provider_payment_id),KEY charge_id(charge_id),KEY created_by(created_by)) $c;";
        $sql[]="CREATE TABLE {$p}payment_charges (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,financial_id BIGINT UNSIGNED NOT NULL,provider VARCHAR(40) NOT NULL DEFAULT 'mercadopago',method VARCHAR(30) NOT NULL DEFAULT 'pix',amount DECIMAL(12,2) NOT NULL DEFAULT 0,currency VARCHAR(10) DEFAULT 'BRL',status VARCHAR(40) DEFAULT 'pending',external_reference VARCHAR(190) DEFAULT '',public_token VARCHAR(100) NOT NULL,provider_payment_id VARCHAR(100) DEFAULT '',provider_preference_id VARCHAR(120) DEFAULT '',payer_email VARCHAR(190) DEFAULT '',qr_code LONGTEXT NULL,qr_code_base64 LONGTEXT NULL,checkout_url LONGTEXT NULL,expires_at DATETIME NULL,paid_at DATETIME NULL,raw_response LONGTEXT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY public_token(public_token),KEY financial_id(financial_id),KEY provider_payment_id(provider_payment_id),KEY external_reference(external_reference),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}financial_splits (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,financial_id BIGINT UNSIGNED NOT NULL,split_type VARCHAR(20) NOT NULL DEFAULT 'partner',user_id BIGINT UNSIGNED DEFAULT 0,label VARCHAR(190) DEFAULT '',percentage DECIMAL(7,4) NOT NULL DEFAULT 0,amount DECIMAL(12,2) NOT NULL DEFAULT 0,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY financial_id(financial_id),KEY split_type(split_type),KEY user_id(user_id),KEY sort_order(sort_order)) $c;";
        $sql[]="CREATE TABLE {$p}ai_logs (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED DEFAULT 0,conversation_id VARCHAR(64) DEFAULT '',client_id BIGINT UNSIGNED DEFAULT 0,provider VARCHAR(30) DEFAULT '',prompt LONGTEXT NOT NULL,response LONGTEXT NULL,proposal LONGTEXT NULL,model VARCHAR(100) DEFAULT '',status VARCHAR(30) DEFAULT 'success',created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY user_id(user_id),KEY conversation_id(conversation_id),KEY client_id(client_id),KEY created_at(created_at)) $c;";
                $sql[]="CREATE TABLE {$p}client_notes (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,client_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED DEFAULT 0,content LONGTEXT NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY client_id(client_id),KEY created_at(created_at)) $c;";
        $sql[]="CREATE TABLE {$p}client_files (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,client_id BIGINT UNSIGNED NOT NULL,project_id BIGINT UNSIGNED DEFAULT 0,attachment_id BIGINT UNSIGNED NOT NULL DEFAULT 0,title VARCHAR(190) DEFAULT '',file_url TEXT NULL,mime_type VARCHAR(100) DEFAULT '',source VARCHAR(20) DEFAULT 'staff',uploaded_by BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY client_id(client_id),KEY project_id(project_id),KEY attachment_id(attachment_id),KEY source(source)) $c;";
        $sql[]="CREATE TABLE {$p}client_approvals (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,client_id BIGINT UNSIGNED NOT NULL,project_id BIGINT UNSIGNED DEFAULT 0,title VARCHAR(190) NOT NULL,description TEXT NULL,attachment_id BIGINT UNSIGNED DEFAULT 0,file_url TEXT NULL,original_path TEXT NULL,original_name VARCHAR(255) DEFAULT '',preview_url TEXT NULL,mime_type VARCHAR(120) DEFAULT '',watermark_enabled TINYINT(1) NOT NULL DEFAULT 0,watermark_text VARCHAR(255) DEFAULT '',release_original TINYINT(1) NOT NULL DEFAULT 0,approval_group VARCHAR(64) DEFAULT '',selection_mode VARCHAR(30) DEFAULT 'single',option_label VARCHAR(190) DEFAULT '',option_order INT NOT NULL DEFAULT 0,status VARCHAR(30) NOT NULL DEFAULT 'pending',requested_by BIGINT UNSIGNED DEFAULT 0,decided_by BIGINT UNSIGNED DEFAULT 0,decision_comment TEXT NULL,requested_at DATETIME NOT NULL,decided_at DATETIME NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY client_id(client_id),KEY project_id(project_id),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}portal_messages (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,client_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED DEFAULT 0,direction VARCHAR(20) NOT NULL DEFAULT 'client',message LONGTEXT NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY client_id(client_id),KEY created_at(created_at)) $c;";
        $sql[]="CREATE TABLE {$p}automations (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(190) NOT NULL,trigger_type VARCHAR(60) NOT NULL,days_offset INT NOT NULL DEFAULT 0,channel VARCHAR(20) NOT NULL DEFAULT 'internal',email_to VARCHAR(190) DEFAULT '',message TEXT NULL,status VARCHAR(20) NOT NULL DEFAULT 'active',last_run_at DATETIME NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY trigger_type(trigger_type),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}automation_runs (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,automation_id BIGINT UNSIGNED NOT NULL,object_key VARCHAR(190) NOT NULL,message TEXT NULL,channel VARCHAR(20) DEFAULT '',email_status VARCHAR(20) DEFAULT '',created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY automation_id(automation_id),KEY object_key(object_key),KEY created_at(created_at)) $c;";
$sql[]="CREATE TABLE {$p}activity_logs (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED DEFAULT 0,
action VARCHAR(100) NOT NULL,
action_label VARCHAR(190) DEFAULT '',
object_type VARCHAR(50) DEFAULT '',
object_id BIGINT UNSIGNED DEFAULT 0,
object_label VARCHAR(190) DEFAULT '',
details TEXT NULL,
before_data LONGTEXT NULL,
after_data LONGTEXT NULL,
ip_address VARCHAR(64) DEFAULT '',
user_agent VARCHAR(255) DEFAULT '',
created_at DATETIME NOT NULL,
PRIMARY KEY(id),KEY user_id(user_id),KEY action(action),KEY object_type(object_type),KEY created_at(created_at)) $c;";
        $sql[]="CREATE TABLE {$p}quote_items (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,quote_id BIGINT UNSIGNED NOT NULL,service_id BIGINT UNSIGNED DEFAULT 0,title VARCHAR(190) NOT NULL,description LONGTEXT NULL,quantity DECIMAL(10,2) NOT NULL DEFAULT 1,unit_price DECIMAL(12,2) NOT NULL DEFAULT 0,total DECIMAL(12,2) NOT NULL DEFAULT 0,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY quote_id(quote_id),KEY service_id(service_id),KEY sort_order(sort_order)) $c;";
        $sql[]="CREATE TABLE {$p}quote_sections (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,quote_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,content LONGTEXT NULL,section_type VARCHAR(40) DEFAULT 'custom',sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY quote_id(quote_id),KEY sort_order(sort_order)) $c;";
        $sql[]="CREATE TABLE {$p}quote_costs (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,quote_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,description TEXT NULL,provider VARCHAR(120) DEFAULT '',amount DECIMAL(12,2) NOT NULL DEFAULT 0,billing_cycle VARCHAR(30) DEFAULT 'one_time',is_external TINYINT(1) NOT NULL DEFAULT 1,is_required TINYINT(1) NOT NULL DEFAULT 1,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY quote_id(quote_id),KEY billing_cycle(billing_cycle),KEY sort_order(sort_order)) $c;";
                $sql[]="CREATE TABLE {$p}quote_cost_options (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,cost_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,amount DECIMAL(12,2) NOT NULL DEFAULT 0,billing_cycle VARCHAR(30) DEFAULT 'monthly',duration_months INT NOT NULL DEFAULT 1,condition_text TEXT NULL,benefits TEXT NULL,highlight TINYINT(1) NOT NULL DEFAULT 0,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY cost_id(cost_id),KEY billing_cycle(billing_cycle),KEY sort_order(sort_order)) $c;";
$sql[]="CREATE TABLE {$p}quote_payment_options (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,quote_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,description TEXT NULL,amount DECIMAL(12,2) NOT NULL DEFAULT 0,billing_cycle VARCHAR(30) DEFAULT 'one_time',installments INT NOT NULL DEFAULT 1,highlight TINYINT(1) NOT NULL DEFAULT 0,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY quote_id(quote_id),KEY sort_order(sort_order)) $c;";
        $sql[]="CREATE TABLE {$p}quote_templates (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(190) NOT NULL,description TEXT NULL,data_json LONGTEXT NOT NULL,status VARCHAR(20) DEFAULT 'active',created_by BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY status(status),KEY name(name)) $c;";

        $sql[]="CREATE TABLE {$p}project_presentations (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,project_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,subtitle VARCHAR(255) DEFAULT '',why_title VARCHAR(190) DEFAULT '',why_content LONGTEXT NULL,vision_title VARCHAR(190) DEFAULT '',vision_content LONGTEXT NULL,included_title VARCHAR(190) DEFAULT '',included_items LONGTEXT NULL,investment_title VARCHAR(190) DEFAULT '',investment_content LONGTEXT NULL,investment_value DECIMAL(12,2) NOT NULL DEFAULT 0,differentials_title VARCHAR(190) DEFAULT '',differentials LONGTEXT NULL,payment_title VARCHAR(190) DEFAULT '',payment_content LONGTEXT NULL,closing_title VARCHAR(190) DEFAULT '',closing_content LONGTEXT NULL,show_why TINYINT(1) DEFAULT 1,show_vision TINYINT(1) DEFAULT 1,show_included TINYINT(1) DEFAULT 1,show_investment TINYINT(1) DEFAULT 1,show_differentials TINYINT(1) DEFAULT 1,show_payment TINYINT(1) DEFAULT 1,show_closing TINYINT(1) DEFAULT 1,pdf_path TEXT NULL,updated_by BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),UNIQUE KEY project_id(project_id)) $c;";
        $sql[]="CREATE TABLE {$p}project_stages (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,project_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,description TEXT NULL,status VARCHAR(30) DEFAULT 'pending',assigned_user_id BIGINT UNSIGNED DEFAULT 0,start_date DATE NULL,due_date DATE NULL,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY project_id(project_id),KEY assigned_user_id(assigned_user_id),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}project_approvals (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,project_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,description TEXT NULL,file_url TEXT NULL,original_path TEXT NULL,original_name VARCHAR(255) DEFAULT '',preview_url TEXT NULL,mime_type VARCHAR(120) DEFAULT '',watermark_enabled TINYINT(1) NOT NULL DEFAULT 0,watermark_text VARCHAR(255) DEFAULT '',release_original TINYINT(1) NOT NULL DEFAULT 0,status VARCHAR(30) DEFAULT 'pending',requested_by BIGINT UNSIGNED DEFAULT 0,requested_at DATETIME NOT NULL,responded_at DATETIME NULL,response_note TEXT NULL,PRIMARY KEY(id),KEY project_id(project_id),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}notifications (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED NOT NULL,sender_user_id BIGINT UNSIGNED DEFAULT 0,delivery_scope VARCHAR(20) DEFAULT 'system',batch_id VARCHAR(64) DEFAULT '',allow_replies TINYINT(1) NOT NULL DEFAULT 0,type VARCHAR(50) DEFAULT 'info',title VARCHAR(190) NOT NULL,message TEXT NULL,module VARCHAR(50) DEFAULT '',entity_type VARCHAR(50) DEFAULT '',entity_id BIGINT UNSIGNED DEFAULT 0,context_label VARCHAR(190) DEFAULT '',url TEXT NULL,is_read TINYINT(1) NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,read_at DATETIME NULL,PRIMARY KEY(id),KEY user_id(user_id),KEY sender_user_id(sender_user_id),KEY delivery_scope(delivery_scope),KEY batch_id(batch_id),KEY allow_replies(allow_replies),KEY is_read(is_read),KEY created_at(created_at),KEY entity_type(entity_type),KEY entity_id(entity_id)) $c;";
        $sql[]="CREATE TABLE {$p}notification_replies (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,notification_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,message TEXT NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY notification_id(notification_id),KEY user_id(user_id),KEY created_at(created_at)) $c;";
        $sql[]="CREATE TABLE {$p}activity_feed (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED DEFAULT 0,actor_user_id BIGINT UNSIGNED DEFAULT 0,action_key VARCHAR(80) NOT NULL,title VARCHAR(190) NOT NULL,description TEXT NULL,module VARCHAR(50) DEFAULT '',entity_type VARCHAR(50) DEFAULT '',entity_id BIGINT UNSIGNED DEFAULT 0,url TEXT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY user_id(user_id),KEY action_key(action_key),KEY created_at(created_at),KEY entity_type(entity_type),KEY entity_id(entity_id)) $c;";
        $sql[]="CREATE TABLE {$p}calendar_events (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,title VARCHAR(190) NOT NULL,description TEXT NULL,event_type VARCHAR(40) DEFAULT 'meeting',start_at DATETIME NOT NULL,end_at DATETIME NULL,all_day TINYINT(1) NOT NULL DEFAULT 0,client_id BIGINT UNSIGNED DEFAULT 0,project_id BIGINT UNSIGNED DEFAULT 0,assigned_user_id BIGINT UNSIGNED DEFAULT 0,status VARCHAR(30) DEFAULT 'scheduled',location VARCHAR(190) DEFAULT '',meeting_url TEXT NULL,created_by BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY start_at(start_at),KEY event_type(event_type),KEY assigned_user_id(assigned_user_id),KEY client_id(client_id),KEY project_id(project_id),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}team_groups (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(120) NOT NULL,slug VARCHAR(120) NOT NULL,description TEXT NULL,status VARCHAR(20) DEFAULT 'active',created_by BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),UNIQUE KEY slug(slug),KEY status(status),KEY name(name)) $c;";
        $sql[]="CREATE TABLE {$p}team_group_members (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,group_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(id),UNIQUE KEY group_user(group_id,user_id),KEY group_id(group_id),KEY user_id(user_id)) $c;";
        $sql[]="CREATE TABLE {$p}permission_scopes (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED NOT NULL,permission_key VARCHAR(120) NOT NULL,group_id BIGINT UNSIGNED NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(id),UNIQUE KEY user_permission_group(user_id,permission_key,group_id),KEY user_id(user_id),KEY permission_key(permission_key),KEY group_id(group_id)) $c;";
        $sql[]="CREATE TABLE {$p}team (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED NOT NULL,role_key VARCHAR(40) DEFAULT 'production',job_title VARCHAR(120) DEFAULT '',department VARCHAR(120) DEFAULT '',capacity_hours DECIMAL(6,2) NOT NULL DEFAULT 8,status VARCHAR(20) DEFAULT 'active',custom_permissions LONGTEXT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),UNIQUE KEY user_id(user_id),KEY role_key(role_key),KEY status(status)) $c;";
        $sql[]="CREATE TABLE {$p}project_comments (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,project_id BIGINT UNSIGNED NOT NULL,task_id BIGINT UNSIGNED DEFAULT 0,user_id BIGINT UNSIGNED DEFAULT 0,content LONGTEXT NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY project_id(project_id),KEY task_id(task_id),KEY created_at(created_at)) $c;";
        $sql[]="CREATE TABLE {$p}project_files (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,project_id BIGINT UNSIGNED NOT NULL,task_id BIGINT UNSIGNED DEFAULT 0,attachment_id BIGINT UNSIGNED DEFAULT 0,title VARCHAR(190) DEFAULT '',file_url TEXT NULL,mime_type VARCHAR(100) DEFAULT '',user_id BIGINT UNSIGNED DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY project_id(project_id),KEY task_id(task_id),KEY attachment_id(attachment_id)) $c;";
        $sql[]="CREATE TABLE {$p}task_checklist (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,task_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,is_done TINYINT(1) NOT NULL DEFAULT 0,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY task_id(task_id),KEY is_done(is_done)) $c;";
        $sql[]="CREATE TABLE {$p}project_templates (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(190) NOT NULL,description TEXT NULL,service_id BIGINT UNSIGNED DEFAULT 0,default_duration INT NOT NULL DEFAULT 30,default_priority VARCHAR(20) DEFAULT 'normal',default_value DECIMAL(12,2) NOT NULL DEFAULT 0,status VARCHAR(20) DEFAULT 'active',created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(id),KEY status(status),KEY service_id(service_id)) $c;";
        $sql[]="CREATE TABLE {$p}project_template_items (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,template_id BIGINT UNSIGNED NOT NULL,title VARCHAR(190) NOT NULL,item_type VARCHAR(30) DEFAULT 'task',description TEXT NULL,day_offset INT NOT NULL DEFAULT 0,priority VARCHAR(20) DEFAULT 'normal',sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,PRIMARY KEY(id),KEY template_id(template_id),KEY item_type(item_type),KEY sort_order(sort_order)) $c;";
        foreach($sql as $q) dbDelta($q);
        self::ensure_financial_schema($p);
        self::ensure_workflow_finance_schema($p);
        self::ensure_client_portal_schema($p);
        self::ensure_approval_schema($p);
        self::ensure_quote_schema($p);
        self::ensure_notification_schema($p);
        // Migração segura das propostas antigas para o novo formato com itens e link público.
        $quotes_table=$p.'quotes';$quote_items_table=$p.'quote_items';
        $legacy_quotes=$wpdb->get_results("SELECT id,title,description,total,subtotal,public_token FROM {$quotes_table}");
        foreach($legacy_quotes as $legacy){
            $updates=[];
            if(empty($legacy->public_token)) $updates['public_token']=wp_generate_password(40,false,false);
            if((float)$legacy->subtotal<=0 && (float)$legacy->total>0) $updates['subtotal']=(float)$legacy->total;
            if($updates) $wpdb->update($quotes_table,$updates,['id'=>$legacy->id]);
            $has_item=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$quote_items_table} WHERE quote_id=%d",$legacy->id));
            if(!$has_item && (float)$legacy->total>0){
                $wpdb->insert($quote_items_table,['quote_id'=>$legacy->id,'service_id'=>0,'title'=>$legacy->title?:'Serviços da proposta','description'=>$legacy->description?:'','quantity'=>1,'unit_price'=>(float)$legacy->total,'total'=>(float)$legacy->total,'sort_order'=>0,'created_at'=>current_time('mysql')]);
            }
        }
        // Migração dos clientes antigos para o cadastro PF/PJ sem perder dados.
        $clients_table=$p.'clients';
        $legacy_clients=$wpdb->get_results("SELECT id,person_type,name,company,legal_name,trade_name,document FROM {$clients_table}");
        foreach($legacy_clients as $legacy_client){
            $digits=preg_replace('/\D+/','',(string)$legacy_client->document);
            $looks_pj=!empty($legacy_client->company)||strlen($digits)===14;
            $updates=[];
            if($looks_pj && ($legacy_client->person_type==='pf'||empty($legacy_client->person_type)))$updates['person_type']='pj';
            if($looks_pj && empty($legacy_client->trade_name) && !empty($legacy_client->company))$updates['trade_name']=$legacy_client->company;
            if($looks_pj && empty($legacy_client->legal_name) && !empty($legacy_client->name))$updates['legal_name']=$legacy_client->name;
            if($updates)$wpdb->update($clients_table,$updates,['id'=>$legacy_client->id]);
        }
        self::ensure_desktop_schema();
        update_option('vfos_db_version',VFOS_VERSION);
        if(!get_option('vfos_ai_provider')) update_option('vfos_ai_provider','openrouter');
        if(!get_option('vfos_openrouter_model')) update_option('vfos_openrouter_model','openrouter/free');
        if(!get_option('vfos_gemini_model')) update_option('vfos_gemini_model','gemini-2.5-flash');
        if(!get_option('vfos_ai_name')) update_option('vfos_ai_name','VisionForge AI');
    }
    public static function next_number($type){
        global $wpdb; $map=['quote'=>['quotes','ORC'],'contract'=>['contracts','CTR']]; if(!isset($map[$type])) return '';
        [$t,$prefix]=$map[$type]; $n=(int)$wpdb->get_var('SELECT MAX(id) FROM '.self::table($t))+1; return 'VF-'.$prefix.'-'.str_pad((string)$n,4,'0',STR_PAD_LEFT);
    }
    public static function financial_cash_stats(){
        global $wpdb;$f=self::table('financial');
        $received=(float)$wpdb->get_var("SELECT COALESCE(SUM(paid_amount),0) FROM $f WHERE type='income'");
        $expenses=(float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM $f WHERE type='expense' AND status='paid' AND is_partner_withdrawal=0");
        $partner=(float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM $f WHERE type='expense' AND status='paid' AND is_partner_withdrawal=1");
        return ['received'=>$received,'operational_expenses'=>$expenses,'partner_withdrawals'=>$partner,'cash'=>round($received-$expenses-$partner,2)];
    }

    public static function dashboard_stats(){
        global $wpdb; $c=self::table('clients');$p=self::table('projects');$f=self::table('financial');$t=self::table('tasks');$q=self::table('quotes');$co=self::table('contracts');
        $l=self::table('leads');
        return ['clients'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM $c WHERE status='active'"),'leads'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM $l WHERE stage NOT IN ('won','lost')"),'pipeline_value'=>(float)$wpdb->get_var("SELECT COALESCE(SUM(estimated_value),0) FROM $l WHERE stage NOT IN ('won','lost')"),'projects'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM $p WHERE status NOT IN ('completed','cancelled')"),'received'=>(float)$wpdb->get_var("SELECT COALESCE(SUM(paid_amount),0) FROM $f WHERE type='income' AND paid_amount>0 AND YEAR(updated_at)=YEAR(CURDATE()) AND MONTH(updated_at)=MONTH(CURDATE())"),'receivable'=>(float)$wpdb->get_var("SELECT COALESCE(SUM(GREATEST(amount-paid_amount,0)),0) FROM $f WHERE type='income' AND status IN ('pending','partial')"),'tasks'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE status NOT IN ('done','cancelled')"),'quotes'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM $q WHERE status IN ('draft','sent')"),'contracts'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM $co WHERE status IN ('draft','sent','viewed','pending_signature')")];
    }
    public static function ai_context(){
        global $wpdb; $s=self::dashboard_stats(); $p=self::table('projects');$c=self::table('clients');$t=self::table('tasks');$q=self::table('quotes');$f=self::table('financial');
        $projects=$wpdb->get_results("SELECT p.id,p.name,p.status,p.value,p.due_date,c.name client FROM $p p LEFT JOIN $c c ON c.id=p.client_id ORDER BY p.updated_at DESC LIMIT 12",ARRAY_A);
        $tasks=$wpdb->get_results("SELECT id,title,status,priority,due_date FROM $t WHERE status NOT IN ('done','cancelled') ORDER BY due_date IS NULL,due_date ASC LIMIT 12",ARRAY_A);
        $quotes=$wpdb->get_results("SELECT q.number,q.title,q.total,q.status,c.name client FROM $q q LEFT JOIN $c c ON c.id=q.client_id ORDER BY q.id DESC LIMIT 10",ARRAY_A);
        $late=(float)$wpdb->get_var("SELECT COALESCE(SUM(GREATEST(amount-paid_amount,0)),0) FROM $f WHERE type='income' AND status IN ('pending','partial') AND due_date<CURDATE()");
        $l=self::table('leads');
        $leads=$wpdb->get_results("SELECT id,name,company,service_interest,estimated_value,stage,probability,next_followup FROM $l WHERE stage NOT IN ('won','lost') ORDER BY next_followup IS NULL,next_followup ASC,id DESC LIMIT 15",ARRAY_A);
        $cal=self::table('calendar_events');
        $calendar=$wpdb->get_results("SELECT id,title,event_type,start_at,end_at,assigned_user_id,status,location FROM $cal WHERE start_at>=NOW() AND status NOT IN ('done','cancelled') ORDER BY start_at ASC LIMIT 15",ARRAY_A);
        $cash=self::financial_cash_stats();
        $receivables=$wpdb->get_results("SELECT f.id,f.description,f.amount,f.paid_amount,f.due_date,f.status,c.name client,GREATEST(f.amount-f.paid_amount,0) balance FROM $f f LEFT JOIN $c c ON c.id=f.client_id WHERE f.type='income' AND f.status IN ('pending','partial') ORDER BY f.due_date IS NULL,f.due_date ASC LIMIT 20",ARRAY_A);
        $recent_clients=$wpdb->get_results("SELECT id,name,email,phone,document,status FROM $c ORDER BY id DESC LIMIT 15",ARRAY_A);
        return ['stats'=>$s,'cash'=>$cash,'overdue_receivable'=>$late,'receivables'=>$receivables,'recent_clients'=>$recent_clients,'recent_projects'=>$projects,'open_tasks'=>$tasks,'recent_quotes'=>$quotes,'open_leads'=>$leads,'upcoming_calendar'=>$calendar];
    }
    public static function client_context($client_id){
        global $wpdb; $id=absint($client_id); if(!$id) return [];
        $c=self::table('clients'); $p=self::table('projects'); $t=self::table('tasks'); $q=self::table('quotes'); $co=self::table('contracts'); $f=self::table('financial'); $n=self::table('client_notes');
        $client=$wpdb->get_row($wpdb->prepare("SELECT id,name,company,email,phone,document,status,notes,created_at,updated_at FROM $c WHERE id=%d",$id),ARRAY_A);
        if(!$client) return [];
        $projects=$wpdb->get_results($wpdb->prepare("SELECT id,name,status,priority,value,due_date,progress,notes FROM $p WHERE client_id=%d ORDER BY updated_at DESC LIMIT 20",$id),ARRAY_A);
        $tasks=$wpdb->get_results($wpdb->prepare("SELECT id,title,status,priority,due_date,description FROM $t WHERE client_id=%d ORDER BY (status='done'),due_date IS NULL,due_date ASC LIMIT 30",$id),ARRAY_A);
        $quotes=$wpdb->get_results($wpdb->prepare("SELECT id,number,title,total,status,payment_terms,valid_until FROM $q WHERE client_id=%d ORDER BY id DESC LIMIT 20",$id),ARRAY_A);
        $contracts=$wpdb->get_results($wpdb->prepare("SELECT id,number,title,value,status,sign_status,sign_url,updated_at FROM $co WHERE client_id=%d ORDER BY id DESC LIMIT 20",$id),ARRAY_A);
        $financial=$wpdb->get_results($wpdb->prepare("SELECT id,type,description,amount,paid_amount,status,due_date,paid_at,method FROM $f WHERE client_id=%d ORDER BY id DESC LIMIT 30",$id),ARRAY_A);
        $notes=$wpdb->get_results($wpdb->prepare("SELECT content,created_at FROM $n WHERE client_id=%d ORDER BY id DESC LIMIT 15",$id),ARRAY_A);
        $received=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(paid_amount),0) FROM $f WHERE client_id=%d AND type='income'",$id));
        $receivable=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(amount-paid_amount,0)),0) FROM $f WHERE client_id=%d AND type='income' AND status IN ('pending','partial')",$id));
        return ['client'=>$client,'summary'=>['received'=>$received,'receivable'=>$receivable,'projects'=>count($projects),'open_tasks'=>count(array_filter($tasks,fn($x)=>!in_array($x['status'],['done','cancelled'],true)))],'projects'=>$projects,'tasks'=>$tasks,'quotes'=>$quotes,'contracts'=>$contracts,'financial'=>$financial,'notes'=>$notes];
    }

    public static function log($action,$type='',$id=0,$details='',$before=null,$after=null,$object_label=''){
        global $wpdb;
        $labels=[
            'save_client'=>'Cliente salvo','delete_client'=>'Cliente excluído','client_note'=>'Nota adicionada ao cliente','client_file_upload'=>'Arquivo adicionado ao cliente','client_file_remove'=>'Arquivo removido do cliente',
            'save_project'=>'Projeto salvo','delete_project'=>'Projeto excluído','save_task'=>'Tarefa salva','delete_task'=>'Tarefa excluída','task_status'=>'Status da tarefa alterado',
            'save_quote'=>'Proposta salva','delete_quote'=>'Proposta excluída','send_quote'=>'Proposta enviada','save_quote_template'=>'Modelo de orçamento salvo','delete_quote_template'=>'Modelo de orçamento excluído','save_contract'=>'Contrato salvo','delete_contract'=>'Contrato excluído',
            'save_financial'=>'Lançamento financeiro salvo','ai_create_contract'=>'Contrato criado pela IA','ai_create_financial'=>'Lançamento financeiro criado pela IA','ai_financial_payment'=>'Recebimento registrado pela IA','financial_payment_added'=>'Recebimento financeiro registrado','financial_payment_deleted'=>'Recebimento financeiro excluído','save_financial_split'=>'Divisão financeira salva','delete_financial'=>'Lançamento financeiro excluído','save_team_member'=>'Membro da equipe salvo','self_permission_toggle'=>'Autoedição de permissões alterada','save_company_info'=>'Dados institucionais atualizados','delete_team_member'=>'Membro da equipe removido','save_team_group'=>'Grupo de equipe salvo','delete_team_group'=>'Grupo de equipe excluído','save_group_members'=>'Integrantes do grupo atualizados',
            'save_calendar_event'=>'Compromisso salvo','delete_calendar_event'=>'Compromisso excluído','save_project_presentation'=>'Apresentação do projeto salva',
            'send_project_presentation'=>'Apresentação do projeto enviada','send_notification'=>'Notificação enviada','reply_notification'=>'Resposta de notificação enviada','delete_sent_notification'=>'Notificação enviada apagada','project_comment'=>'Comentário adicionado ao projeto','project_file'=>'Arquivo adicionado ao projeto',
        ];
        if(!$object_label && $id){
            $tables=['client'=>'clients','project'=>'projects','task'=>'tasks','quote'=>'quotes','contract'=>'contracts','lead'=>'leads','team'=>'team','calendar_event'=>'calendar_events'];
            $name_fields=['client'=>'name','project'=>'name','task'=>'title','quote'=>'title','contract'=>'title','lead'=>'name','calendar_event'=>'title'];
            if(isset($tables[$type],$name_fields[$type])){
                $object_label=(string)$wpdb->get_var($wpdb->prepare("SELECT {$name_fields[$type]} FROM ".self::table($tables[$type])." WHERE id=%d",$id));
            }
        }
        $ip=sanitize_text_field($_SERVER['REMOTE_ADDR']??'');
        $ua=substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']??''),0,255);
        $wpdb->insert(self::table('activity_logs'),[
            'user_id'=>get_current_user_id(),'action'=>sanitize_key($action),'action_label'=>$labels[$action]??ucwords(str_replace('_',' ',$action)),
            'object_type'=>sanitize_key($type),'object_id'=>absint($id),'object_label'=>sanitize_text_field($object_label),
            'details'=>is_scalar($details)?(string)$details:wp_json_encode($details,JSON_UNESCAPED_UNICODE),
            'before_data'=>$before===null?'':wp_json_encode($before,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            'after_data'=>$after===null?'':wp_json_encode($after,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            'ip_address'=>$ip,'user_agent'=>$ua,'created_at'=>current_time('mysql')
        ]);
    }
}
