<?php
if (!defined('ABSPATH')) exit;

class VFOS_Desktop_API {
    const NS = 'vfos/v1';
    const TOKEN_TTL = 2592000;
    private static $tables = [
        'clients','leads','lead_activities','services','projects','tasks','quotes','quote_items',
        'quote_sections','quote_costs','quote_cost_options','quote_payment_options','contracts',
        'financial','financial_payments','payment_charges','financial_splits','financial_recurring'
    ];
    public static function init(){ add_action('rest_api_init',[__CLASS__,'routes']); }
    public static function routes(){
        register_rest_route(self::NS,'/health',['methods'=>'GET','callback'=>[__CLASS__,'health'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/auth/login',['methods'=>'POST','callback'=>[__CLASS__,'login'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/auth/me',['methods'=>'GET','callback'=>[__CLASS__,'me'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/auth/logout',['methods'=>'POST','callback'=>[__CLASS__,'logout'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/team',['methods'=>'GET','callback'=>[__CLASS__,'team'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/notifications',['methods'=>'GET','callback'=>[__CLASS__,'notifications'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/notifications/read',['methods'=>'POST','callback'=>[__CLASS__,'notification_read'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/permissions',['methods'=>'GET','callback'=>[__CLASS__,'permissions'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/sync/bootstrap',['methods'=>'GET','callback'=>[__CLASS__,'bootstrap'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/sync/pull',['methods'=>'GET','callback'=>[__CLASS__,'pull'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/sync/push',['methods'=>'POST','callback'=>[__CLASS__,'push'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/files/upload',['methods'=>'POST','callback'=>[__CLASS__,'upload_file'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/files/list',['methods'=>'GET','callback'=>[__CLASS__,'list_files'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/workflow/quote-contract',['methods'=>'POST','callback'=>[__CLASS__,'quote_contract'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/workflow/quote-project',['methods'=>'POST','callback'=>[__CLASS__,'quote_project'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/workflow/quote-financial',['methods'=>'POST','callback'=>[__CLASS__,'quote_financial'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/workflow/contract-project',['methods'=>'POST','callback'=>[__CLASS__,'contract_project'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/workflow/contract-financial',['methods'=>'POST','callback'=>[__CLASS__,'contract_financial'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,'/workflow/project-financial',['methods'=>'POST','callback'=>[__CLASS__,'project_financial'],'permission_callback'=>'__return_true']);
    }
    private static function token_user($request){
        $header=trim((string)$request->get_header('authorization')); if(!$header||stripos($header,'Bearer ')!==0)return 0;
        $raw=trim(substr($header,7)); if(!$raw)return 0; global $wpdb; $table=VFOS_DB::table('desktop_tokens');
        $hash=hash('sha256',$raw); $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE token_hash=%s AND expires_at>UTC_TIMESTAMP() LIMIT 1",$hash));
        if(!$row)return 0; wp_set_current_user((int)$row->user_id);
        $wpdb->update($table,['last_used_at'=>current_time('mysql',true)],['id'=>(int)$row->id],['%s'],['%d']); return (int)$row->user_id;
    }
    private static function require_user($request){$uid=self::token_user($request);if(!$uid||!user_can($uid,'vfos_access'))return new WP_Error('vfos_auth_required','Autenticação do VisionForge OS necessária.',['status'=>401]);return $uid;}
    public static function health(){return rest_ensure_response(['ok'=>true,'plugin_version'=>VFOS_VERSION,'api_version'=>'1.2.0','server_time'=>gmdate('c')]);}
    public static function login($request){
        $p=$request->get_json_params();$login=sanitize_text_field($p['login']??'');$password=(string)($p['password']??'');
        if(!$login||!$password)return new WP_Error('missing_credentials','Informe usuário/e-mail e senha.',['status'=>400]);
        $user=wp_authenticate($login,$password);if(is_wp_error($user))return new WP_Error('invalid_credentials','Usuário ou senha inválidos.',['status'=>401]);
        if(!user_can($user->ID,'vfos_access'))return new WP_Error('forbidden','Este usuário não possui acesso ao VisionForge OS.',['status'=>403]);
        try{$raw=bin2hex(random_bytes(32));}catch(Exception $e){$raw=wp_generate_password(64,false,false);} global $wpdb;$table=VFOS_DB::table('desktop_tokens');
        $wpdb->insert($table,['user_id'=>(int)$user->ID,'token_hash'=>hash('sha256',$raw),'device_name'=>sanitize_text_field($p['device_name']??'VisionForge Desktop'),'created_at'=>current_time('mysql',true),'last_used_at'=>current_time('mysql',true),'expires_at'=>gmdate('Y-m-d H:i:s',time()+self::TOKEN_TTL)],['%d','%s','%s','%s','%s','%s']);
        return rest_ensure_response(['ok'=>true,'token'=>$raw,'expires_at'=>gmdate('c',time()+self::TOKEN_TTL),'user'=>['id'=>$user->ID,'name'=>$user->display_name,'email'=>$user->user_email]]);
    }
    public static function logout($request){$uid=self::require_user($request);if(is_wp_error($uid))return $uid;global $wpdb;$h=trim(substr((string)$request->get_header('authorization'),7));$wpdb->delete(VFOS_DB::table('desktop_tokens'),['token_hash'=>hash('sha256',$h)],['%s']);return ['ok'=>true];}
    public static function me($request){$uid=self::require_user($request);if(is_wp_error($uid))return $uid;$u=get_userdata($uid);return rest_ensure_response(['ok'=>true,'user'=>['id'=>$uid,'name'=>$u->display_name,'email'=>$u->user_email,'login'=>$u->user_login]]);}
    private static function can_permission($uid,$permission){
        if(class_exists('VFOS_Team') && method_exists('VFOS_Team','can') && !VFOS_Team::can($uid,$permission)) return false;
        return true;
    }
    public static function team($request){
        $uid=self::require_user($request); if(is_wp_error($uid)) return $uid;
        if(!self::can_permission($uid,'team.view')) return new WP_Error('forbidden','Você não possui permissão para visualizar a equipe.',['status'=>403]);
        global $wpdb; $users=[];
        foreach(get_users(['fields'=>['ID','display_name','user_email','user_login'],'orderby'=>'display_name','order'=>'ASC']) as $u){
            $users[]=['id'=>(int)$u->ID,'name'=>$u->display_name,'email'=>$u->user_email,'login'=>$u->user_login,'roles'=>array_values((array)$u->roles)];
        }
        $groups=[]; $gt=VFOS_DB::table('team_groups'); $mt=VFOS_DB::table('team_group_members');
        if($wpdb->get_var("SHOW TABLES LIKE '{$gt}'")){
            $groups=$wpdb->get_results("SELECT g.id,g.name,g.slug,g.description,g.status,COUNT(m.id) AS members_count FROM `{$gt}` g LEFT JOIN `{$mt}` m ON m.group_id=g.id GROUP BY g.id ORDER BY g.name ASC",ARRAY_A);
        }
        return rest_ensure_response(['ok'=>true,'users'=>$users,'groups'=>$groups]);
    }
    public static function permissions($request){
        $uid=self::require_user($request); if(is_wp_error($uid)) return $uid;
        $keys=['clients.view','clients.create','clients.edit','clients.delete','crm.view','crm.edit','crm.delete','projects.view','projects.create','projects.edit','projects.delete','tasks.view','tasks.create','tasks.edit','tasks.delete','quotes.view','quotes.create','quotes.edit','quotes.delete','contracts.view','contracts.create','contracts.edit','contracts.delete','financial.view','financial.create','financial.edit','financial.delete','financial.payments','financial.split','team.view','team.create','team.edit','team.delete','team.permissions','notifications.view','notifications.manage','notifications.send','ai.use'];
        $out=[]; foreach($keys as $key) $out[$key]=self::can_permission($uid,$key);
        return rest_ensure_response(['ok'=>true,'permissions'=>$out]);
    }
    public static function notifications($request){
        $uid=self::require_user($request); if(is_wp_error($uid)) return $uid;
        if(!self::can_permission($uid,'notifications.view')) return new WP_Error('forbidden','Você não possui permissão para visualizar notificações.',['status'=>403]);
        global $wpdb; $t=VFOS_DB::table('notifications');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$t}` WHERE user_id=%d ORDER BY id DESC LIMIT 100",$uid),ARRAY_A);
        return rest_ensure_response(['ok'=>true,'notifications'=>$rows]);
    }
    public static function notification_read($request){
        $uid=self::require_user($request); if(is_wp_error($uid)) return $uid;
        if(!self::can_permission($uid,'notifications.view')) return new WP_Error('forbidden','Você não possui permissão para visualizar notificações.',['status'=>403]);
        $id=absint($request->get_param('id')); if(!$id) return new WP_Error('missing_id','Notificação não informada.',['status'=>400]);
        global $wpdb; $t=VFOS_DB::table('notifications'); $wpdb->update($t,['is_read'=>1,'read_at'=>current_time('mysql')],['id'=>$id,'user_id'=>$uid],['%d','%s'],['%d','%d']);
        return ['ok'=>true,'id'=>$id];
    }
    private static function table($name){return in_array($name,self::$tables,true)?VFOS_DB::table($name):'';}
    private static function rows($name,$since='',$limit=1000){global $wpdb;$table=self::table($name);if(!$table)return [];$cols=$wpdb->get_results("DESCRIBE `{$table}`",ARRAY_A);if(!$cols)return [];$has=false;foreach($cols as $c)if($c['Field']==='updated_at')$has=true;if($since&&$has)return $wpdb->get_results($wpdb->prepare("SELECT * FROM `{$table}` WHERE updated_at>%s ORDER BY updated_at ASC,id ASC LIMIT %d",$since,$limit),ARRAY_A);return $wpdb->get_results($wpdb->prepare("SELECT * FROM `{$table}` ORDER BY id ASC LIMIT %d",$limit),ARRAY_A);}
    public static function bootstrap($request){$uid=self::require_user($request);if(is_wp_error($uid))return $uid;$out=[];foreach(self::$tables as $name)$out[$name]=self::rows($name,'',2000);return rest_ensure_response(['ok'=>true,'server_time'=>gmdate('c'),'tables'=>$out]);}
    public static function pull($request){$uid=self::require_user($request);if(is_wp_error($uid))return $uid;$since=sanitize_text_field($request->get_param('since')?:'1970-01-01 00:00:00');$out=[];foreach(self::$tables as $name)$out[$name]=self::rows($name,$since,2000);return rest_ensure_response(['ok'=>true,'server_time'=>gmdate('c'),'tables'=>$out]);}

    public static function upload_file($request){
        $uid=self::require_user($request); if(is_wp_error($uid)) return $uid;
        if(empty($_FILES['file'])) return new WP_Error('missing_file','Nenhum arquivo foi enviado.',['status'=>400]);
        $parent_table=sanitize_key($request->get_param('parent_table')?:''); $parent_id=absint($request->get_param('parent_id')?:0);
        if($parent_id && !in_array($parent_table,['clients','projects'],true)) return new WP_Error('invalid_parent','Registro pai inválido.',['status'=>400]);
        require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/image.php';
        $file=$_FILES['file']; $overrides=['test_form'=>false,'mimes'=>null];
        $upload=wp_handle_upload($file,$overrides); if(isset($upload['error'])) return new WP_Error('upload_error',$upload['error'],['status'=>400]);
        $filename=basename($upload['file']); $title=sanitize_text_field($request->get_param('title')?:pathinfo($filename,PATHINFO_FILENAME));
        $attachment=['post_mime_type'=>$upload['type'],'post_title'=>$title,'post_content'=>'','post_status'=>'inherit'];
        $attachment_id=wp_insert_attachment($attachment,$upload['file']);
        if(is_wp_error($attachment_id)) return $attachment_id;
        $metadata=wp_generate_attachment_metadata($attachment_id,$upload['file']); if($metadata) wp_update_attachment_metadata($attachment_id,$metadata);
        $url=wp_get_attachment_url($attachment_id); global $wpdb; $now=current_time('mysql'); $linked_id=0;
        if($parent_table==='clients' && $parent_id){
            $linked_id=(int)$wpdb->insert_id; $wpdb->insert(VFOS_DB::table('client_files'),['client_id'=>$parent_id,'project_id'=>0,'attachment_id'=>$attachment_id,'title'=>$title,'file_url'=>$url,'mime_type'=>$upload['type'],'source'=>'desktop','uploaded_by'=>$uid,'created_at'=>$now],['%d','%d','%d','%s','%s','%s','%s','%d','%s']); $linked_id=(int)$wpdb->insert_id;
        } elseif($parent_table==='projects' && $parent_id){
            $wpdb->insert(VFOS_DB::table('project_files'),['project_id'=>$parent_id,'task_id'=>0,'attachment_id'=>$attachment_id,'title'=>$title,'file_url'=>$url,'mime_type'=>$upload['type'],'user_id'=>$uid,'created_at'=>$now],['%d','%d','%d','%s','%s','%s','%d','%s']); $linked_id=(int)$wpdb->insert_id;
        }
        return rest_ensure_response(['ok'=>true,'attachment_id'=>(int)$attachment_id,'linked_id'=>$linked_id,'parent_table'=>$parent_table,'parent_id'=>$parent_id,'title'=>$title,'file_url'=>$url,'mime_type'=>$upload['type'],'size'=>(int)$file['size'],'uploaded_at'=>gmdate('c')]);
    }
    public static function list_files($request){
        $uid=self::require_user($request); if(is_wp_error($uid)) return $uid; global $wpdb;
        $parent_table=sanitize_key($request->get_param('parent_table')?:''); $parent_id=absint($request->get_param('parent_id')?:0); $rows=[];
        if($parent_table==='clients' && $parent_id){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `".VFOS_DB::table('client_files')."` WHERE client_id=%d ORDER BY id DESC",$parent_id),ARRAY_A);}
        elseif($parent_table==='projects' && $parent_id){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `".VFOS_DB::table('project_files')."` WHERE project_id=%d ORDER BY id DESC",$parent_id),ARRAY_A);}
        return rest_ensure_response(['ok'=>true,'files'=>$rows]);
    }
    private static function workflow_permission($uid,$permission){
        if(class_exists('VFOS_Team') && method_exists('VFOS_Team','can') && !VFOS_Team::can($uid,$permission)) return new WP_Error('forbidden','Você não possui permissão para esta etapa do fluxo.',['status'=>403]);
        return true;
    }
    private static function sync_permission($uid,$table,$action){
        $map=[
            'clients'=>['create'=>'clients.create','update'=>'clients.edit','delete'=>'clients.delete'],
            'leads'=>['create'=>'crm.edit','update'=>'crm.edit','delete'=>'crm.delete'],
            'lead_activities'=>['create'=>'crm.edit','update'=>'crm.edit','delete'=>'crm.delete'],
            'projects'=>['create'=>'projects.create','update'=>'projects.edit','delete'=>'projects.delete'],
            'tasks'=>['create'=>'tasks.create','update'=>'tasks.edit','delete'=>'tasks.delete'],
            'quotes'=>['create'=>'quotes.create','update'=>'quotes.edit','delete'=>'quotes.delete'],
            'quote_items'=>['create'=>'quotes.edit','update'=>'quotes.edit','delete'=>'quotes.edit'],
            'quote_sections'=>['create'=>'quotes.edit','update'=>'quotes.edit','delete'=>'quotes.edit'],
            'quote_costs'=>['create'=>'quotes.edit','update'=>'quotes.edit','delete'=>'quotes.edit'],
            'quote_cost_options'=>['create'=>'quotes.edit','update'=>'quotes.edit','delete'=>'quotes.edit'],
            'quote_payment_options'=>['create'=>'quotes.edit','update'=>'quotes.edit','delete'=>'quotes.edit'],
            'contracts'=>['create'=>'contracts.create','update'=>'contracts.edit','delete'=>'contracts.delete'],
            'financial'=>['create'=>'financial.create','update'=>'financial.edit','delete'=>'financial.delete'],
            'financial_payments'=>['create'=>'financial.payments','update'=>'financial.payments','delete'=>'financial.payments'],
            'payment_charges'=>['create'=>'financial.payments','update'=>'financial.payments','delete'=>'financial.payments'],
            'financial_splits'=>['create'=>'financial.split','update'=>'financial.split','delete'=>'financial.split'],
            'financial_recurring'=>['create'=>'financial.create','update'=>'financial.edit','delete'=>'financial.delete'],
        ];
        $permission=$map[$table][$action]??null;
        if($permission && class_exists('VFOS_Team') && method_exists('VFOS_Team','can') && !VFOS_Team::can($uid,$permission)) return new WP_Error('forbidden','Você não possui permissão para alterar este módulo no Desktop.',['status'=>403]);
        return true;
    }
    private static function workflow_id($request,$key='id'){ $uid=self::require_user($request); if(is_wp_error($uid)) return $uid; $id=absint($request->get_param($key)); if(!$id)return new WP_Error('missing_id','Registro não informado.',['status'=>400]); return [$uid,$id]; }
    public static function quote_contract($request){$r=self::workflow_id($request);if(is_wp_error($r))return $r;[$uid,$id]=$r;$p=self::workflow_permission($uid,'contracts.create');if(is_wp_error($p))return $p;if(!class_exists('VFOS_Workflow'))return new WP_Error('workflow_unavailable','Fluxo indisponível.',['status'=>500]);$out=VFOS_Workflow::quote_to_contract($id);return is_wp_error($out)?$out:rest_ensure_response(['ok'=>true,'quote_id'=>$id,'contract_id'=>(int)$out]);}
    public static function quote_project($request){$r=self::workflow_id($request);if(is_wp_error($r))return $r;[$uid,$id]=$r;$p=self::workflow_permission($uid,'projects.create');if(is_wp_error($p))return $p;if(!class_exists('VFOS_Workflow'))return new WP_Error('workflow_unavailable','Fluxo indisponível.',['status'=>500]);$out=VFOS_Workflow::quote_to_project($id);return is_wp_error($out)?$out:rest_ensure_response(['ok'=>true,'quote_id'=>$id,'project_id'=>(int)$out]);}
    public static function quote_financial($request){$r=self::workflow_id($request);if(is_wp_error($r))return $r;[$uid,$id]=$r;$p=self::workflow_permission($uid,'financial.create');if(is_wp_error($p))return $p;if(!class_exists('VFOS_Workflow'))return new WP_Error('workflow_unavailable','Fluxo indisponível.',['status'=>500]);$out=VFOS_Workflow::quote_to_financial($id);return is_wp_error($out)?$out:rest_ensure_response(['ok'=>true,'quote_id'=>$id,'financial_id'=>(int)$out]);}
    public static function contract_project($request){$r=self::workflow_id($request);if(is_wp_error($r))return $r;[$uid,$id]=$r;$p=self::workflow_permission($uid,'projects.create');if(is_wp_error($p))return $p;if(!class_exists('VFOS_Workflow'))return new WP_Error('workflow_unavailable','Fluxo indisponível.',['status'=>500]);$out=VFOS_Workflow::contract_to_project($id);return is_wp_error($out)?$out:rest_ensure_response(['ok'=>true,'contract_id'=>$id,'project_id'=>(int)$out]);}
    public static function contract_financial($request){$r=self::workflow_id($request);if(is_wp_error($r))return $r;[$uid,$id]=$r;$p=self::workflow_permission($uid,'financial.create');if(is_wp_error($p))return $p;if(!class_exists('VFOS_Workflow'))return new WP_Error('workflow_unavailable','Fluxo indisponível.',['status'=>500]);$out=VFOS_Workflow::contract_to_financial($id);return is_wp_error($out)?$out:rest_ensure_response(['ok'=>true,'contract_id'=>$id,'financial_id'=>(int)$out]);}
    public static function project_financial($request){$r=self::workflow_id($request);if(is_wp_error($r))return $r;[$uid,$id]=$r;$p=self::workflow_permission($uid,'financial.create');if(is_wp_error($p))return $p;if(!class_exists('VFOS_Workflow'))return new WP_Error('workflow_unavailable','Fluxo indisponível.',['status'=>500]);$out=VFOS_Workflow::project_to_financial($id);return is_wp_error($out)?$out:rest_ensure_response(['ok'=>true,'project_id'=>$id,'financial_id'=>(int)$out]);}

    public static function push($request){
        $uid=self::require_user($request);if(is_wp_error($uid))return $uid;$body=$request->get_json_params();$ops=is_array($body['operations']??null)?$body['operations']:[];if(count($ops)>200)return new WP_Error('too_many_operations','Máximo de 200 operações por lote.',['status'=>400]);global $wpdb;$results=[];
        foreach($ops as $op){
            $name=sanitize_key($op['table']??'');$action=sanitize_key($op['action']??'');$data=is_array($op['data']??null)?$op['data']:[];$client_op=sanitize_text_field($op['client_op_id']??'');
            if(!$client_op||!self::table($name)||!in_array($action,['create','update','delete'],true)){$results[]=['client_op_id'=>$client_op,'status'=>'error','message'=>'Operação inválida.'];continue;}
            $perm=self::sync_permission($uid,$name,$action);if(is_wp_error($perm)){$results[]=['client_op_id'=>$client_op,'status'=>'forbidden','message'=>$perm->get_error_message()];continue;}
            $dedupe=$wpdb->get_var($wpdb->prepare("SELECT id FROM `".VFOS_DB::table('desktop_sync_ops')."` WHERE client_op_id=%s LIMIT 1",$client_op));if($dedupe){$results[]=['client_op_id'=>$client_op,'status'=>'already_processed'];continue;}
            $table=self::table($name);$cols=$wpdb->get_col("DESCRIBE `{$table}`",0);$clean=[];foreach($data as $k=>$v)if(in_array($k,$cols,true)&&$k!=='id')$clean[$k]=$v;
            $id=absint($data['id']??0);$base=sanitize_text_field($data['_base_updated_at']??'');
            if(in_array($action,['update','delete'],true)&&$id&&$base&&in_array('updated_at',$cols,true)){
                $current=$wpdb->get_var($wpdb->prepare("SELECT updated_at FROM `{$table}` WHERE id=%d",$id));
                if($current&&strtotime($current)!==strtotime($base)){$server_row=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE id=%d LIMIT 1",$id),ARRAY_A);$results[]=['client_op_id'=>$client_op,'status'=>'conflict','server_id'=>$id,'server_updated_at'=>$current,'server'=>$server_row,'message'=>'O registro foi alterado no servidor depois da última sincronização.'];continue;}
            }
            $ok=false;$server_id=0;$message='';
            if($action==='create'){if(!isset($clean['created_at']))$clean['created_at']=current_time('mysql');if(in_array('updated_at',$cols,true)&&!isset($clean['updated_at']))$clean['updated_at']=current_time('mysql');$ok=(bool)$wpdb->insert($table,$clean);$server_id=(int)$wpdb->insert_id;$message=$wpdb->last_error;}
            elseif($action==='update'){if($id){if(in_array('updated_at',$cols,true))$clean['updated_at']=current_time('mysql');$ok=(bool)$wpdb->update($table,$clean,['id'=>$id]);$server_id=$id;$message=$wpdb->last_error;}}
            else{if($id){$ok=(bool)$wpdb->delete($table,['id'=>$id],['%d']);$server_id=$id;$message=$wpdb->last_error;}}
            if($ok||($action==='update'&&$server_id&&$message==='')){$wpdb->insert(VFOS_DB::table('desktop_sync_ops'),['client_op_id'=>$client_op,'user_id'=>$uid,'table_name'=>$name,'action'=>$action,'server_id'=>$server_id,'created_at'=>current_time('mysql',true)],['%s','%d','%s','%s','%d','%s']);$results[]=['client_op_id'=>$client_op,'status'=>'ok','server_id'=>$server_id];}
            else $results[]=['client_op_id'=>$client_op,'status'=>'error','message'=>$message?:'Não foi possível aplicar a operação.'];
        }
        return rest_ensure_response(['ok'=>true,'server_time'=>gmdate('c'),'results'=>$results]);
    }
}
