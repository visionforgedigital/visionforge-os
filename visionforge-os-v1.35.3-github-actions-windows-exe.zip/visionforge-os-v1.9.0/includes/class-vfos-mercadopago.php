<?php
if(!defined('ABSPATH'))exit;

class VFOS_MercadoPago{
    public static function init(){
        add_action('template_redirect',[__CLASS__,'route'],0);
        add_action('admin_post_vfos_mp_save_settings',[__CLASS__,'save_settings']);
        add_action('admin_post_vfos_mp_create_charge',[__CLASS__,'create_charge']);
        add_action('admin_post_vfos_mp_cancel_charge',[__CLASS__,'cancel_charge']);
        add_action('admin_post_vfos_mp_sync_charge',[__CLASS__,'sync_charge_action']);
        add_action('wp_ajax_vfos_mp_card_payment',[__CLASS__,'card_payment']);
        add_action('wp_ajax_nopriv_vfos_mp_card_payment',[__CLASS__,'card_payment']);
        add_action('wp_ajax_vfos_mp_public_status',[__CLASS__,'public_status']);
        add_action('wp_ajax_nopriv_vfos_mp_public_status',[__CLASS__,'public_status']);
        add_action('admin_post_vfos_mp_email_charge',[__CLASS__,'email_charge']);
    }
    public static function table(){return VFOS_DB::table('payment_charges');}
    public static function settings(){
        $d=get_option('vfos_mercadopago',[]);
        return wp_parse_args(is_array($d)?$d:[],[
            'enabled'=>0,'environment'=>'test','public_key'=>'','access_token'=>'','webhook_secret'=>'',
            'pix_enabled'=>1,'checkout_enabled'=>1,'transparent_enabled'=>1,'auto_capture'=>1,'pix_expiration_minutes'=>60
        ]);
    }
    public static function webhook_url(){return add_query_arg('vfos_mp_webhook','1',home_url('/'));}
    public static function payment_url($token){return add_query_arg(['vfos_pay'=>'1','token'=>$token],home_url('/'));}
    private static function api($method,$path,$body=null,$idempotency=''){
        $s=self::settings();$token=trim($s['access_token']);
        if(!$token)return new WP_Error('mp_no_token','Access Token do Mercado Pago não configurado.');
        $headers=['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json','Accept'=>'application/json'];
        if($idempotency)$headers['X-Idempotency-Key']=$idempotency;
        $args=['method'=>$method,'timeout'=>45,'headers'=>$headers];
        if($body!==null)$args['body']=wp_json_encode($body,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $r=wp_remote_request('https://api.mercadopago.com'.$path,$args);
        if(is_wp_error($r))return $r;
        $code=wp_remote_retrieve_response_code($r);$json=json_decode(wp_remote_retrieve_body($r),true);
        if($code<200||$code>=300)return new WP_Error('mp_api_error',$json['message']??($json['error']??('Mercado Pago respondeu HTTP '.$code)),['code'=>$code,'response'=>$json]);
        return $json;
    }
    public static function save_settings(){
        check_admin_referer('vfos_mp_save_settings');VFOS_Team::require_permission('financial.integrations');
        $old=self::settings();$raw=wp_unslash($_POST['mp']??[]);
        $data=[
            'enabled'=>empty($raw['enabled'])?0:1,
            'environment'=>in_array(($raw['environment']??'test'),['test','production'],true)?$raw['environment']:'test',
            'public_key'=>sanitize_text_field($raw['public_key']??''),
            'access_token'=>trim(sanitize_text_field($raw['access_token']??'')),
            'webhook_secret'=>trim(sanitize_text_field($raw['webhook_secret']??'')),
            'pix_enabled'=>empty($raw['pix_enabled'])?0:1,
            'checkout_enabled'=>empty($raw['checkout_enabled'])?0:1,
            'transparent_enabled'=>1,
            'auto_capture'=>empty($raw['auto_capture'])?0:1,
            'pix_expiration_minutes'=>max(30,min(43200,absint($raw['pix_expiration_minutes']??60)))
        ];
        update_option('vfos_mercadopago',$data,false);
        VFOS_DB::log('mp_settings','financial',0,'Configurações do Mercado Pago atualizadas',$old,$data,'Mercado Pago');
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=integrations&vfos_msg='.rawurlencode('Mercado Pago configurado.')));exit;
    }
    public static function test_connection(){
        $r=self::api('GET','/users/me');
        if(is_wp_error($r))return $r;
        return ['id'=>$r['id']??0,'nickname'=>$r['nickname']??'','email'=>$r['email']??'','site_status'=>$r['site_status']??''];
    }
    public static function create_charge(){
        check_admin_referer('vfos_mp_create_charge');VFOS_Team::require_permission('financial.payments');global $wpdb;
        $fid=absint($_POST['financial_id']??0);$method=sanitize_key($_POST['charge_method']??'pix');
        if(!in_array($method,['pix','card'],true))wp_die('Forma de cobrança inválida. O VisionForge OS aceita apenas pagamentos transparentes para novas cobranças.');
        $ft=VFOS_DB::table('financial');$ct=VFOS_DB::table('clients');$f=$wpdb->get_row($wpdb->prepare("SELECT f.*,c.name client_name,c.email client_email,c.billing_email,c.document,c.person_type FROM $ft f LEFT JOIN $ct c ON c.id=f.client_id WHERE f.id=%d AND f.type='income'",$fid));
        if(!$f)wp_die('Cobrança financeira não encontrada.');
        $remaining=max(0,(float)$f->amount-(float)$f->paid_amount);
        $amount=max(0,(float)str_replace(',','.',$_POST['charge_amount']??0));
        if($amount<=0||$amount>$remaining+0.001)wp_die('O valor online precisa ser maior que zero e não pode ultrapassar o saldo de R$ '.esc_html(number_format($remaining,2,',','.')).'.');
        $email=sanitize_email($_POST['payer_email']??($f->billing_email?:$f->client_email));
        if(!$email)wp_die('O Mercado Pago precisa do e-mail do pagador.');
        $token=wp_generate_password(48,false,false);$external='VFOS-'.$fid.'-'.$token;$now=current_time('mysql');
        $base=['financial_id'=>$fid,'provider'=>'mercadopago','method'=>$method,'amount'=>$amount,'currency'=>'BRL','status'=>'pending','external_reference'=>$external,'public_token'=>$token,'payer_email'=>$email,'created_at'=>$now,'updated_at'=>$now];
        if(!$wpdb->insert(self::table(),$base))wp_die('Não foi possível criar o registro da cobrança: '.esc_html($wpdb->last_error));
        $cid=(int)$wpdb->insert_id;
        $notification=self::webhook_url();
        if($method==='pix'){
            $body=[
                'transaction_amount'=>$amount,'description'=>$f->description,'payment_method_id'=>'pix',
                'external_reference'=>$external,'notification_url'=>$notification,
                'payer'=>['email'=>$email]
            ];
            $digits=preg_replace('/\D+/','',(string)$f->document);
            if(in_array(strlen($digits),[11,14],true))$body['payer']['identification']=['type'=>strlen($digits)===14?'CNPJ':'CPF','number'=>$digits];
            $r=self::api('POST','/v1/payments',$body,'vfos-pix-'.$cid.'-'.$token);
            if(is_wp_error($r)){ $wpdb->update(self::table(),['status'=>'error','raw_response'=>wp_json_encode(['error'=>$r->get_error_message()]),'updated_at'=>$now],['id'=>$cid]); wp_die('Mercado Pago: '.esc_html($r->get_error_message()));}
            $td=$r['point_of_interaction']['transaction_data']??[];
            $wpdb->update(self::table(),[
                'provider_payment_id'=>(string)($r['id']??''),'status'=>sanitize_key($r['status']??'pending'),
                'qr_code'=>$td['qr_code']??'','qr_code_base64'=>$td['qr_code_base64']??'','checkout_url'=>$td['ticket_url']??'',
                'expires_at'=>$r['date_of_expiration']??null,'raw_response'=>wp_json_encode($r),'updated_at'=>current_time('mysql')
            ],['id'=>$cid]);
        }elseif($method==='card'){
            $wpdb->update(self::table(),[
                'status'=>'pending','checkout_url'=>self::payment_url($token),'updated_at'=>current_time('mysql')
            ],['id'=>$cid]);
        }else{
            wp_die('Novas cobranças externas foram desativadas. Use Pix transparente ou Cartão transparente.');
        }
        VFOS_DB::log('mp_charge_created','financial',$fid,'Cobrança Mercado Pago criada | '.$method.' | R$ '.number_format($amount,2,',','.'),null,['charge_id'=>$cid],$f->description);
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.$fid.'&charge='.$cid.'&vfos_msg='.rawurlencode('Cobrança online criada.')));exit;
    }
    public static function email_charge(){
        $id=absint($_GET['id']??0);check_admin_referer('vfos_mp_email_charge_'.$id);VFOS_Team::require_permission('financial.payments');global $wpdb;
        $t=self::table();$ft=VFOS_DB::table('financial');$ct=VFOS_DB::table('clients');
        $c=$wpdb->get_row($wpdb->prepare("SELECT pc.*,f.description,c.name client_name,c.email,c.billing_email FROM $t pc JOIN $ft f ON f.id=pc.financial_id LEFT JOIN $ct c ON c.id=f.client_id WHERE pc.id=%d",$id));
        if(!$c)wp_die('Cobrança não encontrada.');
        $email=sanitize_email($c->payer_email?:($c->billing_email?:$c->email));if(!$email)wp_die('O cliente não possui e-mail válido para envio.');
        $company=get_option('vfos_company_info',[]);$brand=is_array($company)&&!empty($company['name'])?$company['name']:'VisionForge Digital';
        $link=self::payment_url($c->public_token);
        $subject='Cobrança '.$brand.' — '.wp_strip_all_tags($c->description);
        $body='<div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;padding:24px;background:#f4f8fa"><div style="background:#fff;border:1px solid #dce7eb;border-radius:18px;padding:28px"><div style="color:#087fc7;font-size:13px;font-weight:800">'.esc_html($brand).'</div><h2 style="color:#17394d;margin:8px 0 4px">Olá, '.esc_html($c->client_name?:'cliente').'</h2><p style="color:#607985;line-height:1.6">Uma cobrança foi disponibilizada para você.</p><div style="margin:20px 0;padding:16px;border-radius:12px;background:#f4f9fb"><strong style="display:block;color:#17394d">'.esc_html($c->description).'</strong><span style="display:block;margin-top:7px;font-size:28px;font-weight:900;color:#17394d">R$ '.number_format((float)$c->amount,2,',','.').'</span></div><a href="'.esc_url($link).'" style="display:inline-block;padding:13px 18px;border-radius:10px;background:#087fc7;color:#fff;text-decoration:none;font-weight:800">Abrir e pagar cobrança</a><p style="font-size:12px;color:#84949c;margin-top:22px">O pagamento é processado pelo Mercado Pago e identificado automaticamente pelo VisionForge OS.</p></div></div>';
        $ok=wp_mail($email,$subject,$body,['Content-Type: text/html; charset=UTF-8']);
        VFOS_DB::log('mp_charge_email','financial',$c->financial_id,'Cobrança enviada por e-mail para '.$email,null,['charge_id'=>$id,'email'=>$email],$c->description);
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.$c->financial_id.'&vfos_msg='.rawurlencode($ok?'Cobrança enviada por e-mail com sucesso.':'O WordPress não conseguiu enviar o e-mail. Verifique a configuração de e-mail/SMTP.')));exit;
    }

    public static function public_status(){
        global $wpdb;$id=absint($_REQUEST['charge_id']??0);$token=sanitize_text_field($_REQUEST['public_token']??'');
        $c=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d AND public_token=%s",$id,$token));
        if(!$c)wp_send_json_error(['message'=>'Cobrança não encontrada.'],404);
        if($c->provider_payment_id&&!in_array($c->status,['approved','cancelled','rejected'],true))self::sync_charge($c->id);
        $c=$wpdb->get_row($wpdb->prepare("SELECT status,paid_at FROM ".self::table()." WHERE id=%d",$id));
        wp_send_json_success(['status'=>$c->status,'paid_at'=>$c->paid_at]);
    }

    public static function card_payment(){
        global $wpdb;
        $charge_id=absint($_POST['charge_id']??0);$public_token=sanitize_text_field($_POST['public_token']??'');
        $c=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d AND public_token=%s",$charge_id,$public_token));
        if(!$c||$c->method!=='card')wp_send_json_error(['message'=>'Cobrança inválida.'],404);
        if($c->status==='approved')wp_send_json_success(['status'=>'approved','message'=>'Pagamento já aprovado.']);
        $token=sanitize_text_field($_POST['token']??'');$method=sanitize_text_field($_POST['payment_method_id']??'');
        $card_type=sanitize_key($_POST['card_type']??'credit');if(!in_array($card_type,['credit','debit'],true))$card_type='credit';$installments=$card_type==='debit'?1:max(1,absint($_POST['installments']??1));$issuer=sanitize_text_field($_POST['issuer_id']??'');
        $payer_email=sanitize_email($_POST['payer_email']??$c->payer_email);
        $doc_type=sanitize_text_field($_POST['identification_type']??'');$doc_number=preg_replace('/\D+/','',sanitize_text_field($_POST['identification_number']??''));
        if(!$token||!$method||!$payer_email)wp_send_json_error(['message'=>'Dados do cartão incompletos.'],400);
        $body=[
            'transaction_amount'=>(float)$c->amount,'token'=>$token,'description'=>'VisionForge - cobrança #'.$c->financial_id,
            'installments'=>$installments,'payment_method_id'=>$method,'external_reference'=>$c->external_reference,
            'notification_url'=>self::webhook_url(),'metadata'=>['vfos_card_type'=>$card_type],'payer'=>['email'=>$payer_email]
        ];
        if($issuer)$body['issuer_id']=$issuer;
        if($doc_type&&$doc_number)$body['payer']['identification']=['type'=>$doc_type,'number'=>$doc_number];
        $r=self::api('POST','/v1/payments',$body,'vfos-card-'.$c->id.'-'.$public_token);
        if(is_wp_error($r))wp_send_json_error(['message'=>$r->get_error_message()],400);
        $wpdb->update(self::table(),['provider_payment_id'=>(string)($r['id']??''),'status'=>sanitize_key($r['status']??'pending'),'raw_response'=>wp_json_encode($r),'updated_at'=>current_time('mysql')],['id'=>$c->id]);
        $fresh=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",$c->id));
        self::apply_payment($fresh,$r);
        wp_send_json_success(['status'=>$r['status']??'pending','status_detail'=>$r['status_detail']??'','message'=>($r['status']??'')==='approved'?'Pagamento aprovado.':'Pagamento enviado para análise.']);
    }

    public static function sync_charge_action(){
        $id=absint($_GET['id']??0);check_admin_referer('vfos_mp_sync_charge_'.$id);VFOS_Team::require_permission('financial.payments');
        self::sync_charge($id);
        global $wpdb;$c=$wpdb->get_row($wpdb->prepare("SELECT financial_id FROM ".self::table()." WHERE id=%d",$id));
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.absint($c->financial_id).'&vfos_msg='.rawurlencode('Status consultado no Mercado Pago.')));exit;
    }
    public static function sync_charge($id){
        global $wpdb;$t=self::table();$c=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));if(!$c)return new WP_Error('not_found','Cobrança online não encontrada.');
        if(!$c->provider_payment_id)return $c;
        $r=self::api('GET','/v1/payments/'.rawurlencode($c->provider_payment_id));if(is_wp_error($r))return $r;
        return self::apply_payment($c,$r);
    }
    private static function apply_payment($charge,$payment){
        global $wpdb;$t=self::table();$status=sanitize_key($payment['status']??'pending');
        $wpdb->update($t,['status'=>$status,'provider_payment_id'=>(string)($payment['id']??$charge->provider_payment_id),'raw_response'=>wp_json_encode($payment),'updated_at'=>current_time('mysql')],['id'=>$charge->id]);
        if($status!=='approved')return $payment;
        $already=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('financial_payments')." WHERE provider='mercadopago' AND provider_payment_id=%s",(string)$payment['id']));
        if($already)return $payment;
        $amount=(float)($payment['transaction_amount']??$charge->amount);
        $ft=VFOS_DB::table('financial');$pt=VFOS_DB::table('financial_payments');$f=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ft WHERE id=%d",$charge->financial_id));
        if(!$f)return $payment;
        $remaining=max(0,(float)$f->amount-(float)$f->paid_amount);$amount=min($remaining,$amount);
        if($amount<=0)return $payment;
        $wpdb->insert($pt,[
            'financial_id'=>$charge->financial_id,'amount'=>$amount,'payment_date'=>!empty($payment['date_approved'])?date('Y-m-d H:i:s',strtotime($payment['date_approved'])):current_time('mysql'),
            'method'=>'Mercado Pago — '.(($payment['payment_method_id']??'')==='pix'?'Pix':ucfirst($payment['payment_type_id']??'online')),
            'notes'=>'Baixa automática Mercado Pago','created_by'=>0,'created_at'=>current_time('mysql'),
            'provider'=>'mercadopago','provider_payment_id'=>(string)$payment['id'],'charge_id'=>$charge->id
        ]);
        $received=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM $pt WHERE financial_id=%d",$charge->financial_id));
        $newstatus=$received<=0?'pending':($received+0.001>=(float)$f->amount?'paid':'partial');
        $wpdb->update($ft,['paid_amount'=>min((float)$f->amount,$received),'status'=>$newstatus,'paid_at'=>$newstatus==='paid'?current_time('mysql'):null,'updated_at'=>current_time('mysql')],['id'=>$charge->financial_id]);
        $wpdb->update($t,['paid_at'=>current_time('mysql')],['id'=>$charge->id]);
        VFOS_DB::log('mp_payment_approved','financial',$charge->financial_id,'Baixa automática Mercado Pago | R$ '.number_format($amount,2,',','.'),null,['payment_id'=>$payment['id'],'charge_id'=>$charge->id],$f->description);
        return $payment;
    }
    public static function cancel_charge(){
        $id=absint($_GET['id']??0);check_admin_referer('vfos_mp_cancel_charge_'.$id);VFOS_Team::require_permission('financial.payments');global $wpdb;
        $c=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",$id));if(!$c)wp_die('Cobrança não encontrada.');
        if($c->status==='approved')wp_die('Pagamento aprovado não pode ser cancelado por esta ação.');
        if($c->provider_payment_id){
            $r=self::api('PUT','/v1/payments/'.rawurlencode($c->provider_payment_id),['status'=>'cancelled']);
            if(is_wp_error($r))wp_die('Mercado Pago: '.esc_html($r->get_error_message()));
        }
        $wpdb->update(self::table(),['status'=>'cancelled','updated_at'=>current_time('mysql')],['id'=>$id]);
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.$c->financial_id.'&vfos_msg='.rawurlencode('Cobrança cancelada.')));exit;
    }
    public static function route(){
        if(isset($_GET['vfos_mp_webhook']))self::webhook();
        if(isset($_GET['vfos_pay']))self::public_payment();
    }
    private static function webhook(){
        $raw=file_get_contents('php://input');$body=json_decode($raw,true)?:[];
        $type=sanitize_key($_GET['type']??($body['type']??($_GET['topic']??'')));
        $pid=sanitize_text_field($_GET['data_id']??($_GET['data']['id']??($body['data']['id']??($_GET['id']??''))));
        if(!$pid){status_header(200);echo 'OK';exit;}

        if(in_array($type,['subscription_preapproval','subscription_authorized_payment','subscription_preapproval_plan'],true)){
            if(class_exists('VFOS_Recurring')&&$type!=='subscription_preapproval_plan')VFOS_Recurring::handle_webhook($type,$pid,$body);
            status_header(200);echo 'OK';exit;
        }

        $payment=self::api('GET','/v1/payments/'.rawurlencode($pid));
        if(is_wp_error($payment)){status_header(200);echo 'OK';exit;}
        if(class_exists('VFOS_Recurring')&&VFOS_Recurring::handle_payment_webhook($payment)){status_header(200);echo 'OK';exit;}
        $external=sanitize_text_field($payment['external_reference']??'');global $wpdb;
        $charge=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE external_reference=%s",$external));
        if($charge)self::apply_payment($charge,$payment);
        status_header(200);echo 'OK';exit;
    }
    private static function public_payment(){
        $token=sanitize_text_field($_GET['token']??'');global $wpdb;
        $c=$wpdb->get_row($wpdb->prepare("SELECT pc.*,f.description,f.amount financial_total,f.paid_amount,c.name client_name FROM ".self::table()." pc JOIN ".VFOS_DB::table('financial')." f ON f.id=pc.financial_id LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=f.client_id WHERE pc.public_token=%s",$token));
        if(!$c){status_header(404);wp_die('Cobrança não encontrada.');}
        if($c->provider_payment_id&&$c->status!=='approved')self::sync_charge($c->id);
        $c=$wpdb->get_row($wpdb->prepare("SELECT pc.*,f.description,c.name client_name FROM ".self::table()." pc JOIN ".VFOS_DB::table('financial')." f ON f.id=pc.financial_id LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=f.client_id WHERE pc.id=%d",$c->id));
        $company=get_option('vfos_company_info',[]);$brand=is_array($company)&&!empty($company['name'])?$company['name']:'VisionForge Digital';$s=self::settings();
        $public_key=trim($s['public_key']);$ajax=admin_url('admin-ajax.php');
        nocache_headers();?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pagamento — <?php echo esc_html($brand);?></title>
        <?php if($c->method==='card'&&$public_key):?><script src="https://sdk.mercadopago.com/js/v2"></script><?php endif;?>
        <style>
        *{box-sizing:border-box}body{margin:0;background:#f3f7f9;font-family:Inter,system-ui,-apple-system,sans-serif;color:#17394d}.wrap{max-width:760px;margin:36px auto;padding:20px}.card{background:#fff;border:1px solid #dfe9ed;border-radius:24px;padding:30px;box-shadow:0 18px 50px #17394d12}.brand{display:flex;justify-content:space-between;gap:15px;align-items:center;font-weight:900;color:#087fc7}.secure{font-size:11px;color:#728792;font-weight:600}.amount{font-size:40px;font-weight:900;margin:12px 0;color:#17394d}.muted{color:#718792}.qr{width:270px;max-width:90%;display:block;margin:20px auto}.copy{width:100%;padding:12px;border:1px solid #dbe6ea;border-radius:10px;background:#f8fbfc;resize:none}.btn{width:100%;border:0;display:block;text-align:center;padding:13px 16px;border-radius:11px;background:#087fc7;color:#fff;text-decoration:none;font-weight:800;margin-top:12px;cursor:pointer}.ok{padding:16px;border-radius:12px;background:#eaf7ef;color:#32734b;font-weight:800}.pending{padding:12px;border-radius:12px;background:#fff7e8;color:#805d27}.small{font-size:12px}.divider{height:1px;background:#e3ebef;margin:22px 0}.method-title{font-size:18px;margin:0 0 5px}.transparent-note{display:flex;gap:9px;align-items:flex-start;padding:11px;border-radius:10px;background:#eef8fc;color:#527080;font-size:12px;margin:14px 0}.payment-result{display:none;margin-top:13px;padding:12px;border-radius:10px}.payment-result.okay{display:block;background:#eaf7ef;color:#32734b}.payment-result.error{display:block;background:#fff0f0;color:#9d3b3b}#cardPaymentBrick_container{min-height:220px;margin-top:10px}.card-type-choice{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:14px 0}.card-type-choice button{border:1px solid #d7e5eb;border-radius:11px;padding:11px;background:#fff;color:#476674;font-weight:800;cursor:pointer}.card-type-choice button.active{border-color:#087fc7;background:#eef8fd;color:#087fc7}.card-type-help{font-size:11px;color:#7b8e97;margin:-4px 0 10px}
        @media(max-width:600px){.wrap{margin:8px auto;padding:10px}.card{padding:20px;border-radius:18px}.amount{font-size:34px}.brand{align-items:flex-start;flex-direction:column}}
        </style></head><body><div class="wrap"><div class="card"><div class="brand"><span><?php echo esc_html($brand);?></span><span class="secure">🔒 Pagamento seguro</span></div><p class="muted"><?php echo esc_html($c->client_name?:'Cobrança online');?></p><h1><?php echo esc_html($c->description);?></h1><div class="amount">R$ <?php echo number_format((float)$c->amount,2,',','.');?></div>
        <div id="vfos-payment-state">
        <?php if($c->status==='approved'):?><div class="ok">✓ Pagamento aprovado e identificado automaticamente.</div>
        <?php elseif($c->status==='cancelled'):?><div class="pending">Esta cobrança foi cancelada.</div>
        <?php else:?><div class="pending">Aguardando pagamento. A confirmação e a baixa são automáticas.</div>
        <?php if($c->method==='pix'):?>
            <div class="divider"></div><h2 class="method-title">Pague com Pix</h2><p class="muted small">Escaneie o QR Code ou use o código Copia e Cola. Você permanece nesta página.</p>
            <?php if($c->qr_code_base64):?><img class="qr" src="data:image/png;base64,<?php echo esc_attr($c->qr_code_base64);?>" alt="QR Code Pix"><?php endif;?>
            <?php if($c->qr_code):?><textarea id="pix-code" class="copy" rows="4" readonly onclick="this.select()"><?php echo esc_textarea($c->qr_code);?></textarea><button class="btn" type="button" onclick="navigator.clipboard.writeText(document.getElementById('pix-code').value);this.textContent='Código copiado ✓'">Copiar Pix</button><?php endif;?>
        <?php elseif($c->method==='card'):?>
            <div class="divider"></div><h2 class="method-title">Pague com cartão</h2><div class="transparent-note"><span>✓</span><span>O formulário seguro do Mercado Pago funciona dentro da página da VisionForge. Os dados completos do cartão não são armazenados pelo VisionForge OS.</span></div>
            <?php if(!$public_key):?><div class="payment-result error" style="display:block">A Public Key do Mercado Pago ainda não foi configurada.</div>
            <?php else:?><div class="card-type-choice"><button type="button" class="active" data-card-type="credit">Cartão de crédito</button><button type="button" data-card-type="debit">Cartão de débito</button></div><p id="card-type-help" class="card-type-help">Crédito selecionado. O Mercado Pago mostrará as opções de crédito disponíveis para o cartão.</p><div id="cardPaymentBrick_container"></div><div id="vfos-card-result" class="payment-result"></div><?php endif;?>
        <?php elseif($c->checkout_url):?><div class="divider"></div><a class="btn" target="_blank" rel="noopener" href="<?php echo esc_url($c->checkout_url);?>">Abrir checkout legado</a><?php endif;?>
        <?php endif;?>
        </div><p class="muted small" style="margin-top:22px">Processamento financeiro realizado pelo Mercado Pago. A VisionForge recebe apenas o status necessário para conciliar a cobrança.</p></div></div>
        <script>
        (function(){
          const chargeId=<?php echo (int)$c->id;?>, publicToken=<?php echo wp_json_encode($c->public_token);?>, ajax=<?php echo wp_json_encode($ajax);?>;
          async function checkStatus(){
            try{
              const fd=new URLSearchParams({action:'vfos_mp_public_status',charge_id:String(chargeId),public_token:publicToken});
              const r=await fetch(ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString(),credentials:'same-origin'});const j=await r.json();
              if(j.success&&j.data.status==='approved'){document.getElementById('vfos-payment-state').innerHTML='<div class="ok">✓ Pagamento aprovado e identificado automaticamente.</div>';return true;}
            }catch(e){} return false;
          }
          setInterval(checkStatus,5000);
          <?php if($c->method==='card'&&$public_key&&$c->status!=='approved'):?>
          document.addEventListener('DOMContentLoaded',async function(){
            try{
              const mp=new MercadoPago(<?php echo wp_json_encode($public_key);?>,{locale:'pt-BR'}),bricksBuilder=mp.bricks();
              let selectedType='credit',controller=null;
              const help=document.getElementById('card-type-help'),buttons=[...document.querySelectorAll('[data-card-type]')];
              async function renderCard(type){
                selectedType=type;
                buttons.forEach(b=>b.classList.toggle('active',b.dataset.cardType===type));
                if(help)help.textContent=type==='debit'?'Débito selecionado. Pagamento à vista; a disponibilidade depende do cartão/banco habilitado pelo Mercado Pago.':'Crédito selecionado. O Mercado Pago mostrará parcelas e opções de crédito disponíveis.';
                if(controller&&controller.unmount)try{await controller.unmount()}catch(e){}
                document.getElementById('cardPaymentBrick_container').innerHTML='';
                const excluded=type==='debit'?['credit_card','prepaid_card']:['debit_card','prepaid_card'];
                const settings={
                  initialization:{amount:<?php echo json_encode((float)$c->amount);?>,payer:{email:<?php echo wp_json_encode($c->payer_email);?>}},
                  customization:{paymentMethods:{types:{excluded:excluded}}},
                  callbacks:{
                    onReady:()=>{},
                    onSubmit:(formData)=>new Promise(async(resolve,reject)=>{
                      const result=document.getElementById('vfos-card-result');result.className='payment-result';result.textContent='Processando pagamento...';result.style.display='block';
                      try{
                        const fd=new URLSearchParams();
                        fd.set('action','vfos_mp_card_payment');fd.set('charge_id',String(chargeId));fd.set('public_token',publicToken);fd.set('card_type',selectedType);
                        fd.set('token',formData.token||'');fd.set('payment_method_id',formData.payment_method_id||'');fd.set('installments',String(selectedType==='debit'?1:(formData.installments||1)));fd.set('issuer_id',String(formData.issuer_id||''));
                        const payer=formData.payer||{};fd.set('payer_email',payer.email||<?php echo wp_json_encode($c->payer_email);?>);
                        if(payer.identification){fd.set('identification_type',payer.identification.type||'');fd.set('identification_number',payer.identification.number||'');}
                        const rr=await fetch(ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString(),credentials:'same-origin'});const jj=await rr.json();
                        if(!jj.success)throw new Error((jj.data&&jj.data.message)||'Não foi possível processar o pagamento.');
                        if(jj.data.status==='approved'){result.className='payment-result okay';result.textContent='✓ Pagamento aprovado. Atualizando...';setTimeout(()=>location.reload(),900);}
                        else{result.className='payment-result okay';result.textContent=jj.data.message||'Pagamento enviado para análise.';}resolve();
                      }catch(err){result.className='payment-result error';result.textContent=err.message||'Falha ao processar o cartão.';reject();}
                    }),
                    onError:()=>{const result=document.getElementById('vfos-card-result');result.className='payment-result error';result.textContent='Não foi possível carregar/processar este tipo de cartão. Tente outra opção.';}
                  }
                };
                controller=await bricksBuilder.create('cardPayment','cardPaymentBrick_container',settings);window.vfosCardBrick=controller;
              }
              buttons.forEach(b=>b.addEventListener('click',()=>renderCard(b.dataset.cardType)));
              await renderCard('credit');
            }catch(err){const result=document.getElementById('vfos-card-result');result.className='payment-result error';result.style.display='block';result.textContent='Não foi possível iniciar o pagamento com cartão.';}
          });
          <?php endif;?>
        })();
        </script></body></html><?php exit;
    }
}
