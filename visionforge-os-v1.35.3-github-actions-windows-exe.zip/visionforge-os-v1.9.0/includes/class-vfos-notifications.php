<?php
if (!defined('ABSPATH')) exit;
class VFOS_Notifications {
    public static function init(){
        add_action('admin_init',[__CLASS__,'generate_due_alerts']);
    }
    public static function notify($user_id,$type,$title,$message='',$module='',$entity_type='',$entity_id=0,$url='',$sender_user_id=0,$delivery_scope='system',$batch_id='',$allow_replies=0,$context_label=''){
        global $wpdb;$user_id=absint($user_id);if(!$user_id)return false;
        $ok=$wpdb->insert(VFOS_DB::table('notifications'),[
            'user_id'=>$user_id,'sender_user_id'=>absint($sender_user_id),'delivery_scope'=>sanitize_key($delivery_scope?:'system'),
            'batch_id'=>sanitize_text_field($batch_id),'allow_replies'=>empty($allow_replies)?0:1,
            'type'=>sanitize_key($type),'title'=>sanitize_text_field($title),'message'=>sanitize_textarea_field($message),
            'module'=>sanitize_key($module),'entity_type'=>sanitize_key($entity_type),'entity_id'=>absint($entity_id),'context_label'=>sanitize_text_field($context_label),'url'=>esc_url_raw($url),
            'is_read'=>0,'created_at'=>current_time('mysql')
        ]);
        if($ok===false){error_log('[VisionForge OS] Erro ao inserir notificação: '.$wpdb->last_error);return false;}
        if(self::email_enabled($user_id))self::send_email($user_id,$title,$message,$url,$type,$sender_user_id);
        return $ok;
    }
    public static function activity($action,$title,$description='',$module='',$entity_type='',$entity_id=0,$url='',$user_id=0){
        global $wpdb;
        $wpdb->insert(VFOS_DB::table('activity_feed'),[
            'user_id'=>absint($user_id),'actor_user_id'=>get_current_user_id(),'action_key'=>sanitize_key($action),'title'=>sanitize_text_field($title),
            'description'=>sanitize_textarea_field($description),'module'=>sanitize_key($module),'entity_type'=>sanitize_key($entity_type),
            'entity_id'=>absint($entity_id),'url'=>esc_url_raw($url),'created_at'=>current_time('mysql')
        ]);
    }
    public static function email_enabled($user_id=null){
        $user_id=$user_id?:get_current_user_id();
        return (bool)get_user_meta(absint($user_id),'_vfos_notification_email_enabled',true);
    }
    public static function send_email($user_id,$title,$message='',$url='',$type='info',$sender_user_id=0){
        $user=get_userdata(absint($user_id));if(!$user||!is_email($user->user_email))return false;
        $company=get_option('vfos_company_info',[]);$brand=is_array($company)&&!empty($company['name'])?$company['name']:'VisionForge Digital';
        $sender=$sender_user_id?get_userdata(absint($sender_user_id)):null;
        $subject='['.$brand.'] '.$title;
        $body='<div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;padding:24px;background:#f5f8fa"><div style="background:#fff;border:1px solid #dce6eb;border-radius:16px;padding:24px"><div style="font-size:12px;font-weight:800;color:#087fc7;margin-bottom:8px">'.esc_html($brand).' • '.esc_html(strtoupper($type)).'</div><h2 style="margin:0 0 12px;color:#17394d">'.esc_html($title).'</h2><div style="font-size:14px;line-height:1.65;color:#435d69">'.nl2br(esc_html($message)).'</div>';
        if($sender)$body.='<p style="font-size:12px;color:#80919a;margin-top:18px">Enviado por '.esc_html($sender->display_name).'</p>';
        if($url)$body.='<p style="margin-top:20px"><a href="'.esc_url($url).'" style="display:inline-block;padding:11px 16px;border-radius:9px;background:#087fc7;color:#fff;text-decoration:none;font-weight:700">Abrir no VisionForge OS</a></p>';
        $body.='<p style="font-size:11px;color:#93a1a8;margin-top:24px">Você está recebendo este e-mail porque ativou notificações por e-mail no VisionForge OS.</p></div></div>';
        return wp_mail($user->user_email,$subject,$body,['Content-Type: text/html; charset=UTF-8']);
    }

    public static function unread_count($user_id=null){
        global $wpdb;$user_id=$user_id?:get_current_user_id();
        return (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('notifications')." WHERE user_id=%d AND is_read=0",$user_id));
    }
    public static function generate_due_alerts(){
        if(!current_user_can('vfos_access'))return;
        $uid=get_current_user_id();$key='vfos_due_alerts_'.date('YmdH');
        if(get_transient($key))return;set_transient($key,1,HOUR_IN_SECONDS);
        global $wpdb;$nt=VFOS_DB::table('notifications');$tt=VFOS_DB::table('tasks');
        $tasks=$wpdb->get_results($wpdb->prepare("SELECT id,title,due_date FROM $tt WHERE assigned_user_id=%d AND status NOT IN ('done','cancelled') AND due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 1 DAY)",$uid));
        foreach($tasks as $t){
            $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $nt WHERE user_id=%d AND entity_type='task' AND entity_id=%d AND type='deadline' AND DATE(created_at)=CURDATE()",$uid,$t->id));
            if(!$exists)self::notify($uid,'deadline','Prazo de tarefa próximo',$t->title.' vence em '.date_i18n('d/m/Y',strtotime($t->due_date)).'.','tasks','task',$t->id,admin_url('admin.php?page=vfos-tasks&tab=new&edit='.$t->id));
        }
        $ct=VFOS_DB::table('calendar_events');
        $events=$wpdb->get_results($wpdb->prepare("SELECT id,title,start_at FROM $ct WHERE assigned_user_id=%d AND status NOT IN ('done','cancelled') AND start_at BETWEEN NOW() AND DATE_ADD(NOW(),INTERVAL 24 HOUR)",$uid));
        foreach($events as $e){
            $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $nt WHERE user_id=%d AND entity_type='calendar_event' AND entity_id=%d AND type='calendar' AND DATE(created_at)=CURDATE()",$uid,$e->id));
            if(!$exists)self::notify($uid,'calendar','Compromisso se aproximando',$e->title.' • '.date_i18n('d/m H:i',strtotime($e->start_at)),'calendar','calendar_event',$e->id,admin_url('admin.php?page=vfos-calendar&tab=new&edit='.$e->id));
        }
    }
}
