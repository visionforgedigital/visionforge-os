<?php
if (!defined('ABSPATH')) exit;
class VFOS_PDF {
    private static function latin($s){
        $s=html_entity_decode((string)$s,ENT_QUOTES|ENT_HTML5,'UTF-8');
        $x=@iconv('UTF-8','Windows-1252//TRANSLIT',$s);
        return $x!==false?$x:$s;
    }
    private static function esc($s){return str_replace(['\\','(',')'],['\\\\','\\(','\\)'],self::latin($s));}
    private static function text_width($text,$size,$bold=false){
        static $normal=[' '=>278,'!'=>278,'"'=>355,'#'=>556,'$'=>556,'%'=>889,'&'=>667,'\''=>191,'('=>333,')'=>333,'*'=>389,'+'=>584,','=>278,'-'=>333,'.'=>278,'/'=>278,'0'=>556,'1'=>556,'2'=>556,'3'=>556,'4'=>556,'5'=>556,'6'=>556,'7'=>556,'8'=>556,'9'=>556,':'=>278,';'=>278,'<'=>584,'='=>584,'>'=>584,'?'=>556,'@'=>1015,'A'=>667,'B'=>667,'C'=>722,'D'=>722,'E'=>667,'F'=>611,'G'=>778,'H'=>722,'I'=>278,'J'=>500,'K'=>667,'L'=>556,'M'=>833,'N'=>722,'O'=>778,'P'=>667,'Q'=>778,'R'=>722,'S'=>667,'T'=>611,'U'=>722,'V'=>667,'W'=>944,'X'=>667,'Y'=>667,'Z'=>611,'['=>278,'\\'=>278,']'=>278,'^'=>469,'_'=>556,'`'=>333,'a'=>556,'b'=>556,'c'=>500,'d'=>556,'e'=>556,'f'=>278,'g'=>556,'h'=>556,'i'=>222,'j'=>222,'k'=>500,'l'=>222,'m'=>833,'n'=>556,'o'=>556,'p'=>556,'q'=>556,'r'=>333,'s'=>500,'t'=>278,'u'=>556,'v'=>500,'w'=>722,'x'=>500,'y'=>500,'z'=>500,'{'=>334,'|'=>260,'}'=>334,'~'=>584];
        static $boldMap=[' '=>278,'!'=>333,'"'=>474,'#'=>556,'$'=>556,'%'=>889,'&'=>722,'\''=>238,'('=>333,')'=>333,'*'=>389,'+'=>584,','=>278,'-'=>333,'.'=>278,'/'=>278,'0'=>556,'1'=>556,'2'=>556,'3'=>556,'4'=>556,'5'=>556,'6'=>556,'7'=>556,'8'=>556,'9'=>556,':'=>333,';'=>333,'<'=>584,'='=>584,'>'=>584,'?'=>611,'@'=>975,'A'=>722,'B'=>722,'C'=>722,'D'=>722,'E'=>667,'F'=>611,'G'=>778,'H'=>722,'I'=>278,'J'=>556,'K'=>722,'L'=>611,'M'=>833,'N'=>722,'O'=>778,'P'=>667,'Q'=>778,'R'=>722,'S'=>667,'T'=>611,'U'=>722,'V'=>667,'W'=>944,'X'=>667,'Y'=>667,'Z'=>611,'['=>333,'\\'=>278,']'=>333,'^'=>584,'_'=>556,'`'=>333,'a'=>556,'b'=>611,'c'=>556,'d'=>611,'e'=>556,'f'=>333,'g'=>611,'h'=>611,'i'=>278,'j'=>278,'k'=>556,'l'=>278,'m'=>889,'n'=>611,'o'=>611,'p'=>611,'q'=>611,'r'=>389,'s'=>556,'t'=>333,'u'=>611,'v'=>556,'w'=>778,'x'=>556,'y'=>556,'z'=>500,'{'=>389,'|'=>280,'}'=>389,'~'=>584];
        $map=$bold?$boldMap:$normal;$sum=0;
        $chars=function_exists('mb_str_split')?mb_str_split((string)$text):str_split((string)$text);
        foreach($chars as $ch){
            if(isset($map[$ch])){$sum+=$map[$ch];continue;}
            // Accented Latin characters use approximately the width of their base letter.
            $ascii=@iconv('UTF-8','ASCII//TRANSLIT',$ch);
            if($ascii!==false&&$ascii!==''){
                $base=substr($ascii,0,1);
                $sum+=$map[$base]??556;
            }else $sum+=556;
        }
        return $sum*((float)$size)/1000;
    }
    private static function style_from_node($node,$style){
        $tag=strtolower($node->nodeName??'');
        if(in_array($tag,['strong','b'],true))$style['bold']=true;
        if(in_array($tag,['em','i'],true))$style['italic']=true;
        if($tag==='u')$style['underline']=true;
        if(preg_match('/^h([1-6])$/',$tag,$m)){
            $sizes=[1=>18,2=>16,3=>14,4=>12.5,5=>11.5,6=>10.5];$style['size']=$sizes[(int)$m[1]];$style['bold']=true;
        }
        if($node instanceof DOMElement){
            $css=(string)$node->getAttribute('style');
            if(preg_match('/text-align\s*:\s*(left|center|right|justify)/i',$css,$m))$style['align']=strtolower($m[1]);
            if(preg_match('/font-size\s*:\s*([0-9.]+)(px|pt)?/i',$css,$m)){
                $v=(float)$m[1];if(strtolower($m[2]??'')==='px')$v*=0.75;if($v>=7&&$v<=28)$style['size']=$v;
            }
            if(preg_match('/font-weight\s*:\s*(bold|[6-9]00)/i',$css))$style['bold']=true;
            if(preg_match('/font-style\s*:\s*italic/i',$css))$style['italic']=true;
            if(preg_match('/text-decoration[^;]*underline/i',$css))$style['underline']=true;
        }
        return $style;
    }
    private static function inline_runs($node,$style){
        $runs=[];
        foreach($node->childNodes as $child){
            if($child instanceof DOMText){$txt=preg_replace('/\s+/u',' ',$child->nodeValue);if($txt!=='')$runs[]=['text'=>$txt]+$style;continue;}
            if($child instanceof DOMElement){$st=self::style_from_node($child,$style);$tag=strtolower($child->nodeName);if($tag==='br'){$runs[]=['break'=>true]+$st;continue;}$runs=array_merge($runs,self::inline_runs($child,$st));}
        }
        return $runs;
    }
    private static function html_style($tag,$attrs,$style){
        $tag=strtolower($tag);
        if(in_array($tag,['strong','b'],true))$style['bold']=true;
        if(in_array($tag,['em','i'],true))$style['italic']=true;
        if($tag==='u')$style['underline']=true;
        if(preg_match('/^h([1-6])$/',$tag,$m)){$sizes=[1=>18,2=>16,3=>14,4=>12.5,5=>11.5,6=>10.5];$style['size']=$sizes[(int)$m[1]];$style['bold']=true;}
        if(preg_match('/style\s*=\s*(["\'])(.*?)\1/is',$attrs,$m)){
            $css=$m[2];if(preg_match('/text-align\s*:\s*(left|center|right|justify)/i',$css,$x))$style['align']=strtolower($x[1]);
            if(preg_match('/font-size\s*:\s*([0-9.]+)\s*(px|pt)?/i',$css,$x)){$v=(float)$x[1];if(strtolower($x[2]??'')==='px')$v*=0.75;if($v>=7&&$v<=28)$style['size']=$v;}
            if(preg_match('/font-weight\s*:\s*(bold|[6-9]00)/i',$css))$style['bold']=true;if(preg_match('/font-style\s*:\s*italic/i',$css))$style['italic']=true;if(preg_match('/text-decoration[^;]*underline/i',$css))$style['underline']=true;
        }
        return $style;
    }
    private static function css_spacing($attrs,$key,$default=0){
        if(!preg_match('/style\s*=\s*(["\'])(.*?)\1/is',(string)$attrs,$m))return $default;
        $css=$m[2];
        $map=['before'=>['margin-top','padding-top'],'after'=>['margin-bottom','padding-bottom']];
        $sum=0.0;
        foreach($map[$key]??[] as $prop){
            if(preg_match('/'.preg_quote($prop,'/').'\s*:\s*([0-9.]+)\s*(px|pt)?/i',$css,$x)){
                $v=(float)$x[1];if(strtolower($x[2]??'')==='px')$v*=0.75;$sum+=$v;
            }
        }
        return $sum?:$default;
    }
    private static function normalize_text($txt){
        $txt=html_entity_decode((string)$txt,ENT_QUOTES|ENT_HTML5,'UTF-8');
        $txt=str_replace(["\r\n","\r","\t"],["\n","\n","    "],$txt);
        // Preserve intentional spaces/newlines; collapse only excessive inline spaces.
        $parts=explode("\n",$txt);
        foreach($parts as &$part)$part=preg_replace('/[ ]{2,}/u',' ',$part);
        return implode("\n",$parts);
    }
    private static function blocks($html){
        $html=(string)$html;
        if(trim(wp_strip_all_tags(str_replace(['<br>','<br/>','<br />'],"\n",$html)))==='')return [];
        $base=['size'=>10.5,'bold'=>false,'italic'=>false,'underline'=>false,'align'=>'left'];
        $style=$base;$styleStack=[];$blocks=[];$current=null;$listStack=[];
        $flush=function($force=false) use (&$current,&$blocks){
            if(!$current){if($force)$blocks[]=['runs'=>[],'blank'=>true,'space_after'=>8];return;}
            if(!empty($current['runs'])||$force)$blocks[]=$current;
            $current=null;
        };
        $newBlock=function($tag,$attrs='') use (&$style){
            $st=self::html_style($tag,$attrs,$style);
            $heading=preg_match('/^h[1-6]$/',$tag);
            return ['runs'=>[],'align'=>$st['align'],'indent'=>$tag==='blockquote'?18:0,
                'space_before'=>self::css_spacing($attrs,'before',$heading?8:0),
                'space_after'=>self::css_spacing($attrs,'after',$heading?8:5)];
        };
        $tokens=preg_split('/(<[^>]+>)/s',$html,-1,PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
        foreach($tokens as $tok){
            if($tok==='' )continue;
            if($tok[0]!=='<'){
                $raw=self::normalize_text($tok);
                if($raw==='')continue;
                if(!$current)$current=['runs'=>[],'align'=>$style['align'],'space_after'=>5];
                $segments=preg_split('/(\n)/u',$raw,-1,PREG_SPLIT_DELIM_CAPTURE);
                foreach($segments as $seg){
                    if($seg==="\n"){$current['runs'][]=['break'=>true,'explicit'=>true]+$style;continue;}
                    if($seg!=='')$current['runs'][]=['text'=>$seg]+$style;
                }
                continue;
            }
            if(preg_match('/^<\s*\/\s*([a-z0-9]+)[^>]*>/i',$tok,$m)){
                $tag=strtolower($m[1]);
                if(in_array($tag,['p','div','h1','h2','h3','h4','h5','h6','blockquote','li'],true))$flush();
                if(in_array($tag,['ul','ol'],true))array_pop($listStack);
                if(isset($styleStack[$tag])&&$styleStack[$tag])$style=array_pop($styleStack[$tag]);
                continue;
            }
            if(!preg_match('/^<\s*([a-z0-9]+)([^>]*)>/i',$tok,$m))continue;
            $tag=strtolower($m[1]);$attrs=$m[2]??'';
            if($tag==='br'){
                if(!$current)$current=['runs'=>[],'align'=>$style['align'],'space_after'=>5];
                $current['runs'][]=['break'=>true,'explicit'=>true]+$style;continue;
            }
            if($tag==='hr'){$flush();$blocks[]=['rule'=>true,'space_before'=>7,'space_after'=>10];continue;}
            if(in_array($tag,['ul','ol'],true)){$flush();$listStack[]=['type'=>$tag,'counter'=>0];continue;}
            if($tag==='li'){
                $flush();$level=max(1,count($listStack));$type=$listStack?$listStack[count($listStack)-1]['type']:'ul';
                if($listStack){$listStack[count($listStack)-1]['counter']++;$n=$listStack[count($listStack)-1]['counter'];}else$n=1;
                $current=['runs'=>[],'align'=>'left','indent'=>($level-1)*15,'space_after'=>5];
                $current['runs'][]=['text'=>$type==='ol'?($n.'. '):'• ','bold'=>true]+$style;continue;
            }
            if(in_array($tag,['p','div','h1','h2','h3','h4','h5','h6','blockquote'],true)){
                $flush();$styleStack[$tag][]=$style;$current=$newBlock($tag,$attrs);$style=self::html_style($tag,$attrs,$style);continue;
            }
            if(in_array($tag,['strong','b','em','i','u','span'],true)){
                $styleStack[$tag][]=$style;$style=self::html_style($tag,$attrs,$style);if($current)$current['align']=$style['align'];continue;
            }
        }
        $flush();
        // Normalize typography without changing the user's paragraph structure:
        // no spaces before punctuation, no duplicated inline spaces, and a normal
        // space after punctuation when formatting splits the sentence into runs.
        foreach($blocks as &$block){
            if(empty($block['runs']))continue;
            $prevText='';
            foreach($block['runs'] as &$run){
                if(!empty($run['break'])){$prevText='';continue;}
                $t=str_replace("\xC2\xA0",' ',(string)($run['text']??''));
                $t=preg_replace('/[ \t]{2,}/u',' ',$t);
                $t=preg_replace('/[ \t]+([,.;:!?])/u','$1',$t);
                if($prevText!=='' && preg_match('/[,;:!?]$/u',$prevText) && preg_match('/^[^\s,.;:!?]/u',$t)){
                    $last=mb_substr($prevText,-1,1,'UTF-8');$first=mb_substr($t,0,1,'UTF-8');
                    if(!(preg_match('/\d/u',$last)&&preg_match('/\d/u',$first)))$t=' '.$t;
                }
                $run['text']=$t;
                if($t!=='')$prevText=rtrim($t);
            }
            unset($run);
        }
        unset($block);
        return $blocks;
    }
    private static function split_long_token($part,$run,$maxWidth){
        $chunks=[];$buf='';
        $chars=function_exists('mb_str_split')?mb_str_split($part):str_split($part);
        foreach($chars as $ch){
            $try=$buf.$ch;
            if($buf!=='' && self::text_width($try,$run['size']??10.5,!empty($run['bold']))>$maxWidth){$chunks[]=$buf;$buf=$ch;}else $buf=$try;
        }
        if($buf!=='')$chunks[]=$buf;return $chunks;
    }
    private static function wrap_block($block,$maxWidth){
        if(!empty($block['rule']))return [$block];
        if(!empty($block['blank'])&&!$block['runs'])return [['runs'=>[],'width'=>0,'blank'=>true]+$block];
        $lines=[];$line=[];$width=0;
        $push=function() use (&$lines,&$line,&$width,$block){$lines[]=['runs'=>$line,'width'=>$width]+$block;$line=[];$width=0;};
        foreach($block['runs'] as $run){
            if(!empty($run['break'])){$push();continue;}
            $parts=preg_split('/(\s+)/u',(string)($run['text']??''),-1,PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
            foreach($parts as $part){
                if($part==='')continue;
                $rw=self::text_width($part,$run['size']??10.5,!empty($run['bold']));
                if($rw>$maxWidth && trim($part)!==''){
                    if($line)$push();
                    foreach(self::split_long_token($part,$run,$maxWidth) as $chunk){$r=$run;$r['text']=$chunk;$cw=self::text_width($chunk,$r['size']??10.5,!empty($r['bold']));$lines[]=['runs'=>[$r],'width'=>$cw]+$block;}
                    continue;
                }
                if($width+$rw>$maxWidth && $line && trim($part)!==''){$push();$part=ltrim($part);if($part==='')continue;$rw=self::text_width($part,$run['size']??10.5,!empty($run['bold']));}
                $r=$run;$r['text']=$part;$line[]=$r;$width+=$rw;
            }
        }
        if($line)$push();
        if(!$lines)$lines[]=['runs'=>[],'width'=>0,'blank'=>true]+$block;
        return $lines;
    }
    private static function pdf_stream($blocks,$pageW=595,$pageH=842){
        // Safe text area inside the supplied letterhead.
        $left=68;$right=62;$topY=690;$bottomY=126;$max=$pageW-$left-$right;
        $pages=[];$stream='';$y=$topY;
        $newPage=function() use (&$pages,&$stream,&$y,$topY){
            if($stream!=='')$pages[]=$stream;
            $stream="q\n595 0 0 842 0 0 cm\n/BG Do\nQ\n";$y=$topY;
        };
        $newPage();
        foreach($blocks as $block){
            $before=(float)($block['space_before']??0);
            if($y-$before<$bottomY)$newPage(); else $y-=$before;
            if(!empty($block['rule'])){
                if($y<($bottomY+15))$newPage();
                $stream.="0.82 G 0.5 w ".$left." ".round($y,2)." m ".($pageW-$right)." ".round($y,2)." l S\n";
                $y-=(float)($block['space_after']??10);continue;
            }
            if(!empty($block['blank'])&&empty($block['runs'])){
                $gap=max(8,(float)($block['space_after']??5));
                if($y-$gap<$bottomY)$newPage();else $y-=$gap;
                continue;
            }
            $indent=(float)($block['indent']??0);
            $lines=self::wrap_block($block,$max-$indent);
            foreach($lines as $line){
                $size=10.5;foreach($line['runs'] as $r)$size=max($size,(float)($r['size']??10.5));
                // Comfortable line-height prevents glyph collision even with mixed font sizes.
                $leading=max(14.0,$size*1.38);
                if($y-$leading<$bottomY)$newPage();
                if(empty($line['runs'])){$y-=$leading;continue;}
                $lineW=(float)$line['width'];$align=$line['align']??'left';$x=$left+$indent;
                if($align==='center')$x=$left+$indent+max(0,($max-$indent-$lineW)/2);
                elseif($align==='right')$x=$pageW-$right-$lineW;
                foreach($line['runs'] as $r){
                    $font=!empty($r['bold'])?(!empty($r['italic'])?'F4':'F2'):(!empty($r['italic'])?'F3':'F1');
                    $fs=(float)($r['size']??10.5);$t=(string)($r['text']??'');if($t==='')continue;
                    $w=self::text_width($t,$fs,!empty($r['bold']));
                    $stream.="BT /$font ".round($fs,2)." Tf 0 g ".round($x,2)." ".round($y,2)." Td (".self::esc($t).") Tj ET\n";
                    if(!empty($r['underline'])&&trim($t)!=='')$stream.="0 G 0.45 w ".round($x,2).' '.round($y-2,2).' m '.round($x+$w,2).' '.round($y-2,2)." l S\n";
                    $x+=$w;
                }
                $y-=$leading;
            }
            $after=max(0,(float)($block['space_after']??5));
            if($y-$after<$bottomY)$newPage();else $y-=$after;
        }
        if($stream!=='')$pages[]=$stream;return $pages;
    }
    public static function contract($title,$content,$number='',$client=''){
        $u=wp_upload_dir();$dir=trailingslashit($u['basedir']).'vfos-contracts';if(!is_dir($dir))wp_mkdir_p($dir);$path=$dir.'/contract-'.sanitize_file_name($number?:wp_generate_password(12,false,false)).'-'.time().'.pdf';
        $bg=VFOS_DIR.'admin/assets/images/visionforge-letterhead.jpg';if(!is_file($bg))return new WP_Error('letterhead_missing','Papel timbrado do contrato não foi encontrado.');$jpg=file_get_contents($bg);$info=getimagesize($bg);if(!$jpg||!$info)return new WP_Error('letterhead_invalid','Papel timbrado inválido.');
        $blocks=self::blocks($content);$pages=self::pdf_stream($blocks);if(!$pages)$pages=["q\n595 0 0 842 0 0 cm\n/BG Do\nQ\n"];
        $objects=[];$objects[1]='<< /Type /Catalog /Pages 2 0 R >>';$objects[3]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';$objects[4]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';$objects[5]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>';$objects[6]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-BoldOblique /Encoding /WinAnsiEncoding >>';
        $objects[7]='<< /Type /XObject /Subtype /Image /Width '.(int)$info[0].' /Height '.(int)$info[1].' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '.strlen($jpg)." >>\nstream\n".$jpg."\nendstream";
        $kids=[];$obj=8;foreach($pages as $contentStream){$pageObj=$obj++;$contentObj=$obj++;$kids[]=$pageObj.' 0 R';$objects[$contentObj]='<< /Length '.strlen($contentStream)." >>\nstream\n".$contentStream.'endstream';$objects[$pageObj]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R >> /XObject << /BG 7 0 R >> >> /Contents '.$contentObj.' 0 R >>';}
        $objects[2]='<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.count($kids).' >>';ksort($objects);$pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offsets=[0=>0];foreach($objects as $n=>$body){$offsets[$n]=strlen($pdf);$pdf.=$n." 0 obj\n".$body."\nendobj\n";}$xref=strlen($pdf);$max=max(array_keys($objects));$pdf.="xref\n0 ".($max+1)."\n0000000000 65535 f \n";for($i=1;$i<=$max;$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i]??0)."\n";$pdf.='trailer << /Size '.($max+1).' /Root 1 0 R >>'."\nstartxref\n".$xref."\n%%EOF\n";if(file_put_contents($path,$pdf)===false)return new WP_Error('pdf_write','Não foi possível gerar o PDF do contrato.');return $path;
    }
}
