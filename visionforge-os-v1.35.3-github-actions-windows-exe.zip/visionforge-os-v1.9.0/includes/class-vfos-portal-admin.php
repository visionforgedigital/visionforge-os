<?php
if (!defined('ABSPATH')) exit;

class VFOS_Portal_Admin {
    public static function init(){
        add_action('admin_menu',[__CLASS__,'menu'],30);
        add_action('admin_post_vfos_create_portal_page',[__CLASS__,'create_page']);
        add_action('admin_post_vfos_portal_access',[__CLASS__,'create_access']);
        add_action('admin_post_vfos_portal_access_settings',[__CLASS__,'save_access_settings']);
        add_action('admin_post_vfos_portal_generate_link',[__CLASS__,'generate_link']);
        add_action('admin_post_vfos_portal_revoke_link',[__CLASS__,'revoke_link']);
        add_action('admin_post_vfos_admin_approval',[__CLASS__,'create_approval']);
        add_action('admin_post_vfos_admin_portal_reply',[__CLASS__,'reply']);
        add_action('admin_post_vfos_portal_send_access',[__CLASS__,'send_access']);
        add_action('admin_post_vfos_toggle_approval_release',[__CLASS__,'toggle_release']);
        add_action('admin_post_vfos_delete_client_approval',[__CLASS__,'delete_approval']);
        add_action('admin_post_vfos_delete_client_approval_group',[__CLASS__,'delete_approval_group']);
    }
    public static function menu(){
        if(!current_user_can('vfos_access'))return;
        if(!current_user_can('manage_options')&&!VFOS_Team::can_permission('clients.portal'))return;
        add_submenu_page('vfos','Área do Cliente','Área do Cliente','vfos_access','vfos-portal',[__CLASS__,'page']);
    }
    private static function guard($action){
        if(!current_user_can('manage_options')&&!VFOS_Team::can_permission('clients.portal'))wp_die('Sem permissão para gerenciar a Área do Cliente.');
        check_admin_referer($action);
    }
    private static function redirect($msg){ wp_safe_redirect(add_query_arg(['page'=>'vfos-portal','vfos_msg'=>$msg],admin_url('admin.php'))); exit; }
    private static function username_from_email($email){ $base=sanitize_user(strstr($email,'@',true),true); if(!$base)$base='cliente'; $u=$base; $i=2; while(username_exists($u)){$u=$base.$i;$i++;} return $u; }
    private static function portal_url(){
        $id=absint(get_option('vfos_portal_page_id'));return $id?get_permalink($id):'';
    }
    private static function direct_url($client){
        $base=self::portal_url();if(!$base||empty($client->portal_token_hint))return '';
        $token=get_transient('vfos_portal_plain_'.$client->id);
        return $token?add_query_arg('vfos_access',$token,$base):'';
    }
    private static function access_mode_label($mode){
        return ['direct_link'=>'Link direto seguro','identifier'=>'E-mail / CPF / CNPJ','both'=>'Link direto + identificação','wordpress'=>'Login com senha'][$mode]??'Link direto seguro';
    }

    public static function page(){
        if(!current_user_can('manage_options')&&!VFOS_Team::can_permission('clients.portal'))wp_die('Sem permissão para acessar a Área do Cliente.');
        global $wpdb;$selected_client=absint($_GET['client_id']??0); $clients=$wpdb->get_results('SELECT * FROM '.VFOS_DB::table('clients').' ORDER BY name');
        $approvals=$wpdb->get_results('SELECT a.*,c.name client_name,p.name project_name FROM '.VFOS_DB::table('client_approvals').' a LEFT JOIN '.VFOS_DB::table('clients').' c ON c.id=a.client_id LEFT JOIN '.VFOS_DB::table('projects').' p ON p.id=a.project_id ORDER BY a.id DESC LIMIT 100');
        $messages=$wpdb->get_results('SELECT m.*,c.name client_name FROM '.VFOS_DB::table('portal_messages').' m LEFT JOIN '.VFOS_DB::table('clients').' c ON c.id=m.client_id ORDER BY m.id DESC LIMIT 30');
        $page_id=absint(get_option('vfos_portal_page_id')); $page_url=$page_id?get_permalink($page_id):'';
        echo '<div class="wrap vfos-wrap"><div class="vfos-top"><div><div class="vfos-brand"><span class="vfos-mark">VF</span><span>VISIONFORGE <b>OS</b></span></div><h1>Área do Cliente</h1><p>Gerencie o portal que seus clientes usam para acompanhar projetos, pagamentos, aprovações, contratos, arquivos e mensagens.</p></div><span class="vfos-version">v'.esc_html(VFOS_VERSION).'</span></div>';
        echo '<div class="vfos-client-area-explainer"><div><span class="vfos-kicker">DUAS ÁREAS DIFERENTES</span><h2>Clientes é interno. Área do Cliente é o portal externo.</h2><p><b>Clientes</b> serve para sua equipe cadastrar e administrar cada cliente. <b>Área do Cliente</b> é o ambiente que você envia para o cliente acompanhar tudo que é dele.</p></div><div><a class="button button-primary vfos-btn" href="'.esc_url(admin_url('admin.php?page=vfos-clients')).'">Abrir Clientes</a>'.($page_url?' <a class="button" target="_blank" href="'.esc_url($page_url).'">Abrir portal público</a>':'').'</div></div>';
        if(!empty($_GET['vfos_msg'])) echo '<div class="vfos-notice">'.esc_html(wp_unslash($_GET['vfos_msg'])).'</div>';
        if($selected_client){
            $sc=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('clients')." WHERE id=%d",$selected_client));
            if($sc){
                $linked=get_users(['meta_key'=>'vfos_client_id','meta_value'=>$selected_client]);
                $plain=get_transient('vfos_portal_plain_'.$selected_client);$quick_direct=$plain&&$page_url?add_query_arg('vfos_access',$plain,$page_url):'';
                echo '<div class="vfos-selected-client-portal"><div><span class="vfos-kicker">CLIENTE SELECIONADO</span><h2>'.esc_html($sc->name).'</h2><p>Modo: '.esc_html(self::access_mode_label($sc->portal_access_mode)).'</p></div><div><a class="button" href="'.esc_url(admin_url('admin.php?page=vfos-client-view&id='.$selected_client)).'">Abrir Cliente 360°</a>'.($quick_direct?'<button type="button" class="button vfos-copy-client-portal" data-link="'.esc_attr($quick_direct).'">Copiar link direto</button>':'').'</div></div>';
            }
        }
        echo '<div class="vfos-grid vfos-grid-2"><div class="vfos-panel"><span class="vfos-kicker">PORTAL</span><h2>Página da Área do Cliente</h2>';
        if($page_url){echo '<p>A página do portal está configurada.</p><p><a class="button button-primary vfos-btn" target="_blank" href="'.esc_url($page_url).'">Abrir portal</a> <a class="button" href="'.esc_url(get_edit_post_link($page_id)).'">Editar página</a></p><code>[visionforge_client_portal]</code>';}
        else{echo '<p>Crie automaticamente uma página com o shortcode do portal.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_create_portal_page">';wp_nonce_field('vfos_create_portal_page');echo '<button class="button button-primary vfos-btn">Criar página Área do Cliente</button></form><p><small>Você também pode usar manualmente <code>[visionforge_client_portal]</code> em qualquer página.</small></p>';}
        echo '</div><div class="vfos-panel"><span class="vfos-kicker">ACESSO SEM SENHA</span><h2>Como o cliente entra?</h2><p>O acesso padrão agora não exige usuário ou senha do WordPress.</p>';
        if(!$selected_client){echo '<p><strong>Selecione um cliente</strong> pela aba Clientes → Área do Cliente para configurar o acesso individual.</p>';}
        else{
            $sc=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('clients')." WHERE id=%d",$selected_client));
            if($sc){
                $generated=!empty($_GET['vfos_generated_link'])?rawurldecode(wp_unslash($_GET['vfos_generated_link'])):'';
                $plain=get_transient('vfos_portal_plain_'.$selected_client);$direct=$generated?:($plain&&$page_url?add_query_arg('vfos_access',$plain,$page_url):'');
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_portal_access_settings"><input type="hidden" name="client_id" value="'.$selected_client.'">';wp_nonce_field('vfos_portal_access_settings');
                echo '<label>Modo de acesso<select name="portal_access_mode"><option value="direct_link" '.selected($sc->portal_access_mode,'direct_link',false).'>Link direto seguro — sem login</option><option value="identifier" '.selected($sc->portal_access_mode,'identifier',false).'>E-mail / CPF / CNPJ — sem senha</option><option value="both" '.selected($sc->portal_access_mode,'both',false).'>Link direto + E-mail/CPF/CNPJ</option><option value="wordpress" '.selected($sc->portal_access_mode,'wordpress',false).'>Login tradicional com senha</option></select></label>';
                echo '<div class="vfos-form-grid"><label>Expiração do link <small>Opcional</small><input type="datetime-local" name="portal_token_expires" value="'.esc_attr($sc->portal_token_expires?date('Y-m-d\TH:i',strtotime($sc->portal_token_expires)):'').'"></label><label class="vfos-switch-row"><input type="checkbox" name="portal_sensitive_confirm" value="1" '.checked(!empty($sc->portal_sensitive_confirm),true,false).'> Pedir confirmação para ações sensíveis</label></div><button class="button">Salvar modo de acesso</button></form>';
                $gen=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_generate_link&client_id='.$selected_client),'vfos_portal_generate_link');
                echo '<div class="vfos-passwordless-actions"><a class="button button-primary vfos-btn" href="'.esc_url($gen).'">'.($sc->portal_token_hash?'Gerar novo link seguro':'Gerar link direto seguro').'</a>';
                if($sc->portal_token_hash){$rev=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_revoke_link&client_id='.$selected_client),'vfos_portal_revoke_link');echo '<a class="button vfos-danger" href="'.esc_url($rev).'">Revogar link</a>';}
                if($direct)echo '<button type="button" class="button vfos-copy-client-portal" data-link="'.esc_attr($direct).'">Copiar link direto</button>';
                echo '</div>';
                if($direct)echo '<div class="vfos-direct-link-box"><strong>Link pronto para enviar</strong><input readonly value="'.esc_attr($direct).'"><small>Quem receber este link entra diretamente na Área do Cliente, sem senha.</small></div>';
                elseif($sc->portal_token_hash)echo '<p><small>Existe um link ativo (final '.esc_html($sc->portal_token_hint).'), mas por segurança o token completo não é armazenado em texto aberto. Clique em “Gerar novo link seguro” para obter um endereço copiável novamente.</small></p>';
                echo '<p><small>Modo atual: <b>'.esc_html(self::access_mode_label($sc->portal_access_mode)).'</b>. E-mail/CPF/CNPJ são usados somente para identificação; não há criação de senha.</small></p>';
            }
        }
        echo '</div></div>';
        echo '<div class="vfos-panel"><span class="vfos-kicker">APROVAÇÕES</span><h2>Enviar arte ou entrega para aprovação</h2><form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_admin_approval">';wp_nonce_field('vfos_admin_approval');echo '<div class="vfos-form-grid"><label>Cliente<select name="client_id" id="vfos-approval-client" required><option value="">Selecione</option>';foreach($clients as $c)echo '<option value="'.$c->id.'" '.selected($selected_client,$c->id,false).'>'.esc_html($c->name).'</option>';echo '</select></label><label>Projeto<select name="project_id"><option value="0">Sem projeto específico</option>';$projects=$wpdb->get_results('SELECT p.id,p.name,c.name client_name FROM '.VFOS_DB::table('projects').' p LEFT JOIN '.VFOS_DB::table('clients').' c ON c.id=p.client_id ORDER BY p.id DESC');foreach($projects as $p)echo '<option value="'.$p->id.'">'.esc_html($p->client_name.' — '.$p->name).'</option>';echo '</select></label><label>Título da apresentação<input name="title" required placeholder="Ex.: Escolha do post da campanha"></label><label>Arquivos / opções<input type="file" name="approval_files[]" multiple accept="image/*,.pdf,.doc,.docx,.zip"><small>Selecione 2, 3 ou mais arquivos de uma vez.</small></label><label>Como o cliente deve decidir?<select name="selection_mode"><option value="choose_one">Escolher uma opção</option><option value="independent">Avaliar cada arquivo separadamente</option></select></label></div><label>Orientações para o cliente<textarea name="description" placeholder="Ex.: Preparamos duas opções de post. Escolha a que mais gostou ou solicite alterações."></textarea></label><div class="vfos-multi-approval-help"><strong>Várias opções na mesma apresentação</strong><p>Quando escolher “Escolher uma opção”, o cliente verá todas as artes juntas e poderá selecionar apenas uma como aprovada. Os nomes dos arquivos serão usados como nome das opções.</p></div><div class="vfos-approval-protection"><div><span class="vfos-kicker">PROTEÇÃO DA ARTE</span><h3>Marca d’água para imagens</h3><p>Quando o arquivo for uma imagem, o portal mostra somente uma prévia com a marca d’água incorporada. O arquivo original fica reservado no sistema.</p></div><label class="vfos-switch-row"><input type="checkbox" name="watermark_enabled" value="1" checked> Aplicar marca d’água</label><label>Texto da marca d’água <small>Opcional</small><input name="watermark_text" placeholder="VISIONFORGE • APENAS PARA APROVAÇÃO"></label></div><div class="vfos-download-release-option"><label class="vfos-switch-row"><input type="checkbox" name="release_after_approval" value="1"> Liberar download automaticamente após a aprovação</label><p>Ative se o cliente já pagou. Se deixar desativado, você poderá liberar o arquivo depois, quando o pagamento for realizado.</p></div><button class="button button-primary vfos-btn">Enviar para aprovação</button></form></div>';
        echo '<div class="vfos-panel"><h2>Aprovações recentes</h2><div class="vfos-table-wrap"><table class="widefat vfos-table"><thead><tr><th>Cliente</th><th>Entrega</th><th>Status</th><th>Resposta</th><th>Data</th></tr></thead><tbody>'; if(!$approvals)echo '<tr><td colspan="5">Nenhuma aprovação criada.</td></tr>'; foreach($approvals as $a){$lab=['pending'=>'Aguardando','approved'=>'Aprovado','changes_requested'=>'Alteração solicitada','not_selected'=>'Não escolhida'][$a->status]??$a->status;$orig=!empty($a->original_path)?wp_nonce_url(admin_url('admin-post.php?action=vfos_approval_original&table=client_approvals&id='.$a->id),'vfos_approval_original_client_approvals_'.$a->id):'';$toggle=wp_nonce_url(admin_url('admin-post.php?action=vfos_toggle_approval_release&id='.$a->id),'vfos_toggle_approval_release_'.$a->id);$delete=wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_client_approval&id='.$a->id.'&client_id='.$a->client_id),'vfos_delete_client_approval');$delete_group=!empty($a->approval_group)?wp_nonce_url(admin_url('admin-post.php?action=vfos_delete_client_approval_group&group='.rawurlencode($a->approval_group).'&client_id='.$a->client_id),'vfos_delete_client_approval_group'):'';echo '<tr><td><strong>'.esc_html($a->client_name).'</strong><small>'.esc_html($a->project_name).'</small></td><td><strong>'.esc_html($a->title).'</strong>'.($a->option_label?'<small>Opção '.((int)$a->option_order+1).' • '.esc_html($a->option_label).'</small>':'').($a->file_url?'<small><a target="_blank" href="'.esc_url($a->file_url).'">Ver prévia</a>'.($orig?' · <a href="'.esc_url($orig).'">Original</a>':'').'</small>':'').'</td><td><span class="vfos-pill">'.esc_html($lab).'</span>'.(!empty($a->watermark_enabled)?'<small>Marca d’água ativa</small>':'').'</td><td>'.esc_html($a->decision_comment?:'—').(!empty($a->original_path)&&$a->status==='approved'?'<small><a href="'.esc_url($toggle).'">'.($a->release_original?'Bloquear download':'Liberar download').'</a></small>':'').'</td><td>'.esc_html(date_i18n('d/m/Y H:i',strtotime($a->requested_at))).'<div class="vfos-approval-delete-actions"><a class="vfos-danger" href="'.esc_url($delete).'" onclick="return confirm(\'Excluir somente esta aprovação/arquivo? Esta ação não pode ser desfeita.\')">Excluir item</a>'.($delete_group?' · <a class="vfos-danger" href="'.esc_url($delete_group).'" onclick="return confirm(\'Excluir a apresentação completa e todas as opções/arquivos dela? Esta ação não pode ser desfeita.\')">Excluir apresentação</a>':'').'</div></td></tr>'; } echo '</tbody></table></div></div>';
        echo '<div class="vfos-panel vfos-download-control-panel"><div class="vfos-section-head"><div><span class="vfos-kicker">ARQUIVOS FINAIS</span><h2>Liberação de downloads</h2><p>Controle quais arquivos aprovados o cliente já pode baixar. Ideal para liberar o original após a confirmação do pagamento.</p></div></div><div class="vfos-download-control-list">';
        $download_rows=$selected_client?$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('client_approvals')." WHERE client_id=%d AND status='approved' AND original_path<>'' ORDER BY decided_at DESC,id DESC",$selected_client)):$wpdb->get_results("SELECT a.*,c.name client_name FROM ".VFOS_DB::table('client_approvals')." a LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=a.client_id WHERE a.status='approved' AND a.original_path<>'' ORDER BY a.decided_at DESC,a.id DESC LIMIT 100");
        if(!$download_rows)echo '<div class="vfos-empty">Nenhum arquivo aprovado aguardando gerenciamento de download.</div>';
        foreach($download_rows as $d){$dtoggle=wp_nonce_url(admin_url('admin-post.php?action=vfos_toggle_approval_release&id='.$d->id),'vfos_toggle_approval_release_'.$d->id);echo '<article><div><small>'.(!$selected_client&&!empty($d->client_name)?esc_html($d->client_name).' • ':'').'APROVADO</small><strong>'.esc_html($d->title).'</strong>'.($d->option_label?'<span>'.esc_html($d->option_label).'</span>':'').'</div><div class="vfos-download-state '.($d->release_original?'is-released':'is-locked').'"><b>'.($d->release_original?'Download liberado':'Download bloqueado').'</b><span>'.($d->release_original?'O cliente já pode baixar o arquivo final na aba Aprovações.':'A aprovação foi feita, mas o arquivo final ainda não está disponível para download.').'</span></div><a class="button '.($d->release_original?'':'button-primary vfos-btn').'" href="'.esc_url($dtoggle).'">'.($d->release_original?'Bloquear download':'Liberar download').'</a></article>';}
        echo '</div></div>';
        echo '<div class="vfos-panel"><span class="vfos-kicker">MENSAGENS</span><h2>Últimas mensagens do portal</h2><div class="vfos-admin-messages">'; if(!$messages)echo '<p>Nenhuma mensagem.</p>'; foreach($messages as $m){echo '<div class="vfos-admin-message"><div><strong>'.esc_html($m->client_name).'</strong><span>'.esc_html($m->direction==='client'?'Cliente':'VisionForge').' · '.esc_html(date_i18n('d/m/Y H:i',strtotime($m->created_at))).'</span></div><p>'.esc_html($m->message).'</p>'; if($m->direction==='client'){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_admin_portal_reply"><input type="hidden" name="client_id" value="'.$m->client_id.'">';wp_nonce_field('vfos_admin_portal_reply');echo '<input name="message" required placeholder="Responder ao cliente"><button class="button">Responder</button></form>';} echo '</div>'; } echo '</div></div></div>';
    }
    private static function delete_approval_files($row){
        if(!$row)return;
        if(!empty($row->original_path)&&is_file($row->original_path))@unlink($row->original_path);
        if(!empty($row->preview_url)){
            $up=wp_upload_dir();
            if(strpos($row->preview_url,$up['baseurl'])===0){
                $path=str_replace($up['baseurl'],$up['basedir'],$row->preview_url);
                if($path&&is_file($path))@unlink($path);
            }
        }
        // Arquivos antigos/não protegidos podem estar na biblioteca de mídia.
        if(!empty($row->attachment_id))wp_delete_attachment(absint($row->attachment_id),true);
    }
    public static function delete_approval(){
        self::guard('vfos_delete_client_approval');global $wpdb;
        $id=absint($_GET['id']??0);$cid=absint($_GET['client_id']??0);
        $t=VFOS_DB::table('client_approvals');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));
        if(!$row)self::redirect('Aprovação não encontrada.');
        self::delete_approval_files($row);
        $wpdb->delete($t,['id'=>$id]);
        VFOS_DB::log('client_approval_deleted','approval',$id,'Aprovação excluída manualmente pela equipe.',(array)$row,null,$row->title);
        wp_safe_redirect(add_query_arg(['page'=>'vfos-portal','client_id'=>$cid?:$row->client_id,'vfos_msg'=>'Aprovação excluída com sucesso.'],admin_url('admin.php')));exit;
    }
    public static function delete_approval_group(){
        self::guard('vfos_delete_client_approval_group');global $wpdb;
        $group=sanitize_text_field(wp_unslash($_GET['group']??''));$cid=absint($_GET['client_id']??0);
        if(!$group)self::redirect('Grupo de aprovação inválido.');
        $t=VFOS_DB::table('client_approvals');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE approval_group=%s".($cid?" AND client_id=%d":""),...($cid?[$group,$cid]:[$group])));
        if(!$rows)self::redirect('Apresentação não encontrada.');
        $snapshot=[];foreach($rows as $row){$snapshot[]=(array)$row;self::delete_approval_files($row);}
        if($cid)$wpdb->query($wpdb->prepare("DELETE FROM $t WHERE approval_group=%s AND client_id=%d",$group,$cid));
        else $wpdb->query($wpdb->prepare("DELETE FROM $t WHERE approval_group=%s",$group));
        VFOS_DB::log('client_approval_group_deleted','approval',0,'Apresentação completa excluída | grupo='.$group.' | itens='.count($rows),$snapshot,null,$rows[0]->title);
        wp_safe_redirect(add_query_arg(['page'=>'vfos-portal','client_id'=>$cid?:$rows[0]->client_id,'vfos_msg'=>count($rows).' item(ns) da apresentação foram excluídos.'],admin_url('admin.php')));exit;
    }

    public static function create_page(){ self::guard('vfos_create_portal_page'); $existing=absint(get_option('vfos_portal_page_id')); if($existing&&get_post($existing))self::redirect('A página do portal já existe.'); $id=wp_insert_post(['post_title'=>'Área do Cliente','post_name'=>'area-do-cliente','post_content'=>'[visionforge_client_portal]','post_status'=>'publish','post_type'=>'page']); if(is_wp_error($id))self::redirect('Não foi possível criar a página.'); update_option('vfos_portal_page_id',$id); self::redirect('Página Área do Cliente criada.'); }
    public static function create_access(){
        self::guard('vfos_portal_access');global $wpdb;
        $cid=absint($_POST['client_id']??0);$client=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.VFOS_DB::table('clients').' WHERE id=%d',$cid));
        if(!$client)self::redirect('Cliente não encontrado.');
        $email=sanitize_email($_POST['email']??'');if(!$email)$email=$client->email;
        if(!$email)self::redirect('Informe um e-mail apenas se quiser manter o login tradicional.');
        $user=get_user_by('email',$email);
        if(!$user){$uid=wp_create_user(self::username_from_email($email),wp_generate_password(40,true,true),$email);if(is_wp_error($uid))self::redirect('Erro ao criar usuário: '.$uid->get_error_message());$user=get_user_by('id',$uid);wp_update_user(['ID'=>$uid,'display_name'=>$client->name]);}
        update_user_meta($user->ID,'vfos_client_id',$cid);update_user_meta($user->ID,'vfos_portal_enabled',1);
        VFOS_DB::log('portal_wp_access','client',$cid,'Login tradicional vinculado sem envio automático de definição de senha.');
        self::redirect('Login tradicional vinculado. Nenhum e-mail de criação de senha foi enviado.');
    }
    public static function save_access_settings(){
        self::guard('vfos_portal_access_settings');global $wpdb;$cid=absint($_POST['client_id']??0);
        $mode=sanitize_key($_POST['portal_access_mode']??'direct_link');if(!in_array($mode,['direct_link','identifier','both','wordpress'],true))$mode='direct_link';
        $expires=trim(sanitize_text_field($_POST['portal_token_expires']??''));$expires=$expires?str_replace('T',' ',$expires).(strlen($expires)<=16?':00':''):null;
        $wpdb->update(VFOS_DB::table('clients'),[
            'portal_access_mode'=>$mode,'portal_identifier_enabled'=>in_array($mode,['identifier','both'],true)?1:0,
            'portal_sensitive_confirm'=>!empty($_POST['portal_sensitive_confirm'])?1:0,
            'portal_token_expires'=>$expires,'updated_at'=>current_time('mysql'),'updated_by'=>get_current_user_id()
        ],['id'=>$cid]);
        VFOS_DB::log('portal_access_settings','client',$cid,'Modo de acesso: '.$mode,null,['mode'=>$mode,'expires'=>$expires]);
        self::redirect('Configurações de acesso da Área do Cliente salvas.');
    }
    public static function generate_link(){
        self::guard('vfos_portal_generate_link');global $wpdb;$cid=absint($_GET['client_id']??$_POST['client_id']??0);
        $client=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('clients')." WHERE id=%d",$cid));if(!$client)self::redirect('Cliente não encontrado.');
        $token=wp_generate_password(64,false,false);$hash=hash('sha256',$token);$hint=substr($token,-8);
        $wpdb->update(VFOS_DB::table('clients'),['portal_token_hash'=>$hash,'portal_token_hint'=>$hint,'portal_token_created_at'=>current_time('mysql'),'portal_token_created_by'=>get_current_user_id(),'updated_at'=>current_time('mysql')],['id'=>$cid]);
        set_transient('vfos_portal_plain_'.$cid,$token,30*DAY_IN_SECONDS);
        VFOS_DB::log('portal_direct_link_generated','client',$cid,'Novo link direto seguro gerado. Final: '.$hint);
        $base=self::portal_url();$url=$base?add_query_arg('vfos_access',$token,$base):'';
        wp_safe_redirect(add_query_arg(['page'=>'vfos-portal','client_id'=>$cid,'vfos_msg'=>'Link direto gerado.','vfos_generated_link'=>rawurlencode($url)],admin_url('admin.php')));exit;
    }
    public static function revoke_link(){
        self::guard('vfos_portal_revoke_link');global $wpdb;$cid=absint($_GET['client_id']??0);
        $wpdb->update(VFOS_DB::table('clients'),['portal_token_hash'=>'','portal_token_hint'=>'','portal_token_created_at'=>null,'portal_token_created_by'=>0,'updated_at'=>current_time('mysql')],['id'=>$cid]);
        delete_transient('vfos_portal_plain_'.$cid);VFOS_DB::log('portal_direct_link_revoked','client',$cid,'Link direto revogado.');
        self::redirect('Link direto revogado. O endereço antigo não acessa mais a Área do Cliente.');
    }
    public static function create_approval(){
        self::guard('vfos_admin_approval');global $wpdb;
        $cid=absint($_POST['client_id']??0);$title=sanitize_text_field($_POST['title']??'');if(!$cid||!$title)self::redirect('Informe cliente e título.');
        $client=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('clients')." WHERE id=%d",$cid));if(!$client)self::redirect('Cliente não encontrado.');
        $project_id=absint($_POST['project_id']??0);
        $description=sanitize_textarea_field($_POST['description']??'');
        $selection_mode=in_array(sanitize_key($_POST['selection_mode']??'choose_one'),['choose_one','independent'],true)?sanitize_key($_POST['selection_mode']??'choose_one'):'choose_one';
        $group='APV-'.strtoupper(wp_generate_password(10,false,false));
        $now=current_time('mysql');

        $files=$_FILES['approval_files']??null;
        $count=0;$ids=[];$errors=[];
        if($files && !empty($files['name']) && is_array($files['name'])){
            $total=count($files['name']);
            for($i=0;$i<$total;$i++){
                if(empty($files['name'][$i]))continue;
                $_FILES['vfos_single_approval']=[
                    'name'=>$files['name'][$i],
                    'type'=>$files['type'][$i]??'',
                    'tmp_name'=>$files['tmp_name'][$i]??'',
                    'error'=>$files['error'][$i]??0,
                    'size'=>$files['size'][$i]??0,
                ];
                $asset=VFOS_Approval_Assets::handle_upload('vfos_single_approval',$client->name,!empty($_POST['watermark_enabled']),sanitize_text_field($_POST['watermark_text']??''));
                unset($_FILES['vfos_single_approval']);
                if(is_wp_error($asset)){$errors[]=$files['name'][$i].': '.$asset->get_error_message();continue;}
                $label=pathinfo(sanitize_file_name($files['name'][$i]),PATHINFO_FILENAME);
                $label=$label?:('Opção '.($count+1));
                $wpdb->insert(VFOS_DB::table('client_approvals'),[
                    'client_id'=>$cid,'project_id'=>$project_id,'title'=>$title,'description'=>$description,'attachment_id'=>0,
                    'file_url'=>$asset['file_url'],'original_path'=>$asset['original_path'],'original_name'=>$asset['original_name'],
                    'preview_url'=>$asset['preview_url'],'mime_type'=>$asset['mime_type'],'watermark_enabled'=>!empty($_POST['watermark_enabled'])&&$asset['is_image']?1:0,
                    'watermark_text'=>$asset['watermark_text'],'release_original'=>!empty($_POST['release_after_approval'])?1:0,'approval_group'=>$group,'selection_mode'=>$selection_mode,
                    'option_label'=>$label,'option_order'=>$count,'status'=>'pending','requested_by'=>get_current_user_id(),
                    'requested_at'=>$now,'updated_at'=>$now
                ]);
                if($wpdb->insert_id){$ids[]=(int)$wpdb->insert_id;$count++;}
            }
        }

        // Compatibilidade: permite uma apresentação sem arquivo para link/texto futuro.
        if(!$count){
            if($errors)self::redirect('Nenhum arquivo foi enviado. '.implode(' | ',$errors));
            self::redirect('Selecione pelo menos um arquivo para a apresentação.');
        }

        VFOS_DB::log('approval_group_requested','approval',reset($ids),'client='.$cid.' | group='.$group.' | options='.$count.' | mode='.$selection_mode,null,['ids'=>$ids],$title);
        $user_ids=get_users(['meta_key'=>'vfos_client_id','meta_value'=>$cid,'fields'=>'ids']);
        $portal_id=absint(get_option('vfos_portal_page_id'));$portal_url=$portal_id?add_query_arg(['vfos_tab'=>'approvals'],get_permalink($portal_id)):'';
        foreach($user_ids as $uid){
            VFOS_Notifications::notify($uid,'approval','Nova apresentação para aprovação',$title.' • '.$count.' opção(ões)','portal','client_approval',reset($ids),$portal_url,get_current_user_id(),'personal','',0,'Aprovação • '.$title);
        }
        self::redirect($count.' arquivo(s) enviados na mesma apresentação para o cliente.'.($errors?' Alguns arquivos falharam: '.implode(' | ',$errors):''));
    }
    public static function toggle_release(){
        if(!current_user_can('manage_options')&&!VFOS_Team::can_permission('clients.portal'))wp_die('Sem permissão para gerenciar a Área do Cliente.');
        $id=absint($_GET['id']??0);check_admin_referer('vfos_toggle_approval_release_'.$id);global $wpdb;
        $t=VFOS_DB::table('client_approvals');$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$id));if(!$r)self::redirect('Aprovação não encontrada.');
        if($r->status!=='approved')self::redirect('O original só pode ser liberado depois da aprovação do cliente.');
        $new=empty($r->release_original)?1:0;$wpdb->update($t,['release_original'=>$new,'updated_at'=>current_time('mysql')],['id'=>$id]);
        VFOS_DB::log('approval_original_release','approval',$id,$new?'Original liberado ao cliente':'Original bloqueado novamente',['release_original'=>(int)$r->release_original],['release_original'=>$new],$r->title);
        wp_safe_redirect(add_query_arg(['page'=>'vfos-portal','client_id'=>$r->client_id,'vfos_msg'=>$new?'Download do arquivo final liberado para o cliente.':'Download do arquivo final bloqueado novamente.'],admin_url('admin.php')));exit;
    }
    public static function send_access(){
        self::guard('vfos_portal_send_access');global $wpdb;
        $cid=absint($_GET['client_id']??$_POST['client_id']??0);
        $client=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('clients')." WHERE id=%d",$cid));if(!$client)self::redirect('Cliente não encontrado.');
        $email=sanitize_email($client->email?:$client->billing_email);if(!$email)self::redirect('O cliente não possui e-mail cadastrado.');
        $portal=self::portal_url();if(!$portal)self::redirect('Crie primeiro a página da Área do Cliente.');
        $token=get_transient('vfos_portal_plain_'.$cid);
        $access=$token?add_query_arg('vfos_access',$token,$portal):$portal;
        $subject='Área do Cliente — VisionForge Digital';
        $body='<div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;padding:24px;background:#f4f8fa"><div style="background:#fff;border:1px solid #dce7eb;border-radius:18px;padding:28px"><div style="font-size:13px;font-weight:900;color:#087fc7">VISIONFORGE DIGITAL</div><h2 style="color:#17394d">Olá, '.esc_html($client->name).'</h2><p style="color:#607985;line-height:1.6">Sua Área do Cliente está disponível para acompanhar projetos, aprovações, pagamentos, propostas, contratos, arquivos e mensagens.</p><a href="'.esc_url($access).'" style="display:inline-block;padding:12px 17px;background:#087fc7;color:#fff;text-decoration:none;border-radius:10px;font-weight:800">Acessar Área do Cliente</a><p style="font-size:12px;color:#82939d;margin-top:20px">Este acesso não exige criação de senha quando o cliente estiver configurado para link direto ou identificação simples.</p></div></div>';
        $sent=wp_mail($email,$subject,$body,['Content-Type: text/html; charset=UTF-8']);
        VFOS_DB::log('portal_access_email','client',$cid,'Link da Área do Cliente enviado por e-mail: '.($sent?'sim':'não'));
        self::redirect($sent?'Link de acesso enviado por e-mail.':'Não foi possível enviar o e-mail. Verifique o SMTP do WordPress.');
    }

    public static function reply(){ self::guard('vfos_admin_portal_reply'); global $wpdb; $cid=absint($_POST['client_id']??0);$msg=sanitize_textarea_field($_POST['message']??'');if($cid&&$msg){$wpdb->insert(VFOS_DB::table('portal_messages'),['client_id'=>$cid,'user_id'=>get_current_user_id(),'direction'=>'staff','message'=>$msg,'created_at'=>current_time('mysql')]);VFOS_DB::log('portal_reply','client',$cid,$msg);}self::redirect('Resposta enviada ao portal do cliente.'); }
}
