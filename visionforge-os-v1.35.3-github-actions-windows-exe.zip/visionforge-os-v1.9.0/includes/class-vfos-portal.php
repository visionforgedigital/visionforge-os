<?php
if (!defined('ABSPATH')) exit;

class VFOS_Portal {
    public static function init(){
        add_shortcode('visionforge_client_portal',[__CLASS__,'shortcode']);
        add_action('wp_enqueue_scripts',[__CLASS__,'assets']);
        add_action('admin_post_vfos_portal_decision',[__CLASS__,'decision']);
        add_action('admin_post_nopriv_vfos_portal_decision',[__CLASS__,'decision']);
        add_action('admin_post_vfos_portal_project_decision',[__CLASS__,'project_decision']);
        add_action('admin_post_nopriv_vfos_portal_project_decision',[__CLASS__,'project_decision']);
        add_action('admin_post_vfos_portal_message',[__CLASS__,'message']);
        add_action('admin_post_nopriv_vfos_portal_message',[__CLASS__,'message']);
        add_action('admin_post_vfos_portal_upload',[__CLASS__,'upload']);
        add_action('admin_post_nopriv_vfos_portal_upload',[__CLASS__,'upload']);
        add_action('admin_post_nopriv_vfos_portal_identify',[__CLASS__,'identify']);
        add_action('admin_post_vfos_portal_identify',[__CLASS__,'identify']);
        add_action('admin_post_nopriv_vfos_portal_exit',[__CLASS__,'portal_exit']);
        add_action('admin_post_vfos_portal_exit',[__CLASS__,'portal_exit']);
        add_filter('body_class',[__CLASS__,'body_class']);
        add_action('template_redirect',[__CLASS__,'standalone_page']);
    }
    public static function assets(){
        if(!is_singular()) return;
        global $post; if(!$post || !has_shortcode($post->post_content,'visionforge_client_portal')) return;
        wp_enqueue_style('vfos-portal',VFOS_URL.'public/assets/css/portal.css',[],VFOS_VERSION);
    }
    public static function standalone_page(){
        if(is_admin()||wp_doing_ajax())return;
        $page_id=absint(get_option('vfos_portal_page_id'));if(!$page_id||!is_page($page_id))return;
        status_header(200);nocache_headers();
        echo '<!doctype html><html '.get_language_attributes().'><head><meta charset="'.esc_attr(get_bloginfo('charset')).'"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Área do Cliente • VisionForge Digital</title>';
        wp_head();
        echo '<style>html,body{margin:0!important;padding:0!important;background:#eaf1f5!important}#wpadminbar{display:none!important}html{margin-top:0!important}</style></head><body class="vfos-standalone-portal">';
        echo do_shortcode('[visionforge_client_portal]');
        wp_footer();echo '</body></html>';exit;
    }

    public static function body_class($classes){
        if(is_singular()){global $post;if($post&&has_shortcode($post->post_content,'visionforge_client_portal'))$classes[]='vfos-client-portal-page';}
        return $classes;
    }
    private static function portal_page_url(){
        $id=absint(get_option('vfos_portal_page_id'));return $id?get_permalink($id):get_permalink();
    }
    private static function cookie_name(){return 'vfos_portal_session';}
    private static function session_secret(){return wp_salt('auth').'|vfos-client-portal';}
    private static function session_value($cid,$expires){
        $payload=$cid.'|'.$expires;$sig=hash_hmac('sha256',$payload,self::session_secret());return base64_encode($payload.'|'.$sig);
    }
    private static function set_portal_session($cid,$ttl=43200){
        $expires=time()+max(900,(int)$ttl);$value=self::session_value($cid,$expires);
        setcookie(self::cookie_name(),$value,['expires'=>$expires,'path'=>COOKIEPATH?:'/','domain'=>COOKIE_DOMAIN?:'','secure'=>is_ssl(),'httponly'=>true,'samesite'=>'Lax']);
        $_COOKIE[self::cookie_name()]=$value;
    }
    private static function session_client_id(){
        $raw=$_COOKIE[self::cookie_name()]??'';if(!$raw)return 0;
        $decoded=base64_decode($raw,true);if(!$decoded)return 0;$parts=explode('|',$decoded);if(count($parts)!==3)return 0;
        [$cid,$expires,$sig]=$parts;if((int)$expires<time())return 0;
        $expected=hash_hmac('sha256',$cid.'|'.$expires,self::session_secret());if(!hash_equals($expected,$sig))return 0;
        return absint($cid);
    }
    private static function token_client_id($token){
        if(!$token||strlen($token)<32)return 0;global $wpdb;$hash=hash('sha256',$token);
        $row=$wpdb->get_row($wpdb->prepare("SELECT id,portal_access_mode,portal_token_expires,status FROM ".VFOS_DB::table('clients')." WHERE portal_token_hash=%s LIMIT 1",$hash));
        if(!$row||$row->status!=='active'||!in_array($row->portal_access_mode,['direct_link','both'],true))return 0;
        if($row->portal_token_expires&&strtotime($row->portal_token_expires)<current_time('timestamp'))return 0;
        return absint($row->id);
    }
    public static function client_id(){
        if(get_current_user_id()){
            $uid=absint(get_user_meta(get_current_user_id(),'vfos_client_id',true));
            if($uid&&get_user_meta(get_current_user_id(),'vfos_portal_enabled',true))return $uid;
        }
        $sid=self::session_client_id();if($sid)return $sid;
        $token=sanitize_text_field(wp_unslash($_GET['vfos_access']??''));
        if($token){$cid=self::token_client_id($token);if($cid){self::set_portal_session($cid);return $cid;}}
        return 0;
    }
    private static function money($v){return 'R$ '.number_format((float)$v,2,',','.');}
    private static function badge($status){
        $labels=['pending'=>'Aguardando','approved'=>'Aprovado','changes_requested'=>'Alteração solicitada','not_selected'=>'Não escolhida','planning'=>'Planejamento','in_progress'=>'Em andamento','review'=>'Em aprovação','completed'=>'Concluído','draft'=>'Rascunho','sent'=>'Enviado','accepted'=>'Aceito','rejected'=>'Recusado','signed'=>'Assinado','paid'=>'Pago','cancelled'=>'Cancelado','scheduled'=>'Agendado'];
        return '<span class="vfos-portal-badge status-'.esc_attr($status).'">'.esc_html($labels[$status]??ucfirst($status)).'</span>';
    }
    private static function nav_url($tab='home',$extra=[]){
        $url=self::portal_page_url();$args=array_merge(['vfos_tab'=>$tab],$extra);return add_query_arg($args,$url);
    }
    private static function project_allowed($project_id,$client_id){
        global $wpdb;return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".VFOS_DB::table('projects')." WHERE id=%d AND client_id=%d",$project_id,$client_id));
    }
    private static function login(){
        $msg=sanitize_text_field(wp_unslash($_GET['vfos_login_msg']??''));
        ob_start();?>
        <div class="vfos-portal-shell vfos-login-shell">
          <div class="vfos-login-visual">
            <img src="<?php echo esc_url(VFOS_URL.'admin/assets/images/visionforge-logo.png'); ?>" alt="VisionForge">
            <span>ÁREA DO CLIENTE</span><h1>Acompanhe tudo sem criar senha.</h1><p>Use o link enviado pela VisionForge ou identifique-se com seu e-mail, CPF ou CNPJ.</p>
          </div>
          <div class="vfos-login-card"><h2>Acessar Área do Cliente</h2><p>Não é necessário criar uma senha.</p>
            <?php if($msg)echo '<div class="vfos-portal-notice">'.esc_html($msg).'</div>'; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="vfos-identifier-login">
              <input type="hidden" name="action" value="vfos_portal_identify">
              <?php wp_nonce_field('vfos_portal_identify'); ?>
              <label>E-mail, CPF ou CNPJ<input name="identifier" autocomplete="email" required placeholder="Digite seu e-mail, CPF ou CNPJ"></label>
              <button type="submit">Continuar sem senha</button>
            </form>
            <p class="vfos-login-help">Se você recebeu um link direto da VisionForge, basta abri-lo — não precisa preencher este campo.</p>
          </div>
        </div><?php return ob_get_clean();
    }
    public static function identify(){
        check_admin_referer('vfos_portal_identify');global $wpdb;
        $identifier=trim(sanitize_text_field(wp_unslash($_POST['identifier']??'')));$normalized=preg_replace('/\D+/','',$identifier);
        if(!$identifier)wp_safe_redirect(add_query_arg('vfos_login_msg','Informe seu e-mail, CPF ou CNPJ.',self::portal_page_url()));
        $table=VFOS_DB::table('clients');$row=null;
        if(is_email($identifier)){
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE status='active' AND portal_access_mode IN ('identifier','both') AND (LOWER(email)=LOWER(%s) OR LOWER(billing_email)=LOWER(%s) OR LOWER(responsible_email)=LOWER(%s)) LIMIT 1",$identifier,$identifier,$identifier));
        }elseif(strlen($normalized)>=11){
            // Formatação de CPF/CNPJ no banco não interfere na comparação.
            $rows=$wpdb->get_results("SELECT * FROM $table WHERE status='active' AND portal_access_mode IN ('identifier','both')");
            foreach($rows as $candidate){
                foreach([$candidate->document,$candidate->responsible_cpf] as $doc){
                    if($doc&&preg_replace('/\D+/','',$doc)===$normalized){$row=$candidate;break 2;}
                }
            }
        }
        if(!$row){wp_safe_redirect(add_query_arg('vfos_login_msg','Não encontramos uma Área do Cliente liberada para esse dado.',self::portal_page_url()));exit;}
        self::set_portal_session($row->id);VFOS_DB::log('portal_passwordless_identify','client',$row->id,'Acesso sem senha por identificação.');
        wp_safe_redirect(self::portal_page_url());exit;
    }
    public static function portal_exit(){
        check_admin_referer('vfos_portal_exit');setcookie(self::cookie_name(),'',time()-3600,COOKIEPATH?:'/',COOKIE_DOMAIN?:'',is_ssl(),true);unset($_COOKIE[self::cookie_name()]);
        wp_safe_redirect(self::portal_page_url());exit;
    }

    public static function shortcode(){
        $cid=self::client_id();if(!$cid)return self::login();
        global $wpdb;
        $client=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('clients')." WHERE id=%d",$cid));
        if(!$client)return '<div class="vfos-portal-shell"><div class="vfos-login-card"><h2>Cliente não encontrado.</h2></div></div>';
        $tab=sanitize_key($_GET['vfos_tab']??'home');
        $allowed=['home','projects','approvals','proposals','contracts','financial','files','messages'];
        if(!in_array($tab,$allowed,true))$tab='home';
        $project_id=absint($_GET['project']??0);
        $projects=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('projects')." WHERE client_id=%d ORDER BY FIELD(status,'in_progress','review','planning','completed','cancelled'),id DESC",$cid));
        $received=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(paid_amount),0) FROM ".VFOS_DB::table('financial')." WHERE client_id=%d AND type='income'",$cid));
        $pending=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(amount-paid_amount,0)),0) FROM ".VFOS_DB::table('financial')." WHERE client_id=%d AND type='income' AND status IN ('pending','partial')",$cid));
        $approval_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('client_approvals')." WHERE client_id=%d AND status='pending'",$cid));
        $project_approval_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('project_approvals')." pa JOIN ".VFOS_DB::table('projects')." p ON p.id=pa.project_id WHERE p.client_id=%d AND pa.status='pending'",$cid));
        $approval_count+=$project_approval_count;
        ob_start();?>
        <div class="vfos-portal-shell">
          <aside class="vfos-portal-sidebar">
            <div class="vfos-portal-brand"><img src="<?php echo esc_url(VFOS_URL.'admin/assets/images/visionforge-logo.png'); ?>" alt="VisionForge"></div>
            <div class="vfos-client-chip"><span><?php echo esc_html(strtoupper(mb_substr($client->name,0,2))); ?></span><div><strong><?php echo esc_html($client->name); ?></strong><small>Cliente VisionForge</small></div></div>
            <nav><?php
              $nav=['home'=>'Visão geral','projects'=>'Projetos','approvals'=>'Aprovações','proposals'=>'Propostas','contracts'=>'Contratos','financial'=>'Financeiro','files'=>'Arquivos','messages'=>'Mensagens'];
              foreach($nav as $k=>$label) echo '<a class="'.($tab===$k?'is-active':'').'" href="'.esc_url(self::nav_url($k)).'"><i></i><span>'.esc_html($label).'</span>'.($k==='approvals'&&$approval_count?'<b>'.$approval_count.'</b>':'').'</a>';
            ?></nav>
            <?php $exit_url=is_user_logged_in()?wp_logout_url(self::portal_page_url()):wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_exit'),'vfos_portal_exit'); ?><a class="vfos-portal-logout" href="<?php echo esc_url($exit_url); ?>">Sair</a>
          </aside>
          <main class="vfos-portal-main">
            <header class="vfos-mobile-head"><img src="<?php echo esc_url(VFOS_URL.'admin/assets/images/visionforge-logo.png'); ?>" alt=""><strong><?php echo esc_html($client->name); ?></strong></header>
            <?php if(!empty($_GET['vfos_portal_msg'])) echo '<div class="vfos-portal-notice">'.esc_html(wp_unslash($_GET['vfos_portal_msg'])).'</div>'; ?>
            <?php
            if($project_id && self::project_allowed($project_id,$cid)) self::render_project($project_id,$cid);
            elseif($tab==='home') self::render_home($client,$projects,$received,$pending,$approval_count);
            elseif($tab==='projects') self::render_projects($projects);
            elseif($tab==='approvals') self::render_approvals($cid);
            elseif($tab==='proposals') self::render_proposals($cid);
            elseif($tab==='contracts') self::render_contracts($cid);
            elseif($tab==='financial') self::render_financial($cid,$received,$pending);
            elseif($tab==='files') self::render_files($cid,$projects);
            elseif($tab==='messages') self::render_messages($cid);
            ?>
          </main>
        </div><?php
        return ob_get_clean();
    }
    private static function page_head($eyebrow,$title,$text=''){
        echo '<div class="vfos-portal-page-head"><div><span>'.esc_html($eyebrow).'</span><h1>'.esc_html($title).'</h1>'.($text?'<p>'.esc_html($text).'</p>':'').'</div></div>';
    }
    private static function render_home($client,$projects,$received,$pending,$approvals){
        self::page_head('VISÃO GERAL','Olá, '.$client->name,'Aqui está o andamento da sua jornada com a VisionForge.');
        echo '<section class="vfos-client-hero"><div><span>SEU ESPAÇO VISIONFORGE</span><h2>Projetos digitais, organizados em um só lugar.</h2><p>Acompanhe tudo sem depender de mensagens espalhadas.</p></div><div class="vfos-client-hero-mark"></div></section>';
        echo '<div class="vfos-portal-kpis"><div><span>Projetos</span><strong>'.count($projects).'</strong><small>total</small></div><div><span>Pago</span><strong>'.esc_html(self::money($received)).'</strong><small>confirmado</small></div><div><span>A pagar</span><strong>'.esc_html(self::money($pending)).'</strong><small>pendente</small></div><div><span>Aprovações</span><strong>'.$approvals.'</strong><small>aguardando você</small></div></div>';
        echo '<section class="vfos-portal-panel"><div class="vfos-section-head"><div><small>PROJETOS</small><h2>Em destaque</h2></div><a href="'.esc_url(self::nav_url('projects')).'">Ver todos →</a></div><div class="vfos-project-showcase">';
        $shown=0;foreach($projects as $p){if($shown>=3)break;$shown++;self::project_card($p);}if(!$shown)echo '<div class="vfos-empty">Nenhum projeto disponível.</div>';echo '</div></section>';
    }
    private static function project_card($p){
        echo '<article class="vfos-project-card"><div class="vfos-project-card-top"><div><small>PROJETO</small><h3>'.esc_html($p->name).'</h3></div>'.self::badge($p->status).'</div><p>'.esc_html(wp_trim_words($p->notes?:'Projeto em acompanhamento pela VisionForge.',20)).'</p><div class="vfos-progress"><i style="width:'.min(100,absint($p->progress)).'%"></i></div><footer><span><strong>'.absint($p->progress).'%</strong> concluído</span><span>'.($p->due_date?'Prazo '.esc_html(date_i18n('d/m/Y',strtotime($p->due_date))):'Sem prazo definido').'</span></footer><a class="vfos-card-link" href="'.esc_url(self::nav_url('projects',['project'=>$p->id])).'">Abrir projeto →</a></article>';
    }
    private static function render_projects($projects){
        self::page_head('PROJETOS','Seus projetos','Acompanhe progresso, etapas, tarefas e entregas.');
        echo '<div class="vfos-project-showcase vfos-project-showcase-all">';if(!$projects)echo '<div class="vfos-empty">Nenhum projeto disponível.</div>';foreach($projects as $p)self::project_card($p);echo '</div>';
    }
    private static function render_project($id,$cid){
        global $wpdb;
        $p=$wpdb->get_row($wpdb->prepare("SELECT p.*,s.name service_name FROM ".VFOS_DB::table('projects')." p LEFT JOIN ".VFOS_DB::table('services')." s ON s.id=p.service_id WHERE p.id=%d AND p.client_id=%d",$id,$cid));
        $stages=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_stages')." WHERE project_id=%d ORDER BY sort_order,id",$id));
        $tasks=$wpdb->get_results($wpdb->prepare("SELECT t.*,ps.title stage_name FROM ".VFOS_DB::table('tasks')." t LEFT JOIN ".VFOS_DB::table('project_stages')." ps ON ps.id=t.stage_id WHERE t.project_id=%d AND t.status<>'cancelled' ORDER BY t.due_date IS NULL,t.due_date,t.id",$id));
        $files=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_files')." WHERE project_id=%d ORDER BY id DESC LIMIT 12",$id));
        $apps=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_approvals')." WHERE project_id=%d ORDER BY id DESC",$id));
        self::page_head('PROJETO','Projeto '.$p->name,$p->service_name?:'Projeto personalizado VisionForge');
        echo '<a class="vfos-back" href="'.esc_url(self::nav_url('projects')).'">← Voltar para projetos</a><section class="vfos-project-detail-hero"><div><span>PROGRESSO GERAL</span><h2>'.absint($p->progress).'% concluído</h2><div class="vfos-progress large"><i style="width:'.absint($p->progress).'%"></i></div></div><div><span>STATUS</span>'.self::badge($p->status).'<small>'.($p->due_date?'Prazo: '.date_i18n('d/m/Y',strtotime($p->due_date)):'Sem prazo definido').'</small></div></section>';
        echo '<section class="vfos-portal-panel"><div class="vfos-section-head"><div><small>ETAPAS</small><h2>Linha de produção</h2></div></div><div class="vfos-client-stages">';
        if(!$stages)echo '<div class="vfos-empty">As etapas deste projeto ainda não foram publicadas.</div>';
        foreach($stages as $s){$cnt=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('tasks')." WHERE stage_id=%d AND status<>'cancelled'",$s->id));$done=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".VFOS_DB::table('tasks')." WHERE stage_id=%d AND status='done'",$s->id));$pct=$cnt?(int)round($done/$cnt*100):($s->status==='done'?100:0);echo '<article><div class="vfos-stage-number">'.((int)$s->sort_order+1).'</div><div><strong>'.esc_html($s->title).'</strong><div class="vfos-progress"><i style="width:'.$pct.'%"></i></div><small>'.$pct.'%'.($s->due_date?' • prazo '.date_i18n('d/m/Y',strtotime($s->due_date)):'').'</small></div></article>';}echo '</div></section>';
        echo '<div class="vfos-portal-columns"><section class="vfos-portal-panel"><div class="vfos-section-head"><div><small>TAREFAS</small><h2>Andamento</h2></div></div><div class="vfos-client-task-list">';if(!$tasks)echo '<div class="vfos-empty">Nenhuma tarefa publicada.</div>';foreach($tasks as $t)echo '<article><span class="vfos-task-state status-'.esc_attr($t->status).'">'.($t->status==='done'?'✓':'').'</span><div><strong>'.esc_html($t->title).'</strong><small>'.esc_html($t->stage_name?:'Projeto').' '.($t->due_date?'• '.date_i18n('d/m/Y',strtotime($t->due_date)):'').'</small></div>'.self::badge($t->status).'</article>';echo '</div></section>';
        $final_client=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('client_approvals')." WHERE project_id=%d AND status='approved' AND release_original=1 AND original_path<>'' ORDER BY decided_at DESC,id DESC",$id));
        $final_project=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_approvals')." WHERE project_id=%d AND status='approved' AND release_original=1 AND original_path<>'' ORDER BY responded_at DESC,id DESC",$id));
        echo '<section class="vfos-portal-panel"><div class="vfos-section-head"><div><small>ARQUIVOS</small><h2>Materiais e entregas finais</h2></div><a href="'.esc_url(self::nav_url('files')).'">Ver todos os arquivos →</a></div>';
        if($final_client||$final_project){echo '<div class="vfos-final-files-inline"><span class="vfos-kicker">ARQUIVOS FINAIS LIBERADOS</span><div class="vfos-final-file-grid">';foreach($final_client as $fa){$u=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_approval_original&table=client_approvals&id='.$fa->id),'vfos_portal_approval_original_client_approvals_'.$fa->id);echo '<a href="'.esc_url($u).'"><span>↓</span><div><strong>'.esc_html($fa->option_label?:$fa->title).'</strong><small>Arquivo final • '.esc_html($p->name).'</small></div></a>';}foreach($final_project as $fa){$u=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_approval_original&table=project_approvals&id='.$fa->id),'vfos_portal_approval_original_project_approvals_'.$fa->id);echo '<a href="'.esc_url($u).'"><span>↓</span><div><strong>'.esc_html($fa->title).'</strong><small>Arquivo final • '.esc_html($p->name).'</small></div></a>';}echo '</div></div>';}
        echo '<div class="vfos-file-grid">';if(!$files)echo '<div class="vfos-empty">Nenhum outro arquivo publicado.</div>';foreach($files as $f)echo '<a target="_blank" href="'.esc_url($f->file_url).'"><span>↗</span><div><strong>'.esc_html($f->title?:'Arquivo do projeto').'</strong><small>'.esc_html($f->mime_type).'</small></div></a>';echo '</div></section></div>';
        echo '<section class="vfos-portal-panel"><div class="vfos-section-head"><div><small>APROVAÇÕES</small><h2>Entregas deste projeto</h2></div></div><div class="vfos-approval-list">';
        if(!$apps)echo '<div class="vfos-empty">Nenhuma entrega aguardando aprovação neste projeto.</div>';
        foreach($apps as $a){echo '<article class="vfos-approval-card vfos-project-approval-card">'.self::approval_media($a,'project_approvals').'<div class="vfos-approval-body"><small>ENTREGA • '.esc_html($p->name).'</small><h3>'.esc_html($a->title).'</h3><p>'.esc_html($a->description).'</p>'.self::badge($a->status).(!empty($a->watermark_enabled)?'<div class="vfos-protected-preview-note">🔒 Esta imagem é uma prévia protegida para aprovação.</div>':'').($a->response_note?'<div class="vfos-client-comment"><strong>Sua resposta</strong><p>'.esc_html($a->response_note).'</p></div>':'').self::final_download($a,'project_approvals');if($a->status==='pending')echo self::project_decision_form($a);echo '</div></article>';}echo '</div></section>';
    }
    private static function project_decision_form($a){
        ob_start();?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="vfos-decision-form"><input type="hidden" name="action" value="vfos_portal_project_decision"><input type="hidden" name="approval_id" value="<?php echo absint($a->id); ?>"><?php wp_nonce_field('vfos_portal_project_decision_'.$a->id); ?><label>Comentário<textarea name="comment" placeholder="Opcional ao aprovar; obrigatório para solicitar alteração"></textarea></label><div><button name="decision" value="approved" class="vfos-approve">Aprovar</button><button name="decision" value="changes_requested" class="vfos-change">Solicitar alteração</button></div></form><?php return ob_get_clean();
    }
    private static function render_approvals($cid){
        global $wpdb;
        self::page_head('APRESENTAÇÕES E APROVAÇÕES','Entregas para sua revisão','Compare opções, escolha sua favorita, aprove entregas ou solicite alterações diretamente por aqui.');
        $general=$wpdb->get_results($wpdb->prepare("SELECT a.*,p.name project_name FROM ".VFOS_DB::table('client_approvals')." a LEFT JOIN ".VFOS_DB::table('projects')." p ON p.id=a.project_id WHERE a.client_id=%d ORDER BY a.requested_at DESC,a.option_order ASC,a.id ASC",$cid));
        $project=$wpdb->get_results($wpdb->prepare("SELECT a.*,p.name project_name FROM ".VFOS_DB::table('project_approvals')." a JOIN ".VFOS_DB::table('projects')." p ON p.id=a.project_id WHERE p.client_id=%d ORDER BY FIELD(a.status,'pending','changes_requested','approved'),a.id DESC",$cid));

        echo '<section class="vfos-approval-intro"><div><span>FLUXO DE APROVAÇÃO</span><h2>Revise antes da entrega final</h2><p>Quando houver mais de uma opção, compare todas na mesma apresentação e escolha a que preferir.</p></div><div class="vfos-approval-intro-steps"><b>1</b><span>Compare</span><b>2</b><span>Escolha ou peça ajuste</span><b>3</b><span>Receba o arquivo final quando liberado</span></div></section>';

        echo '<div class="vfos-approval-list vfos-client-presentation-list">';
        if(!$general&&!$project)echo '<div class="vfos-empty">Nenhuma entrega disponível para aprovação.</div>';

        $groups=[];
        foreach($general as $a){
            $key=$a->approval_group?:('single-'.$a->id);
            if(!isset($groups[$key]))$groups[$key]=[];
            $groups[$key][]=$a;
        }

        foreach($groups as $group=>$options){
            $first=$options[0];$is_multi=count($options)>1;$mode=$first->selection_mode?:'single';
            if($is_multi){
                $approved=array_filter($options,fn($x)=>$x->status==='approved');
                echo '<section class="vfos-choice-presentation"><div class="vfos-choice-head"><div><small>'.esc_html($first->project_name?:'Apresentação VisionForge').' • '.esc_html(date_i18n('d/m/Y',strtotime($first->requested_at))).'</small><h2>'.esc_html($first->title).'</h2><p>'.esc_html($first->description).'</p></div><span class="vfos-choice-mode">'.($mode==='choose_one'?'Escolha uma opção':'Avalie cada opção').'</span></div>';
                if($mode==='choose_one'&&!$approved)echo '<div class="vfos-choice-instruction">Escolha a opção que mais gostou. Ao aprovar uma, as demais serão marcadas como não escolhidas.</div>';
                if($approved){$chosen=reset($approved);echo '<div class="vfos-choice-selected">✓ Opção escolhida: <strong>'.esc_html($chosen->option_label?:('Opção '.($chosen->option_order+1))).'</strong></div>';}
                echo '<div class="vfos-choice-grid">';
                foreach($options as $a){
                    $label=$a->option_label?:('Opção '.($a->option_order+1));
                    echo '<article class="vfos-choice-option status-'.esc_attr($a->status).'"><div class="vfos-choice-option-label"><span>OPÇÃO '.($a->option_order+1).'</span><strong>'.esc_html($label).'</strong>'.self::badge($a->status).'</div>';
                    echo self::approval_media($a,'client_approvals');
                    echo '<div class="vfos-choice-option-body">';
                    if(!empty($a->watermark_enabled))echo '<div class="vfos-protected-preview-note"><strong>🔒 Prévia protegida</strong><span>A marca d’água está incorporada nesta imagem.</span></div>';
                    if(!empty($a->decision_comment))echo '<div class="vfos-client-comment"><strong>Seu comentário</strong><p>'.esc_html($a->decision_comment).'</p></div>';
                    echo self::final_download($a,'client_approvals');
                    if($a->status==='pending')echo self::decision_form($a,$mode==='choose_one');
                    echo '</div></article>';
                }
                echo '</div></section>';
            }else{
                $a=$first;
                echo '<article class="vfos-approval-card is-presentation">'.self::approval_media($a,'client_approvals').'<div class="vfos-approval-body"><small>'.esc_html($a->project_name?:'Entrega VisionForge').' • '.esc_html(date_i18n('d/m/Y',strtotime($a->requested_at))).'</small><h3>'.esc_html($a->title).'</h3><p>'.esc_html($a->description).'</p>'.self::badge($a->status);
                if(!empty($a->watermark_enabled))echo '<div class="vfos-protected-preview-note"><strong>🔒 Prévia protegida</strong><span>A marca d’água está incorporada na imagem apresentada.</span></div>';
                if(!empty($a->decision_comment))echo '<div class="vfos-client-comment"><strong>Seu comentário</strong><p>'.esc_html($a->decision_comment).'</p></div>';
                echo self::final_download($a,'client_approvals');
                if($a->status==='pending')echo self::decision_form($a,false);
                echo '</div></article>';
            }
        }

        foreach($project as $a){
            echo '<article class="vfos-approval-card is-presentation">'.self::approval_media($a,'project_approvals').'<div class="vfos-approval-body"><small>'.esc_html($a->project_name?:'Entrega VisionForge').' • '.esc_html(date_i18n('d/m/Y',strtotime($a->requested_at))).'</small><h3>'.esc_html($a->title).'</h3><p>'.esc_html($a->description).'</p>'.self::badge($a->status);
            if(!empty($a->watermark_enabled))echo '<div class="vfos-protected-preview-note"><strong>🔒 Prévia protegida</strong><span>A marca d’água está incorporada na imagem apresentada.</span></div>';
            if(!empty($a->response_note))echo '<div class="vfos-client-comment"><strong>Seu comentário</strong><p>'.esc_html($a->response_note).'</p></div>';
            echo self::final_download($a,'project_approvals');
            if($a->status==='pending')echo self::project_decision_form($a);
            echo '</div></article>';
        }
        echo '</div>';
    }

    private static function approval_media($a,$table){
        $url=$a->preview_url?:$a->file_url;if(!$url)return '<div class="vfos-approval-media"><span>Entrega VisionForge</span></div>';
        $mime=$a->mime_type??'';
        if(!$mime && !empty($a->attachment_id))$mime=(string)get_post_mime_type($a->attachment_id);
        if(strpos((string)$mime,'image/')===0 || preg_match('/\.(jpe?g|png|webp|gif)(\?.*)?$/i',$url)){
            return '<div class="vfos-approval-media is-protected"><img src="'.esc_url($url).'" alt="'.esc_attr($a->title).'"><div class="vfos-preview-shield"><span>PRÉVIA PARA APROVAÇÃO</span></div></div>';
        }
        return '<div class="vfos-approval-media is-file"><a class="vfos-file-link" target="_blank" rel="noopener" href="'.esc_url($url).'">Abrir arquivo para revisão</a></div>';
    }

    private static function final_download($a,$table){
        if($a->status!=='approved'||empty($a->original_path))return '';
        if(empty($a->release_original))return '<div class="vfos-final-delivery is-locked"><strong>✓ Aprovação concluída</strong><span>O arquivo final ainda não foi liberado para download pela VisionForge.</span></div>';
        $url=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_approval_original&table='.$table.'&id='.$a->id),'vfos_portal_approval_original_'.$table.'_'.$a->id);
        return '<div class="vfos-final-delivery"><strong>✓ Arquivo final disponível</strong><span>Seu arquivo original sem marca d’água foi liberado pela VisionForge.</span><a href="'.esc_url($url).'">Baixar arquivo final</a></div>';
    }

    private static function decision_form($a,$choose=false){ob_start();?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="vfos-decision-form"><input type="hidden" name="action" value="vfos_portal_decision"><input type="hidden" name="approval_id" value="<?php echo absint($a->id); ?>"><?php wp_nonce_field('vfos_portal_decision_'.$a->id); ?><label>Comentário<textarea name="comment" placeholder="<?php echo esc_attr($choose?'Opcional ao escolher; use para explicar sua preferência.':'Opcional ao aprovar; obrigatório se solicitar alteração'); ?>"></textarea></label><div><button name="decision" value="approved" class="vfos-approve"><?php echo $choose?'Escolher esta opção':'Aprovar'; ?></button><button name="decision" value="changes_requested" class="vfos-change">Solicitar alteração</button></div></form><?php return ob_get_clean();}
    private static function render_proposals($cid){
        global $wpdb;self::page_head('PROPOSTAS','Propostas comerciais','Consulte valores, validade e situação das propostas.');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quotes')." WHERE client_id=%d ORDER BY id DESC",$cid));
        echo '<section class="vfos-portal-panel"><div class="vfos-document-list">';if(!$rows)echo '<div class="vfos-empty">Nenhuma proposta disponível.</div>';foreach($rows as $q){echo '<article><div><small>'.esc_html($q->number).'</small><strong>'.esc_html($q->title).'</strong><span>'.($q->valid_until?'Validade '.date_i18n('d/m/Y',strtotime($q->valid_until)):'Sem validade definida').'</span></div><div><strong>'.esc_html(self::money($q->total)).'</strong>'.self::badge($q->status).'</div>'.($q->public_token?'<a class="vfos-primary-link" target="_blank" href="'.esc_url(VFOS_Proposal::url($q)).'">Abrir proposta</a>':'').'</article>';}echo '</div></section>';
    }
    private static function render_contracts($cid){
        global $wpdb;self::page_head('CONTRATOS','Documentos e assinaturas','Acompanhe contratos e acesse o VisionForge Sign.');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('contracts')." WHERE client_id=%d ORDER BY id DESC",$cid));
        echo '<section class="vfos-portal-panel"><div class="vfos-document-list">';if(!$rows)echo '<div class="vfos-empty">Nenhum contrato disponível.</div>';foreach($rows as $c)echo '<article><div><small>'.esc_html($c->number).'</small><strong>'.esc_html($c->title).'</strong><span>'.esc_html(self::money($c->value)).'</span></div><div>'.self::badge($c->status).($c->sign_public_code?'<small>'.esc_html($c->sign_public_code).'</small>':'').'</div>'.($c->status==='signed'&&$c->sign_signed_url?'<a class="vfos-primary-link" target="_blank" href="'.esc_url($c->sign_signed_url).'">Baixar contrato assinado</a>':($c->sign_url?'<a class="vfos-primary-link" target="_blank" href="'.esc_url($c->sign_url).'">Assinar no VisionForge Sign</a>':'')).'</article>';echo '</div></section>';
    }
    private static function render_financial($cid,$received,$pending){
        global $wpdb;self::page_head('FINANCEIRO','Pagamentos e cobranças','Acompanhe valores contratados, pagamentos realizados, saldo pendente e cobranças disponíveis.');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('financial')." WHERE client_id=%d AND type='income' ORDER BY due_date IS NULL,due_date DESC,id DESC",$cid));
        echo '<div class="vfos-portal-kpis"><div><span>Total pago</span><strong>'.esc_html(self::money($received)).'</strong></div><div><span>A pagar</span><strong>'.esc_html(self::money($pending)).'</strong></div></div>';
        echo '<section class="vfos-portal-panel"><div class="vfos-section-head"><div><small>COBRANÇAS</small><h2>Histórico financeiro</h2></div></div><div class="vfos-payment-list">';
        if(!$rows)echo '<div class="vfos-empty">Nenhuma cobrança disponível.</div>';
        foreach($rows as $f){
            $balance=max(0,(float)$f->amount-(float)$f->paid_amount);$charge=null;
            if(class_exists('VFOS_MercadoPago')&&$balance>0){
                $charge=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_MercadoPago::table()." WHERE financial_id=%d AND status NOT IN ('cancelled','rejected') ORDER BY (status='approved') ASC,id DESC LIMIT 1",$f->id));
                if($charge&&$charge->status==='approved')$charge=null;
            }
            echo '<article class="vfos-client-financial-row"><div><strong>'.esc_html($f->description).'</strong><small>'.($f->due_date?'Vencimento '.date_i18n('d/m/Y',strtotime($f->due_date)):'Sem vencimento').'</small></div><div class="vfos-client-financial-values"><span>Contratado <b>'.esc_html(self::money($f->amount)).'</b></span><span>Pago <b>'.esc_html(self::money($f->paid_amount)).'</b></span><span>Saldo <b>'.esc_html(self::money($balance)).'</b></span></div>'.self::badge($f->status);
            if($charge&&!empty($charge->public_token)){
                echo '<a class="vfos-portal-pay-button" href="'.esc_url(VFOS_MercadoPago::payment_url($charge->public_token)).'" target="_blank" rel="noopener">Pagar agora</a>';
            }
            echo '</article>';
        }
        echo '</div></section>';
    }
    private static function render_files($cid,$projects){
        global $wpdb;self::page_head('ARQUIVOS','Seus arquivos e entregas finais','Baixe arquivos já liberados pela VisionForge e consulte os materiais compartilhados do seu projeto.');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT f.*,p.name project_name FROM ".VFOS_DB::table('client_files')." f LEFT JOIN ".VFOS_DB::table('projects')." p ON p.id=f.project_id WHERE f.client_id=%d ORDER BY f.id DESC",$cid));
        $final_general=$wpdb->get_results($wpdb->prepare("SELECT a.*,p.name project_name FROM ".VFOS_DB::table('client_approvals')." a LEFT JOIN ".VFOS_DB::table('projects')." p ON p.id=a.project_id WHERE a.client_id=%d AND a.status='approved' AND a.release_original=1 AND a.original_path<>'' ORDER BY a.decided_at DESC,a.id DESC",$cid));
        $final_project=$wpdb->get_results($wpdb->prepare("SELECT a.*,p.name project_name FROM ".VFOS_DB::table('project_approvals')." a JOIN ".VFOS_DB::table('projects')." p ON p.id=a.project_id WHERE p.client_id=%d AND a.status='approved' AND a.release_original=1 AND a.original_path<>'' ORDER BY a.responded_at DESC,a.id DESC",$cid));

        echo '<section class="vfos-portal-panel vfos-final-files-panel"><div class="vfos-section-head"><div><small>ENTREGAS FINAIS</small><h2>Arquivos liberados para download</h2><p>Aqui ficam reunidos os arquivos finais aprovados que a VisionForge já liberou para você.</p></div><span class="vfos-final-files-count">'.(count($final_general)+count($final_project)).' arquivo(s)</span></div><div class="vfos-final-file-grid">';
        if(!$final_general&&!$final_project)echo '<div class="vfos-empty">Nenhum arquivo final foi liberado ainda.</div>';
        foreach($final_general as $a){$url=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_approval_original&table=client_approvals&id='.$a->id),'vfos_portal_approval_original_client_approvals_'.$a->id);echo '<a class="vfos-final-file-card" href="'.esc_url($url).'"><span class="vfos-final-file-icon">↓</span><div><small>ARQUIVO FINAL</small><strong>'.esc_html($a->option_label?:$a->title).'</strong><em>'.esc_html($a->project_name?:'Entrega VisionForge').' • '.esc_html($a->original_name?:'Arquivo original').'</em></div><b>Baixar</b></a>';}
        foreach($final_project as $a){$url=wp_nonce_url(admin_url('admin-post.php?action=vfos_portal_approval_original&table=project_approvals&id='.$a->id),'vfos_portal_approval_original_project_approvals_'.$a->id);echo '<a class="vfos-final-file-card" href="'.esc_url($url).'"><span class="vfos-final-file-icon">↓</span><div><small>ARQUIVO FINAL</small><strong>'.esc_html($a->title).'</strong><em>'.esc_html($a->project_name).' • '.esc_html($a->original_name?:'Arquivo original').'</em></div><b>Baixar</b></a>';}
        echo '</div></section>';

        echo '<section class="vfos-portal-panel"><div class="vfos-section-head"><div><small>OUTROS ARQUIVOS</small><h2>Materiais compartilhados</h2></div></div><div class="vfos-file-grid">';if(!$rows)echo '<div class="vfos-empty">Nenhum outro arquivo disponível.</div>';foreach($rows as $f)echo '<a target="_blank" href="'.esc_url($f->file_url).'"><span>↗</span><div><strong>'.esc_html($f->title?:'Arquivo').'</strong><small>'.esc_html(($f->project_name?$f->project_name.' • ':'').($f->source==='client'?'Enviado por você':'VisionForge')).'</small></div></a>';echo '</div></section>';

        echo '<section class="vfos-portal-panel"><div class="vfos-section-head"><div><small>ENVIAR</small><h2>Compartilhar arquivo com a VisionForge</h2></div></div><form class="vfos-upload-form" method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_portal_upload">';wp_nonce_field('vfos_portal_upload');echo '<label>Projeto<select name="project_id"><option value="0">Geral</option>';foreach($projects as $p)echo '<option value="'.$p->id.'">'.esc_html($p->name).'</option>';echo '</select></label><label>Nome do arquivo<input name="title" placeholder="Ex.: Textos do site"></label><label>Arquivo<input type="file" name="client_file" required></label><button class="vfos-portal-button">Enviar arquivo</button></form></section>';
    }
    private static function render_messages($cid){
        global $wpdb;self::page_head('MENSAGENS','Fale com a VisionForge','Mantenha as conversas importantes vinculadas ao seu atendimento.');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('portal_messages')." WHERE client_id=%d ORDER BY id DESC LIMIT 50",$cid));
        echo '<section class="vfos-portal-panel"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="vfos-message-form"><input type="hidden" name="action" value="vfos_portal_message">';wp_nonce_field('vfos_portal_message');echo '<textarea name="message" required placeholder="Escreva sua mensagem..."></textarea><button class="vfos-portal-button">Enviar mensagem</button></form><div class="vfos-message-list">';if(!$rows)echo '<div class="vfos-empty">Nenhuma mensagem ainda.</div>';foreach($rows as $m)echo '<div class="'.esc_attr($m->direction).'"><small>'.($m->direction==='client'?'Você':'VisionForge').' • '.date_i18n('d/m/Y H:i',strtotime($m->created_at)).'</small><p>'.esc_html($m->message).'</p></div>';echo '</div></section>';
    }
    public static function decision(){
        global $wpdb;$id=absint($_POST['approval_id']??0);check_admin_referer('vfos_portal_decision_'.$id);$cid=self::client_id();if(!$cid)wp_die('Sessão da Área do Cliente inválida ou expirada.');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('client_approvals')." WHERE id=%d AND client_id=%d",$id,$cid));if(!$row)wp_die('Aprovação não encontrada.');
        $decision=sanitize_key($_POST['decision']??'');$comment=sanitize_textarea_field($_POST['comment']??'');if(!in_array($decision,['approved','changes_requested'],true))wp_die('Decisão inválida.');if($decision==='changes_requested'&&!$comment)wp_die('Informe o que precisa ser alterado.');
        $table=VFOS_DB::table('client_approvals');
        $wpdb->update($table,['status'=>$decision,'decision_comment'=>$comment,'decided_by'=>get_current_user_id(),'decided_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],['id'=>$id]);
        if($decision==='approved'&&!empty($row->approval_group)&&$row->selection_mode==='choose_one'){
            $wpdb->query($wpdb->prepare("UPDATE $table SET status='not_selected',decision_comment='',decided_by=%d,decided_at=%s,updated_at=%s WHERE client_id=%d AND approval_group=%s AND id<>%d AND status='pending'",get_current_user_id(),current_time('mysql'),current_time('mysql'),$cid,$row->approval_group,$id));
        }
        VFOS_DB::log('portal_'.$decision,'approval',$id,'client='.$cid.(!empty($row->approval_group)?' | group='.$row->approval_group:''));self::notify_staff($decision==='approved'?($row->selection_mode==='choose_one'?'Cliente escolheu uma opção':'Entrega aprovada pelo cliente'):'Cliente solicitou alteração',($row->option_label?$row->option_label.' • ':'').$row->title,$row->project_id);
        if($decision==='changes_requested'&&$row->project_id)self::create_change_task($row->project_id,$cid,$row->title,$comment);
        wp_safe_redirect(add_query_arg('vfos_portal_msg',rawurlencode($decision==='approved'?'Entrega aprovada com sucesso.':'Solicitação de alteração enviada.'),self::nav_url('approvals')));exit;
    }
    public static function project_decision(){
        global $wpdb;$id=absint($_POST['approval_id']??0);check_admin_referer('vfos_portal_project_decision_'.$id);$cid=self::client_id();if(!$cid)wp_die('Sessão da Área do Cliente inválida ou expirada.');
        $row=$wpdb->get_row($wpdb->prepare("SELECT pa.* FROM ".VFOS_DB::table('project_approvals')." pa JOIN ".VFOS_DB::table('projects')." p ON p.id=pa.project_id WHERE pa.id=%d AND p.client_id=%d",$id,$cid));if(!$row)wp_die('Aprovação não encontrada.');
        $decision=sanitize_key($_POST['decision']??'');$comment=sanitize_textarea_field($_POST['comment']??'');if(!in_array($decision,['approved','changes_requested'],true))wp_die('Decisão inválida.');if($decision==='changes_requested'&&!$comment)wp_die('Informe o que precisa ser alterado.');
        $wpdb->update(VFOS_DB::table('project_approvals'),['status'=>$decision,'responded_at'=>current_time('mysql'),'response_note'=>$comment],['id'=>$id]);
        self::notify_staff($decision==='approved'?'Entrega do projeto aprovada':'Alteração solicitada no projeto',$row->title,$row->project_id);if($decision==='changes_requested')self::create_change_task($row->project_id,$cid,$row->title,$comment);
        wp_safe_redirect(add_query_arg(['vfos_portal_msg'=>rawurlencode($decision==='approved'?'Entrega aprovada com sucesso.':'Alteração solicitada.'),'project'=>$row->project_id],self::nav_url('projects')));exit;
    }
    private static function create_change_task($project,$cid,$title,$comment){
        global $wpdb;$assignee=(int)$wpdb->get_var($wpdb->prepare("SELECT assigned_user_id FROM ".VFOS_DB::table('tasks')." WHERE project_id=%d AND assigned_user_id>0 ORDER BY id DESC LIMIT 1",$project));
        $wpdb->insert(VFOS_DB::table('tasks'),['project_id'=>$project,'client_id'=>$cid,'title'=>'Ajuste solicitado: '.$title,'description'=>$comment,'status'=>'pending','priority'=>'high','assigned_user_id'=>$assignee,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);$tid=$wpdb->insert_id;
        if($assignee)VFOS_Notifications::notify($assignee,'approval','Cliente solicitou alteração',$title,'tasks','task',$tid,admin_url('admin.php?page=vfos-tasks&tab=new&edit='.$tid));
    }
    private static function notify_staff($title,$message,$project_id=0){
        $users=get_users(['role__in'=>['administrator','vfos_team_member'],'fields'=>'ids']);foreach($users as $uid){if(user_can($uid,'manage_options')||VFOS_Team::can('projects',$uid))VFOS_Notifications::notify($uid,'approval',$title,$message,'projects','project',$project_id,$project_id?admin_url('admin.php?page=vfos-project-view&id='.$project_id.'&tab=approvals'):admin_url('admin.php?page=vfos-portal'));}
    }
    public static function message(){
        check_admin_referer('vfos_portal_message');global $wpdb;$cid=self::client_id();if(!$cid)wp_die('Sessão da Área do Cliente inválida ou expirada.');$msg=sanitize_textarea_field($_POST['message']??'');if($cid&&$msg){$wpdb->insert(VFOS_DB::table('portal_messages'),['client_id'=>$cid,'user_id'=>get_current_user_id(),'direction'=>'client','message'=>$msg,'created_at'=>current_time('mysql')]);self::notify_staff('Nova mensagem de cliente',wp_trim_words($msg,18),0);VFOS_DB::log('portal_message','client',$cid,$msg);}wp_safe_redirect(add_query_arg('vfos_portal_msg',rawurlencode('Mensagem enviada.'),self::nav_url('messages')));exit;
    }
    public static function upload(){
        check_admin_referer('vfos_portal_upload');global $wpdb;$cid=self::client_id();if(!$cid)wp_die('Sessão da Área do Cliente inválida ou expirada.');$project=absint($_POST['project_id']??0);if($project&&!self::project_allowed($project,$cid))wp_die('Projeto inválido.');
        if(empty($_FILES['client_file']['name']))wp_die('Selecione um arquivo.');
        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';$aid=media_handle_upload('client_file',0);if(is_wp_error($aid))wp_die(esc_html($aid->get_error_message()));
        $url=wp_get_attachment_url($aid);$title=sanitize_text_field($_POST['title']??'')?:get_the_title($aid);
        $wpdb->insert(VFOS_DB::table('client_files'),['client_id'=>$cid,'project_id'=>$project,'attachment_id'=>$aid,'title'=>$title,'file_url'=>$url,'mime_type'=>get_post_mime_type($aid),'source'=>'client','uploaded_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        self::notify_staff('Cliente enviou um arquivo',$title,$project);VFOS_DB::log('portal_upload','client',$cid,$title);
        wp_safe_redirect(add_query_arg('vfos_portal_msg',rawurlencode('Arquivo enviado com sucesso.'),self::nav_url('files')));exit;
    }
}
