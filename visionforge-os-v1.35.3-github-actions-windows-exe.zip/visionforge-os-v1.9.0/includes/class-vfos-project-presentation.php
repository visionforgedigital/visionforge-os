<?php
if (!defined('ABSPATH')) exit;

class VFOS_Project_Presentation {
    private static function esc($s){
        $s=html_entity_decode(wp_strip_all_tags((string)$s),ENT_QUOTES|ENT_HTML5,'UTF-8');
        $s=str_replace(["\r","\n"],[' ',' '],$s);
        $s=@iconv('UTF-8','Windows-1252//TRANSLIT',$s)?:$s;
        return str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$s);
    }
    private static function text_width($text,$size,$bold=false){
        // Practical Helvetica metric good enough for presentation blocks.
        $factor=$bold?.56:.50;return strlen(@iconv('UTF-8','ASCII//TRANSLIT',(string)$text)?:$text)*$size*$factor;
    }
    private static function wrap($text,$size,$max,$bold=false){
        $text=trim(preg_replace('/\s+/u',' ',wp_strip_all_tags((string)$text)));if($text==='')return [];
        $words=preg_split('/\s+/u',$text);$lines=[];$line='';
        foreach($words as $w){$try=$line===''?$w:$line.' '.$w;if(self::text_width($try,$size,$bold)>$max&&$line!==''){$lines[]=$line;$line=$w;}else$line=$try;}
        if($line!=='')$lines[]=$line;return $lines;
    }
    private static function rgb($hex){
        $hex=ltrim($hex,'#');return [hexdec(substr($hex,0,2))/255,hexdec(substr($hex,2,2))/255,hexdec(substr($hex,4,2))/255];
    }
    private static function color($hex,$stroke=false){
        [$r,$g,$b]=self::rgb($hex);return round($r,3).' '.round($g,3).' '.round($b,3).' '.($stroke?'RG':'rg')."\n";
    }
    private static function text(&$s,$x,$y,$text,$size=12,$bold=false,$color='#17364d'){
        $font=$bold?'F2':'F1';$s.=self::color($color)."BT /$font ".round($size,1)." Tf ".round($x,1).' '.round($y,1)." Td (".self::esc($text).") Tj ET\n";
    }
    private static function paragraph(&$s,$x,&$y,$text,$size=11,$max=455,$leading=16,$bold=false,$color='#435b68',$max_lines=30){
        $paras=preg_split('/\n\s*\n/u',trim(wp_strip_all_tags(str_replace(['<br>','<br/>','<br />'],"\n",$text))));
        foreach($paras as $para){
            $lines=self::wrap($para,$size,$max,$bold);$c=0;
            foreach($lines as $line){if(++$c>$max_lines)break;self::text($s,$x,$y,$line,$size,$bold,$color);$y-=$leading;}
            $y-=7;
        }
    }
    private static function base_page($bgObj=7){
        return "q\n595 0 0 842 0 0 cm\n/BG Do\nQ\n";
    }
    private static function section_head(&$s,$eyebrow,$title,$subtitle=''){
        self::text($s,55,738,strtoupper($eyebrow),9,true,'#0798df');
        self::text($s,55,708,$title,23,true,'#17364d');
        $s.=self::color('#ff9800',true)."1.7 w 55 691 m 225 691 l S\n";
        if($subtitle)self::text($s,55,670,$subtitle,10,false,'#647985');
    }
    private static function bullet_page($eyebrow,$title,$items,$intro=''){
        $s=self::base_page();self::section_head($s,$eyebrow,$title,$intro);$y=630;$n=0;
        foreach($items as $item){$item=trim($item);if(!$item)continue;$n++;$lines=self::wrap($item,11,415,false);$h=max(48,22+count($lines)*15);if($y-$h<100)break;
            $s.="q ".self::color($n%2?'#eef8fd':'#fff6e9')."55 ".round($y-$h+10,1)." 485 ".round($h-8,1)." re f Q\n";
            $s.=self::color($n%2?'#0798df':'#ff9800')."70 ".round($y-16,1)." 9 9 re f\n";
            $ty=$y-11;foreach($lines as $line){self::text($s,92,$ty,$line,11,false,'#334e5d');$ty-=15;}$y-=$h+9;
        }return $s;
    }
    private static function content_page($eyebrow,$title,$content,$highlight=''){
        $s=self::base_page();self::section_head($s,$eyebrow,$title);$y=635;if($highlight){$s.="q ".self::color('#eef8fd')."55 580 485 70 re f Q\n";self::text($s,75,620,$highlight,13,true,'#17364d');$y=545;}self::paragraph($s,55,$y,$content,11,480,17,false,'#405965',34);return $s;
    }
    private static function cover($title,$subtitle,$client){
        $s=self::base_page();
        self::text($s,60,720,'VISIONFORGE DIGITAL',11,true,'#0798df');
        self::text($s,60,525,'APRESENTAÇÃO DO PROJETO',10,true,'#5d7380');
        $lines=self::wrap($title,31,450,true);$y=480;$i=0;foreach($lines as $line){self::text($s,60,$y,$line,31,true,$i++?'#ff9800':'#17364d');$y-=39;}
        $s.=self::color('#ff9800',true)."2 w 60 ".round($y-5,1)." m 260 ".round($y-5,1)." l S\n";
        if($subtitle){$y-=35;foreach(self::wrap($subtitle,13,430,false) as $line){self::text($s,60,$y,$line,13,false,'#536c79');$y-=19;}}
        self::text($s,60,150,'CLIENTE: '.strtoupper($client),11,true,'#17364d');
        return $s;
    }
    private static function investment_page($row,$project){
        $s=self::base_page();self::section_head($s,'INVESTIMENTO',$row->investment_title?:'Investimento do projeto');
        $y=635;self::paragraph($s,55,$y,$row->investment_content,11,480,17,false,'#405965',18);
        $s.="q ".self::color('#eaf6fc')."55 290 485 150 re f Q\n";
        self::text($s,80,395,'INVESTIMENTO DO PROJETO',10,true,'#536c79');
        self::text($s,80,340,'R$ '.number_format((float)$row->investment_value,2,',','.'),31,true,'#0798df');
        self::text($s,80,315,'Valor do projeto apresentado pela VisionForge Digital',10,false,'#6b7f8b');
        return $s;
    }
    private static function closing_page($row,$project){
        $s=self::base_page();$title=$row->closing_title?:'Rumo ao Sucesso Digital!';
        self::text($s,80,545,$title,29,true,'#17364d');$y=495;self::paragraph($s,80,$y,$row->closing_content,12,430,18,false,'#516875',20);
        self::text($s,80,190,'VISIONFORGE DIGITAL',15,true,'#0798df');self::text($s,80,166,'Transformando ideias em experiências digitais.',10,false,'#667d89');
        return $s;
    }
    public static function generate($project_id){
        global $wpdb;$project_id=absint($project_id);
        $project=$wpdb->get_row($wpdb->prepare("SELECT p.*,c.name client_name,c.company client_company FROM ".VFOS_DB::table('projects')." p LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=p.client_id WHERE p.id=%d",$project_id));
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('project_presentations')." WHERE project_id=%d",$project_id));
        if(!$project||!$row)return new WP_Error('presentation_missing','Apresentação do projeto não encontrada.');
        $pages=[];$pages[]=self::cover($row->title?:$project->name,$row->subtitle,$project->client_company?:$project->client_name);
        if($row->show_why)$pages[]=self::content_page('ESTRATÉGIA',$row->why_title?:'Por que investir neste projeto?',$row->why_content);
        if($row->show_vision)$pages[]=self::content_page('NOSSA VISÃO',$row->vision_title?:'O que imaginamos para '.$project->client_name,$row->vision_content);
        if($row->show_included)$pages[]=self::bullet_page('ESCOPO',$row->included_title?:'O que está incluso',preg_split('/\r\n|\r|\n/',$row->included_items?:''),'Tudo que faz parte desta entrega.');
        if($row->show_investment)$pages[]=self::investment_page($row,$project);
        if($row->show_differentials)$pages[]=self::bullet_page('DIFERENCIAIS',$row->differentials_title?:'Diferenciais e benefícios',preg_split('/\r\n|\r|\n/',$row->differentials?:''),'O cuidado VisionForge além da entrega.');
        if($row->show_payment)$pages[]=self::content_page('CONDIÇÕES',$row->payment_title?:'Formas de pagamento e como trabalhamos',$row->payment_content,'Organização, transparência e segurança durante todo o projeto.');
        if($row->show_closing)$pages[]=self::closing_page($row,$project);

        $bg=VFOS_DIR.'admin/assets/images/visionforge-presentation-bg.jpg';if(!is_file($bg))return new WP_Error('presentation_bg','Fundo da apresentação não encontrado.');
        $jpg=file_get_contents($bg);$info=getimagesize($bg);if(!$jpg||!$info)return new WP_Error('presentation_bg_invalid','Fundo da apresentação inválido.');
        $objects=[];$objects[1]='<< /Type /Catalog /Pages 2 0 R >>';$objects[3]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';$objects[4]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $objects[7]='<< /Type /XObject /Subtype /Image /Width '.(int)$info[0].' /Height '.(int)$info[1].' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '.strlen($jpg)." >>\nstream\n".$jpg."\nendstream";
        $kids=[];$obj=8;foreach($pages as $stream){$pageObj=$obj++;$contentObj=$obj++;$kids[]=$pageObj.' 0 R';$objects[$contentObj]='<< /Length '.strlen($stream)." >>\nstream\n".$stream."endstream";$objects[$pageObj]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << /BG 7 0 R >> >> /Contents '.$contentObj.' 0 R >>';}
        $objects[2]='<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.count($kids).' >>';ksort($objects);
        $pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offsets=[0=>0];foreach($objects as $n=>$body){$offsets[$n]=strlen($pdf);$pdf.=$n." 0 obj\n".$body."\nendobj\n";}$xref=strlen($pdf);$max=max(array_keys($objects));$pdf.="xref\n0 ".($max+1)."\n0000000000 65535 f \n";for($i=1;$i<=$max;$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i]??0)."\n";$pdf.='trailer << /Size '.($max+1).' /Root 1 0 R >>'."\nstartxref\n".$xref."\n%%EOF\n";
        $u=wp_upload_dir();$dir=trailingslashit($u['basedir']).'vfos-project-presentations';if(!is_dir($dir))wp_mkdir_p($dir);$path=$dir.'/projeto-'.sanitize_file_name($project->name).'-'.time().'.pdf';if(file_put_contents($path,$pdf)===false)return new WP_Error('write','Não foi possível gerar o PDF da apresentação.');
        $wpdb->update(VFOS_DB::table('project_presentations'),['pdf_path'=>$path,'updated_at'=>current_time('mysql')],['project_id'=>$project_id]);return $path;
    }
}
