<?php
if (!defined('ABSPATH')) exit;

class VFOS_Proposal {
    public static function init(){
        add_action('template_redirect',[__CLASS__,'maybe_render']);
        add_action('admin_post_vfos_proposal_decision',[__CLASS__,'decision']);
        add_action('admin_post_nopriv_vfos_proposal_decision',[__CLASS__,'decision']);
        add_action('admin_post_vfos_proposal_feedback',[__CLASS__,'feedback']);
        add_action('admin_post_nopriv_vfos_proposal_feedback',[__CLASS__,'feedback']);
    }

    public static function url($quote){
        $token=is_object($quote)?$quote->public_token:($quote['public_token']??'');
        return add_query_arg('vfos_proposal',rawurlencode($token),home_url('/'));
    }

    private static function quote_by_token($token){
        global $wpdb;
        $token=sanitize_text_field($token);
        if(!$token) return null;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT q.*,COALESCE(NULLIF(c.trade_name,''),NULLIF(c.legal_name,''),c.name) client_name,c.legal_name client_company,c.email client_email,c.phone client_phone
             FROM ".VFOS_DB::table('quotes')." q
             LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=q.client_id
             WHERE q.public_token=%s",$token
        ));
    }

    public static function maybe_render(){
        if(empty($_GET['vfos_proposal'])) return;
        $q=self::quote_by_token(wp_unslash($_GET['vfos_proposal']));
        status_header($q?200:404);
        nocache_headers();
        if(!$q){
            self::page_start('Proposta não encontrada');
            echo '<main class="vf-public"><div class="vf-proposal"><h1>Proposta não encontrada</h1><p>Este link não é válido ou a proposta não está mais disponível.</p></div></main>';
            self::page_end(); exit;
        }
        self::render($q); exit;
    }

    private static function company_info(){
        $d=get_option('vfos_company_info',[]);
        if(!is_array($d))$d=[];
        return wp_parse_args($d,[
            'name'=>'VisionForge Digital','legal_name'=>'','document_type'=>'cnpj','document'=>'',
            'description'=>'Soluções digitais desenvolvidas com estratégia, inovação e foco em resultados.',
            'slogan'=>'Transformando ideias em experiências digitais.','website'=>'','email'=>'','phone'=>'','whatsapp'=>'',
            'zip'=>'','address'=>'','city'=>'','state'=>'','socials'=>[],'responsibles'=>[],
            'show_document'=>1,'show_address'=>1,'show_responsibles'=>1,'show_socials'=>1
        ]);
    }
    private static function social_label($key){
        return ['instagram'=>'Instagram','facebook'=>'Facebook','linkedin'=>'LinkedIn','youtube'=>'YouTube','tiktok'=>'TikTok','x'=>'X / Twitter'][$key]??ucfirst((string)$key);
    }

    private static function page_start($title){
        echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<title>'.esc_html($title).' • '.esc_html(self::company_info()['name']).'</title>';
        echo '<style>
        :root{--blue:#0798df;--blue2:#087bc7;--orange:#ff9800;--ink:#16384f;--muted:#6f818c;--line:#e3edf1;--soft:#f5fafc}
        *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:var(--ink);background:#eaf1f5}
        .vf-public{padding:28px 14px}.vf-proposal{max-width:1040px;margin:auto;display:grid;gap:18px}.vf-page{position:relative;background:#fff;border-radius:28px;overflow:hidden;box-shadow:0 18px 60px rgba(24,58,80,.11);border:1px solid #e3ebef}
        .vf-cover{min-height:650px;padding:44px 50px;background:linear-gradient(135deg,#fff 0%,#fff 54%,#fff7eb 100%);display:flex;flex-direction:column;justify-content:space-between}
        .vf-cover:before{content:"";position:absolute;left:-130px;bottom:-170px;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(7,152,223,.25),rgba(7,152,223,0) 68%)}
        .vf-cover:after{content:"";position:absolute;right:-130px;top:-160px;width:520px;height:520px;border-radius:50%;background:radial-gradient(circle,rgba(255,152,0,.19),rgba(255,152,0,0) 68%)}
        .vf-cover>*{position:relative;z-index:1}.vf-logo{width:310px;max-width:70%;height:auto}.vf-cover-top{display:flex;justify-content:space-between;align-items:flex-start;gap:20px}.vf-number{text-align:right}.vf-number span,.vf-eyebrow{display:block;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:#748792;font-weight:800}.vf-number strong{display:block;margin-top:4px;font-size:17px}.vf-cover-main{max-width:780px;margin:55px 0}.vf-cover-main h1{font-size:48px;line-height:1.04;margin:9px 0 14px;letter-spacing:-.035em}.vf-cover-main p{font-size:17px;line-height:1.6;color:#607682;max-width:700px}.vf-gradient-text{background:linear-gradient(90deg,var(--blue),var(--orange));-webkit-background-clip:text;background-clip:text;color:transparent}.vf-cover-footer{display:grid;grid-template-columns:1fr auto;gap:20px;align-items:end;border-top:1px solid #e9eff2;padding-top:22px}.vf-client-name strong{font-size:18px}.vf-client-name small{display:block;color:#7a8d97;margin-top:3px}.vf-validity{text-align:right}.vf-validity strong,.vf-validity small{display:block}.vf-validity small{color:#8998a0;margin-top:3px}
        .vf-content-page{padding:42px 50px}.vf-page-head{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:28px}.vf-page-head .vf-num{font-size:12px;color:#9cacb4;font-weight:900}.vf-page-head h2{margin:5px 0 0;font-size:31px;line-height:1.15}.vf-page-head p{margin:7px 0 0;color:#71858f}.vf-section-copy{font-size:15px;line-height:1.8;color:#4e6673;white-space:pre-line}.vf-section-accent{height:4px;width:86px;border-radius:99px;background:linear-gradient(90deg,var(--blue),var(--orange));margin-bottom:20px}
        .vf-items{display:grid;gap:10px}.vf-item{display:grid;grid-template-columns:1fr auto;gap:18px;padding:16px 18px;border:1px solid var(--line);border-radius:16px;background:linear-gradient(145deg,#fff,#fbfdfe)}.vf-item h3{font-size:14px;margin:0}.vf-item p{font-size:11px;color:#788b95;margin:5px 0 0}.vf-item-price{text-align:right;min-width:125px}.vf-item-price strong{display:block;font-size:16px}.vf-item-price small{color:#84959e}.vf-total-card{margin-top:18px;padding:22px;border-radius:18px;background:#15384f;color:#fff;display:flex;justify-content:space-between;align-items:center;gap:20px}.vf-total-card span{font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#bed1dc}.vf-total-card strong{font-size:31px;color:#ffb142}
        .vf-payment-grid,.vf-cost-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}.vf-payment,.vf-cost{padding:18px;border:1px solid var(--line);border-radius:17px;background:#fff}.vf-payment.highlight{border:2px solid #8acdf0;background:linear-gradient(145deg,#f2fbff,#fff9ef)}.vf-payment .badge,.vf-cost .badge{display:inline-flex;padding:5px 8px;border-radius:99px;background:#edf7fc;color:#087fc7;font-size:9px;font-weight:800;text-transform:uppercase}.vf-payment h3,.vf-cost h3{margin:10px 0 5px;font-size:15px}.vf-payment p,.vf-cost p{margin:0;color:#748791;font-size:11px;line-height:1.5}.vf-price-line{margin-top:14px;display:flex;justify-content:space-between;align-items:end;gap:12px}.vf-price-line strong{font-size:21px}.vf-price-line small{color:#83949d}.vf-cost.external{background:#fafcfd}.vf-external-note{padding:14px 16px;margin-top:15px;border-radius:13px;background:#fff7e9;color:#805715;font-size:11px;line-height:1.55}
        .vf-info-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.vf-info-box{padding:18px;border:1px solid var(--line);border-radius:16px;background:#fbfdfe}.vf-info-box span{display:block;font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:#87969e;margin-bottom:6px}.vf-info-box p{margin:0;white-space:pre-line;line-height:1.65;color:#566d79}
        .vf-cta{padding:42px 50px;background:linear-gradient(135deg,#15384f,#087fc7);color:#fff}.vf-cta h2{font-size:30px;margin:0 0 8px}.vf-cta p{color:#d5e6ef;line-height:1.6}.vf-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}.vf-btn{border:0;border-radius:12px;padding:13px 18px;font-weight:800;cursor:pointer;font-size:13px}.vf-accept{background:#fff;color:#087fc7}.vf-reject{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}.vf-print{background:#ff9d17;color:#fff}.vf-status{display:inline-flex;padding:7px 10px;border-radius:99px;background:rgba(255,255,255,.12);font-weight:700}.vf-status.accepted{background:#e8f7ed;color:#287447}.vf-status.rejected{background:#fff0f0;color:#a43a3a}.vf-expired{padding:13px;border-radius:12px;background:#fff2dd;color:#805414}.vf-screen-toolbar{position:sticky;bottom:14px;z-index:20;display:flex;justify-content:center;padding:0 14px}.vf-screen-toolbar>div{display:flex;gap:8px;padding:8px;border-radius:14px;background:rgba(16,47,68,.94);box-shadow:0 12px 30px rgba(0,0,0,.2)}.vf-screen-toolbar a,.vf-screen-toolbar button{border:0;border-radius:9px;padding:10px 14px;background:#fff;color:#15384f;text-decoration:none;font-weight:800;cursor:pointer}.vf-screen-toolbar .primary{background:var(--orange);color:#fff}

        .vf-feedback-box{margin-top:18px;padding:18px;border-radius:16px;background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.18)}.vf-feedback-box h3{margin:0 0 6px;font-size:16px}.vf-feedback-box p{margin:0 0 12px;color:#d4e5ed}.vf-feedback-box label{display:grid;gap:5px;margin:10px 0;font-size:10px;font-weight:800}.vf-feedback-box textarea{width:100%;min-height:92px;padding:11px;border-radius:11px;border:1px solid rgba(255,255,255,.28);background:#fff;color:#17364d;resize:vertical}.vf-feedback-box .vf-help{font-size:9px;color:#c8dae4}.vf-decision-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:18px}.vf-decision-card{padding:16px;border-radius:15px;background:rgba(255,255,255,.09);border:1px solid rgba(255,255,255,.18)}.vf-decision-card h3{margin:0 0 5px}.vf-decision-card p{font-size:11px;margin:0 0 10px}.vf-decision-card textarea{width:100%;min-height:80px;padding:10px;border-radius:10px;border:1px solid rgba(255,255,255,.26);background:#fff;color:#17364d;margin:5px 0}.vf-feedback-saved{margin-top:16px;padding:14px;border-radius:13px;background:rgba(255,255,255,.12)}.vf-feedback-saved strong{display:block;margin-bottom:5px}.vf-feedback-saved p{margin:0;color:#e2edf2;white-space:pre-line}

        .vf-external-provider{margin:0 0 18px;padding:18px;border:1px solid var(--line);border-radius:18px;background:#fbfdfe}.vf-external-provider-head{display:flex;justify-content:space-between;gap:18px;align-items:flex-start}.vf-external-provider-head h3{margin:7px 0 5px;font-size:19px}.vf-external-provider-head p{margin:0;color:#748791;font-size:11px;line-height:1.5}.vf-external-provider-head>strong{font-size:11px;color:#6d818c}.vf-external-options{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:14px}.vf-external-option{padding:14px;border:1px solid #e2ebef;border-radius:14px;background:#fff}.vf-external-option.highlight{border:2px solid #7fc8ed;background:linear-gradient(145deg,#f1fbff,#fff8ee)}.vf-external-option-top{display:flex;justify-content:space-between;gap:8px}.vf-external-option h4{margin:7px 0 0;font-size:14px}.vf-recommended{font-size:8px;font-weight:800;color:#fff;background:#ff9800;border-radius:99px;padding:5px 7px;height:max-content}.vf-external-option-price{margin:12px 0 8px}.vf-external-option-price strong,.vf-external-option-price small{display:block}.vf-external-option-price strong{font-size:20px}.vf-external-option-price small{font-size:9px;color:#82949d;margin-top:2px}.vf-option-condition,.vf-option-benefits{margin-top:7px;padding:8px 9px;border-radius:9px;background:#f4f8fa;color:#607681;font-size:9px;line-height:1.45}.vf-option-benefits{background:#eef8f2;color:#4d725d}
        .vf-summary-investments{display:grid;gap:14px;margin-bottom:17px}.vf-summary-main{padding:20px;border-radius:17px;background:#15384f;color:#fff}.vf-summary-main span,.vf-summary-main strong,.vf-summary-main small{display:block}.vf-summary-main span{font-size:9px;text-transform:uppercase;letter-spacing:.12em;color:#bdd1dc}.vf-summary-main strong{margin-top:6px;font-size:31px;color:#ffad2e}.vf-summary-main small{margin-top:5px;color:#d0e0e8}.vf-summary-external{padding:18px;border:1px solid #eadfc9;border-radius:17px;background:#fffaf1}.vf-summary-external-title span,.vf-summary-external-title small{display:block}.vf-summary-external-title span{font-weight:900;color:#5a4930}.vf-summary-external-title small{font-size:9px;color:#8b7c67;margin-top:3px}.vf-summary-external-row{display:grid;grid-template-columns:1fr auto;gap:16px;padding:11px 0;border-bottom:1px solid #eee3d0}.vf-summary-external-row:last-of-type{border-bottom:0}.vf-summary-external-row strong,.vf-summary-external-row small{display:block}.vf-summary-external-row small{font-size:9px;color:#8b7b66;margin-top:3px}.vf-summary-external-row>div:last-child{text-align:right}.vf-summary-warning{margin-top:10px;padding:9px 10px;border-radius:10px;background:#fff3da;color:#785922;font-size:9px;line-height:1.45}

        .vf-company-intro{display:grid;grid-template-columns:260px 1fr;gap:28px;align-items:center;padding:22px;border-radius:18px;background:linear-gradient(135deg,#f4fbff,#fff8ed);border:1px solid var(--line)}.vf-company-intro .vf-logo{width:100%;max-width:245px}.vf-company-intro p{margin:0;color:#5c7480;line-height:1.7;font-size:13px}.vf-company-contact-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:16px}.vf-company-contact-grid>div{padding:14px;border:1px solid var(--line);border-radius:13px;background:#fff}.vf-company-contact-grid>div.wide{grid-column:1/-1}.vf-company-contact-grid span,.vf-company-contact-grid strong{display:block}.vf-company-contact-grid span{font-size:8px;text-transform:uppercase;letter-spacing:.1em;color:#87979f}.vf-company-contact-grid strong{margin-top:4px;font-size:12px}.vf-company-responsibles,.vf-company-socials{margin-top:20px}.vf-company-responsibles>div{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-top:9px}.vf-company-responsibles article{padding:13px;border:1px solid var(--line);border-radius:13px;background:#fbfdfe}.vf-company-responsibles article strong,.vf-company-responsibles article small,.vf-company-responsibles article span{display:block}.vf-company-responsibles article small{margin:3px 0 7px;color:#7e9099}.vf-company-responsibles article span{font-size:9px;color:#607782;margin-top:2px}.vf-company-socials>div{display:flex;gap:7px;flex-wrap:wrap;margin-top:9px}.vf-company-socials>div>span{padding:9px 11px;border:1px solid var(--line);border-radius:11px;background:#fff}.vf-company-socials strong,.vf-company-socials small{display:block}.vf-company-socials strong{font-size:9px;color:#087fc7}.vf-company-socials small{font-size:8px;color:#81929b;margin-top:2px}.vf-company-slogan{margin-top:22px;padding:14px;text-align:center;border-radius:13px;background:#15384f;color:#fff;font-weight:800;letter-spacing:.02em}.vf-cta-contacts{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;margin:18px 0}.vf-cta-contacts span{padding:11px 12px;border:1px solid rgba(255,255,255,.17);border-radius:11px;background:rgba(255,255,255,.08);font-size:10px}.vf-cta-contacts b{display:block;font-size:8px;text-transform:uppercase;letter-spacing:.09em;color:#9fdaf6;margin-bottom:3px}

        .vf-company-link{color:#087fc7;text-decoration:none;overflow-wrap:anywhere}.vf-company-link:hover{text-decoration:underline}.vf-company-socials>div>a.vf-social-link{display:block;padding:9px 11px;border:1px solid var(--line);border-radius:11px;background:#fff;text-decoration:none;transition:.18s ease}.vf-company-socials>div>a.vf-social-link:hover{border-color:#8bcdf0;transform:translateY(-1px);box-shadow:0 5px 14px rgba(16,75,108,.08)}.vf-social-link strong,.vf-social-link small,.vf-social-link b{display:block}.vf-social-link strong{font-size:9px;color:#087fc7}.vf-social-link small{font-size:8px;color:#81929b;margin-top:2px}.vf-social-link b{font-size:8px;color:#f39218;margin-top:5px}.vf-cta-contact-link{padding:11px 12px;border:1px solid rgba(255,255,255,.17);border-radius:11px;background:rgba(255,255,255,.08);font-size:10px;color:#fff;text-decoration:none}.vf-cta-contact-link:hover{background:rgba(255,255,255,.14)}.vf-cta-contact-link b{display:block;font-size:8px;text-transform:uppercase;letter-spacing:.09em;color:#9fdaf6;margin-bottom:3px}
        @media(max-width:720px){.vf-company-intro{grid-template-columns:1fr}.vf-company-contact-grid,.vf-company-responsibles>div{grid-template-columns:1fr}.vf-company-contact-grid>div.wide{grid-column:1}.vf-external-options{grid-template-columns:1fr}.vf-summary-external-row{grid-template-columns:1fr}.vf-summary-external-row>div:last-child{text-align:left}.vf-decision-grid{grid-template-columns:1fr}.vf-public{padding:0}.vf-proposal{gap:0}.vf-page{border-radius:0;border-left:0;border-right:0}.vf-cover,.vf-content-page,.vf-cta{padding:27px 22px}.vf-cover{min-height:620px}.vf-cover-main h1{font-size:36px}.vf-cover-top,.vf-cover-footer{grid-template-columns:1fr;display:grid}.vf-number,.vf-validity{text-align:left}.vf-payment-grid,.vf-cost-grid,.vf-info-grid{grid-template-columns:1fr}.vf-item{grid-template-columns:1fr}.vf-item-price{text-align:left}.vf-screen-toolbar{bottom:8px}}
        @page{size:A4;margin:0}
        @media print{html,body{background:#fff!important}.vf-public{padding:0}.vf-proposal{max-width:none;display:block}.vf-page{width:210mm;min-height:297mm;border:0;border-radius:0;box-shadow:none;page-break-after:always;break-after:page}.vf-page:last-child{page-break-after:auto}.vf-cover{min-height:297mm;padding:24mm 18mm}.vf-content-page{padding:18mm}.vf-cta{padding:22mm 18mm}.vf-screen-toolbar,.vf-actions form,.vf-print{display:none!important}.vf-payment-grid,.vf-cost-grid{grid-template-columns:1fr 1fr}.vf-item,.vf-payment,.vf-cost,.vf-info-box{break-inside:avoid}}
        </style></head><body>';
    }

    private static function page_end(){ echo '</body></html>'; }

    private static function cycle_label($cycle){
        return ['one_time'=>'Pagamento único','monthly'=>'Mensal','quarterly'=>'Trimestral','semiannual'=>'Semestral','annual'=>'Anual','biennial'=>'A cada 2 anos','variable'=>'Valor variável','recurring'=>'Recorrente'][$cycle]??ucfirst((string)$cycle);
    }

    public static function render($q){
        global $wpdb;
        $company=self::company_info();
        $visibility=['custom_sections'=>1,'external_costs'=>1,'payment_options'=>1,'company_info'=>1];
        $proposal_order=['custom_sections','deliverables','external_costs','payment_options','summary','company_info'];
        if(!empty($q->proposal_visibility)){
            $decoded=json_decode($q->proposal_visibility,true);
            if(is_array($decoded)){
                $visibility=array_merge($visibility,$decoded);
                if(!empty($decoded['order'])&&is_array($decoded['order'])){
                    $clean=[];foreach($decoded['order'] as $key)if(in_array($key,$proposal_order,true)&&!in_array($key,$clean,true))$clean[]=$key;
                    foreach($proposal_order as $key)if(!in_array($key,$clean,true))$clean[]=$key;
                    $proposal_order=$clean;
                }
            }
        }
        $items=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quote_items')." WHERE quote_id=%d ORDER BY sort_order,id",$q->id));
        $sections=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quote_sections')." WHERE quote_id=%d ORDER BY sort_order,id",$q->id));
        $costs=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quote_costs')." WHERE quote_id=%d ORDER BY sort_order,id",$q->id));if($costs){$cot=VFOS_DB::table('quote_cost_options');foreach($costs as $cost)$cost->options=$wpdb->get_results($wpdb->prepare("SELECT * FROM $cot WHERE cost_id=%d ORDER BY sort_order,id",$cost->id));}
        $payments=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quote_payment_options')." WHERE quote_id=%d ORDER BY sort_order,id",$q->id));
        $expired=$q->valid_until && strtotime($q->valid_until.' 23:59:59')<current_time('timestamp') && !in_array($q->status,['accepted','rejected'],true);
        $client=$q->client_name?:'Proposta padrão VisionForge';
        self::page_start($q->title);
        echo '<main class="vf-public"><article class="vf-proposal" data-proposal-order="'.esc_attr(wp_json_encode($proposal_order)).'">';
        echo '<section class="vf-page vf-cover"><div class="vf-cover-top"><img class="vf-logo" src="'.esc_url(VFOS_URL.'admin/assets/images/visionforge-logo-horizontal.png').'" alt="VisionForge Digital"><div class="vf-number"><span>PROPOSTA COMERCIAL</span><strong>'.esc_html($q->number).'</strong></div></div><div class="vf-cover-main"><span class="vf-eyebrow">SOLUÇÕES DIGITAIS • ESTRATÉGIA • RESULTADOS</span><h1>'.esc_html($q->title).'</h1><p>'.esc_html($q->description?:'Uma solução digital pensada para fortalecer sua presença, melhorar a experiência do seu público e gerar novas oportunidades para o seu negócio.').'</p></div><div class="vf-cover-footer"><div class="vf-client-name"><span class="vf-eyebrow">PREPARADO PARA</span><strong>'.esc_html($client).'</strong><small>'.esc_html($company['name']).' • '.esc_html($company['slogan']).'</small></div><div class="vf-validity"><span class="vf-eyebrow">VALIDADE</span><strong>'.($q->valid_until?esc_html(date_i18n('d/m/Y',strtotime($q->valid_until))):'Sem prazo definido').'</strong><small>Status: '.esc_html(ucfirst($q->status)).'</small></div></div></section>';

        $page=1;
        foreach($sections as $sec){$page++;echo '<section class="vf-page vf-content-page" data-proposal-key="custom_sections"><div class="vf-page-head"><div><span class="vf-eyebrow">'.esc_html(strtoupper($sec->section_type==='why'?'POR QUE INVESTIR':($sec->section_type==='vision'?'NOSSA VISÃO':($sec->section_type==='benefits'?'BENEFÍCIOS':'PROPOSTA VISIONFORGE')))).'</span><h2>'.esc_html($sec->title).'</h2></div><span class="vf-num">'.str_pad((string)$page,2,'0',STR_PAD_LEFT).'</span></div><div class="vf-section-accent"></div><div class="vf-section-copy">'.nl2br(esc_html($sec->content)).'</div></section>';}

        $page++;echo '<section class="vf-page vf-content-page" data-proposal-key="deliverables"><div class="vf-page-head"><div><span class="vf-eyebrow">O QUE ESTÁ INCLUSO</span><h2>Entregas da VisionForge</h2><p>Veja tudo que faz parte do investimento principal desta proposta.</p></div><span class="vf-num">'.str_pad((string)$page,2,'0',STR_PAD_LEFT).'</span></div><div class="vf-items">';
        foreach($items as $i)echo '<div class="vf-item"><div><h3>'.esc_html($i->title).'</h3>'.($i->description?'<p>'.esc_html($i->description).'</p>':'').'</div><div class="vf-item-price"><strong>R$ '.number_format((float)$i->total,2,',','.').'</strong><small>'.number_format((float)$i->quantity,2,',','.').' × R$ '.number_format((float)$i->unit_price,2,',','.').'</small></div></div>';
        echo '</div><div class="vf-total-card"><div><span>INVESTIMENTO VISIONFORGE</span><small>Custos externos não estão incluídos neste total.</small></div><strong>R$ '.number_format((float)$q->total,2,',','.').'</strong></div></section>';

        if(!empty($visibility['payment_options'])&&$payments){$page++;echo '<section class="vf-page vf-content-page" data-proposal-key="payment_options"><div class="vf-page-head"><div><span class="vf-eyebrow">FORMAS DE PAGAMENTO</span><h2>Escolha a condição que faz mais sentido</h2><p>As condições abaixo detalham periodicidade, parcelas e valores.</p></div><span class="vf-num">'.str_pad((string)$page,2,'0',STR_PAD_LEFT).'</span></div><div class="vf-payment-grid">';foreach($payments as $p){$amount=(float)$p->amount>0?(float)$p->amount:(float)$q->total;echo '<div class="vf-payment '.($p->highlight?'highlight':'').'"><span class="badge">'.esc_html(self::cycle_label($p->billing_cycle)).'</span><h3>'.esc_html($p->title).'</h3><p>'.esc_html($p->description).'</p><div class="vf-price-line"><div><strong>R$ '.number_format($amount,2,',','.').'</strong><small>'.($p->installments>1?' em até '.(int)$p->installments.' parcelas':'').'</small></div>'.($p->highlight?'<span class="badge">Recomendado</span>':'').'</div></div>';}echo '</div>'.($q->payment_terms?'<div class="vf-external-note"><strong>Condições gerais:</strong> '.nl2br(esc_html($q->payment_terms)).'</div>':'').'</section>';}

        if(!empty($visibility['external_costs'])&&$costs){
            $page++;echo '<section class="vf-page vf-content-page" data-proposal-key="external_costs"><div class="vf-page-head"><div><span class="vf-eyebrow">CUSTOS EXTERNOS</span><h2>Serviços necessários fora da VisionForge</h2><p>Compare planos, prazos, valores e benefícios oferecidos por terceiros.</p></div><span class="vf-num">'.str_pad((string)$page,2,'0',STR_PAD_LEFT).'</span></div>';
            foreach($costs as $c){
                echo '<div class="vf-external-provider"><div class="vf-external-provider-head"><div><span class="badge">'.($c->is_required?'Obrigatório':'Opcional').'</span><h3>'.esc_html($c->title).'</h3><p>'.esc_html($c->description).'</p></div><strong>'.esc_html($c->provider?:'Fornecedor externo').'</strong></div><div class="vf-external-options">';
                $opts=$c->options?:[(object)['title'=>'Opção principal','amount'=>$c->amount,'billing_cycle'=>$c->billing_cycle,'duration_months'=>1,'condition_text'=>'','benefits'=>'','highlight'=>0]];
                foreach($opts as $o){
                    echo '<div class="vf-external-option '.($o->highlight?'highlight':'').'"><div class="vf-external-option-top"><div><span class="badge">'.esc_html(self::cycle_label($o->billing_cycle)).'</span><h4>'.esc_html($o->title).'</h4></div>'.($o->highlight?'<span class="vf-recommended">Destaque</span>':'').'</div><div class="vf-external-option-price"><strong>'.((float)$o->amount>0?'R$ '.number_format((float)$o->amount,2,',','.'):'A consultar').'</strong><small>'.((int)$o->duration_months>1?(int)$o->duration_months.' meses':'').'</small></div>';
                    if($o->condition_text)echo '<div class="vf-option-condition"><b>Condição:</b> '.esc_html($o->condition_text).'</div>';
                    if($o->benefits)echo '<div class="vf-option-benefits"><b>Inclui:</b> '.esc_html($o->benefits).'</div>';
                    echo '</div>';
                }
                echo '</div></div>';
            }
            echo '<div class="vf-external-note"><strong>Importante:</strong> os valores acima são pagos diretamente aos respectivos fornecedores e podem mudar sem aviso prévio. Eles não fazem parte do valor cobrado pela '.esc_html($company['name']).'.</div></section>';
        }

        $mandatory_external=[];
        if(!empty($visibility['external_costs']))foreach($costs as $c){
            if(empty($c->is_required))continue;
            $opts=$c->options?:[(object)['title'=>'Opção principal','amount'=>$c->amount,'billing_cycle'=>$c->billing_cycle,'duration_months'=>1]];
            $priced=array_values(array_filter($opts,fn($o)=>(float)$o->amount>0));
            $min=null;
            foreach($priced as $o)if($min===null||(float)$o->amount<(float)$min->amount)$min=$o;
            $mandatory_external[]=['cost'=>$c,'option'=>$min,'options'=>$opts];
        }
        $page++;echo '<section class="vf-page vf-content-page" data-proposal-key="summary"><div class="vf-page-head"><div><span class="vf-eyebrow">RESUMO DA PROPOSTA</span><h2>Investimento e condições</h2><p>Visão clara do que é pago à VisionForge e do que precisa ser contratado externamente.</p></div><span class="vf-num">'.str_pad((string)$page,2,'0',STR_PAD_LEFT).'</span></div>';
        echo '<div class="vf-summary-investments"><div class="vf-summary-main"><span>Investimento '.esc_html($company['name']).'</span><strong>R$ '.number_format((float)$q->total,2,',','.').'</strong>'.((float)$q->discount_amount>0?'<small>Desconto aplicado: R$ '.number_format((float)$q->discount_amount,2,',','.').'</small>':'').'</div>';
        if($mandatory_external){
            echo '<div class="vf-summary-external"><div class="vf-summary-external-title"><span>Custos externos obrigatórios</span><small>Valores pagos a terceiros • escolha uma opção de cada categoria</small></div>';
            foreach($mandatory_external as $m){$c=$m['cost'];$o=$m['option'];echo '<div class="vf-summary-external-row"><div><strong>'.esc_html($c->title).'</strong><small>'.esc_html($c->provider?:'Fornecedor externo').'</small></div><div>'.($o?'<strong>A partir de R$ '.number_format((float)$o->amount,2,',','.').'</strong><small>'.esc_html($o->title).' • '.esc_html(self::cycle_label($o->billing_cycle)).'</small>':'<strong>A consultar</strong><small>Consulte as opções apresentadas</small>').'</div></div>';}
            echo '<div class="vf-summary-warning">Os valores externos acima são referências mínimas entre as opções cadastradas. O valor final depende do plano escolhido pelo cliente e não é recebido pela '.esc_html($company['name']).'.</div></div>';
        }
        echo '</div><div class="vf-info-grid"><div class="vf-info-box"><span>Validade</span><p>'.($q->valid_until?esc_html(date_i18n('d/m/Y',strtotime($q->valid_until))):'Sem prazo definido').'</p></div><div class="vf-info-box"><span>Pagamento '.esc_html($company['name']).'</span><p>'.nl2br(esc_html($q->payment_terms?:'A combinar')).'</p></div><div class="vf-info-box" style="grid-column:1/-1"><span>Observações</span><p>'.nl2br(esc_html($q->notes?:'Esta proposta contempla os itens e condições apresentados neste documento.')).'</p></div></div></section>';

        if(!empty($visibility['company_info'])){
        $page++;
        echo '<section class="vf-page vf-content-page vf-company-page" data-proposal-key="company_info"><div class="vf-page-head"><div><span class="vf-eyebrow">QUEM ESTÁ POR TRÁS DA PROPOSTA</span><h2>'.esc_html($company['name']).'</h2><p>'.esc_html($company['description']).'</p></div><span class="vf-num">'.str_pad((string)$page,2,'0',STR_PAD_LEFT).'</span></div><div class="vf-section-accent"></div>';
        echo '<div class="vf-company-intro"><img class="vf-logo" src="'.esc_url(VFOS_URL.'admin/assets/images/visionforge-logo-horizontal.png').'" alt="'.esc_attr($company['name']).'"><p>'.nl2br(esc_html($company['description'])).'</p></div>';
        echo '<div class="vf-company-contact-grid">';
        if($company['website'])echo '<div><span>Site</span><strong><a class="vf-company-link" href="'.esc_url($company['website']).'" target="_blank" rel="noopener noreferrer">'.esc_html(preg_replace('#^https?://#','',$company['website'])).'</a></strong></div>';
        if($company['email'])echo '<div><span>E-mail</span><strong>'.esc_html($company['email']).'</strong></div>';
        if($company['phone'])echo '<div><span>Telefone</span><strong>'.esc_html($company['phone']).'</strong></div>';
        if($company['whatsapp'])echo '<div><span>WhatsApp</span><strong>'.esc_html($company['whatsapp']).'</strong></div>';
        if(!empty($company['show_document'])&&$company['document'])echo '<div><span>'.esc_html(strtoupper($company['document_type'])).'</span><strong>'.esc_html($company['document']).'</strong></div>';
        if(!empty($company['show_address'])&&($company['address']||$company['city'])){$addr=trim(implode(' • ',array_filter([$company['address'],trim(($company['city']??'').(($company['state']??'')?'/'.$company['state']:'')),$company['zip']??''])));echo '<div class="wide"><span>Endereço</span><strong>'.esc_html($addr).'</strong></div>';}
        echo '</div>';
        if(!empty($company['show_responsibles'])&&!empty($company['responsibles'])){
            echo '<div class="vf-company-responsibles"><span class="vf-eyebrow">RESPONSÁVEIS</span><div>';
            foreach((array)$company['responsibles'] as $r){if(empty($r['name']))continue;echo '<article><strong>'.esc_html($r['name']).'</strong><small>'.esc_html($r['role']??'').'</small>';if(!empty($r['email']))echo '<span>'.esc_html($r['email']).'</span>';if(!empty($r['phone']))echo '<span>'.esc_html($r['phone']).'</span>';echo '</article>';}
            echo '</div></div>';
        }
        if(!empty($company['show_socials'])&&!empty($company['socials'])){
            $valid_socials=array_filter((array)$company['socials']);
            if($valid_socials){echo '<div class="vf-company-socials"><span class="vf-eyebrow">REDES SOCIAIS</span><div>';foreach($valid_socials as $key=>$url)echo '<a class="vf-social-link" href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer"><strong>'.esc_html(self::social_label($key)).'</strong><small>'.esc_html(preg_replace('#^https?://#','',$url)).'</small><b>Acessar ↗</b></a>';echo '</div></div>';}
        }
        echo '<div class="vf-company-slogan">'.esc_html($company['slogan']).'</div></section>';
        }

        echo '<section class="vf-page vf-cta"><div style="display:inline-flex;padding:12px 16px;border-radius:15px;background:#fff"><img class="vf-logo" src="'.esc_url(VFOS_URL.'admin/assets/images/visionforge-logo-horizontal.png').'" alt="VisionForge Digital"></div><div style="margin-top:60px"><span class="vf-eyebrow" style="color:#9bd8f6">PRÓXIMO PASSO</span><h2>Vamos transformar esta ideia em uma experiência digital?</h2><p>'.esc_html($company['slogan']).'</p>';if($company['website']||$company['email']||$company['whatsapp']||$company['phone']){echo '<div class="vf-cta-contacts">';if($company['website'])echo '<a class="vf-cta-contact-link" href="'.esc_url($company['website']).'" target="_blank" rel="noopener noreferrer"><b>Site</b>'.esc_html(preg_replace('#^https?://#','',$company['website'])).' ↗</a>';if($company['email'])echo '<span><b>E-mail</b>'.esc_html($company['email']).'</span>';if($company['whatsapp'])echo '<span><b>WhatsApp</b>'.esc_html($company['whatsapp']).'</span>';elseif($company['phone'])echo '<span><b>Telefone</b>'.esc_html($company['phone']).'</span>';echo '</div>';}
        if($q->client_observations)echo '<div class="vf-feedback-saved"><strong>Observações enviadas</strong><p>'.esc_html($q->client_observations).'</p></div>';
        if(!$q->client_id){
            echo '<p>Esta é uma proposta padrão da VisionForge. Você pode enviar uma observação para nossa equipe antes de seguir com a contratação.</p>';
            echo '<div class="vf-feedback-box"><h3>Tem alguma observação?</h3><p>Envie dúvidas, ajustes ou informações adicionais sobre esta proposta.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_proposal_feedback"><input type="hidden" name="token" value="'.esc_attr($q->public_token).'">';wp_nonce_field('vfos_proposal_feedback_'.$q->id);echo '<label>Observações<textarea name="client_observations" required maxlength="4000" placeholder="Escreva aqui suas dúvidas, comentários ou ajustes que gostaria de discutir..."></textarea></label><button class="vf-btn vf-accept">Enviar observações</button></form></div>';
        }elseif($q->status==='accepted'){
            echo '<p><span class="vf-status accepted">✓ Proposta aceita</span> em '.esc_html(date_i18n('d/m/Y H:i',strtotime($q->decided_at))).'. Nossa equipe seguirá com os próximos passos.</p>';
        }elseif($q->status==='rejected'){
            echo '<p><span class="vf-status rejected">Proposta recusada</span> em '.esc_html(date_i18n('d/m/Y H:i',strtotime($q->decided_at))).'.</p>';
            if($q->rejection_reason)echo '<div class="vf-feedback-saved"><strong>Motivo informado</strong><p>'.esc_html($q->rejection_reason).'</p></div>';
            if($q->revision_suggestion)echo '<div class="vf-feedback-saved"><strong>Sugestão de alteração</strong><p>'.esc_html($q->revision_suggestion).'</p></div>';
        }elseif($expired){
            echo '<div class="vf-expired">Esta proposta ultrapassou a data de validade. Entre em contato com a VisionForge para uma atualização.</div>';
        }else{
            echo '<p>Você pode enviar observações antes de tomar uma decisão ou registrar sua resposta agora.</p>';
            echo '<div class="vf-feedback-box"><h3>Enviar observações sem decidir agora</h3><p>Use este campo para pedir ajustes, tirar dúvidas ou complementar informações.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_proposal_feedback"><input type="hidden" name="token" value="'.esc_attr($q->public_token).'">';wp_nonce_field('vfos_proposal_feedback_'.$q->id);echo '<label>Observações<textarea name="client_observations" required maxlength="4000" placeholder="Ex.: Gostaria de incluir integração com WhatsApp e entender melhor o prazo de entrega."></textarea></label><button class="vf-btn vf-accept">Enviar observações</button></form></div>';
            echo '<div class="vf-decision-grid"><div class="vf-decision-card"><h3>Quero contratar</h3><p>Se a proposta estiver de acordo, confirme o aceite.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_proposal_decision"><input type="hidden" name="token" value="'.esc_attr($q->public_token).'"><input type="hidden" name="decision" value="accepted">';wp_nonce_field('vfos_proposal_decision_'.$q->id);echo '<label>Observação opcional<textarea name="client_observations" maxlength="4000" placeholder="Se quiser, deixe uma observação junto com o aceite."></textarea></label><button class="vf-btn vf-accept">Aceitar proposta</button></form></div>';
            echo '<div class="vf-decision-card"><h3>Não quero seguir desta forma</h3><p>Para recusarmos corretamente, conte o motivo e o que poderia ser alterado.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="vfos_proposal_decision"><input type="hidden" name="token" value="'.esc_attr($q->public_token).'"><input type="hidden" name="decision" value="rejected">';wp_nonce_field('vfos_proposal_decision_'.$q->id);echo '<label>Por que você está recusando? <textarea name="rejection_reason" required maxlength="4000" placeholder="Ex.: O investimento ficou acima do orçamento disponível neste momento."></textarea></label><label>O que você sugere alterar? <textarea name="revision_suggestion" required maxlength="4000" placeholder="Ex.: Gostaria de uma versão mais enxuta, sem a integração X, ou com outra condição de pagamento."></textarea></label><label>Observação adicional <textarea name="client_observations" maxlength="4000" placeholder="Opcional"></textarea></label><button class="vf-btn vf-reject">Enviar recusa e sugestão</button></form></div></div>';
        }
        echo '</div></section></article></main><div class="vf-screen-toolbar"><div><button class="primary" onclick="window.print()">Baixar / Salvar PDF</button><button onclick="window.scrollTo({top:0,behavior:\'smooth\'})">Voltar ao início</button></div></div>';
        echo '<script>
        (function(){
          function reorderProposal(){
            var root=document.querySelector(".vf-proposal");if(!root)return;
            var order=[];try{order=JSON.parse(root.getAttribute("data-proposal-order")||"[]");}catch(e){}
            if(!Array.isArray(order)||!order.length)return;
            var finalPage=root.querySelector(".vf-cta");
            order.forEach(function(key){
              Array.prototype.slice.call(root.querySelectorAll("[data-proposal-key=\""+key+"\"]")).forEach(function(node){
                root.insertBefore(node,finalPage);
              });
            });
            var n=2;
            root.querySelectorAll(".vf-page:not(.vf-cover):not(.vf-cta) .vf-num").forEach(function(el){
              el.textContent=String(n++).padStart(2,"0");
            });
          }
          if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",reorderProposal);else reorderProposal();
        })();
        </script>';
        self::page_end();
    }

    public static function feedback(){
        global $wpdb;
        $token=sanitize_text_field(wp_unslash($_POST['token']??''));
        $q=self::quote_by_token($token);
        if(!$q)wp_die('Proposta não encontrada.');
        check_admin_referer('vfos_proposal_feedback_'.$q->id);
        $obs=sanitize_textarea_field(wp_unslash($_POST['client_observations']??''));
        if(!$obs)wp_die('Digite uma observação antes de enviar.');
        $now=current_time('mysql');
        $existing=trim((string)$q->client_observations);
        $merged=$existing?($existing."\n\n[".date_i18n('d/m/Y H:i')."]\n".$obs):("[".date_i18n('d/m/Y H:i')."]\n".$obs);
        $wpdb->update(VFOS_DB::table('quotes'),[
            'client_observations'=>$merged,
            'feedback_updated_at'=>$now,
            'updated_at'=>$now
        ],['id'=>$q->id]);
        VFOS_DB::log('proposal_feedback','quote',$q->id,'Observação enviada pelo cliente',null,['client_observations'=>$obs],$q->title);
        $admin_email=get_option('admin_email');
        if($admin_email)wp_mail($admin_email,'VisionForge OS • Nova observação na proposta '.$q->number,"Proposta: {$q->title}\n\nObservação do cliente:\n{$obs}\n\nAcesse o VisionForge OS para consultar.");
        $fresh=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quotes')." WHERE id=%d",$q->id));
        wp_safe_redirect(add_query_arg('feedback','sent',self::url($fresh)));exit;
    }

    public static function decision(){
        global $wpdb;
        $token=sanitize_text_field(wp_unslash($_POST['token']??''));
        $decision=sanitize_key($_POST['decision']??'');
        $q=self::quote_by_token($token);
        if(!$q || !in_array($decision,['accepted','rejected'],true)) wp_die('Solicitação inválida.');
        check_admin_referer('vfos_proposal_decision_'.$q->id);
        if(in_array($q->status,['accepted','rejected'],true)){wp_safe_redirect(self::url($q));exit;}
        if($q->valid_until && strtotime($q->valid_until.' 23:59:59')<current_time('timestamp'))wp_die('Esta proposta expirou.');

        $obs=sanitize_textarea_field(wp_unslash($_POST['client_observations']??''));
        $reason=sanitize_textarea_field(wp_unslash($_POST['rejection_reason']??''));
        $suggestion=sanitize_textarea_field(wp_unslash($_POST['revision_suggestion']??''));
        if($decision==='rejected'&&(!$reason||!$suggestion))wp_die('Para recusar a proposta, informe o motivo da recusa e uma sugestão de alteração.');

        $now=current_time('mysql');$update=[
            'status'=>$decision,'decided_at'=>$now,
            'decision_ip'=>sanitize_text_field($_SERVER['REMOTE_ADDR']??''),
            'feedback_updated_at'=>$now,'updated_at'=>$now
        ];
        if($obs){
            $existing=trim((string)$q->client_observations);
            $update['client_observations']=$existing?($existing."\n\n[".date_i18n('d/m/Y H:i')."]\n".$obs):("[".date_i18n('d/m/Y H:i')."]\n".$obs);
        }
        if($decision==='rejected'){
            $update['rejection_reason']=$reason;
            $update['revision_suggestion']=$suggestion;
        }
        $wpdb->update(VFOS_DB::table('quotes'),$update,['id'=>$q->id]);
        VFOS_DB::log('proposal_'.$decision,'quote',$q->id,$decision==='rejected'?'Motivo: '.$reason.' | Sugestão: '.$suggestion:'Proposta aceita',null,$update,$q->title);
        if($decision==='accepted')self::convert_accepted_quote($q->id);

        $admin_email=get_option('admin_email');
        if($admin_email){
            $subject='VisionForge OS • '.$q->number.' '.($decision==='accepted'?'aceita':'recusada');
            $body='A proposta '.$q->number.' - '.$q->title.' foi '.($decision==='accepted'?'aceita':'recusada').' pelo cliente.';
            if($obs)$body.="\n\nObservação:\n".$obs;
            if($decision==='rejected')$body.="\n\nMotivo da recusa:\n".$reason."\n\nSugestão de alteração:\n".$suggestion;
            wp_mail($admin_email,$subject,$body);
        }
        $fresh=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quotes')." WHERE id=%d",$q->id));
        wp_safe_redirect(self::url($fresh));exit;
    }

    public static function convert_accepted_quote($quote_id){
        if(class_exists('VFOS_Workflow'))return VFOS_Workflow::process_quote_acceptance($quote_id);
        return false;
    }
}
