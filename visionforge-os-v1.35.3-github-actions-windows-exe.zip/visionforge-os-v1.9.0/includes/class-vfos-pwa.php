<?php
if(!defined('ABSPATH'))exit;

class VFOS_PWA{
    public static function init(){
        add_action('template_redirect',[__CLASS__,'endpoint'],0);
        add_action('admin_head',[__CLASS__,'head']);
        add_action('login_head',[__CLASS__,'login_head']);
    }

    public static function manifest_url(){ return add_query_arg(['vfos_pwa_manifest'=>'1','v'=>VFOS_VERSION],home_url('/')); }
    public static function sw_url(){ return add_query_arg(['vfos_pwa_sw'=>'1','uid'=>get_current_user_id(),'v'=>VFOS_VERSION],home_url('/')); }

    public static function endpoint(){
        if(isset($_GET['vfos_pwa_manifest'])){ self::manifest();exit; }
        if(isset($_GET['vfos_pwa_sw'])){ self::service_worker();exit; }
    }

    private static function manifest(){
        nocache_headers();
        header('Content-Type: application/manifest+json; charset=utf-8');
        $company=get_option('vfos_company_info',[]);
        $name=is_array($company)&&!empty($company['name'])?$company['name'].' OS':'VisionForge OS';
        $start=add_query_arg('vfos_app','1',admin_url('admin.php?page=vfos'));
        echo wp_json_encode([
            'id'=>wp_parse_url($start,PHP_URL_PATH).'?page=vfos',
            'name'=>$name,'short_name'=>'VisionForge OS',
            'description'=>'Sistema de gestão da VisionForge Digital com modo offline e sincronização posterior.',
            'start_url'=>$start,'scope'=>admin_url(),'display'=>'standalone',
            'display_override'=>['window-controls-overlay','standalone','minimal-ui'],'orientation'=>'any',
            'background_color'=>'#0f3045','theme_color'=>'#087fc7',
            'icons'=>[
                ['src'=>VFOS_URL.'admin/assets/images/vfos-app-192-v2.png','sizes'=>'192x192','type'=>'image/png','purpose'=>'any'],
                ['src'=>VFOS_URL.'admin/assets/images/vfos-app-512-v2.png','sizes'=>'512x512','type'=>'image/png','purpose'=>'any'],
                ['src'=>VFOS_URL.'admin/assets/images/vfos-app-512-v2.png','sizes'=>'512x512','type'=>'image/png','purpose'=>'maskable']
            ],
            'shortcuts'=>[
                ['name'=>'Dashboard','short_name'=>'Dashboard','url'=>add_query_arg('vfos_app','1',admin_url('admin.php?page=vfos')),'icons'=>[['src'=>VFOS_URL.'admin/assets/images/vfos-app-192-v2.png','sizes'=>'192x192']]],
                ['name'=>'Clientes','short_name'=>'Clientes','url'=>add_query_arg('vfos_app','1',admin_url('admin.php?page=vfos-clients')),'icons'=>[['src'=>VFOS_URL.'admin/assets/images/vfos-app-192-v2.png','sizes'=>'192x192']]],
                ['name'=>'Projetos','short_name'=>'Projetos','url'=>add_query_arg('vfos_app','1',admin_url('admin.php?page=vfos-projects')),'icons'=>[['src'=>VFOS_URL.'admin/assets/images/vfos-app-192-v2.png','sizes'=>'192x192']]],
                ['name'=>'Financeiro','short_name'=>'Financeiro','url'=>add_query_arg('vfos_app','1',admin_url('admin.php?page=vfos-financial')),'icons'=>[['src'=>VFOS_URL.'admin/assets/images/vfos-app-192-v2.png','sizes'=>'192x192']]]
            ]
        ],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    }

    private static function service_worker(){
        nocache_headers();
        header('Content-Type: application/javascript; charset=utf-8');
        header('Service-Worker-Allowed: /');
        $uid=max(0,(int)get_current_user_id());
        $assets=[
            VFOS_URL.'admin/assets/css/admin.css',
            VFOS_URL.'admin/assets/js/admin.js',
            VFOS_URL.'admin/assets/images/vfos-app-192-v2.png',
            VFOS_URL.'admin/assets/images/vfos-app-512-v2.png'
        ];
        $precache=[admin_url('admin.php?page=vfos'),admin_url('admin.php?page=vfos-app')];
        ?>
const VFOS_VERSION=<?php echo wp_json_encode(VFOS_VERSION); ?>;
const VFOS_USER=<?php echo wp_json_encode($uid); ?>;
const VFOS_PREFIX='vfos-offline-';
const STATIC_CACHE=`${VFOS_PREFIX}static-u${VFOS_USER}-v${VFOS_VERSION}`;
const PAGE_CACHE=`${VFOS_PREFIX}pages-u${VFOS_USER}-v${VFOS_VERSION}`;
const CONFIG_CACHE=`${VFOS_PREFIX}config-u${VFOS_USER}`;
const ASSETS=<?php echo wp_json_encode($assets,JSON_UNESCAPED_SLASHES); ?>;
const PRECACHE=<?php echo wp_json_encode($precache,JSON_UNESCAPED_SLASHES); ?>;
const MODE_KEY=new Request(location.origin+'/__vfos_offline_mode__');
async function saveMode(mode,fast){
  runtimeMode=['auto','online','offline'].includes(mode)?mode:'auto';
  fastApp=fast!==false;
  const c=await caches.open(CONFIG_CACHE);
  await c.put(MODE_KEY,new Response(JSON.stringify({mode:runtimeMode,fast:fastApp}),{headers:{'Content-Type':'application/json'}}));
}
async function loadMode(){
  try{const c=await caches.open(CONFIG_CACHE),r=await c.match(MODE_KEY);if(r){const d=await r.json();runtimeMode=d.mode||'auto';fastApp=d.fast!==false;}}catch(e){}
  return {mode:runtimeMode,fast:fastApp};
}
function isVisionForgePage(url){
  return url.origin===location.origin && url.pathname.includes('/wp-admin/') && (url.searchParams.get('page')||'').startsWith('vfos');
}
function isStatic(url){return url.origin===location.origin && (url.pathname.includes('/wp-content/plugins/visionforge-os') || /\.(?:css|js|png|jpg|jpeg|webp|svg|woff2?)$/i.test(url.pathname));}
function offlinePage(){return new Response('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#087fc7"><title>VisionForge OS • Offline</title><body style="margin:0;background:#f4f7f9;font-family:system-ui;color:#153747"><main style="max-width:620px;margin:12vh auto;padding:28px"><div style="background:#fff;border:1px solid #dce7ec;border-radius:22px;padding:28px;box-shadow:0 20px 50px rgba(15,48,69,.08)"><b style="color:#087fc7">VISIONFORGE OS</b><h1>Esta área ainda não foi salva offline</h1><p>Abra esta página pelo menos uma vez com internet. Depois ela ficará disponível no aplicativo mesmo sem conexão.</p><button onclick="history.back()" style="border:0;border-radius:10px;padding:12px 17px;background:#087fc7;color:#fff;font-weight:700">Voltar</button></div></main></body></html>',{status:503,headers:{'Content-Type':'text/html; charset=utf-8','X-VFOS-Offline':'1'}});}

self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const c=await caches.open(STATIC_CACHE);await Promise.allSettled(ASSETS.map(u=>c.add(new Request(u,{credentials:'same-origin'}))));
    self.skipWaiting();
  })());
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const names=await caches.keys();
    const keep=new Set([STATIC_CACHE,PAGE_CACHE,CONFIG_CACHE]);
    await Promise.all(names.filter(n=>n.startsWith(VFOS_PREFIX)&&!keep.has(n)).map(n=>caches.delete(n)));
    await self.clients.claim();
  })());
});
self.addEventListener('message',event=>{
  const d=event.data||{};
  if(d.type==='VFOS_SET_MODE')event.waitUntil(saveMode(d.mode,d.fast));
  if(d.type==='VFOS_WARM_PAGES'&&Array.isArray(d.urls))event.waitUntil((async()=>{
    const c=await caches.open(PAGE_CACHE);
    for(const u of d.urls.slice(0,30)){
      try{
        const url=new URL(u);
        if(!isVisionForgePage(url))continue;
        const req=new Request(u,{credentials:'same-origin',cache:'no-store'});
        const r=await fetch(req);
        if(r.ok)await c.put(req,r.clone());
      }catch(e){}
    }
  })());
  if(d.type==='VFOS_CLEAR_OFFLINE')event.waitUntil((async()=>{
    await caches.delete(PAGE_CACHE);
    await caches.open(PAGE_CACHE);
    await saveMode('auto',true);
  })());
});

async function staticResponse(req){
  const cache=await caches.open(STATIC_CACHE),hit=await cache.match(req,{ignoreSearch:false});
  if(hit){fetch(req).then(r=>{if(r.ok)cache.put(req,r.clone());}).catch(()=>{});return hit;}
  try{const r=await fetch(req);if(r.ok)cache.put(req,r.clone());return r;}catch(e){return hit||Response.error();}
}
async function networkAndCache(req,timeoutMs){
  const cache=await caches.open(PAGE_CACHE);
  const controller=new AbortController();
  const timer=timeoutMs?setTimeout(()=>controller.abort(),timeoutMs):null;
  try{
    const r=await fetch(req,{signal:controller.signal,credentials:'same-origin',cache:'no-store'});
    if(timer)clearTimeout(timer);
    if(r&&r.ok)await cache.put(req,r.clone());
    return r;
  }catch(e){
    if(timer)clearTimeout(timer);
    const hit=await cache.match(req);
    return hit||offlinePage();
  }
}
async function fastCachedPage(req){
  const cache=await caches.open(PAGE_CACHE),hit=await cache.match(req);
  if(hit){
    fetch(req,{credentials:'same-origin',cache:'no-store'}).then(r=>{if(r&&r.ok)cache.put(req,r.clone());}).catch(()=>{});
    return hit;
  }
  // Em página ainda não armazenada, não aborta cedo demais em internet fraca.
  return networkAndCache(req,15000);
}
self.addEventListener('fetch',event=>{
  const req=event.request,url=new URL(req.url);
  if(req.method!=='GET')return;

  // v1.32.7: páginas HTML nunca são interceptadas.
  // Isso garante que menus, links e formulários naveguem exatamente como no WordPress.
  if(req.mode==='navigate')return;

  // Apenas arquivos estáticos podem ser servidos pelo cache.
  if(isStatic(url))event.respondWith(staticResponse(req));
});
        <?php
    }

    public static function head(){
        $page=sanitize_key($_GET['page']??'');if(strpos($page,'vfos')!==0)return;
        $warm=[];
        foreach(['vfos','vfos-clients','vfos-quotes','vfos-projects','vfos-tasks','vfos-calendar','vfos-financial','vfos-contracts','vfos-notifications','vfos-app'] as $p){
            if($p==='vfos'||VFOS_Team::can(str_replace(['vfos-','-templates'],['',''],$p)))$warm[]=admin_url('admin.php?page='.$p);
        }
        echo '<link rel="manifest" href="'.esc_url(self::manifest_url()).'">';
        echo '<meta name="theme-color" content="#087fc7"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="VisionForge OS">';
        echo '<link rel="apple-touch-icon" href="'.esc_url(VFOS_URL.'admin/assets/images/vfos-app-192-v2.png').'">';
        echo '<script>window.VFOS_PWA='.wp_json_encode(['sw'=>self::sw_url(),'start'=>admin_url('admin.php?page=vfos'),'user'=>get_current_user_id(),'version'=>VFOS_VERSION,'warm'=>$warm]).';</script>';
    }

    public static function login_head(){
        echo '<link rel="manifest" href="'.esc_url(self::manifest_url()).'"><meta name="theme-color" content="#087fc7"><link rel="apple-touch-icon" href="'.esc_url(VFOS_URL.'admin/assets/images/vfos-app-192-v2.png').'">';
    }
}
