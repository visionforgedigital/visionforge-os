<?php
if(!defined('ABSPATH'))exit;

class VFOS_Recurring{
    public static function init(){
        add_action('admin_post_vfos_save_recurring',[__CLASS__,'save']);
        add_action('admin_post_vfos_delete_recurring',[__CLASS__,'delete']);
        add_action('admin_post_vfos_toggle_recurring',[__CLASS__,'toggle']);
        add_action('admin_post_vfos_sync_recurring',[__CLASS__,'sync_action']);
        add_action('admin_post_vfos_email_recurring',[__CLASS__,'email_action']);

        add_action('wp_ajax_vfos_recurring_card_authorize',[__CLASS__,'ajax_card_authorize']);
        add_action('wp_ajax_nopriv_vfos_recurring_card_authorize',[__CLASS__,'ajax_card_authorize']);
        add_action('wp_ajax_vfos_recurring_pix_authorize',[__CLASS__,'ajax_pix_authorize']);
        add_action('wp_ajax_nopriv_vfos_recurring_pix_authorize',[__CLASS__,'ajax_pix_authorize']);
        add_action('wp_ajax_vfos_recurring_public_status',[__CLASS__,'ajax_public_status']);
        add_action('wp_ajax_nopriv_vfos_recurring_public_status',[__CLASS__,'ajax_public_status']);

        add_action('template_redirect',[__CLASS__,'route'],0);
        add_action('vfos_recurring_daily',[__CLASS__,'daily_sync']);
        add_action('vfos_recurring_first_payment_probe',[__CLASS__,'first_payment_probe'],10,1);
        if(!wp_next_scheduled('vfos_recurring_daily'))wp_schedule_event(time()+300,'daily','vfos_recurring_daily');
    }

    public static function table(){return VFOS_DB::table('financial_recurring');}
    public static function url($token){return add_query_arg(['vfos_subscription'=>'1','token'=>$token],home_url('/'));}

    private static function api($method,$path,$body=null,$idempotency=''){
        $s=VFOS_MercadoPago::settings();$token=trim($s['access_token']??'');
        if(!$token)return new WP_Error('mp_no_token','Access Token do Mercado Pago não configurado.');
        $headers=['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json','Accept'=>'application/json'];
        if($idempotency)$headers['X-Idempotency-Key']=$idempotency;
        $args=['method'=>$method,'timeout'=>50,'headers'=>$headers];
        if($body!==null)$args['body']=wp_json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $r=wp_remote_request('https://api.mercadopago.com'.$path,$args);
        if(is_wp_error($r))return $r;
        $code=wp_remote_retrieve_response_code($r);$json=json_decode(wp_remote_retrieve_body($r),true);
        if($code<200||$code>=300)return new WP_Error('mp_subscription_api',$json['message']??($json['error']??('Mercado Pago respondeu HTTP '.$code)),['code'=>$code,'response'=>$json]);
        return is_array($json)?$json:[];
    }

    private static function interval_spec($frequency,$count=1){
        $count=max(1,(int)$count);
        switch($frequency){
            case 'weekly': return [7*$count,'days'];
            case 'quarterly': return [3*$count,'months'];
            case 'semiannual': return [6*$count,'months'];
            case 'annual': return [12*$count,'months'];
            default: return [$count,'months'];
        }
    }

    private static function next_date($date,$frequency,$count=1){
        $count=max(1,(int)$count);$ts=strtotime($date?:date('Y-m-d'));
        switch($frequency){
            case 'weekly': return date('Y-m-d',strtotime("+{$count} week",$ts));
            case 'quarterly': return date('Y-m-d',strtotime("+".(3*$count)." month",$ts));
            case 'semiannual': return date('Y-m-d',strtotime("+".(6*$count)." month",$ts));
            case 'annual': return date('Y-m-d',strtotime("+{$count} year",$ts));
            default:return date('Y-m-d',strtotime("+{$count} month",$ts));
        }
    }

    private static function iso_date($date,$now=false){
        if($now)return gmdate('Y-m-d\TH:i:s.000\Z',time());
        $ts=strtotime($date.' 12:00:00 UTC');return gmdate('Y-m-d\TH:i:s.000\Z',$ts);
    }

    private static function row_by_token($token){
        global $wpdb;$token=sanitize_text_field($token);
        return $wpdb->get_row($wpdb->prepare("SELECT r.*,c.name client_name,c.email client_email,c.billing_email FROM ".self::table()." r LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=r.client_id WHERE r.public_token=%s",$token));
    }

    public static function save(){
        check_admin_referer('vfos_save_recurring');VFOS_Team::require_permission('financial.create');global $wpdb;
        $id=absint($_POST['id']??0);$old=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",$id)):null;
        $freq=sanitize_key($_POST['frequency']??'monthly');if(!in_array($freq,['weekly','monthly','quarterly','semiannual','annual'],true))$freq='monthly';
        $method=sanitize_key($_POST['subscription_method']??'choose');if(!in_array($method,['choose','card','pix'],true))$method='choose';
        $first=sanitize_key($_POST['first_charge_mode']??'now');if(!in_array($first,['now','due'],true))$first='now';
        $next=sanitize_text_field($_POST['next_due_date']??date('Y-m-d'));
        if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$next))$next=date('Y-m-d');
        $end=sanitize_text_field($_POST['end_date']??'');if($end&&!preg_match('/^\d{4}-\d{2}-\d{2}$/',$end))$end='';
        $client_id=absint($_POST['client_id']??0);
        $payer=sanitize_email($_POST['payer_email']??'');
        if(!$payer&&$client_id)$payer=sanitize_email($wpdb->get_var($wpdb->prepare("SELECT COALESCE(NULLIF(billing_email,''),email) FROM ".VFOS_DB::table('clients')." WHERE id=%d",$client_id)));
        $public=$old&&$old->public_token?$old->public_token:wp_generate_password(54,false,false);
        $data=[
            'client_id'=>$client_id,'project_id'=>absint($_POST['project_id']??0),'contract_id'=>absint($_POST['contract_id']??0),
            'title'=>sanitize_text_field(wp_unslash($_POST['title']??'')),'amount'=>max(0,(float)str_replace(',','.',$_POST['amount']??0)),
            'frequency'=>$freq,'interval_count'=>max(1,min(24,absint($_POST['interval_count']??1))),
            'next_due_date'=>$next,'end_date'=>$end?:null,'auto_generate'=>1,
            'payment_method'=>'Mercado Pago Assinaturas','gateway'=>'mercadopago','subscription_method'=>$method,'first_charge_mode'=>$first,
            'billing_day'=>($freq==='monthly'&&(int)date('j',strtotime($next))<=28?(int)date('j',strtotime($next)):0),'payer_email'=>$payer,'public_token'=>$public,
            'notes'=>sanitize_textarea_field(wp_unslash($_POST['notes']??'')),
            'status'=>$old&&in_array($old->status,['active','paused'],true)?$old->status:'pending_authorization','updated_at'=>current_time('mysql')
        ];
        if(!$data['title']||$data['amount']<=0)wp_die('Informe título e valor da assinatura.');
        if($id)$ok=$wpdb->update(self::table(),$data,['id'=>$id]);
        else{$data['created_by']=get_current_user_id();$data['created_at']=current_time('mysql');$ok=$wpdb->insert(self::table(),$data);$id=(int)$wpdb->insert_id;}
        if($ok===false||!$id)wp_die('Não foi possível salvar a assinatura recorrente: '.esc_html($wpdb->last_error?:'erro no banco de dados.'));
        VFOS_DB::log('save_recurring','financial_recurring',$id,'Assinatura recorrente salva | '.$freq.' | primeira cobrança='.$first,$old?(array)$old:null,$data,$data['title']);
        $url=self::url($public);
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=recurring&edit_recurring='.$id.'&vfos_msg='.rawurlencode('Assinatura salva. Envie o link de autorização ao cliente: '.$url)));exit;
    }

    public static function email_action(){
        $id=absint($_GET['id']??0);check_admin_referer('vfos_email_recurring_'.$id);VFOS_Team::require_permission('financial.payments');global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT r.*,c.name client_name,c.email client_email,c.billing_email FROM ".self::table()." r LEFT JOIN ".VFOS_DB::table('clients')." c ON c.id=r.client_id WHERE r.id=%d",$id));
        if(!$r)wp_die('Assinatura não encontrada.');
        $email=sanitize_email($r->payer_email?:($r->billing_email?:$r->client_email));if(!$email)wp_die('O cliente não possui e-mail válido.');
        $brand='VisionForge Digital';$company=get_option('vfos_company_info',[]);if(is_array($company)&&!empty($company['name']))$brand=$company['name'];
        $first=$r->first_charge_mode==='now'?'A primeira mensalidade entra no ciclo imediatamente após a autorização.':'A primeira cobrança ocorrerá em '.date_i18n('d/m/Y',strtotime($r->next_due_date)).'.';
        $failed=$r->gateway_status==='payment_failed';
        $action=$failed?'Atualize o cartão da sua assinatura':'Autorize sua assinatura recorrente';
        $body="Olá ".($r->client_name?:'').",\n\n{$action}: {$r->title}\nValor: R$ ".number_format((float)$r->amount,2,',','.')."\n{$first}\n\nAcesse a página segura da VisionForge:\n".self::url($r->public_token)."\n\n".($failed?'Identificamos uma falha na última tentativa de cobrança. Cadastre um novo cartão para as próximas tentativas.':'Depois da autorização, as próximas cobranças no cartão serão processadas automaticamente pelo Mercado Pago.')."\n\n{$brand}";
        if(!wp_mail($email,$brand.($failed?' • Atualize seu meio de pagamento':' • Autorize sua assinatura recorrente'),$body))wp_die('Não foi possível enviar o e-mail.');
        VFOS_DB::log('email_recurring','financial_recurring',$id,'Link de autorização enviado por e-mail para '.$email);
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=recurring&vfos_msg='.rawurlencode('Link de autorização enviado para '.$email.'.')));exit;
    }

    private static function cancel_preapproval($subscription_id){
        $subscription_id=trim((string)$subscription_id);if(!$subscription_id)return true;
        $current=self::api('GET','/preapproval/'.rawurlencode($subscription_id));
        if(!is_wp_error($current)){
            $st=sanitize_key($current['status']??'');
            if(in_array($st,['canceled','cancelled'],true))return $current;
        }
        // Algumas contas/versões do endpoint retornam erro para "canceled" e aceitam "cancelled".
        // Tentamos primeiro o valor observado na API real e mantemos fallback para o valor documentado.
        $attempts=['cancelled','canceled'];$last=null;
        foreach($attempts as $status){
            $res=self::api('PUT','/preapproval/'.rawurlencode($subscription_id),['status'=>$status]);
            if(!is_wp_error($res))return $res;
            $last=$res;
        }
        return $last?:new WP_Error('cancel_failed','O Mercado Pago não confirmou o cancelamento.');
    }

    public static function toggle(){
        $id=absint($_GET['id']??0);check_admin_referer('vfos_toggle_recurring_'.$id);VFOS_Team::require_permission('financial.edit');global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",$id));if(!$r)wp_die('Assinatura não encontrada.');
        $new=$r->status==='active'?'paused':'active';
        if($r->gateway_subscription_id){
            $mpstatus=$new==='paused'?'paused':'authorized';
            $res=self::api('PUT','/preapproval/'.rawurlencode($r->gateway_subscription_id),['status'=>$mpstatus]);
            if(is_wp_error($res))wp_die('Mercado Pago: '.esc_html($res->get_error_message()));
            $wpdb->update(self::table(),['gateway_status'=>sanitize_key($res['status']??$mpstatus),'gateway_raw'=>wp_json_encode($res),'last_sync_at'=>current_time('mysql')],['id'=>$id]);
        }
        $wpdb->update(self::table(),['status'=>$new,'updated_at'=>current_time('mysql')],['id'=>$id]);
        VFOS_DB::log('toggle_recurring','financial_recurring',$id,'Assinatura '.($new==='paused'?'pausada':'reativada'));
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=recurring'));exit;
    }

    public static function delete(){
        $id=absint($_GET['id']??0);check_admin_referer('vfos_delete_recurring_'.$id);VFOS_Team::require_permission('financial.delete');global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",$id));if(!$r)wp_die('Assinatura não encontrada.');
        if($r->gateway_subscription_id&&!in_array($r->gateway_status,['canceled','cancelled'],true)){
            $res=self::cancel_preapproval($r->gateway_subscription_id);
            if(is_wp_error($res))wp_die('Não foi possível cancelar a assinatura no Mercado Pago. Nada foi apagado no VisionForge. Motivo: '.esc_html($res->get_error_message()));
            $wpdb->update(self::table(),['gateway_status'=>sanitize_key($res['status']??'cancelled'),'status'=>'cancelled','gateway_raw'=>wp_json_encode($res),'last_sync_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],['id'=>$id]);
        }
        $old=(array)$r;$wpdb->delete(self::table(),['id'=>$id]);VFOS_DB::log('delete_recurring','financial_recurring',$id,'Assinatura cancelada no gateway e excluída do VisionForge',$old,null,$r->title);
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=recurring'));exit;
    }

    public static function sync_action(){
        $id=absint($_GET['id']??0);check_admin_referer('vfos_sync_recurring_'.$id);VFOS_Team::require_permission('financial.view');
        $res=self::sync($id);$msg=is_wp_error($res)?$res->get_error_message():'Assinatura sincronizada com o Mercado Pago.';
        wp_safe_redirect(admin_url('admin.php?page=vfos-financial&tab=recurring&vfos_msg='.rawurlencode($msg)));exit;
    }

    public static function sync($id){
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",$id));if(!$r)return new WP_Error('not_found','Assinatura não encontrada.');
        if(!$r->gateway_subscription_id)return new WP_Error('not_authorized','O cliente ainda não autorizou a cobrança recorrente.');
        $mp=self::api('GET','/preapproval/'.rawurlencode($r->gateway_subscription_id));if(is_wp_error($mp))return $mp;
        self::store_subscription($r,$mp);self::sync_invoices($r);return $mp;
    }

    private static function store_subscription($r,$mp){
        global $wpdb;$status=sanitize_key($mp['status']??'');
        $local=in_array($status,['authorized','active'],true)?'active':(in_array($status,['paused'],true)?'paused':(in_array($status,['canceled','cancelled'],true)?'cancelled':'pending_authorization'));
        $next=$r->next_due_date;
        if(!empty($mp['next_payment_date']))$next=date('Y-m-d',strtotime($mp['next_payment_date']));
        $wpdb->update(self::table(),[
            'gateway_subscription_id'=>(string)($mp['id']??$r->gateway_subscription_id),
            'gateway_plan_id'=>(string)($mp['preapproval_plan_id']??$r->gateway_plan_id),
            'gateway_status'=>$status,'status'=>$local,'next_due_date'=>$next,
            'authorized_at'=>($local==='active'&&empty($r->authorized_at))?current_time('mysql'):$r->authorized_at,
            'gateway_raw'=>wp_json_encode($mp,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'last_sync_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')
        ],['id'=>$r->id]);
    }

    private static function sync_invoices($r){
        if(!$r||empty($r->gateway_subscription_id))return false;
        $path='/authorized_payments/search?preapproval_id='.rawurlencode($r->gateway_subscription_id).'&sort=date_created&criteria=desc&limit=20';
        $data=self::api('GET',$path);if(is_wp_error($data))return $data;
        $results=is_array($data['results']??null)?$data['results']:[];
        foreach($results as $invoice){
            $payment_id=(string)($invoice['payment']['id']??'');
            $pstatus=sanitize_key($invoice['payment']['status']??($invoice['status']??''));
            if($payment_id&&$pstatus==='approved'){
                self::record_payment($r,$payment_id,(float)($invoice['transaction_amount']??$r->amount),$invoice['debit_date']??($invoice['date_created']??current_time('mysql')),'Mercado Pago — Assinatura');
            }elseif(in_array($pstatus,['rejected','cancelled','canceled'],true)){
                $wpdb->update(self::table(),['gateway_status'=>'payment_failed','updated_at'=>current_time('mysql')],['id'=>$r->id]);
                VFOS_DB::log('recurring_payment_failed','financial_recurring',$r->id,'Falha em cobrança recorrente. Cliente deve revisar/atualizar o meio de pagamento.',null,['invoice'=>$invoice],$r->title);
            }
        }
        return $data;
    }
    public static function first_payment_probe($id){
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",absint($id)));
        if(!$r||$r->first_charge_mode!=='now'||empty($r->gateway_subscription_id)||!empty($r->last_paid_at))return;
        self::sync((int)$r->id);
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",$r->id));
        if($r&&!$r->last_paid_at&&in_array($r->status,['active','pending_authorization'],true)){
            // A documentação do Mercado Pago informa que a 1ª parcela pode levar aproximadamente 1h.
            // Mantemos sondagens curtas sem criar uma cobrança duplicada por fora da assinatura.
            $age=time()-strtotime($r->authorized_at?:$r->updated_at?:current_time('mysql'));
            if($age<4500&&!wp_next_scheduled('vfos_recurring_first_payment_probe',[(int)$r->id]))wp_schedule_single_event(time()+300,'vfos_recurring_first_payment_probe',[(int)$r->id]);
        }
    }

    public static function daily_sync(){
        global $wpdb;$rows=$wpdb->get_results("SELECT id FROM ".self::table()." WHERE gateway_subscription_id<>'' AND status IN ('active','paused','pending_authorization') ORDER BY id DESC LIMIT 300");
        foreach($rows as $r)self::sync((int)$r->id);
    }

    public static function ajax_card_authorize(){
        global $wpdb;$token=sanitize_text_field($_POST['public_token']??'');$r=self::row_by_token($token);
        if(!$r)wp_send_json_error(['message'=>'Assinatura não encontrada.'],404);
        $is_update=!empty($r->gateway_subscription_id);
        if($is_update&&$r->status==='cancelled')wp_send_json_error(['message'=>'Esta assinatura foi cancelada e não pode receber um novo cartão.'],409);
        $card=sanitize_text_field($_POST['card_token_id']??'');$email=sanitize_email($_POST['payer_email']??$r->payer_email??$r->client_email);
        if(!$card||!$email)wp_send_json_error(['message'=>'Informe um cartão válido e e-mail do pagador.'],400);
        if($is_update){
            $mp=self::api('PUT','/preapproval/'.rawurlencode($r->gateway_subscription_id),['card_token_id'=>$card]);
            if(is_wp_error($mp))wp_send_json_error(['message'=>'Não foi possível atualizar o cartão: '.$mp->get_error_message()],400);
            $wpdb->update(self::table(),['subscription_method'=>'card','payer_email'=>$email,'gateway_status'=>sanitize_key($mp['status']??'authorized'),'status'=>'active','gateway_raw'=>wp_json_encode($mp),'last_sync_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],['id'=>$r->id]);
            VFOS_DB::log('recurring_card_updated','financial_recurring',$r->id,'Cartão principal da assinatura atualizado pelo cliente.',null,['subscription_id'=>$r->gateway_subscription_id],$r->title);
            wp_send_json_success(['status'=>$mp['status']??'authorized','message'=>'Cartão atualizado com sucesso. As próximas cobranças usarão o novo cartão.','subscription_id'=>$r->gateway_subscription_id,'updated'=>true]);
        }
        [$frequency,$ftype]=self::interval_spec($r->frequency,$r->interval_count);
        $start=$r->first_charge_mode==='now'?self::iso_date('',true):self::iso_date($r->next_due_date);
        $auto=['frequency'=>$frequency,'frequency_type'=>$ftype,'start_date'=>$start,'transaction_amount'=>(float)$r->amount,'currency_id'=>'BRL'];
        if($r->end_date)$auto['end_date']=self::iso_date($r->end_date);
        $body=[
            'reason'=>$r->title,'external_reference'=>'VFOS-REC-'.$r->id.'-'.$r->public_token,'payer_email'=>$email,
            'card_token_id'=>$card,'auto_recurring'=>$auto,'back_url'=>self::url($r->public_token),'status'=>'authorized'
        ];
        $mp=self::api('POST','/preapproval',$body,'vfos-rec-card-'.$r->id.'-'.$r->public_token);
        if(is_wp_error($mp))wp_send_json_error(['message'=>$mp->get_error_message()],400);
        $wpdb->update(self::table(),['subscription_method'=>'card','payer_email'=>$email],['id'=>$r->id]);
        $fresh=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",$r->id));self::store_subscription($fresh,$mp);
        if($r->first_charge_mode==='now'){
            self::sync_invoices($fresh);
            if(!wp_next_scheduled('vfos_recurring_first_payment_probe',[(int)$r->id]))wp_schedule_single_event(time()+90,'vfos_recurring_first_payment_probe',[(int)$r->id]);
        }
        VFOS_DB::log('recurring_authorized_card','financial_recurring',$r->id,'Cobrança recorrente autorizada com cartão',null,['subscription_id'=>$mp['id']??''],$r->title);
        $message=$r->first_charge_mode==='now'?'Assinatura autorizada. A primeira mensalidade foi solicitada para o ciclo imediato e será conciliada automaticamente assim que o Mercado Pago processar a parcela.':'Cartão cadastrado e cobrança recorrente autorizada.';
        wp_send_json_success(['status'=>$mp['status']??'authorized','message'=>$message,'subscription_id'=>$mp['id']??'']);
    }

    public static function ajax_pix_authorize(){
        /*
         * O Pix comum do Checkout Transparente retorna QR Code/Copia e Cola, mas esse QR
         * é de uso único e NÃO cria autorização para débitos futuros.
         *
         * O Pix Automático do Banco Central admite QR composto para autorizar a recorrência,
         * porém o PSP do recebedor precisa expor essa jornada/API. A API pública de
         * Assinaturas /preapproval do Mercado Pago usada por este plugin não documenta
         * uma resposta com QR composto de autorização do Pix Automático.
         *
         * Por segurança financeira, não transformamos um Pix mensal manual em "automático"
         * e não enviamos o cliente ao checkout hospedado fingindo ser transparente.
         */
        $token=sanitize_text_field($_POST['public_token']??'');$r=self::row_by_token($token);
        if(!$r)wp_send_json_error(['message'=>'Assinatura não encontrada.'],404);
        VFOS_DB::log('recurring_pix_automatic_unavailable','financial_recurring',$r->id,'Pix Automático transparente solicitado, mas o provedor atual não expõe QR composto de autorização pela API pública utilizada.',null,null,$r->title);
        wp_send_json_error([
            'code'=>'pix_automatic_provider_required',
            'message'=>'Pix Automático transparente ainda não está disponível nesta integração do Mercado Pago. Um QR Code Pix comum não pode ser usado para autorizar débitos futuros. Para Pix Automático de verdade, o VisionForge precisa de um PSP/iniciador que entregue pela API o QR Code composto de autorização da recorrência.'
        ],409);
    }

    public static function ajax_public_status(){
        $token=sanitize_text_field($_REQUEST['public_token']??'');$r=self::row_by_token($token);
        if(!$r)wp_send_json_error(['message'=>'Assinatura não encontrada.'],404);
        if($r->gateway_subscription_id){
            self::sync((int)$r->id);
            if($r->first_charge_mode==='now'&&empty($r->last_paid_at)){
                $throttle='vfos_rec_invoice_poll_'.$r->id;
                if(!get_transient($throttle)){set_transient($throttle,1,15);self::sync_invoices($r);}
            }
        }
        $r=self::row_by_token($token);
        wp_send_json_success(['status'=>$r->status,'gateway_status'=>$r->gateway_status,'authorized'=>in_array($r->status,['active'],true),'payment_error'=>($r->gateway_status==='payment_failed'),'authorization_pending'=>($r->status==='pending_authorization'),'authorization_url'=>self::url($r->public_token),'next_due_date'=>$r->next_due_date,'last_paid_at'=>$r->last_paid_at,'first_charge_pending'=>($r->first_charge_mode==='now'&&empty($r->last_paid_at)&&$r->status==='active')]);
    }

    public static function handle_webhook($type,$id,$body=[]){
        global $wpdb;$id=sanitize_text_field($id);
        if($type==='subscription_preapproval'){
            $mp=self::api('GET','/preapproval/'.rawurlencode($id));if(is_wp_error($mp))return false;
            $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE gateway_subscription_id=%s",$id));
            if(!$r&&!empty($mp['preapproval_plan_id']))$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE gateway_plan_id=%s ORDER BY id DESC LIMIT 1",$mp['preapproval_plan_id']));
            if(!$r&&!empty($mp['external_reference'])&&preg_match('/^VFOS-REC-(\d+)-/',$mp['external_reference'],$m))$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",(int)$m[1]));
            if($r){self::store_subscription($r,$mp);VFOS_DB::log('recurring_webhook_preapproval','financial_recurring',$r->id,'Status de assinatura atualizado: '.($mp['status']??''));}
            return true;
        }
        if($type==='subscription_authorized_payment'){
            $invoice=self::api('GET','/authorized_payments/'.rawurlencode($id));if(is_wp_error($invoice))return false;
            $sid=(string)($invoice['preapproval_id']??'');$r=$sid?$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE gateway_subscription_id=%s",$sid)):null;
            if(!$r)return false;
            $payment_id=(string)($invoice['payment']['id']??'');$pstatus=sanitize_key($invoice['payment']['status']??($invoice['status']??''));
            if($payment_id&&$pstatus==='approved')self::record_payment($r,$payment_id,(float)($invoice['transaction_amount']??$r->amount),$invoice['debit_date']??current_time('mysql'),'Mercado Pago — Assinatura');
            elseif(in_array($pstatus,['rejected','cancelled','canceled'],true))$wpdb->update(self::table(),['gateway_status'=>'payment_failed','updated_at'=>current_time('mysql')],['id'=>$r->id]);
            if($sid)self::sync((int)$r->id);
            return true;
        }
        return false;
    }

    public static function handle_payment_webhook($payment){
        global $wpdb;$external=sanitize_text_field($payment['external_reference']??'');$sid=(string)($payment['metadata']['preapproval_id']??($payment['preapproval_id']??''));
        $r=null;
        if($sid)$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE gateway_subscription_id=%s",$sid));
        if(!$r&&preg_match('/^VFOS-REC-(\d+)-/',$external,$m))$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d",(int)$m[1]));
        if(!$r)return false;
        if(($payment['status']??'')==='approved'){
            self::record_payment($r,(string)$payment['id'],(float)($payment['transaction_amount']??$r->amount),$payment['date_approved']??current_time('mysql'),'Mercado Pago — '.(($payment['payment_method_id']??'')==='pix'?'Pix recorrente':'Assinatura'));
        }
        return true;
    }

    private static function record_payment($r,$payment_id,$amount,$date,$method){
        global $wpdb;$pt=VFOS_DB::table('financial_payments');
        if(!$payment_id||$wpdb->get_var($wpdb->prepare("SELECT id FROM $pt WHERE provider='mercadopago' AND provider_payment_id=%s",$payment_id)))return;
        $date_mysql=date('Y-m-d H:i:s',strtotime($date));$due=date('Y-m-d',strtotime($date));
        $ft=VFOS_DB::table('financial');
        $wpdb->insert($ft,[
            'client_id'=>$r->client_id,'project_id'=>$r->project_id,'type'=>'income','description'=>$r->title,
            'amount'=>$amount,'paid_amount'=>$amount,'status'=>'paid','due_date'=>$due,'paid_at'=>$date_mysql,'method'=>$method,
            'source_type'=>'subscription','source_id'=>$r->id,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')
        ]);
        $fid=(int)$wpdb->insert_id;if(!$fid)return;
        $wpdb->insert($pt,[
            'financial_id'=>$fid,'amount'=>$amount,'payment_date'=>$date_mysql,'method'=>$method,'notes'=>'Cobrança recorrente automática',
            'created_by'=>0,'provider'=>'mercadopago','provider_payment_id'=>$payment_id,'charge_id'=>0,'created_at'=>current_time('mysql')
        ]);
        $next=self::next_date($r->next_due_date?:$due,$r->frequency,$r->interval_count);
        $wpdb->update(self::table(),['last_financial_id'=>$fid,'last_payment_id'=>$payment_id,'last_paid_at'=>$date_mysql,'next_due_date'=>$next,'updated_at'=>current_time('mysql')],['id'=>$r->id]);
        VFOS_DB::log('recurring_payment_approved','financial_recurring',$r->id,'Mensalidade recebida automaticamente | R$ '.number_format($amount,2,',','.'),null,['payment_id'=>$payment_id,'financial_id'=>$fid],$r->title);
        if(class_exists('VFOS_Notifications'))VFOS_Notifications::activity('recurring_payment','Mensalidade recebida automaticamente',$r->title.' • R$ '.number_format($amount,2,',','.'),'financial','financial',$fid,admin_url('admin.php?page=vfos-financial&tab=receipts'));
    }

    public static function route(){
        if(isset($_GET['vfos_subscription']))self::public_page();
    }

    private static function public_page(){
        $token=sanitize_text_field($_GET['token']??'');$r=self::row_by_token($token);
        if(!$r){status_header(404);wp_die('Assinatura não encontrada.');}
        $mp=VFOS_MercadoPago::settings();$public_key=trim($mp['public_key']??'');$ajax=admin_url('admin-ajax.php');
        $company=get_option('vfos_company_info',[]);$brand=is_array($company)&&!empty($company['name'])?$company['name']:'VisionForge Digital';
        $first=$r->first_charge_mode==='now'?'A primeira mensalidade entra no ciclo de cobrança imediatamente após a autorização. O Mercado Pago informa que a primeira parcela da assinatura pode levar aproximadamente até 1 hora para ser efetivamente debitada.':'Nenhuma mensalidade será cobrada agora. A primeira cobrança será em '.date_i18n('d/m/Y',strtotime($r->next_due_date)).'.';
        nocache_headers();?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Assinatura — <?php echo esc_html($brand);?></title>
        <?php if($public_key):?><script src="https://sdk.mercadopago.com/js/v2"></script><?php endif;?>
        <style>
        *{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 20% 0,#eaf7ff 0,#f4f8fa 35%,#eef3f5 100%);font-family:Inter,system-ui,-apple-system,sans-serif;color:#17394d}.wrap{max-width:860px;margin:36px auto;padding:18px}.shell{background:#fff;border:1px solid #dce8ed;border-radius:26px;overflow:hidden;box-shadow:0 24px 70px #17394d18}.top{padding:28px 30px;background:linear-gradient(135deg,#11354b,#087fc7);color:#fff}.brand{font-size:13px;font-weight:900;letter-spacing:.04em}.top h1{margin:12px 0 5px;font-size:30px}.top p{margin:0;color:#d9ebf4}.summary{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;padding:25px 30px;border-bottom:1px solid #e2ecef}.price{font-size:36px;font-weight:900}.price small{font-size:13px;color:#6d8590}.first{padding:13px;border-radius:12px;background:#f2f9fc;color:#537180;font-size:12px;line-height:1.5}.methods{padding:25px 30px}.methods h2{margin:0 0 4px}.methods>p{margin:0 0 17px;color:#748892;font-size:12px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}.method{border:1px solid #dce8ed;border-radius:17px;padding:17px;background:#fff}.method h3{margin:0 0 4px}.method p{font-size:11px;color:#768993;line-height:1.5}.badge{display:inline-flex;padding:5px 7px;border-radius:99px;background:#eaf7ef;color:#337552;font-size:9px;font-weight:900}.btn{width:100%;border:0;border-radius:11px;padding:12px 14px;background:#087fc7;color:#fff;font-weight:850;cursor:pointer}.btn.pix{background:#2f8b63}.muted{font-size:10px;color:#82949d}.state{padding:14px;border-radius:12px;background:#fff7e7;color:#82612c;margin:0 30px 22px}.state.ok{background:#eaf8ef;color:#32734b}.result{display:none;padding:11px;border-radius:10px;margin-top:10px;font-size:12px}.result.ok{display:block;background:#eaf8ef;color:#32734b}.result.err{display:block;background:#fff0f0;color:#a33d3d}.loading{display:none;position:fixed;inset:0;background:#0b2536aa;z-index:9999;place-items:center}.loading.on{display:grid}.pix-auth{display:none;position:fixed;inset:0;background:#0b2536b8;z-index:9998;place-items:center;padding:18px}.pix-auth.on{display:grid}.pix-auth-box{width:min(520px,96vw);padding:22px;border-radius:18px;background:#fff;box-shadow:0 24px 70px #0005}.pix-auth-box h3{margin:0 0 7px}.pix-auth-box p{color:#6f8490;font-size:12px;line-height:1.55}.pix-auth-actions{display:flex;gap:8px;flex-wrap:wrap}.pix-auth-actions .btn{width:auto;margin:0}.pix-auth-actions .secondary{background:#eef5f8;color:#315565}.loaderbox{padding:20px 25px;border-radius:16px;background:#fff;box-shadow:0 20px 60px #0004;text-align:center}.spinner{width:34px;height:34px;border:4px solid #dcebf2;border-top-color:#087fc7;border-radius:50%;margin:0 auto 10px;animation:spin .8s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}#cardPaymentBrick_container{min-height:250px;margin-top:12px}@media(max-width:700px){.wrap{margin:7px auto;padding:8px}.summary,.grid{grid-template-columns:1fr}.top,.summary,.methods{padding:20px}.state{margin:0 20px 18px}.price{font-size:31px}}
        </style></head><body><div id="pix-auth" class="pix-auth"><div class="pix-auth-box"><span class="badge">PIX AUTOMÁTICO</span><h3>Confirme a autorização bancária</h3><p>A página da VisionForge continuará aberta e verificará a autorização automaticamente. A confirmação final precisa acontecer no ambiente seguro autorizado pelo Mercado Pago ou pelo seu banco.</p><div class="pix-auth-actions"><button id="pix-open-auth" class="btn pix" type="button">Abrir autorização segura</button><button id="pix-close-auth" class="btn secondary" type="button">Fechar aviso</button></div><div id="pix-auth-status" class="result"></div></div></div><div id="loading" class="loading"><div class="loaderbox"><div class="spinner"></div><strong>Processando autorização...</strong><div class="muted">Não feche esta página.</div></div></div><main class="wrap"><section class="shell"><div class="top"><div class="brand"><?php echo esc_html($brand);?></div><h1><?php echo esc_html($r->title);?></h1><p>Autorize uma vez e as próximas cobranças serão processadas automaticamente.</p></div><div class="summary"><div><span class="muted">VALOR RECORRENTE</span><div class="price">R$ <?php echo number_format((float)$r->amount,2,',','.');?> <small>/ <?php echo esc_html($r->frequency==='monthly'?'mês':$r->frequency);?></small></div><div class="muted"><?php echo esc_html($r->client_name?:'Cliente');?></div></div><div class="first"><?php echo esc_html($first);?></div></div>
        <?php if($r->status==='active'):?><div id="state" class="state ok"><?php echo ($r->first_charge_mode==='now'&&empty($r->last_paid_at))?'✓ Assinatura autorizada. A primeira mensalidade está aguardando processamento pelo Mercado Pago; a baixa será registrada automaticamente assim que aprovada.':'✓ Assinatura autorizada. As próximas cobranças serão realizadas automaticamente pelo Mercado Pago.';?></div><?php else:?><div id="state" class="state">Aguardando sua autorização. Escolha como deseja deixar o pagamento recorrente.</div><?php endif;?>
        <?php if($r->status!=='active'):?><div class="methods"><h2>Escolha a forma de pagamento recorrente transparente</h2><p>Você inicia tudo pela página da VisionForge. Depois da autorização inicial, o gateway executa as cobranças automaticamente conforme o vencimento.</p><div class="grid">
        <?php if(in_array($r->subscription_method,['choose','card'],true)):?><article class="method"><span class="badge">AUTOMÁTICO</span><h3>Cartão de crédito recorrente</h3><p>Cadastre o cartão de crédito com segurança. O Mercado Pago guarda a autorização/token e faz as próximas cobranças sem você precisar preencher novamente.</p><p class="muted"><strong>Débito recorrente:</strong> o Mercado Pago não disponibiliza cartão de débito para Assinaturas no Brasil. Para débito automático recorrente, use Pix Automático.</p><?php if(!$public_key):?><div class="result err" style="display:block">A Public Key do Mercado Pago ainda não está configurada.</div><?php else:?><div id="cardPaymentBrick_container"></div><div id="card-result" class="result"></div><?php endif;?></article><?php endif;?>
        <?php if(in_array($r->subscription_method,['choose','pix'],true)):?><article class="method"><span class="badge">PIX AUTOMÁTICO</span><h3>Pix recorrente</h3><p>Todo o fluxo é iniciado nesta página da VisionForge. Para a autorização bancária obrigatória, abrimos somente uma janela segura de consentimento e mantemos esta página aberta acompanhando o status.</p><button id="pix-btn" class="btn pix" type="button">Autorizar Pix Automático</button><div id="pix-result" class="result"></div><p class="muted">Você não perde esta página. A janela de autorização pode ser fechada automaticamente quando o consentimento for confirmado.</p></article><?php endif;?>
        </div></div><?php endif;?>
        <div style="padding:0 30px 25px" class="muted">Pagamento e recorrência processados pelo Mercado Pago com experiência VisionForge. O VisionForge OS não armazena número completo do cartão nem CVV.</div></section></main>
        <script>
        (function(){
          const token=<?php echo wp_json_encode($r->public_token);?>, ajax=<?php echo wp_json_encode($ajax);?>;
          const loading=document.getElementById('loading'); function load(v){loading.classList.toggle('on',!!v)}
          async function post(data){const fd=new URLSearchParams(data);const res=await fetch(ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},credentials:'same-origin',body:fd.toString()});return res.json();}
          let pixAuthUrl='',pixPopup=null,pixPoll=null;
          const pix=document.getElementById('pix-btn'),pixModal=document.getElementById('pix-auth'),pixOpen=document.getElementById('pix-open-auth'),pixClose=document.getElementById('pix-close-auth'),pixStatus=document.getElementById('pix-auth-status');
          function openPixConsent(){
            if(!pixAuthUrl)return;
            const w=520,h=760,left=Math.max(0,(screen.width-w)/2),top=Math.max(0,(screen.height-h)/2);
            pixPopup=window.open(pixAuthUrl,'vfosPixAutomatico','popup=yes,width='+w+',height='+h+',left='+left+',top='+top+',resizable=yes,scrollbars=yes');
            if(!pixPopup){pixStatus.className='result err';pixStatus.textContent='Seu navegador bloqueou a janela. Clique novamente em “Abrir autorização segura” e permita pop-ups para este site.';return;}
            pixStatus.className='result ok';pixStatus.textContent='Janela segura aberta. Conclua a autorização e volte para esta tela.';
          }
          if(pixOpen)pixOpen.addEventListener('click',openPixConsent);
          if(pixClose)pixClose.addEventListener('click',()=>pixModal.classList.remove('on'));
          if(pix)pix.addEventListener('click',async()=>{const out=document.getElementById('pix-result');load(true);try{
            const j=await post({action:'vfos_recurring_pix_authorize',public_token:token});if(!j.success)throw new Error((j.data&&j.data.message)||'Não foi possível iniciar o Pix Automático.');
            pixAuthUrl=j.data.url;pixModal.classList.add('on');out.className='result ok';out.textContent='Autorização preparada. Confirme na janela segura sem sair da VisionForge.';
            openPixConsent();
          }catch(e){out.className='result err';out.textContent=e.message;}finally{load(false)}});
          async function check(){try{const j=await post({action:'vfos_recurring_public_status',public_token:token});if(j.success&&j.data.authorized){
            if(pixPopup&&!pixPopup.closed)try{pixPopup.close()}catch(e){};
            if(pixModal)pixModal.classList.remove('on');
            const s=document.getElementById('state');if(s){s.className='state ok';s.textContent=j.data.first_charge_pending?'✓ Assinatura autorizada. A primeira mensalidade está em processamento pelo Mercado Pago e será registrada automaticamente quando aprovada.':'✓ Assinatura autorizada. As próximas cobranças serão realizadas automaticamente.';if(!j.data.first_charge_pending)setTimeout(()=>location.reload(),1200);}return true;
          }}catch(e){}return false;}
          pixPoll=setInterval(check,4000);
          <?php if($public_key&&$r->status!=='active'&&in_array($r->subscription_method,['choose','card'],true)):?>
          document.addEventListener('DOMContentLoaded',async function(){try{
            const mp=new MercadoPago(<?php echo wp_json_encode($public_key);?>,{locale:'pt-BR'}),builder=mp.bricks();
            window.vfosRecurringBrick=await builder.create('cardPayment','cardPaymentBrick_container',{
              initialization:{amount:<?php echo json_encode((float)$r->amount);?>,payer:{email:<?php echo wp_json_encode($r->payer_email?:$r->client_email);?>}},
              customization:{paymentMethods:{types:{excluded:['debit_card','prepaid_card']}}},
              callbacks:{
                onReady:()=>{},
                onSubmit:(formData)=>new Promise(async(resolve,reject)=>{const out=document.getElementById('card-result');load(true);try{
                  const payer=formData.payer||{};const j=await post({action:'vfos_recurring_card_authorize',public_token:token,card_token_id:formData.token||'',payer_email:payer.email||<?php echo wp_json_encode($r->payer_email?:$r->client_email);?>});
                  if(!j.success)throw new Error((j.data&&j.data.message)||'Não foi possível autorizar a assinatura.');
                  out.className='result ok';out.textContent='✓ '+(j.data.message||'Assinatura autorizada.');setTimeout(()=>location.reload(),1100);resolve();
                }catch(e){out.className='result err';out.textContent=e.message;reject();}finally{load(false)}}),
                onError:()=>{const out=document.getElementById('card-result');out.className='result err';out.textContent='Não foi possível carregar ou validar o cartão.';}
              }
            });
          }catch(e){const out=document.getElementById('card-result');out.className='result err';out.textContent='Não foi possível iniciar o formulário de cartão.';}});<?php endif;?>
        })();
        </script></body></html><?php exit;
    }
}
