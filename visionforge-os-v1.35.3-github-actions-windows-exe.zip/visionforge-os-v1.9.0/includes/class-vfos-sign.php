<?php
if (!defined('ABSPATH')) exit;
class VFOS_Sign {
    public static function init(){ add_action('vfs_contract_event',[__CLASS__,'handle_event'],10,4); }
    public static function local_available(){return class_exists('VF_Sign')&&method_exists('VF_Sign','instance')&&method_exists(VF_Sign::instance(),'os_create_contract');}
    public static function configured(){return self::local_available() || trim((string)get_option('vfos_sign_endpoint',''))!=='';}
    private static function map_local_status($status){return in_array($status,['complete','completed','signed'],true)?'signed':(in_array($status,['opened','viewed','document_viewed','sign_page_opened'],true)?'pending_signature':'sent');}
    private static function prepare_pdf($row){
        // Sempre regenera a partir do conteúdo atual para garantir o papel timbrado e a formatação da versão vigente.
        return VFOS_PDF::contract($row['title'],$row['content'],$row['number'],$row['client_name']??'');
    }
    public static function send_contract($contract_id){
        global $wpdb;$ct=VFOS_DB::table('contracts');$cl=VFOS_DB::table('clients');
        $row=$wpdb->get_row($wpdb->prepare("SELECT x.*,c.name client_name,c.email client_email,c.phone client_phone,c.document client_document FROM $ct x LEFT JOIN $cl c ON c.id=x.client_id WHERE x.id=%d",$contract_id),ARRAY_A);
        if(!$row)return new WP_Error('not_found','Contrato não encontrado.');if(!$row['client_email'])return new WP_Error('email_missing','Cadastre o e-mail do cliente antes de enviar ao VisionForge Sign.');
        $pdf=self::prepare_pdf($row);if(is_wp_error($pdf))return $pdf;$wpdb->update($ct,['pdf_path'=>$pdf,'updated_at'=>current_time('mysql')],['id'=>$contract_id]);
        if(self::local_available()){
            $r=VF_Sign::instance()->os_create_contract(['local_id'=>(int)$row['id'],'title'=>$row['title'],'pdf_path'=>$pdf,'signer'=>['name'=>$row['client_name'],'email'=>$row['client_email'],'phone'=>$row['client_phone'],'cpf'=>$row['client_document'],'role_label'=>'Contratante']]);
            if(is_wp_error($r))return $r;self::store_bridge_data($contract_id,$r);return $r;
        }
        $endpoint=trim((string)get_option('vfos_sign_endpoint',''));if(!$endpoint)return new WP_Error('no_endpoint','O VisionForge Sign não está ativo neste WordPress e nenhum endpoint remoto foi configurado.');
        $token=trim((string)get_option('vfos_sign_token',''));$payload=['source'=>'visionforge-os','contract'=>['local_id'=>(int)$row['id'],'number'=>$row['number'],'title'=>$row['title'],'content'=>$row['content'],'value'=>(float)$row['value']],'signer'=>['name'=>$row['client_name'],'email'=>$row['client_email'],'phone'=>$row['client_phone'],'cpf'=>$row['client_document']],'callback_url'=>admin_url('admin-ajax.php?action=vfos_sign_callback')];$headers=['Content-Type'=>'application/json'];if($token)$headers['Authorization']='Bearer '.$token;
        $res=wp_remote_post($endpoint,['timeout'=>45,'headers'=>$headers,'body'=>wp_json_encode($payload)]);if(is_wp_error($res))return $res;$code=wp_remote_retrieve_response_code($res);$body=json_decode(wp_remote_retrieve_body($res),true);if($code<200||$code>=300)return new WP_Error('sign_error',$body['message']??'VisionForge Sign retornou erro HTTP '.$code.'.');self::store_bridge_data($contract_id,$body);return $body;
    }
    private static function store_bridge_data($contract_id,$r){
        global $wpdb;$ct=VFOS_DB::table('contracts');$status=sanitize_key($r['status']??'draft');$mapped=self::map_local_status($status);$wpdb->update($ct,['status'=>$mapped,'sign_external_id'=>(string)($r['id']??$r['document_id']??''),'sign_public_code'=>sanitize_text_field($r['public_code']??''),'sign_url'=>esc_url_raw($r['sign_url']??$r['url']??''),'sign_admin_url'=>esc_url_raw($r['admin_url']??''),'sign_signed_url'=>esc_url_raw($r['signed_pdf_url']??''),'sign_status'=>$status,'sign_opened_at'=>$r['opened_at']??null,'sign_signed_at'=>$r['signed_at']??null,'sign_updated_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],['id'=>$contract_id]);if($mapped==='signed'){$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ct WHERE id=%d",$contract_id));if($row){if(!empty($row->flow_create_project))VFOS_Workflow::contract_to_project($contract_id);if(!empty($row->flow_create_financial))VFOS_Workflow::contract_to_financial($contract_id);}}VFOS_DB::log('contract_sent_to_sign','contract',$contract_id,(string)($r['id']??''));if(class_exists('VFOS_Notifications'))VFOS_Notifications::activity('contract_sent_to_sign','Contrato conectado ao VisionForge Sign',(string)($r['public_code']??''),'contracts','contract',$contract_id,admin_url('admin.php?page=vfos-contracts'));
    }
    public static function sync($contract_id){
        global $wpdb;$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('contracts')." WHERE id=%d",$contract_id),ARRAY_A);if(!$row||!$row['sign_external_id'])return new WP_Error('not_linked','Contrato ainda não vinculado ao VisionForge Sign.');if(!self::local_available())return new WP_Error('remote_sync','Sincronização direta disponível quando o VisionForge Sign está no mesmo WordPress.');$r=VF_Sign::instance()->os_status(absint($row['sign_external_id']));if(is_wp_error($r))return $r;self::store_bridge_data($contract_id,$r);return $r;
    }
    public static function send_invite($contract_id){
        global $wpdb;$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('contracts')." WHERE id=%d",$contract_id),ARRAY_A);if(!$row||!$row['sign_external_id'])return new WP_Error('not_linked','Primeiro crie o documento no VisionForge Sign.');if(!self::local_available())return new WP_Error('remote_invite','Envio direto do convite requer o VisionForge Sign no mesmo WordPress.');$r=VF_Sign::instance()->os_send_invite(absint($row['sign_external_id']));if(is_wp_error($r))return $r;self::store_bridge_data($contract_id,$r);return $r;
    }
    public static function handle_event($external_id,$signer_id,$event,$details=[]){
        global $wpdb;$ct=VFOS_DB::table('contracts');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ct WHERE sign_external_id=%s",(string)absint($external_id)));if(!$row)return;
        $status='sent';$local='sent';$opened=$row->sign_opened_at;$signed=$row->sign_signed_at;
        if(in_array($event,['sign_page_opened','document_viewed','email_verified'],true)){$status=$event;$local='pending_signature';if(!$opened)$opened=current_time('mysql');}
        if($event==='document_signed'){$status='partially_signed';$local='pending_signature';}
        if($event==='contract_completed'){$status='complete';$local='signed';$signed=current_time('mysql');}if($event==='signed_pdf_ready'){$status='complete';$local='signed';}
        $data=['sign_status'=>$status,'status'=>$local,'sign_opened_at'=>$opened,'sign_signed_at'=>$signed,'sign_updated_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')];
        if(self::local_available()){$r=VF_Sign::instance()->os_status(absint($external_id));if(!is_wp_error($r)){if(!empty($r['signed_pdf_url']))$data['sign_signed_url']=esc_url_raw($r['signed_pdf_url']);if(!empty($r['sign_url']))$data['sign_url']=esc_url_raw($r['sign_url']);if(!empty($r['public_code']))$data['sign_public_code']=sanitize_text_field($r['public_code']);if(!empty($r['signed_at']))$data['sign_signed_at']=$r['signed_at'];}}
        $wpdb->update($ct,$data,['id'=>$row->id]);if($local==='signed'){if(!empty($row->flow_create_project))VFOS_Workflow::contract_to_project($row->id);if(!empty($row->flow_create_financial))VFOS_Workflow::contract_to_financial($row->id);}VFOS_DB::log('vfs_event','contract',$row->id,$event);
        if(class_exists('VFOS_Notifications')&&in_array($event,['sign_page_opened','document_signed','contract_completed','signed_pdf_ready'],true)){$title=in_array($event,['contract_completed','signed_pdf_ready'],true)?'Contrato assinado':($event==='document_signed'?'Assinatura realizada':'Contrato visualizado');$users=get_users(['role__in'=>['administrator','vfos_team_member'],'fields'=>'ids']);foreach($users as $uid)if(user_can($uid,'manage_options')||VFOS_Team::can('contracts',$uid))VFOS_Notifications::notify($uid,'contract',$title,$row->title,'contracts','contract',$row->id,admin_url('admin.php?page=vfos-contracts'));}
    }
}
