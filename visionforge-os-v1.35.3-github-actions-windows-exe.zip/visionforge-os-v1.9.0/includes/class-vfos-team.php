<?php
if (!defined('ABSPATH')) exit;

class VFOS_Team {
    private static $modules=[
        'dashboard'=>'Dashboard','crm'=>'Leads / CRM','clients'=>'Clientes','services'=>'Serviços','quotes'=>'Propostas',
        'projects'=>'Projetos','tasks'=>'Tarefas','calendar'=>'Agenda','financial'=>'Financeiro','contracts'=>'Contratos',
        'sign'=>'VisionForge Sign','notifications'=>'Notificações','audit'=>'Auditoria','reports'=>'Relatórios','automations'=>'Automações',
        'ai'=>'VisionForge AI','team'=>'Equipe','settings'=>'Configurações',
    ];
    private static $permissions=[
        'dashboard'=>['view'=>'Visualizar dashboard'],
        'crm'=>['view'=>'Visualizar leads','create'=>'Cadastrar leads','edit'=>'Editar leads','delete'=>'Excluir leads','stage'=>'Mover etapa do funil','convert'=>'Converter lead em cliente'],
        'clients'=>['view'=>'Visualizar clientes','create'=>'Cadastrar clientes','edit'=>'Editar clientes','delete'=>'Excluir clientes','notes'=>'Adicionar notas','files'=>'Gerenciar arquivos','portal'=>'Gerenciar Área do Cliente e acessos'],
        'services'=>['view'=>'Visualizar serviços','create'=>'Cadastrar serviços','edit'=>'Editar serviços'],
        'quotes'=>['view'=>'Visualizar propostas','create'=>'Criar propostas','edit'=>'Editar propostas','delete'=>'Excluir propostas','send'=>'Enviar propostas','convert'=>'Gerar contrato/projeto','templates'=>'Gerenciar modelos de orçamento'],
        'projects'=>['view'=>'Visualizar projetos','create'=>'Criar projetos','edit'=>'Editar projetos','delete'=>'Excluir projetos','stages'=>'Gerenciar etapas','tasks'=>'Gerenciar tarefas do projeto','files'=>'Gerenciar arquivos','comments'=>'Comentar','approvals'=>'Gerenciar aprovações','presentation'=>'Criar/editar apresentação PDF'],
        'tasks'=>['view'=>'Visualizar tarefas','create'=>'Criar tarefas','edit'=>'Editar tarefas','delete'=>'Excluir tarefas','status'=>'Alterar status','checklist'=>'Gerenciar checklist','transfer'=>'Transferir tarefas para outros usuários'],
        'calendar'=>['view'=>'Visualizar agenda','create'=>'Criar compromissos','edit'=>'Editar compromissos','delete'=>'Excluir compromissos'],
        'financial'=>['view'=>'Visualizar financeiro','create'=>'Criar lançamentos','edit'=>'Editar lançamentos','delete'=>'Excluir lançamentos','payments'=>'Registrar recebimentos e entradas','split'=>'Gerenciar divisão entre sócios e caixa','integrations'=>'Configurar integrações financeiras e Mercado Pago'],
        'contracts'=>['view'=>'Visualizar contratos','create'=>'Criar contratos','edit'=>'Editar contratos','delete'=>'Excluir contratos','pdf'=>'Gerar/visualizar PDF','templates'=>'Gerenciar modelos','sign_create'=>'Criar documento no VF Sign','sign_sync'=>'Sincronizar com VF Sign','sign_invite'=>'Enviar convite de assinatura','sign_download'=>'Baixar documento assinado'],
        'sign'=>['view'=>'Acessar o VF Sign','create'=>'Cadastrar documentos no VF Sign','manage_signers'=>'Adicionar/remover signatários','fields'=>'Posicionar campos de assinatura','invite'=>'Enviar convites','download'=>'Visualizar/baixar PDFs e dossiês','delete'=>'Excluir documentos','settings'=>'Alterar configurações do VF Sign'],
        'notifications'=>['view'=>'Visualizar notificações','manage'=>'Marcar/gerenciar notificações','send'=>'Enviar notificações individuais','send_general'=>'Enviar notificações gerais para a equipe','delete_sent'=>'Apagar notificações enviadas'],
        'audit'=>['view'=>'Visualizar auditoria','export'=>'Exportar auditoria'],
        'reports'=>['view'=>'Visualizar relatórios','export'=>'Exportar relatórios'],
        'automations'=>['view'=>'Visualizar automações','manage'=>'Criar/editar automações'],
        'ai'=>['use'=>'Usar VisionForge AI','execute'=>'Autorizar ações da IA'],
        'team'=>['view'=>'Visualizar equipe','create'=>'Cadastrar membro','edit'=>'Editar membro','delete'=>'Remover membro','permissions'=>'Alterar permissões','groups'=>'Gerenciar grupos','group_members'=>'Gerenciar integrantes dos grupos'],
        'company'=>['view'=>'Visualizar dados institucionais','edit'=>'Alterar dados institucionais'],
        'settings'=>['view'=>'Visualizar configurações','edit'=>'Alterar configurações'],
    ];

    public static function init(){ self::install_roles(); self::sync_all_external_caps(); }
    private static function sync_all_external_caps(){
        global $wpdb;$table=VFOS_DB::table('team');$exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table));if($exists!==$table)return;
        foreach($wpdb->get_col("SELECT user_id FROM $table WHERE status='active'") as $uid)self::sync_external_caps($uid);
    }
    public static function install_roles(){
        $admin=get_role('administrator');if($admin){$admin->add_cap('vfos_access');$admin->add_cap('manage_vf_sign');}
        $role=get_role('vfos_team_member');
        if(!$role)add_role('vfos_team_member','VisionForge • Equipe',['read'=>true,'vfos_access'=>true]);
        else{$role->add_cap('read');$role->add_cap('vfos_access');}
    }
    public static function modules(){return self::$modules;}
    public static function permissions(){return self::$permissions;}
    public static function permission_label($key){
        [$module,$action]=array_pad(explode('.',$key,2),2,'');
        return self::$permissions[$module][$action]??$key;
    }
    public static function module_permissions($module){
        $out=[];foreach(self::$permissions[$module]??[] as $a=>$label)$out[]=$module.'.'.$a;return $out;
    }
    public static function all_permission_keys(){
        $out=[];foreach(array_keys(self::$permissions) as $m)$out=array_merge($out,self::module_permissions($m));return $out;
    }
    private static function full($modules){
        $out=[];foreach($modules as $m)$out=array_merge($out,self::module_permissions($m));return array_values(array_unique($out));
    }
    public static function presets(){
        $all=array_keys(self::$modules);
        return [
            'admin_os'=>['label'=>'Administrador do OS','permissions'=>self::full($all),'description'=>'Acesso completo ao VisionForge OS e ao VisionForge Sign.'],
            'manager'=>['label'=>'Gestor','permissions'=>self::full(['dashboard','crm','clients','services','quotes','projects','tasks','calendar','financial','contracts','sign','notifications','audit','reports','automations','ai']),'description'=>'Gestão ampla da operação, sem administração da equipe/configurações do OS.'],
            'commercial'=>['label'=>'Comercial','permissions'=>self::full(['dashboard','crm','clients','services','quotes','projects','tasks','calendar','notifications','ai']),'description'=>'Leads, clientes, propostas e acompanhamento comercial.'],
            'production'=>['label'=>'Produção / Designer','permissions'=>self::full(['dashboard','clients','projects','tasks','calendar','notifications','ai']),'description'=>'Projetos, tarefas, arquivos, aprovações e rotina de produção.'],
            'finance'=>['label'=>'Financeiro','permissions'=>self::full(['dashboard','clients','financial','contracts','calendar','notifications','reports']),'description'=>'Recebimentos, despesas, contratos e relatórios financeiros.'],
            'custom'=>['label'=>'Personalizado','permissions'=>['dashboard.view','tasks.view'],'description'=>'Permissões definidas individualmente.'],
        ];
    }
    public static function profile($user_id){
        global $wpdb;return $wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('team')." WHERE user_id=%d",absint($user_id)));
    }
    public static function allowed_permissions($user_id=null){
        $user_id=$user_id?:get_current_user_id();
        if(user_can($user_id,'manage_options'))return self::all_permission_keys();
        $p=self::profile($user_id);if(!$p||$p->status!=='active')return [];
        if(!empty($p->custom_permissions)){
            $decoded=json_decode($p->custom_permissions,true);
            if(is_array($decoded)){
                // Backwards compatibility: old versions stored module names only.
                $is_legacy=false;foreach($decoded as $v)if(strpos((string)$v,'.')===false){$is_legacy=true;break;}
                if($is_legacy)return self::full(array_values(array_intersect(array_keys(self::$modules),$decoded)));
                return array_values(array_intersect(self::all_permission_keys(),$decoded));
            }
        }
        $presets=self::presets();return $presets[$p->role_key]['permissions']??[];
    }
    public static function can_permission($permission,$user_id=null){
        $user_id=$user_id?:get_current_user_id();if(user_can($user_id,'manage_options'))return true;
        return in_array($permission,self::allowed_permissions($user_id),true);
    }
    public static function self_permission_edit_enabled($user_id=null){
        $user_id=$user_id?:get_current_user_id();
        if(user_can($user_id,'manage_options'))return true;
        return (bool)get_user_meta(absint($user_id),'_vfos_allow_self_permission_edit',true);
    }
    public static function can_edit_permissions_of($target_user_id,$actor_user_id=null){
        $actor_user_id=$actor_user_id?:get_current_user_id();
        $target_user_id=absint($target_user_id);
        if(user_can($actor_user_id,'manage_options'))return true;
        if($target_user_id===$actor_user_id)return self::self_permission_edit_enabled($actor_user_id);
        return self::can_permission('team.permissions',$actor_user_id)&&self::user_in_scope('team.permissions',$target_user_id,$actor_user_id);
    }
    public static function can($module,$user_id=null){
        $view=isset(self::$permissions[$module]['view'])?$module.'.view':($module==='ai'?'ai.use':$module.'.view');
        return self::can_permission($view,$user_id);
    }
    public static function require_module($module){if(!self::can($module))wp_die('Você não possui permissão para acessar este módulo do VisionForge OS.');}
    public static function require_permission($permission){if(!self::can_permission($permission))wp_die('Você não possui permissão para executar esta ação.');}
    public static function action_permission($action){
        $map=[
            'vfos_save_settings'=>'settings.edit',
            'vfos_save_company_info'=>'company.edit',
            'vfos_save_client'=>'clients.edit','vfos_delete_client'=>'clients.delete','vfos_save_client_note'=>'clients.notes','vfos_upload_client_file'=>'clients.files','vfos_delete_client_file'=>'clients.files',
            'vfos_save_service'=>'services.edit',
            'vfos_save_project'=>'projects.edit','vfos_delete_project'=>'projects.delete','vfos_save_project_template'=>'projects.edit','vfos_delete_project_template'=>'projects.edit','vfos_apply_project_template'=>'projects.edit',
            'vfos_save_project_comment'=>'projects.comments','vfos_upload_project_file'=>'projects.files','vfos_delete_project_file'=>'projects.files','vfos_save_project_stage'=>'projects.stages','vfos_delete_project_stage'=>'projects.stages','vfos_save_project_approval'=>'projects.approvals','vfos_delete_project_approval'=>'projects.approvals','vfos_toggle_project_approval_release'=>'projects.approvals',
            'vfos_save_project_presentation'=>'projects.presentation','vfos_project_presentation_pdf'=>'projects.presentation','vfos_send_project_presentation'=>'projects.presentation',
            'vfos_save_task'=>'tasks.edit','vfos_delete_task'=>'tasks.delete','vfos_add_checklist_item'=>'tasks.checklist','vfos_toggle_checklist_item'=>'tasks.checklist','vfos_delete_checklist_item'=>'tasks.checklist',
            'vfos_save_financial'=>'financial.edit','vfos_add_financial_payment'=>'financial.payments','vfos_delete_financial_payment'=>'financial.payments','vfos_save_financial_split'=>'financial.split',
            'vfos_save_quote'=>'quotes.edit','vfos_delete_quote'=>'quotes.delete','vfos_send_quote'=>'quotes.send','vfos_quote_to_contract'=>'quotes.convert','vfos_save_quote_template'=>'quotes.templates','vfos_update_quote_template'=>'quotes.templates','vfos_delete_quote_template'=>'quotes.templates',
            'vfos_save_contract'=>'contracts.edit','vfos_delete_contract'=>'contracts.delete','vfos_send_sign'=>'contracts.sign_create','vfos_sign_sync'=>'contracts.sign_sync','vfos_sign_invite'=>'contracts.sign_invite','vfos_contract_pdf'=>'contracts.pdf','vfos_save_contract_template'=>'contracts.templates','vfos_delete_contract_template'=>'contracts.templates',
            'vfos_save_lead'=>'crm.edit','vfos_delete_lead'=>'crm.delete','vfos_lead_stage'=>'crm.stage','vfos_convert_lead'=>'crm.convert',
            'vfos_save_calendar_event'=>'calendar.edit','vfos_delete_calendar_event'=>'calendar.delete',
            'vfos_send_notification'=>'notifications.send',
            'vfos_delete_sent_notification'=>'notifications.delete_sent',
            'vfos_save_team_member'=>'team.edit','vfos_delete_team_member'=>'team.delete',
            'vfos_save_team_group'=>'team.groups','vfos_delete_team_group'=>'team.groups','vfos_save_group_members'=>'team.group_members',
        ];
        return $map[$action]??'dashboard.view';
    }
    public static function action_module($action){
        $p=self::action_permission($action);return explode('.',$p,2)[0];
    }
    public static function sync_external_caps($user_id){
        $u=new WP_User(absint($user_id));if(!$u->exists())return;
        if(self::can_permission('sign.view',$user_id))$u->add_cap('manage_vf_sign');else if(!$u->has_cap('manage_options'))$u->remove_cap('manage_vf_sign');
    }
    public static function limited_to_assigned($user_id=null){
        $user_id=$user_id?:get_current_user_id();if(user_can($user_id,'manage_options'))return false;
        $p=self::profile($user_id);return $p&&$p->status==='active'&&$p->role_key==='production'&&empty($p->custom_permissions);
    }
    public static function groups($active_only=true){
        global $wpdb;$t=VFOS_DB::table('team_groups');$where=$active_only?" WHERE status='active'":'';return $wpdb->get_results("SELECT * FROM $t".$where." ORDER BY name");
    }
    public static function user_groups($user_id){
        global $wpdb;$user_id=absint($user_id);if(!$user_id)return [];
        return array_map('absint',$wpdb->get_col($wpdb->prepare("SELECT group_id FROM ".VFOS_DB::table('team_group_members')." WHERE user_id=%d",$user_id)));
    }
    public static function group_members($group_id){
        global $wpdb;$group_id=absint($group_id);if(!$group_id)return [];
        return array_map('absint',$wpdb->get_col($wpdb->prepare("SELECT user_id FROM ".VFOS_DB::table('team_group_members')." WHERE group_id=%d",$group_id)));
    }
    public static function permission_scope_groups($permission,$user_id=null){
        global $wpdb;$user_id=$user_id?:get_current_user_id();if(user_can($user_id,'manage_options'))return [];
        return array_map('absint',$wpdb->get_col($wpdb->prepare("SELECT group_id FROM ".VFOS_DB::table('permission_scopes')." WHERE user_id=%d AND permission_key=%s",$user_id,sanitize_text_field($permission))));
    }
    public static function permission_is_scoped($permission,$user_id=null){
        return count(self::permission_scope_groups($permission,$user_id))>0;
    }
    public static function user_in_scope($permission,$target_user_id,$user_id=null){
        $user_id=$user_id?:get_current_user_id();if(user_can($user_id,'manage_options'))return true;
        if(!self::can_permission($permission,$user_id))return false;
        $scope=self::permission_scope_groups($permission,$user_id);if(!$scope)return true;
        return (bool)array_intersect($scope,self::user_groups($target_user_id));
    }
    public static function allowed_scope_groups($permission,$user_id=null){
        $user_id=$user_id?:get_current_user_id();if(!self::can_permission($permission,$user_id))return [];
        $scope=self::permission_scope_groups($permission,$user_id);
        if($scope)return $scope;
        return array_map(fn($g)=>(int)$g->id,self::groups(true));
    }
    public static function can_target_group($permission,$group_id,$user_id=null){
        $user_id=$user_id?:get_current_user_id();if(user_can($user_id,'manage_options'))return true;
        if(!self::can_permission($permission,$user_id))return false;
        $scope=self::permission_scope_groups($permission,$user_id);if(!$scope)return true;
        return in_array(absint($group_id),$scope,true);
    }
    public static function sync_permission_scopes($user_id,$scopes){
        global $wpdb;$user_id=absint($user_id);$t=VFOS_DB::table('permission_scopes');$wpdb->delete($t,['user_id'=>$user_id]);
        $valid_groups=array_map(fn($g)=>(int)$g->id,self::groups(false));$valid_permissions=self::all_permission_keys();$now=current_time('mysql');
        foreach((array)$scopes as $permission=>$groups){
            $permission=sanitize_text_field($permission);if(!in_array($permission,$valid_permissions,true))continue;
            foreach(array_unique(array_map('absint',(array)$groups)) as $gid){
                if(!$gid||!in_array($gid,$valid_groups,true))continue;
                $wpdb->insert($t,['user_id'=>$user_id,'permission_key'=>$permission,'group_id'=>$gid,'created_at'=>$now]);
            }
        }
    }
    public static function sync_user_groups($user_id,$groups){
        global $wpdb;$user_id=absint($user_id);$t=VFOS_DB::table('team_group_members');$wpdb->delete($t,['user_id'=>$user_id]);$now=current_time('mysql');
        $valid=array_map(fn($g)=>(int)$g->id,self::groups(false));
        foreach(array_unique(array_map('absint',(array)$groups)) as $gid){if($gid&&in_array($gid,$valid,true))$wpdb->insert($t,['group_id'=>$gid,'user_id'=>$user_id,'created_at'=>$now]);}
    }
    public static function workload($from=null,$to=null){
        global $wpdb;$from=$from?:date('Y-m-01');$to=$to?:date('Y-m-t');$team=VFOS_DB::table('team');$tasks=VFOS_DB::table('tasks');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT tm.*,u.display_name,u.user_email,COUNT(t.id) total_tasks,
             SUM(CASE WHEN t.status='done' THEN 1 ELSE 0 END) done_tasks,
             SUM(CASE WHEN t.status NOT IN ('done','cancelled') THEN 1 ELSE 0 END) open_tasks,
             SUM(CASE WHEN t.status NOT IN ('done','cancelled') AND t.due_date<CURDATE() THEN 1 ELSE 0 END) overdue_tasks
             FROM $team tm JOIN {$wpdb->users} u ON u.ID=tm.user_id
             LEFT JOIN $tasks t ON t.assigned_user_id=tm.user_id AND (t.due_date IS NULL OR t.due_date BETWEEN %s AND %s)
             WHERE tm.status='active' GROUP BY tm.id,u.display_name,u.user_email ORDER BY open_tasks DESC,u.display_name ASC",$from,$to
        ));
    }
}
