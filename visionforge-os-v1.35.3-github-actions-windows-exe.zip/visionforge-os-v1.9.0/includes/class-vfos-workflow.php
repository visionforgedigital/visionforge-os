<?php
if(!defined('ABSPATH'))exit;

class VFOS_Workflow{
    public static function init(){
        add_action('admin_post_vfos_flow_lead_quote',[__CLASS__,'action_lead_quote']);
        add_action('admin_post_vfos_flow_quote_contract',[__CLASS__,'action_quote_contract']);
        add_action('admin_post_vfos_flow_quote_project',[__CLASS__,'action_quote_project']);
        add_action('admin_post_vfos_flow_quote_financial',[__CLASS__,'action_quote_financial']);
        add_action('admin_post_vfos_flow_contract_project',[__CLASS__,'action_contract_project']);
        add_action('admin_post_vfos_flow_contract_financial',[__CLASS__,'action_contract_financial']);
        add_action('admin_post_vfos_flow_project_financial',[__CLASS__,'action_project_financial']);
    }

    private static function now(){return current_time('mysql');}
    public static function lead_to_quote($lead_id){
        global $wpdb;$lt=VFOS_DB::table('leads');$lead=$wpdb->get_row($wpdb->prepare("SELECT * FROM $lt WHERE id=%d",$lead_id));
        if(!$lead)return new WP_Error('lead_missing','Lead não encontrado.');
        if($lead->converted_quote_id)return (int)$lead->converted_quote_id;
        $client_id=(int)$lead->converted_client_id;$now=self::now();
        if(!$client_id){
            $wpdb->insert(VFOS_DB::table('clients'),['name'=>$lead->name,'company'=>$lead->company,'email'=>$lead->email,'phone'=>$lead->phone,'status'=>'active','notes'=>'Criado a partir do lead #'.$lead->id.($lead->notes?"\n\n".$lead->notes:''),'created_at'=>$now,'updated_at'=>$now]);
            $client_id=(int)$wpdb->insert_id;
            if(!$client_id)return new WP_Error('client_create',$wpdb->last_error?:'Não foi possível criar o cliente.');
            $wpdb->update($lt,['converted_client_id'=>$client_id,'updated_at'=>$now],['id'=>$lead_id]);
        }
        $wpdb->insert(VFOS_DB::table('quotes'),[
            'client_id'=>$client_id,'lead_id'=>$lead->id,'number'=>VFOS_DB::next_number('quote'),
            'title'=>$lead->service_interest?:'Proposta comercial','description'=>'Proposta criada a partir do lead '.$lead->name.'.',
            'subtotal'=>(float)$lead->estimated_value,'total'=>(float)$lead->estimated_value,'payment_terms'=>'','status'=>'draft',
            'flow_create_contract'=>1,'flow_create_project'=>1,'flow_create_financial'=>1,'public_token'=>wp_generate_password(40,false,false),
            'created_at'=>$now,'updated_at'=>$now
        ]);
        $qid=(int)$wpdb->insert_id;if(!$qid)return new WP_Error('quote_create',$wpdb->last_error?:'Não foi possível criar o orçamento.');
        $wpdb->update($lt,['converted_quote_id'=>$qid,'stage'=>'proposal','updated_at'=>$now],['id'=>$lead_id]);
        VFOS_DB::log('workflow_lead_quote','lead',$lead_id,'Lead → Orçamento #'.$qid,null,['quote_id'=>$qid],$lead->name);
        return $qid;
    }

    public static function quote_to_contract($quote_id){
        global $wpdb;$qt=VFOS_DB::table('quotes');$q=$wpdb->get_row($wpdb->prepare("SELECT * FROM $qt WHERE id=%d",$quote_id));if(!$q)return new WP_Error('quote_missing','Orçamento não encontrado.');
        if($q->converted_contract_id)return (int)$q->converted_contract_id;$now=self::now();
        $wpdb->insert(VFOS_DB::table('contracts'),[
            'client_id'=>$q->client_id,'quote_id'=>$q->id,'project_id'=>(int)$q->converted_project_id,
            'number'=>VFOS_DB::next_number('contract'),'title'=>'Contrato - '.$q->title,'content'=>'','value'=>$q->total,'status'=>'draft',
            'created_at'=>$now,'updated_at'=>$now
        ]);
        $id=(int)$wpdb->insert_id;if(!$id)return new WP_Error('contract_create',$wpdb->last_error?:'Não foi possível criar o contrato.');
        $wpdb->update($qt,['converted_contract_id'=>$id,'updated_at'=>$now],['id'=>$quote_id]);
        VFOS_DB::log('workflow_quote_contract','quote',$quote_id,'Orçamento → Contrato #'.$id,null,['contract_id'=>$id],$q->title);return $id;
    }

    public static function quote_to_project($quote_id){
        global $wpdb;$qt=VFOS_DB::table('quotes');$q=$wpdb->get_row($wpdb->prepare("SELECT * FROM $qt WHERE id=%d",$quote_id));if(!$q)return new WP_Error('quote_missing','Orçamento não encontrado.');
        if($q->converted_project_id)return (int)$q->converted_project_id;
        $items=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quote_items')." WHERE quote_id=%d ORDER BY sort_order,id",$quote_id));
        $service=0;foreach($items as $i)if($i->service_id){$service=(int)$i->service_id;break;}$now=self::now();
        $wpdb->insert(VFOS_DB::table('projects'),[
            'client_id'=>$q->client_id,'service_id'=>$service,'name'=>$q->title,'status'=>'planning','priority'=>'normal','value'=>$q->total,'progress'=>0,
            'notes'=>'Criado a partir do orçamento '.$q->number.'.','source_type'=>'quote','source_id'=>$q->id,'created_at'=>$now,'updated_at'=>$now
        ]);
        $id=(int)$wpdb->insert_id;if(!$id)return new WP_Error('project_create',$wpdb->last_error?:'Não foi possível criar o projeto.');
        $wpdb->update($qt,['converted_project_id'=>$id,'updated_at'=>$now],['id'=>$quote_id]);
        if($q->converted_contract_id)$wpdb->update(VFOS_DB::table('contracts'),['project_id'=>$id,'updated_at'=>$now],['id'=>$q->converted_contract_id]);
        VFOS_DB::log('workflow_quote_project','quote',$quote_id,'Orçamento → Projeto #'.$id,null,['project_id'=>$id],$q->title);return $id;
    }

    public static function quote_to_financial($quote_id){
        global $wpdb;$qt=VFOS_DB::table('quotes');$q=$wpdb->get_row($wpdb->prepare("SELECT * FROM $qt WHERE id=%d",$quote_id));if(!$q)return new WP_Error('quote_missing','Orçamento não encontrado.');
        if($q->converted_financial_id)return (int)$q->converted_financial_id;$project=(int)$q->converted_project_id;$now=self::now();
        $wpdb->insert(VFOS_DB::table('financial'),[
            'client_id'=>$q->client_id,'project_id'=>$project,'type'=>'income','description'=>$q->number.' - '.$q->title,
            'amount'=>$q->total,'paid_amount'=>0,'status'=>'pending','source_type'=>'quote','source_id'=>$q->id,'created_at'=>$now,'updated_at'=>$now
        ]);
        $id=(int)$wpdb->insert_id;if(!$id)return new WP_Error('financial_create',$wpdb->last_error?:'Não foi possível criar a cobrança.');
        $wpdb->update($qt,['converted_financial_id'=>$id,'updated_at'=>$now],['id'=>$quote_id]);
        VFOS_DB::log('workflow_quote_financial','quote',$quote_id,'Orçamento → Financeiro #'.$id,null,['financial_id'=>$id],$q->title);return $id;
    }

    public static function contract_to_project($contract_id){
        global $wpdb;$ct=VFOS_DB::table('contracts');$c=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ct WHERE id=%d",$contract_id));if(!$c)return new WP_Error('contract_missing','Contrato não encontrado.');
        if($c->project_id)return (int)$c->project_id;$now=self::now();
        $wpdb->insert(VFOS_DB::table('projects'),[
            'client_id'=>$c->client_id,'name'=>preg_replace('/^Contrato\s*-\s*/i','',$c->title),'status'=>'planning','priority'=>'normal','value'=>$c->value,'progress'=>0,
            'notes'=>'Criado a partir do contrato '.$c->number.'.','source_type'=>'contract','source_id'=>$c->id,'created_at'=>$now,'updated_at'=>$now
        ]);
        $id=(int)$wpdb->insert_id;if(!$id)return new WP_Error('project_create',$wpdb->last_error?:'Não foi possível criar o projeto.');
        $wpdb->update($ct,['project_id'=>$id,'updated_at'=>$now],['id'=>$contract_id]);
        VFOS_DB::log('workflow_contract_project','contract',$contract_id,'Contrato → Projeto #'.$id,null,['project_id'=>$id],$c->title);return $id;
    }

    public static function contract_to_financial($contract_id){
        global $wpdb;$ct=VFOS_DB::table('contracts');$c=$wpdb->get_row($wpdb->prepare("SELECT * FROM $ct WHERE id=%d",$contract_id));if(!$c)return new WP_Error('contract_missing','Contrato não encontrado.');
        if($c->converted_financial_id)return (int)$c->converted_financial_id;$now=self::now();
        $wpdb->insert(VFOS_DB::table('financial'),[
            'client_id'=>$c->client_id,'project_id'=>$c->project_id,'type'=>'income','description'=>$c->number.' - '.$c->title,'amount'=>$c->value,'paid_amount'=>0,
            'status'=>'pending','source_type'=>'contract','source_id'=>$c->id,'created_at'=>$now,'updated_at'=>$now
        ]);
        $id=(int)$wpdb->insert_id;if(!$id)return new WP_Error('financial_create',$wpdb->last_error?:'Não foi possível criar a cobrança.');
        $wpdb->update($ct,['converted_financial_id'=>$id,'updated_at'=>$now],['id'=>$contract_id]);
        VFOS_DB::log('workflow_contract_financial','contract',$contract_id,'Contrato → Financeiro #'.$id,null,['financial_id'=>$id],$c->title);return $id;
    }

    public static function project_to_financial($project_id){
        global $wpdb;$pt=VFOS_DB::table('projects');$p=$wpdb->get_row($wpdb->prepare("SELECT * FROM $pt WHERE id=%d",$project_id));if(!$p)return new WP_Error('project_missing','Projeto não encontrado.');
        if($p->converted_financial_id)return (int)$p->converted_financial_id;$now=self::now();
        $wpdb->insert(VFOS_DB::table('financial'),[
            'client_id'=>$p->client_id,'project_id'=>$p->id,'type'=>'income','description'=>'Projeto - '.$p->name,'amount'=>$p->value,'paid_amount'=>0,'status'=>'pending',
            'source_type'=>'project','source_id'=>$p->id,'created_at'=>$now,'updated_at'=>$now
        ]);
        $id=(int)$wpdb->insert_id;if(!$id)return new WP_Error('financial_create',$wpdb->last_error?:'Não foi possível criar a cobrança.');
        $wpdb->update($pt,['converted_financial_id'=>$id,'updated_at'=>$now],['id'=>$project_id]);
        VFOS_DB::log('workflow_project_financial','project',$project_id,'Projeto → Financeiro #'.$id,null,['financial_id'=>$id],$p->name);return $id;
    }

    public static function process_quote_acceptance($quote_id){
        global $wpdb;$q=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".VFOS_DB::table('quotes')." WHERE id=%d",$quote_id));if(!$q)return false;
        $out=[];
        if(!empty($q->flow_create_project))$out['project_id']=self::quote_to_project($quote_id);
        if(!empty($q->flow_create_contract))$out['contract_id']=self::quote_to_contract($quote_id);
        if(!empty($q->flow_create_financial))$out['financial_id']=self::quote_to_financial($quote_id);
        return $out;
    }

    private static function redirect($url,$result){
        if(is_wp_error($result))$url=add_query_arg('vfos_msg',rawurlencode($result->get_error_message()),$url);
        wp_safe_redirect($url);exit;
    }
    public static function action_lead_quote(){check_admin_referer('vfos_flow_lead_quote');VFOS_Team::require_permission('quotes.create');$id=absint($_GET['id']??0);$r=self::lead_to_quote($id);self::redirect(is_wp_error($r)?admin_url('admin.php?page=vfos-leads'):admin_url('admin.php?page=vfos-quotes&edit='.$r),$r);}
    public static function action_quote_contract(){check_admin_referer('vfos_flow_quote_contract');VFOS_Team::require_permission('contracts.create');$id=absint($_GET['id']??0);$r=self::quote_to_contract($id);self::redirect(is_wp_error($r)?admin_url('admin.php?page=vfos-quotes'):admin_url('admin.php?page=vfos-contracts&edit='.$r),$r);}
    public static function action_quote_project(){check_admin_referer('vfos_flow_quote_project');VFOS_Team::require_permission('projects.create');$id=absint($_GET['id']??0);$r=self::quote_to_project($id);self::redirect(is_wp_error($r)?admin_url('admin.php?page=vfos-quotes'):admin_url('admin.php?page=vfos-project-view&id='.$r),$r);}
    public static function action_quote_financial(){check_admin_referer('vfos_flow_quote_financial');VFOS_Team::require_permission('financial.create');$id=absint($_GET['id']??0);$r=self::quote_to_financial($id);self::redirect(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.(is_wp_error($r)?0:$r)),$r);}
    public static function action_contract_project(){check_admin_referer('vfos_flow_contract_project');VFOS_Team::require_permission('projects.create');$id=absint($_GET['id']??0);$r=self::contract_to_project($id);self::redirect(is_wp_error($r)?admin_url('admin.php?page=vfos-contracts'):admin_url('admin.php?page=vfos-project-view&id='.$r),$r);}
    public static function action_contract_financial(){check_admin_referer('vfos_flow_contract_financial');VFOS_Team::require_permission('financial.create');$id=absint($_GET['id']??0);$r=self::contract_to_financial($id);self::redirect(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.(is_wp_error($r)?0:$r)),$r);}
    public static function action_project_financial(){check_admin_referer('vfos_flow_project_financial');VFOS_Team::require_permission('financial.create');$id=absint($_GET['id']??0);$r=self::project_to_financial($id);self::redirect(admin_url('admin.php?page=vfos-financial&tab=charges&financial_id='.(is_wp_error($r)?0:$r)),$r);}
}
