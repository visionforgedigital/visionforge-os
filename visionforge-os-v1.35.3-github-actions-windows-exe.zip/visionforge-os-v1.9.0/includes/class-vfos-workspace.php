<?php
if (!defined('ABSPATH')) exit;

class VFOS_Workspace {
    public static function init(){
        add_filter('login_redirect',[__CLASS__,'login_redirect'],20,3);
        add_action('admin_init',[__CLASS__,'protect_admin'],1);
        add_action('admin_menu',[__CLASS__,'clean_menu'],9999);
        add_action('admin_bar_menu',[__CLASS__,'clean_admin_bar'],9999);
        add_action('admin_head',[__CLASS__,'admin_head'],9999);
        add_action('admin_footer_text',[__CLASS__,'footer_text'],9999);
        add_filter('update_footer',[__CLASS__,'footer_version'],9999);
        add_filter('admin_title',[__CLASS__,'admin_title'],9999,2);
        add_filter('screen_options_show_screen',[__CLASS__,'hide_screen_options'],20,2);
        add_filter('help_tabs',[__CLASS__,'hide_help_tabs'],20);
        add_action('wp_dashboard_setup',[__CLASS__,'remove_dashboard_widgets'],9999);
    }

    public static function is_team_user($user_id=0){
        $user_id=$user_id?:get_current_user_id();
        if(!$user_id || user_can($user_id,'manage_options')) return false;
        return user_can($user_id,'vfos_access');
    }

    public static function login_redirect($redirect_to,$requested,$user){
        if($user instanceof WP_User && self::is_team_user($user->ID)){
            return admin_url('admin.php?page=vfos');
        }
        return $redirect_to;
    }

    private static function allowed_admin_request(){
        global $pagenow;
        if(in_array($pagenow,['admin-ajax.php','admin-post.php','async-upload.php'],true)) return true;
        if($pagenow==='profile.php') return false;
        if($pagenow==='admin.php'){
            $page=sanitize_key($_GET['page']??'');
            if($page==='vfos' || strpos($page,'vfos-')===0) return true;
            if(strpos($page,'vfs-')===0 && class_exists('VFOS_Team') && VFOS_Team::can_permission('sign.view')) return true;
        }
        return false;
    }

    public static function protect_admin(){
        if(!self::is_team_user()) return;

        // Remove generic WordPress/plugin notices for team users.
        remove_all_actions('admin_notices');
        remove_all_actions('all_admin_notices');
        remove_all_actions('network_admin_notices');
        remove_all_actions('user_admin_notices');

        global $pagenow;
        if(in_array($pagenow,['admin-ajax.php','admin-post.php','async-upload.php'],true)) return;

        // wp-admin root, profile, plugin screens, settings, etc. always return to VFOS.
        if(!self::allowed_admin_request()){
            wp_safe_redirect(admin_url('admin.php?page=vfos'));
            exit;
        }
    }

    public static function clean_menu(){
        if(!self::is_team_user()) return;
        global $menu,$submenu;

        $allowed_top=['vfos'];
        if(class_exists('VFOS_Team') && VFOS_Team::can_permission('sign.view')) $allowed_top[]='vfs-sign';

        foreach((array)$menu as $key=>$item){
            $slug=$item[2]??'';
            if(!in_array($slug,$allowed_top,true)) unset($menu[$key]);
        }

        // Keep only VFOS children the current user can actually access.
        if(isset($submenu['vfos'])){
            foreach($submenu['vfos'] as $key=>$item){
                $slug=$item[2]??'';
                if($slug==='vfos') continue;
                if(strpos($slug,'vfos-')!==0) unset($submenu['vfos'][$key]);
            }
        }
    }

    public static function clean_admin_bar($bar){
        if(!self::is_team_user()) return;
        foreach(['wp-logo','about','wporg','documentation','support-forums','feedback','site-name','view-site','updates','comments','new-content','new-post','new-media','new-page','customize','search'] as $id){
            $bar->remove_node($id);
        }
        $bar->add_node([
            'id'=>'vfos-home',
            'title'=>'VisionForge OS',
            'href'=>admin_url('admin.php?page=vfos'),
            'meta'=>['class'=>'vfos-adminbar-home']
        ]);
        if(class_exists('VFOS_Notifications') && class_exists('VFOS_Team') && VFOS_Team::can('notifications')){
            $count=VFOS_Notifications::unread_count();
            $bar->add_node([
                'id'=>'vfos-notifications',
                'title'=>'Notificações'.($count?' <span class="vfos-ab-count">'.$count.'</span>':''),
                'href'=>admin_url('admin.php?page=vfos-notifications')
            ]);
        }
    }

    public static function admin_head(){
        if(!self::is_team_user()) return;
        echo '<style>
        #wpfooter{padding-left:20px}
        #wpadminbar #wp-admin-bar-vfos-home>.ab-item{font-weight:800!important}
        #wpadminbar .vfos-ab-count{display:inline-grid;place-items:center;min-width:17px;height:17px;padding:0 4px;margin-left:4px;border-radius:99px;background:#ff9800;color:#fff;font-size:9px;font-weight:900}
        .update-nag,.notice:not(.vfos-keep-notice),.error:not(.vfos-keep-notice),.updated:not(.vfos-keep-notice),#screen-meta-links{display:none!important}
        body.vfos-team-workspace #adminmenuwrap,body.vfos-team-workspace #adminmenuback{background:#102f44}
        body.vfos-team-workspace #adminmenu .wp-menu-name{font-weight:650}
        body.vfos-team-workspace #adminmenu .wp-has-current-submenu>a.wp-has-current-submenu,
        body.vfos-team-workspace #adminmenu a.current{background:#0798df}
        body.vfos-team-workspace #wpadminbar{background:#102f44}
        </style><script>document.addEventListener("DOMContentLoaded",function(){document.body.classList.add("vfos-team-workspace");});</script>';
    }

    public static function footer_text($text){
        if(self::is_team_user()) return 'VisionForge OS • Ambiente interno VisionForge Digital';
        return $text;
    }
    public static function footer_version($text){
        if(self::is_team_user()) return 'VisionForge OS v'.(defined('VFOS_VERSION')?VFOS_VERSION:'');
        return $text;
    }
    public static function admin_title($admin_title,$title){
        if(self::is_team_user()) return ($title?$title.' • ':'').'VisionForge OS';
        return $admin_title;
    }
    public static function hide_screen_options($show,$screen=null){
        return self::is_team_user()?false:$show;
    }
    public static function hide_help_tabs($tabs){
        return self::is_team_user()?[]:$tabs;
    }
    public static function remove_dashboard_widgets(){
        if(!self::is_team_user()) return;
        global $wp_meta_boxes;$wp_meta_boxes['dashboard']=[];
    }
}
