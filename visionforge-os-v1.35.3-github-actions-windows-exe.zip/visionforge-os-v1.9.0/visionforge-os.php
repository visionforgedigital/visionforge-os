<?php
/**
 * Plugin Name: VisionForge OS
 * Plugin URI: https://visionforgedigital.online
 * Description: Sistema de gestão da VisionForge Digital com CRM, projetos, tarefas, orçamentos, financeiro, contratos, VisionForge Sign e VisionForge AI.
 * Version: 1.34.9
 * Author: VisionForge Digital
 * Text Domain: visionforge-os
 */
if (!defined('ABSPATH')) exit;

define('VFOS_VERSION', '1.34.9');
define('VFOS_FILE', __FILE__);
define('VFOS_DIR', plugin_dir_path(__FILE__));
define('VFOS_URL', plugin_dir_url(__FILE__));

require_once VFOS_DIR . 'includes/class-vfos-db.php';
require_once VFOS_DIR . 'includes/class-vfos-pdf.php';
require_once VFOS_DIR . 'includes/class-vfos-project-presentation.php';
require_once VFOS_DIR . 'includes/class-vfos-sign.php';
require_once VFOS_DIR . 'includes/class-vfos-ai.php';
require_once VFOS_DIR . 'includes/class-vfos-team.php';
require_once VFOS_DIR . 'includes/class-vfos-workspace.php';
require_once VFOS_DIR . 'includes/class-vfos-notifications.php';
require_once VFOS_DIR . 'includes/class-vfos-admin.php';
require_once VFOS_DIR . 'includes/class-vfos-pwa.php';
require_once VFOS_DIR . 'includes/class-vfos-desktop-api.php';
require_once VFOS_DIR . 'includes/class-vfos-mercadopago.php';
require_once VFOS_DIR . 'includes/class-vfos-workflow.php';
require_once VFOS_DIR . 'includes/class-vfos-recurring.php';
require_once VFOS_DIR . 'includes/class-vfos-reports.php';
require_once VFOS_DIR . 'includes/class-vfos-automations.php';
require_once VFOS_DIR . 'includes/class-vfos-portal.php';
require_once VFOS_DIR . 'includes/class-vfos-approval-assets.php';
require_once VFOS_DIR . 'includes/class-vfos-proposal.php';
require_once VFOS_DIR . 'includes/class-vfos-portal-admin.php';

register_activation_hook(__FILE__, ['VFOS_DB', 'activate']);

add_action('admin_notices', function(){
    if(!current_user_can('activate_plugins')) return;
    if(!function_exists('get_plugins')) require_once ABSPATH.'wp-admin/includes/plugin.php';
    $current=plugin_basename(__FILE__);$dupes=[];
    foreach(get_plugins() as $basename=>$data){
        if($basename===$current) continue;
        if(($data['Name']??'')==='VisionForge OS') $dupes[]=$basename;
    }
    if($dupes){
        echo '<div class="notice notice-warning"><p><strong>VisionForge OS:</strong> foram encontradas cópias antigas do plugin: <code>'.esc_html(implode(', ',$dupes)).'</code>. A versão atual não apaga seus dados ao remover apenas os arquivos do plugin. Após confirmar que esta versão está funcionando, mantenha somente uma cópia ativa.</p></div>';
    }
});

add_action('plugins_loaded', function () {
    if (get_option('vfos_db_version') !== VFOS_VERSION) VFOS_DB::activate();
    VFOS_Team::init();
    VFOS_Workspace::init();
    VFOS_Notifications::init();
    VFOS_Sign::init();
    VFOS_Admin::instance();
    VFOS_PWA::init();
    VFOS_Desktop_API::init();
    VFOS_MercadoPago::init();
    VFOS_Workflow::init();
    VFOS_Recurring::init();
    VFOS_Automations::init();
    VFOS_Portal::init();
    VFOS_Approval_Assets::init();
    VFOS_Proposal::init();
    VFOS_Portal_Admin::init();
});

register_deactivation_hook(__FILE__, function(){
    $ts=wp_next_scheduled('vfos_daily_automations'); if($ts) wp_unschedule_event($ts,'vfos_daily_automations');
    $rt=wp_next_scheduled('vfos_recurring_daily'); if($rt) wp_unschedule_event($rt,'vfos_recurring_daily');
});
